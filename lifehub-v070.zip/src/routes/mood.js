const { Router } = require('../mini-http');
const { getDb } = require('../services/db');
const { requireAuth } = require('../middleware/auth');
const mood = require('../services/mood');
const logger = require('../services/logger');

const router = Router();
const MAX_CHAT_HISTORY = 200;

// ---------- 每日心情紀錄 ----------

router.get('/entries', requireAuth, (req, res) => {
  const db = getDb();
  const { from, to } = req.query;
  let rows;
  if (from && to) {
    rows = db
      .prepare('SELECT * FROM mood_entries WHERE user_id = ? AND entry_date BETWEEN ? AND ? ORDER BY entry_date ASC')
      .all(req.session.userId, from, to);
  } else {
    rows = db
      .prepare('SELECT * FROM mood_entries WHERE user_id = ? ORDER BY entry_date DESC LIMIT 60')
      .all(req.session.userId);
  }
  res.json(rows);
});

// 用日期當 key 做 upsert：同一天重複記錄會直接更新，而不是新增多筆。
router.put('/entries/:date', requireAuth, (req, res) => {
  const { date } = req.params;
  const { score, tags, note } = req.body || {};
  const scoreNum = Number(score);
  if (!date || !Number.isInteger(scoreNum) || scoreNum < 1 || scoreNum > 10) {
    return res.status(400).json({ error: '請提供有效的日期與 1-10 的心情分數' });
  }
  const db = getDb();
  const now = new Date().toISOString();
  const tagsStr = Array.isArray(tags) ? tags.join(',') : (tags || null);
  db.prepare(
    `INSERT INTO mood_entries (user_id, entry_date, score, tags, note, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?)
     ON CONFLICT(user_id, entry_date) DO UPDATE SET score = excluded.score, tags = excluded.tags, note = excluded.note, updated_at = excluded.updated_at`
  ).run(req.session.userId, date, scoreNum, tagsStr, note || null, now, now);
  res.json({ ok: true });
});

router.get('/summary', requireAuth, (req, res) => {
  const db = getDb();
  const { days } = req.query;
  const n = Math.min(Math.max(Number(days) || 30, 1), 180);
  const since = new Date();
  since.setDate(since.getDate() - n);
  const sinceStr = since.toISOString().slice(0, 10);

  const rows = db
    .prepare('SELECT entry_date, score, tags FROM mood_entries WHERE user_id = ? AND entry_date >= ? ORDER BY entry_date ASC')
    .all(req.session.userId, sinceStr);

  const avg = rows.length ? rows.reduce((s, r) => s + r.score, 0) / rows.length : null;
  const tagCounts = {};
  rows.forEach((r) => {
    (r.tags || '').split(',').filter(Boolean).forEach((t) => { tagCounts[t] = (tagCounts[t] || 0) + 1; });
  });
  const topTags = Object.entries(tagCounts).sort((a, b) => b[1] - a[1]).slice(0, 5).map(([tag, count]) => ({ tag, count }));

  res.json({ series: rows, average: avg != null ? Math.round(avg * 10) / 10 : null, topTags, count: rows.length });
});

// ---------- 情緒陪伴對話 (獨立於一般 AI 助理) ----------

router.get('/chat/history', requireAuth, (req, res) => {
  const db = getDb();
  const rows = db
    .prepare('SELECT role, content, created_at FROM mood_chat_messages WHERE user_id = ? ORDER BY id ASC LIMIT ?')
    .all(req.session.userId, MAX_CHAT_HISTORY);
  res.json(rows);
});

router.post('/chat', requireAuth, async (req, res) => {
  const { message } = req.body || {};
  if (!message || !String(message).trim()) {
    return res.status(400).json({ error: '請提供 message' });
  }
  const db = getDb();
  const now = new Date().toISOString();
  const crisisNow = mood.detectCrisisSignal(message);
  db.prepare('INSERT INTO mood_chat_messages (user_id, role, content, flagged, created_at) VALUES (?, ?, ?, ?, ?)').run(
    req.session.userId,
    'user',
    message,
    crisisNow ? 1 : 0,
    now
  );

  const history = db
    .prepare('SELECT role, content FROM mood_chat_messages WHERE user_id = ? ORDER BY id ASC LIMIT ?')
    .all(req.session.userId, MAX_CHAT_HISTORY);

  try {
    const result = await mood.chatMoodCompanion(history);
    db.prepare('INSERT INTO mood_chat_messages (user_id, role, content, flagged, created_at) VALUES (?, ?, ?, ?, ?)').run(
      req.session.userId,
      'assistant',
      result.reply,
      result.crisisDetected ? 1 : 0,
      new Date().toISOString()
    );
    res.json(result);
  } catch (e) {
    logger.error('心情陪伴對話失敗', { error: e.message });
    res.status(502).json({ error: 'AI 陪伴暫時無法回應，請稍後再試', detail: e.message });
  }
});

router.delete('/chat/history', requireAuth, (req, res) => {
  const db = getDb();
  db.prepare('DELETE FROM mood_chat_messages WHERE user_id = ?').run(req.session.userId);
  res.json({ ok: true });
});

module.exports = router;
