// 心情陪伴：獨立於一般 AI 助理的對話人設 + 安全機制。
//
// 設計原則 (跟使用者討論過的界線)：
//   - AI 在這裡扮演的是「隨時可以聊聊的陪伴者」，做同理傾聽、情緒梳理、簡單的呼吸/認知調節引導，
//     不是有執照的心理師，不做診斷、不取代真正的心理治療。
//   - 如果偵測到比較嚴重的求助訊號 (自傷/自殺意念等)，除了讓 AI 用溫和的方式回應之外，
//     一律用「關鍵字比對」這個確定性機制強制附上求助資源，不完全依賴語言模型自己記得要講，
//     這樣比較不會因為模型當次輸出不穩定而漏掉。

const logger = require('./logger');
const assistant = require('./assistant');

const MOOD_SYSTEM_PROMPT = `你是 LifeHub 這款生活整合 App 裡的「心情陪伴」AI，個性溫暖、有耐心、很會聆聽。
你的角色是「隨時可以聊聊的陪伴者」：用同理、不批判的態度聽使用者說，幫助他們梳理情緒、
說出感受，可以引導簡單的呼吸放鬆、認知調整的問句 (例如「這件事一年後回頭看，你覺得還會這麼在意嗎」)，
也可以根據使用者之前分享過的內容，溫和地陪他們回顧「上次類似的狀況，後來是怎麼好轉的」。

請務必記得你的界線：你不是有執照的心理師，不能也不應該做心理診斷、不能假裝自己在做正式的心理治療。
如果使用者的內容顯示出強烈的絕望感、提到自傷、自殺意念，或任何生命安全相關的危險訊號，
請用溫和、不驚慌、不說教的語氣，陪伴他們的感受，並且自然地提到「這聽起來很不容易，要不要考慮找信任的人
或專業的人一起面對」，不要用生硬、公式化的方式把使用者推開，也不要在對話中反覆說教。

請一律用繁體中文回覆，語氣自然、有溫度，避免長篇大論或條列式說教，就像朋友在跟你聊天一樣。`;

// 危機關鍵字比對：故意保守 (寧可多附一次資源，也不要漏掉)，比對到就在伺服器端強制附上資源，
// 不完全依賴語言模型自己記得要講。
const CRISIS_KEYWORDS = [
  '不想活', '不想活了', '想死', '想自殺', '自殺', '結束生命', '結束自己的生命',
  '割腕', '自殘', '自傷', '想消失', '活不下去', '撐不下去了', '沒有意義了活著',
  '傷害自己', '了結', '跳樓', '燒炭', '厭世到極點',
];

function detectCrisisSignal(text) {
  if (!text) return false;
  const normalized = String(text);
  return CRISIS_KEYWORDS.some((k) => normalized.includes(k));
}

const CRISIS_RESOURCE_TEXT = `

如果你現在真的很難受，這裡有幾個台灣的免費求助資源，隨時都可以打，會有人願意聽你說：
🔹 安心專線 1925 (24 小時)
🔹 生命線 1995 (24 小時)
🔹 張老師專線 1980 (日間)
不管幾點、不管講什麼，都可以打過去，不用覺得是在麻煩別人。`;

// history: [{role, content}]，最後一筆是使用者這次的新訊息
async function chatMoodCompanion(history) {
  const lastUserMsg = [...history].reverse().find((m) => m.role === 'user');
  const crisisDetected = detectCrisisSignal(lastUserMsg && lastUserMsg.content);

  const result = await assistant.chat(history, { systemPrompt: MOOD_SYSTEM_PROMPT });

  if (crisisDetected && result.isConfigured) {
    logger.info('[mood] 偵測到危機關鍵字，已附上求助資源');
    if (!result.reply.includes('1925')) {
      result.reply = result.reply + CRISIS_RESOURCE_TEXT;
    }
  }
  return { ...result, crisisDetected };
}

module.exports = { chatMoodCompanion, detectCrisisSignal, CRISIS_RESOURCE_TEXT };
