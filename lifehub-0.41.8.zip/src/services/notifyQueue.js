// 推播的「靜音時段」+「短時間內合併成一則」共用邏輯。
//
// 背景：三支獨立的排程 (一般提醒/精準待辦提醒/服藥提醒，見 routes/push.js) 原本各自算好
// 內容就直接對每個訂閱裝置送出，彼此互不知道對方的存在。使用者實際使用時的抱怨是「連續跳出
// 好幾則通知，很有轟炸感」——例如同一分鐘內剛好待辦提醒跟服藥提醒都到期，就會连續跳兩則。
// 這支檔案提供一個所有推播來源都要經過的共用出口 queueNotification()，做兩件事：
//
//   1. 靜音時段 (晚上 11 點到早上 10 點) 不推「非緊急」通知——使用者自己沒有指定精準時間的
//      被動提醒 (帳單快到期/待辦逾期/好幾天沒記心情/生日/另一半生理週期)，可以等隔天早上
//      再看，不用半夜跳出來吵醒人。「緊急」的例外：使用者自己明確設定精準時間的待辦提醒、
//      跟服藥提醒——這兩種是使用者主動排定要在那個時間點被提醒，硬生生延後或跳過反而違背
//      使用者原本的意思 (例如吃藥時間就是設在半夜)，所以不受靜音時段限制。
//   2. 合併：同一個使用者短時間內 (90 秒) 累積到的多筆通知，不會各自立刻送出，而是等 90 秒
//      的收集窗結束後，一次送出「一則」通知 (多筆時標題變成「X 則新提醒」、內文列出每一則)。
//      這個機制對「緊急」通知一樣適用——兩顆藥剛好同一分鐘該吃，也應該合併成一則，而不是
//      連續跳兩次，跳兩次一樣有轟炸感，緊急只是「不受靜音時段限制」，跟「要不要合併」是
//      兩件不同的事。
//
// 三支排程只需要把「直接迴圈訂閱裝置送出」改成呼叫 queueNotification()，其餘 (加密、簽章、
// 失效訂閱清除) 都還是 webpush.js 負責，這裡只管「什麼時候送、送幾則」。

const logger = require('./logger');
const { sendNotification } = require('./webpush');

const BUNDLE_WINDOW_MS = 90 * 1000; // 90 秒內的通知合併成一則，短到不會讓使用者等太久才看到，長到足夠吸收同一批排程觸發的多筆提醒
const QUIET_HOURS_START = 23; // 晚上 11 點
const QUIET_HOURS_END = 10; // 早上 10 點 (不含，10:00 開始正常推播)

const pending = new Map(); // userId -> { items: [{title, body, icon}], timer }

function isQuietHoursNow(date = new Date()) {
  const h = date.getHours();
  // 跨午夜的區間 (23 點到隔天 10 點)：小時 >= 23 或 < 10 都算在靜音時段內
  return h >= QUIET_HOURS_START || h < QUIET_HOURS_END;
}

async function flushUser(db, userId) {
  const entry = pending.get(userId);
  if (!entry) return;
  pending.delete(userId);
  const items = entry.items;
  if (!items.length) return;

  let title, body, icon;
  if (items.length === 1) {
    ({ title, body, icon } = items[0]);
  } else {
    // 合併成一則：標題講清楚「有幾件事」，內文把每一則的標題跟內容各列一行 (最多列 5 則，
    // 避免通知內容過長被系統截斷)，圖示沿用第一則的 (同一個使用者這段時間內圖示通常一樣)。
    title = `${items.length} 則新提醒`;
    body = items.slice(0, 5).map((i) => `${i.title}：${i.body}`).join('\n');
    icon = items[0].icon;
  }

  const subs = db.prepare('SELECT * FROM push_subscriptions WHERE user_id = ?').all(userId);
  for (const sub of subs) {
    try {
      const result = await sendNotification(db, sub, { title, body, icon });
      if (!result.ok && (result.status === 404 || result.status === 410)) {
        db.prepare('DELETE FROM push_subscriptions WHERE id = ?').run(sub.id);
      }
    } catch (e) {
      logger.error('[push] 合併推播送出失敗', { userId, message: e.message });
    }
  }
}

// opts.urgent = true：跳過靜音時段判斷 (服藥提醒/使用者自訂精準待辦提醒用這個)。
// 其餘一律視為「非緊急」，靜音時段內直接跳過、不進佇列 (使用者隔天打開 App 首頁一樣看得到
// 對應的洞察內容，只是不會半夜推播打擾)。
//
// 回傳值 (true = 已排入佇列/會送出, false = 靜音時段跳過) 給呼叫端判斷要不要更新自己的
// 「已推播過」紀錄——如果直接無條件標記成「送過了」，靜音時段結束後同樣的提醒內容會被
// 誤判成「24小時內推播過」而永遠不會真的送出，這裡讓呼叫端只在真的排入佇列時才標記。
function queueNotification(db, userId, { title, body, icon, urgent = false }) {
  if (!urgent && isQuietHoursNow()) {
    logger.info('[push] 靜音時段 (23:00-10:00)，跳過非緊急通知', { userId, title });
    return false;
  }
  let entry = pending.get(userId);
  if (!entry) {
    entry = { items: [], timer: null };
    pending.set(userId, entry);
  }
  entry.items.push({ title, body, icon });
  if (entry.timer) clearTimeout(entry.timer);
  entry.timer = setTimeout(() => {
    flushUser(db, userId).catch((e) => logger.error('[push] 合併通知 flush 失敗', { userId, message: e.message }));
  }, BUNDLE_WINDOW_MS);
  entry.timer.unref(); // 不阻止 process 正常結束 (跟其他排程 timer 一致)
  return true;
}

module.exports = { queueNotification, isQuietHoursNow, BUNDLE_WINDOW_MS };
