// 心情陪伴：獨立於一般 AI 助理的對話人設 + 安全機制。
//
// 設計原則 (跟使用者討論過的界線)：
//   - AI 在這裡扮演的是「隨時可以聊聊的陪伴者」，做同理傾聽、情緒梳理、簡單的呼吸/認知調節引導，
//     不是有執照的心理師，不做診斷、不取代真正的心理治療。
//   - 如果偵測到比較嚴重的求助訊號 (自傷/自殺意念等)，除了讓 AI 用溫和的方式回應之外，
//     一律用「關鍵字比對」這個確定性機制強制附上求助資源，不完全依賴語言模型自己記得要講，
//     這樣比較不會因為模型當次輸出不穩定而漏掉。

const logger = require('./logger');
const assistant = require('./assistant');

const MOOD_SYSTEM_PROMPT = `你是 LifeHub 這款生活整合 App 裡的「心情陪伴」AI，個性溫暖、有耐心、很會聆聽。
你的角色是「隨時可以聊聊的陪伴者」：用同理、不批判的態度聽使用者說，幫助他們梳理情緒、
說出感受，可以引導簡單的呼吸放鬆、認知調整的問句 (例如「這件事一年後回頭看，你覺得還會這麼在意嗎」)，
也可以根據使用者之前分享過的內容，溫和地陪他們回顧「上次類似的狀況，後來是怎麼好轉的」。

請務必記得你的界線：你不是有執照的心理師，不能也不應該做心理診斷、不能假裝自己在做正式的心理治療。
如果使用者的內容顯示出強烈的絕望感、提到自傷、自殺意念，或任何生命安全相關的危險訊號，
請用溫和、不驚慌、不說教的語氣，陪伴他們的感受，並且自然地提到「這聽起來很不容易，要不要考慮找信任的人
或專業的人一起面對」，不要用生硬、公式化的方式把使用者推開，也不要在對話中反覆說教。

請一律用繁體中文回覆，語氣自然、有溫度，避免長篇大論或條列式說教，就像朋友在跟你聊天一樣。`;

// 危機關鍵字比對：故意保守 (寧可多附一次資源，也不要漏掉)，比對到就在伺服器端強制附上資源，
// 不完全依賴語言模型自己記得要講。
const CRISIS_KEYWORDS = [
  '不想活', '不想活了', '想死', '想自殺', '自殺', '結束生命', '結束自己的生命',
  '割腕', '自殘', '自傷', '想消失', '活不下去', '撐不下去了', '沒有意義了活著',
  '傷害自己', '了結', '跳樓', '燒炭', '厭世到極點',
];

function detectCrisisSignal(text) {
  if (!text) return false;
  const normalized = String(text);
  return CRISIS_KEYWORDS.some((k) => normalized.includes(k));
}

const CRISIS_RESOURCE_TEXT = `

如果你現在真的很難受，這裡有幾個台灣的免費求助資源，隨時都可以打，會有人願意聽你說：
🔹 安心專線 1925 (24 小時)
🔹 生命線 1995 (24 小時)
🔹 張老師專線 1980 (日間)
不管幾點、不管講什麼，都可以打過去，不用覺得是在麻煩別人。`;

// relationshipContext: 選填，使用者在「人際關係」模塊已經記錄過的人 (姓名/關係/備註)，
// 讓 AI 在對話中聽到這些名字時，能認得「這是使用者提過的誰」、給出更貼近脈絡的陪伴或建議，
// 而不是每次都要使用者重新解釋這個人是誰。這只是「認得人」用的背景資料，AI 不應該主動
// 把使用者沒提到的人搬出來講，更不能對使用者的社交頻率下評論或催促。
const RELATIONSHIP_CONTEXT_NOTE = `以下是使用者在「人際關係」模塊記錄過的一些人 (姓名/關係/簡短備註)，
只是讓你認得使用者聊天中提到的名字是誰、脈絡是什麼，可以在對話中自然地展現「我記得你說過的這個人」，
或在使用者主動想討論跟這個人的狀況時，提供更貼近脈絡的陪伴或想法。
但絕對不要主動提起使用者沒有先提到的人，也不要對使用者「多久沒跟誰聯絡」這件事發表意見或催促，那是另一個功能的事，這裡只是輔助你認人。

另外，當使用者聊到跟某個人之間的狀況或衝突時 (例如吵架、誤會、關係緊張)，請保持客觀，不要只憑使用者單方的敘述
就對那個人下評論或評價、也不要直接站在使用者這一邊去附和指責對方。可以同理使用者當下的感受，
但描述事情本身時盡量保持中立，提醒這只是聽到的其中一種觀點，溫和地引導使用者自己去想想對方可能的處境或想法、
或想想接下來想怎麼處理，而不是替使用者評斷「對方不對」或「你才是對的」。`;

// history: [{role, content}]，最後一筆是使用者這次的新訊息
// memoryContext: 選填，之前對話的長期記憶摘要 (見下方「AI 對話記憶強化」)，
// 有的話會附加在系統提示後面，讓 AI 就算看不到逐字稿，也還記得比較久以前聊過的重點。
async function chatMoodCompanion(history, memoryContext, relationshipContext) {
  const lastUserMsg = [...history].reverse().find((m) => m.role === 'user');
  const crisisDetected = detectCrisisSignal(lastUserMsg && lastUserMsg.content);

  let systemPrompt = MOOD_SYSTEM_PROMPT;
  if (memoryContext) {
    systemPrompt += `\n\n以下是你們之前聊過、比較久以前的對話重點摘要 (不是逐字稿，是重點整理)，可以自然地在對話中參考，但不用刻意提起：\n${memoryContext}`;
  }
  if (relationshipContext) {
    systemPrompt += `\n\n${RELATIONSHIP_CONTEXT_NOTE}\n${relationshipContext}`;
  }

  const result = await assistant.chat(history, { systemPrompt });

  if (crisisDetected && result.isConfigured) {
    logger.info('[mood] 偵測到危機關鍵字，已附上求助資源');
    if (!result.reply.includes('1925')) {
      result.reply = result.reply + CRISIS_RESOURCE_TEXT;
    }
  }
  return { ...result, crisisDetected };
}

const WEEKLY_REVIEW_SYSTEM_PROMPT = `你是 LifeHub 的心情陪伴 AI。使用者會給你這週的心情紀錄資料 (日期、分數、標籤、備註)，
請用溫暖、像朋友寫小卡片一樣的口吻，寫一段大約 100-150 字的「這週回顧」。
不要用條列式、不要說教、不要給醫療建議，重點是讓使用者感覺「有人真的看見了我這週的狀態」。
如果這週分數偏低，語氣要格外溫柔、不要一直強調負面，可以帶一點鼓勵；如果分數不錯，就自然地肯定使用者。
請一律用繁體中文回覆。`;

// entries: [{entry_date, score, tags, note}]，由呼叫端 (route) 準備好這週的資料
async function generateWeeklyReview(entries) {
  if (!entries.length) {
    return { isConfigured: true, reply: '這週還沒有心情紀錄，先從記一筆今天的心情開始吧 🌱' };
  }
  const lines = entries.map((e) => {
    const tagsText = e.tags ? `標籤：${e.tags}` : '';
    const noteText = e.note ? `備註：${e.note}` : '';
    return `${e.entry_date}：${e.score} 分 ${tagsText} ${noteText}`.trim();
  });
  const prompt = `這是我這週的心情紀錄：\n${lines.join('\n')}\n請幫我寫這週的回顧。`;
  return assistant.chat([{ role: 'user', content: prompt }], { systemPrompt: WEEKLY_REVIEW_SYSTEM_PROMPT });
}

const MONTHLY_REVIEW_SYSTEM_PROMPT = `你是 LifeHub 的心情陪伴 AI。使用者會給你一整個月的心情紀錄資料 (日期、分數、標籤、備註)，
請用溫暖、像朋友寫信一樣的口吻，寫一段大約 150-220 字的「這個月的回顧」。
內容可以自然地提到這個月整體的狀態、有沒有比較明顯的高低起伏、常出現的標籤或主題，
不要用條列式、不要說教、不要給醫療建議，重點是讓使用者感覺「有人真的看見了我這個月的樣子」。
請一律用繁體中文回覆。`;

// entries: [{entry_date, score, tags, note}]，monthLabel 例如 "2026-07"
async function generateMonthlyReview(entries, monthLabel) {
  if (!entries.length) {
    return { isConfigured: true, reply: `${monthLabel} 還沒有心情紀錄，先從記一筆這個月的心情開始吧 🌱` };
  }
  const lines = entries.map((e) => {
    const tagsText = e.tags ? `標籤：${e.tags}` : '';
    const noteText = e.note ? `備註：${e.note}` : '';
    return `${e.entry_date}：${e.score} 分 ${tagsText} ${noteText}`.trim();
  });
  const prompt = `這是我 ${monthLabel} 的心情紀錄：\n${lines.join('\n')}\n請幫我寫這個月的回顧。`;
  return assistant.chat([{ role: 'user', content: prompt }], { systemPrompt: MONTHLY_REVIEW_SYSTEM_PROMPT });
}

// ---------- AI 對話記憶強化 ----------
// 對話存在資料庫的逐字稿只保留「最近 N 則」給 AI 當上下文 (見 routes/mood.js 的 MAX_CHAT_HISTORY)，
// 但這樣聊太久之前的重點會被忘記。做法：每累積一定則數的舊訊息，就請 AI 把那一段的重點濃縮成
// 1-2 句摘要存起來 (mood_chat_memory)，之後聊天時把這些摘要一起交給 AI，讓它「記得」更久以前的事，
// 但不需要每次都把全部逐字稿塞進去 (省 token、也比較不會超過上下文長度)。
const MEMORY_SUMMARY_SYSTEM_PROMPT = `你是在幫「心情陪伴 AI」整理長期記憶。以下是一段使用者跟 AI 之間比較久以前的對話紀錄，
請把這段對話中，對未來繼續陪伴這位使用者「真的重要」的重點濃縮成 1-2 句話 (例如：使用者在意的人事物、
持續困擾他的狀況、他提過想努力的方向、重要的生活事件)。不要摘要瑣碎的閒聊內容，
如果整段對話沒什麼特別需要記住的重點，就回答「無重要記憶點」。請一律用繁體中文回覆，只回傳摘要本身，不要加其他說明文字。`;

async function summarizeChatChunk(messages) {
  const transcript = messages.map((m) => `${m.role === 'user' ? '使用者' : 'AI'}: ${m.content}`).join('\n');
  const result = await assistant.chat(
    [{ role: 'user', content: `這是一段對話紀錄：\n${transcript}\n請幫我濃縮成重點摘要。` }],
    { systemPrompt: MEMORY_SUMMARY_SYSTEM_PROMPT }
  );
  return result;
}

// ---------- CBT 式思考記錄：卡住的時候，陪使用者走一遍認知重塑練習 ----------
// 定位：這是自助用的認知行為練習輔助工具，不是心理治療或診斷；AI 只是幫忙提供「一個可能的角度」，
// 使用者永遠可以直接自己寫 reframe、不採用 AI 的建議。
const REFRAME_SYSTEM_PROMPT = `你是 LifeHub 的心情陪伴 AI，現在在陪使用者做一個簡單的認知重塑 (CBT) 練習。
使用者會給你：當下的情境、腦中出現的念頭、支持這個念頭的證據、不支持這個念頭的證據。
請你用溫和、不批判的語氣，幫他寫一句「可能更平衡一點的想法」(reframe)，這句話不是要否定他的感受、
也不是要他假裝一切都很好，而是根據他自己列出的正反證據，找一個更貼近事實全貌的角度。
只回傳這句 reframe 本身 (1-3 句話)，不要加開場白或條列說明，語氣像朋友輕輕跟他說話一樣。
請一律用繁體中文回覆。`;

async function suggestReframe({ situation, thought, evidenceFor, evidenceAgainst }) {
  const prompt = `情境：${situation || '(未填寫)'}\n腦中的念頭：${thought}\n支持這個念頭的證據：${evidenceFor || '(未填寫)'}\n不支持這個念頭的證據：${evidenceAgainst || '(未填寫)'}\n請幫我想一句可能更平衡的想法。`;
  return assistant.chat([{ role: 'user', content: prompt }], { systemPrompt: REFRAME_SYSTEM_PROMPT });
}

// ---------- 陪伴對話更主動的開場 ----------
// 使用情境：使用者清過對話畫面 (mood_chat_messages 被清空)，但長期記憶摘要 (mood_chat_memory)
// 還在，這時候不要讓對話室看起來像「完全沒聊過」，而是讓 AI 主動先開口、自然地接續之前的重點，
// 讓使用者感覺真的被記得，而不用自己先打字破冰。
const OPENER_SYSTEM_PROMPT = `你是 LifeHub 的心情陪伴 AI。使用者現在打開對話室，畫面上還沒有新的對話，
但你們之前聊過、有一些重點記憶摘要。請你主動先開口，寫一句自然的問候/關心 (1-2 句話)，
可以很自然地帶到記憶摘要裡的內容 (例如問問後續狀況)，但不要生硬地複誦摘要內容、不要像在做總結報告，
語氣要像朋友一樣輕鬆。請一律用繁體中文回覆，只回傳這句開場白本身。`;

async function generateChatOpener(memoryContext) {
  const prompt = `這是你們之前聊過的重點摘要：\n${memoryContext}\n請幫我想一句開場白。`;
  return assistant.chat([{ role: 'user', content: prompt }], { systemPrompt: OPENER_SYSTEM_PROMPT });
}

module.exports = {
  chatMoodCompanion,
  detectCrisisSignal,
  generateWeeklyReview,
  generateMonthlyReview,
  summarizeChatChunk,
  suggestReframe,
  generateChatOpener,
  CRISIS_RESOURCE_TEXT,
};
