const { Router } = require('../mini-http');
const { getDb } = require('../services/db');
const { requireAuth } = require('../middleware/auth');

const router = Router();

router.get('/transactions', requireAuth, (req, res) => {
  const db = getDb();
  const { month } = req.query; // YYYY-MM
  let rows;
  if (month) {
    rows = db
      .prepare(`SELECT * FROM finance_transactions WHERE user_id = ? AND tx_date LIKE ? ORDER BY tx_date DESC, id DESC`)
      .all(req.session.userId, `${month}%`);
  } else {
    rows = db
      .prepare(`SELECT * FROM finance_transactions WHERE user_id = ? ORDER BY tx_date DESC, id DESC LIMIT 200`)
      .all(req.session.userId);
  }
  res.json(rows);
});

router.post('/transactions', requireAuth, (req, res) => {
  const { tx_date, type, category, amount, note } = req.body || {};
  if (!tx_date || !type || !category || amount === undefined) {
    return res.status(400).json({ error: '缺少必要欄位 (日期/類型/分類/金額)' });
  }
  if (!['income', 'expense'].includes(type)) return res.status(400).json({ error: 'type 必須是 income 或 expense' });

  const db = getDb();
  const info = db
    .prepare(
      'INSERT INTO finance_transactions (user_id, tx_date, type, category, amount, note, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)'
    )
    .run(req.session.userId, tx_date, type, category, Number(amount), note || null, new Date().toISOString());
  res.json({ id: info.lastInsertRowid });
});

router.delete('/transactions/:id', requireAuth, (req, res) => {
  const db = getDb();
  db.prepare('DELETE FROM finance_transactions WHERE id = ? AND user_id = ?').run(req.params.id, req.session.userId);
  res.json({ ok: true });
});

router.get('/summary', requireAuth, (req, res) => {
  const { month } = req.query;
  const db = getDb();
  const like = month ? `${month}%` : `${new Date().toISOString().slice(0, 7)}%`;

  const byCategory = db
    .prepare(
      `SELECT category, type, SUM(amount) as total FROM finance_transactions
       WHERE user_id = ? AND tx_date LIKE ? GROUP BY category, type ORDER BY total DESC`
    )
    .all(req.session.userId, like);

  const totals = db
    .prepare(
      `SELECT type, SUM(amount) as total FROM finance_transactions WHERE user_id = ? AND tx_date LIKE ? GROUP BY type`
    )
    .all(req.session.userId, like);

  const monthlyTrend = db
    .prepare(
      `SELECT substr(tx_date,1,7) as ym, type, SUM(amount) as total FROM finance_transactions
       WHERE user_id = ? GROUP BY ym, type ORDER BY ym DESC LIMIT 12`
    )
    .all(req.session.userId);

  res.json({ month: like.replace('%', ''), byCategory, totals, monthlyTrend: monthlyTrend.reverse() });
});

// 固定支出/訂閱偵測：找「備註/分類組合」在至少 2 個不同月份都出現、金額差距不大的支出，
// 整理成一份「你可能有的固定支出」清單，讓你確認、不是自動幫你下結論
router.get('/subscriptions', requireAuth, (req, res) => {
  const db = getDb();
  const rows = db
    .prepare(
      `SELECT category, note, amount, tx_date FROM finance_transactions
       WHERE user_id = ? AND type = 'expense' AND note IS NOT NULL AND trim(note) != ''
       ORDER BY tx_date ASC`
    )
    .all(req.session.userId);

  const groups = new Map();
  rows.forEach((r) => {
    const key = `${r.category}::${String(r.note).trim().toLowerCase()}`;
    if (!groups.has(key)) groups.set(key, { category: r.category, note: r.note, entries: [] });
    groups.get(key).entries.push({ amount: r.amount, ym: r.tx_date.slice(0, 7), tx_date: r.tx_date });
  });

  const candidates = [];
  groups.forEach((g) => {
    const distinctMonths = new Set(g.entries.map((e) => e.ym));
    if (distinctMonths.size < 2) return;
    const amounts = g.entries.map((e) => e.amount);
    const avg = amounts.reduce((s, a) => s + a, 0) / amounts.length;
    const maxDiff = Math.max(...amounts.map((a) => Math.abs(a - avg)));
    if (avg > 0 && maxDiff / avg > 0.15) return; // 金額差太多，可能不是同一筆固定支出
    candidates.push({
      category: g.category,
      note: g.note,
      monthsSeen: distinctMonths.size,
      avgAmount: Math.round(avg),
      lastDate: g.entries[g.entries.length - 1].tx_date,
      occurrences: g.entries.length,
    });
  });
  candidates.sort((a, b) => b.monthsSeen - a.monthsSeen || b.avgAmount - a.avgAmount);

  res.json({
    disclaimer: '依「備註+分類」在多個月份出現、金額相近的規則整理，是猜測不是保證，請自行確認是否為真的固定支出。',
    candidates,
  });
});

// 淨資產趨勢：用每月收支計算「累計現金結餘」隨時間的變化 (不含股票等投資部位市值，
// 投資部位市值請看股票頁的庫存損益總覽，避免兩邊資料來源不一致造成混淆)
router.get('/networth-trend', requireAuth, (req, res) => {
  const db = getDb();
  const monthly = db
    .prepare(
      `SELECT substr(tx_date,1,7) as ym,
              SUM(CASE WHEN type='income' THEN amount ELSE 0 END) as income,
              SUM(CASE WHEN type='expense' THEN amount ELSE 0 END) as expense
       FROM finance_transactions WHERE user_id = ? GROUP BY ym ORDER BY ym ASC`
    )
    .all(req.session.userId);

  let cumulative = 0;
  const trend = monthly.map((m) => {
    cumulative += (m.income || 0) - (m.expense || 0);
    return { ym: m.ym, income: m.income || 0, expense: m.expense || 0, netChange: (m.income || 0) - (m.expense || 0), cumulativeBalance: cumulative };
  });

  res.json({
    disclaimer: '這裡的「累計結餘」只計算記帳收支的累加，不包含股票等投資部位的市值。',
    trend,
    currentCumulativeBalance: cumulative,
  });
});

router.get('/budgets', requireAuth, (req, res) => {
  const db = getDb();
  res.json(db.prepare('SELECT * FROM finance_budgets WHERE user_id = ?').all(req.session.userId));
});

router.put('/budgets/:category', requireAuth, (req, res) => {
  const { monthly_limit } = req.body || {};
  if (monthly_limit === undefined || monthly_limit === null || Number.isNaN(Number(monthly_limit)) || Number(monthly_limit) <= 0) {
    return res.status(400).json({ error: '請提供有效的 monthly_limit (需大於 0)' });
  }
  const db = getDb();
  const existing = db
    .prepare('SELECT id FROM finance_budgets WHERE user_id = ? AND category = ?')
    .get(req.session.userId, req.params.category);
  if (existing) {
    db.prepare('UPDATE finance_budgets SET monthly_limit = ? WHERE id = ?').run(Number(monthly_limit), existing.id);
  } else {
    db.prepare('INSERT INTO finance_budgets (user_id, category, monthly_limit) VALUES (?, ?, ?)').run(
      req.session.userId,
      req.params.category,
      Number(monthly_limit)
    );
  }
  res.json({ ok: true });
});

// ---- 財務目標 ----
// 不需要使用者手動記錄「存了多少」，而是用目標設立日之後的實際淨儲蓄 (收入-支出) 自動推算進度，
// 並用過去的平均月淨儲蓄速度，推算大概何時能達成。

function computeGoalProgress(db, userId, goal) {
  const row = db
    .prepare(
      `SELECT
         COALESCE(SUM(CASE WHEN type = 'income' THEN amount ELSE 0 END), 0) as income,
         COALESCE(SUM(CASE WHEN type = 'expense' THEN amount ELSE 0 END), 0) as expense
       FROM finance_transactions WHERE user_id = ? AND tx_date >= ?`
    )
    .get(userId, goal.start_date);
  const netSaved = Math.round((row.income - row.expense) * 100) / 100;
  const progressPct = goal.target_amount > 0 ? Math.max(0, Math.min(100, Math.round((netSaved / goal.target_amount) * 1000) / 10)) : 0;

  // 用「目標設立至今」的月數，算平均每月淨儲蓄速度，藉此推算大約何時能達成
  const start = new Date(goal.start_date + 'T00:00:00Z');
  const now = new Date();
  const monthsElapsed = Math.max(1 / 30, (now - start) / (1000 * 60 * 60 * 24 * 30));
  const monthlyRate = netSaved / monthsElapsed;

  let projectedDate = null;
  let onTrack = null;
  const remaining = goal.target_amount - netSaved;
  if (remaining <= 0) {
    projectedDate = 'reached';
  } else if (monthlyRate > 0.01) {
    const monthsNeeded = remaining / monthlyRate;
    const projected = new Date(now.getTime() + monthsNeeded * 30 * 24 * 60 * 60 * 1000);
    projectedDate = projected.toISOString().slice(0, 10);
    if (goal.target_date) {
      onTrack = projectedDate <= goal.target_date;
    }
  }

  return { ...goal, netSaved, progressPct, monthlyRate: Math.round(monthlyRate * 100) / 100, projectedDate, onTrack };
}

router.get('/goals', requireAuth, (req, res) => {
  const db = getDb();
  const goals = db
    .prepare('SELECT * FROM finance_goals WHERE user_id = ? AND archived = 0 ORDER BY created_at DESC')
    .all(req.session.userId);
  res.json(goals.map((g) => computeGoalProgress(db, req.session.userId, g)));
});

router.post('/goals', requireAuth, (req, res) => {
  const { name, target_amount, target_date, start_date } = req.body || {};
  if (!name || !target_amount || Number(target_amount) <= 0) {
    return res.status(400).json({ error: '請提供目標名稱與大於 0 的目標金額' });
  }
  const db = getDb();
  const info = db
    .prepare(
      'INSERT INTO finance_goals (user_id, name, target_amount, target_date, start_date, archived, created_at) VALUES (?, ?, ?, ?, ?, 0, ?)'
    )
    .run(
      req.session.userId,
      name,
      Number(target_amount),
      target_date || null,
      start_date || new Date().toISOString().slice(0, 10),
      new Date().toISOString()
    );
  res.json({ id: info.lastInsertRowid });
});

router.delete('/goals/:id', requireAuth, (req, res) => {
  const db = getDb();
  db.prepare('UPDATE finance_goals SET archived = 1 WHERE id = ? AND user_id = ?').run(req.params.id, req.session.userId);
  res.json({ ok: true });
});

module.exports = router;
