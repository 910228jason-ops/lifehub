// 遊戲化點數 + 獎勵兌換頁面 (v0.43)。
//
// 點數本身不能直接調整 (沒有「手動加點」的 API)，只會在完成待辦/寫日記/記心情/記帳這幾個
// 既有行為時自動加點 (見 tasks.js/diary.js/mood.js/finance.js 裡對 services/points.js 的呼叫)，
// 這裡只負責「查詢點數/管理獎勵項目/兌換」。
//
// 獎勵項目完全由使用者自訂 (標題 + 花費點數)，系統不預設任何獎勵內容——每個人想犒賞自己的
// 東西差異很大 (有人想要「看一集劇」，有人想要「買一杯手搖飲」)，預設清單多半用不到，不如
// 讓使用者自己決定「多少點換什麼」。

const { Router } = require('../mini-http');
const { getDb } = require('../services/db');
const { requireAuth } = require('../middleware/auth');
const { getBalance } = require('../services/points');

const router = Router();

// v0.52：獎勵項目可以掛在某個 partner_links 連結底下「共同建立」，重用既有的家人/伴侶配對
// 系統，不另外做一套邀請機制。這兩個小 helper 分別回答「我跟誰有連結」跟「這個連結是不是
// 真的屬於我 (不能亂填別人的 linkId 把獎勵塞進去)」。
function getUserLinks(db, userId) {
  const rows = db
    .prepare('SELECT id, user_a_id, user_b_id FROM partner_links WHERE user_a_id = ? OR user_b_id = ?')
    .all(userId, userId);
  return rows.map((r) => ({ linkId: r.id, partnerUserId: r.user_a_id === userId ? r.user_b_id : r.user_a_id }));
}
function linkBelongsToUser(db, linkId, userId) {
  const row = db.prepare('SELECT id FROM partner_links WHERE id = ? AND (user_a_id = ? OR user_b_id = ?)').get(linkId, userId, userId);
  return !!row;
}
function userLabel(db, userId) {
  const u = db.prepare('SELECT name, email FROM users WHERE id = ?').get(userId);
  return (u && (u.name || u.email)) || '對方';
}
// 一個獎勵項目「誰有權限看到/編輯/刪除/兌換」：私人的 (link_id 是 null) 只有建立者本人；
// 共同的 (link_id 有值) 則是那個連結底下的雙方都算數，不限定只有當初建立的那個人。
function canAccessReward(db, reward, userId) {
  if (!reward.link_id) return reward.user_id === userId;
  return linkBelongsToUser(db, reward.link_id, userId);
}

router.get('/points', requireAuth, (req, res) => {
  const db = getDb();
  const balance = getBalance(db, req.session.userId);
  const transactions = db
    .prepare('SELECT delta, reason, created_at FROM point_transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT 50')
    .all(req.session.userId);
  res.json({ balance, transactions });
});

// v0.52：除了自己私人的獎勵項目 (link_id 是 null)，也把「已連結對象共同建立」的獎勵項目
// 一起撈出來，並且標上是跟誰共同、是誰建立的，方便前端顯示成一個標籤。共同獎勵不會因為
// 誰新增的就只有那個人看得到——這正是「共同建立」的重點：雙方看到的清單完全一樣。
router.get('/points/rewards', requireAuth, (req, res) => {
  const db = getDb();
  const userId = req.session.userId;
  const links = getUserLinks(db, userId);
  const linkIds = links.map((l) => l.linkId);
  let rewards;
  if (linkIds.length) {
    const placeholders = linkIds.map(() => '?').join(',');
    rewards = db
      .prepare(`SELECT * FROM point_rewards WHERE (link_id IS NULL AND user_id = ?) OR link_id IN (${placeholders}) ORDER BY cost ASC`)
      .all(userId, ...linkIds);
  } else {
    rewards = db.prepare('SELECT * FROM point_rewards WHERE user_id = ? AND link_id IS NULL ORDER BY cost ASC').all(userId);
  }
  const enriched = rewards.map((r) => {
    if (!r.link_id) return { ...r, shared: false };
    const link = links.find((l) => l.linkId === r.link_id);
    const partnerLabel = link ? userLabel(db, link.partnerUserId) : '對方';
    const creatorId = r.created_by_user_id || r.user_id;
    return {
      ...r,
      shared: true,
      partnerLabel,
      creatorLabel: creatorId === userId ? '我' : userLabel(db, creatorId),
      createdByMe: creatorId === userId,
    };
  });
  res.json({ rewards: enriched, balance: getBalance(db, userId) });
});

router.post('/points/rewards', requireAuth, (req, res) => {
  const { title, cost, linkId } = req.body || {};
  const trimmed = String(title || '').trim();
  const costNum = Number(cost);
  if (!trimmed) return res.status(400).json({ error: '請輸入獎勵名稱' });
  if (!Number.isInteger(costNum) || costNum <= 0) return res.status(400).json({ error: '花費點數必須是大於 0 的整數' });
  const db = getDb();
  let resolvedLinkId = null;
  if (linkId !== undefined && linkId !== null && linkId !== '') {
    if (!linkBelongsToUser(db, linkId, req.session.userId)) return res.status(400).json({ error: '找不到這個共同連結' });
    resolvedLinkId = linkId;
  }
  const result = db
    .prepare('INSERT INTO point_rewards (user_id, title, cost, created_at, link_id, created_by_user_id) VALUES (?, ?, ?, ?, ?, ?)')
    .run(req.session.userId, trimmed, costNum, new Date().toISOString(), resolvedLinkId, req.session.userId);
  res.json({ id: result.lastInsertRowid });
});

router.put('/points/rewards/:id', requireAuth, (req, res) => {
  const db = getDb();
  const reward = db.prepare('SELECT * FROM point_rewards WHERE id = ?').get(req.params.id);
  if (!reward || !canAccessReward(db, reward, req.session.userId)) return res.status(404).json({ error: '找不到這個獎勵項目' });
  const { title, cost } = req.body || {};
  const trimmed = String(title || '').trim();
  const costNum = Number(cost);
  if (!trimmed) return res.status(400).json({ error: '請輸入獎勵名稱' });
  if (!Number.isInteger(costNum) || costNum <= 0) return res.status(400).json({ error: '花費點數必須是大於 0 的整數' });
  db.prepare('UPDATE point_rewards SET title = ?, cost = ? WHERE id = ?').run(trimmed, costNum, reward.id);
  res.json({ ok: true });
});

router.delete('/points/rewards/:id', requireAuth, (req, res) => {
  const db = getDb();
  const reward = db.prepare('SELECT * FROM point_rewards WHERE id = ?').get(req.params.id);
  if (!reward || !canAccessReward(db, reward, req.session.userId)) return res.status(404).json({ error: '找不到這個獎勵項目' });
  db.prepare('DELETE FROM point_rewards WHERE id = ?').run(reward.id);
  res.json({ ok: true });
});

router.post('/points/rewards/:id/redeem', requireAuth, (req, res) => {
  const db = getDb();
  const reward = db.prepare('SELECT * FROM point_rewards WHERE id = ?').get(req.params.id);
  if (!reward || !canAccessReward(db, reward, req.session.userId)) return res.status(404).json({ error: '找不到這個獎勵項目' });
  const balance = getBalance(db, req.session.userId);
  if (balance < reward.cost) return res.status(400).json({ error: `點數不夠，還差 ${reward.cost - balance} 點` });

  // 共同獎勵一樣是「各自扣各自的點數」，不是共用點數池——兩個人各自累積點數的方式跟速度
  // 不同，共用點數池反而會讓人搞不清楚是誰的點數換走的，各自扣自己的比較直覺也比較公平。
  const now = new Date().toISOString();
  db.prepare('UPDATE user_points SET balance = balance - ?, updated_at = ? WHERE user_id = ?').run(reward.cost, now, req.session.userId);
  db.prepare('INSERT INTO point_transactions (user_id, delta, reason, created_at) VALUES (?, ?, ?, ?)').run(
    req.session.userId, -reward.cost, `redeem:${reward.title}`, now
  );
  db.prepare('INSERT INTO point_redemptions (user_id, reward_id, reward_title, cost, created_at) VALUES (?, ?, ?, ?, ?)').run(
    req.session.userId, reward.id, reward.title, reward.cost, now
  );
  res.json({ ok: true, newBalance: getBalance(db, req.session.userId) });
});

router.get('/points/redemptions', requireAuth, (req, res) => {
  const db = getDb();
  const rows = db
    .prepare('SELECT reward_title, cost, created_at FROM point_redemptions WHERE user_id = ? ORDER BY created_at DESC LIMIT 50')
    .all(req.session.userId);
  res.json({ redemptions: rows });
});

module.exports = router;
