// 跨模組洞察 / 主動式提醒。
//
// 這裡刻意不做「跨模塊深層模式識別」那種需要大量資料、AI 幫忙寫成一段話的深度分析
// (那個已經在心情頁做過了，見 src/services/moodPatterns.js)。這裡要做的是更輕量、
// 首頁就看得到的東西：
//   1. 主動式提醒——把「帳單快到期」「這個月某分類超支」「待辦拖很久」「好幾天沒記心情」
//      這幾件本來都要自己點進去每個分頁才會發現的事，集中成一份列表主動列在首頁。
//   2. 本週動態——單純用程式把心情/記帳/待辦/行事曆/日記這幾個模組本週的數字撈出來，
//      拼成幾句話，不叫 AI (不需要、也不用等待/花費)，資料就是資料，看得懂就好。
//
// 這個檔案沒有另外掛載新的 app.mount()，而是比照 feedback.js 的作法，把 routes 直接
// push 進已經掛在 /api 的 debug.js router，實際路徑就是 /api/insights/*。

const { Router } = require('../mini-http');
const { getDb } = require('../services/db');
const { requireAuth } = require('../middleware/auth');

const router = Router();

function todayStr() { return new Date().toISOString().slice(0, 10); }
function daysAgoStr(n) { return new Date(Date.now() - n * 24 * 3600 * 1000).toISOString().slice(0, 10); }

// 抽出成獨立函式：/api/insights/reminders 這支 API 用，背景推播排程 (src/routes/push.js)
// 也用同一份邏輯算出「這個使用者現在有哪些提醒」，兩邊不會算出不一樣的結果。
function computeReminders(db, userId) {
  const items = [];

  // ---- 帳單快到期還沒繳 (7 天內到期、這個月還沒標記已繳) ----
  try {
    const period = todayStr().slice(0, 7);
    const bills = db.prepare('SELECT * FROM bills WHERE user_id = ? AND active = 1').all(userId);
    const paidRows = db.prepare('SELECT bill_id FROM bill_payments WHERE user_id = ? AND paid_period = ?').all(userId, period);
    const paidSet = new Set(paidRows.map((r) => r.bill_id));
    const dayOfMonth = new Date().getDate();
    bills.forEach((b) => {
      if (paidSet.has(b.id)) return;
      const daysLeft = b.due_day - dayOfMonth;
      if (daysLeft <= 7) {
        items.push({
          severity: daysLeft < 0 ? 'critical' : 'warning',
          icon: '🧾',
          text: daysLeft < 0
            ? `「${b.name}」帳單已經過了繳款日 (每月 ${b.due_day} 號)，還沒標記已繳`
            : daysLeft === 0
              ? `「${b.name}」帳單今天到期 (NT$${Number(b.amount).toLocaleString()})`
              : `「${b.name}」帳單還有 ${daysLeft} 天到期 (NT$${Number(b.amount).toLocaleString()})`,
          tab: 'bills',
        });
      }
    });
  } catch (e) { /* bills 模組資料不存在時忽略，不影響其他提醒 */ }

  // ---- 這個月分類預算超支 ----
  try {
    const period = todayStr().slice(0, 7);
    const budgets = db.prepare('SELECT * FROM finance_budgets WHERE user_id = ?').all(userId);
    if (budgets.length) {
      const spent = db
        .prepare(
          `SELECT category, SUM(amount) as total FROM finance_transactions
           WHERE user_id = ? AND type = 'expense' AND tx_date LIKE ? GROUP BY category`
        )
        .all(userId, `${period}%`);
      const spentByCat = {};
      spent.forEach((s) => { spentByCat[s.category] = s.total; });
      budgets.forEach((b) => {
        const used = spentByCat[b.category] || 0;
        if (used > b.monthly_limit) {
          const overPct = Math.round(((used - b.monthly_limit) / b.monthly_limit) * 100);
          items.push({
            severity: 'warning',
            icon: '💰',
            text: `本月「${b.category}」已經花了 NT$${Math.round(used).toLocaleString()}，超出預算 NT$${Math.round(b.monthly_limit).toLocaleString()} 約 ${overPct}%`,
            tab: 'finance',
          });
        }
      });
    }
  } catch (e) { /* ignore */ }

  // ---- 待辦事項拖延 (逾期超過 3 天還沒完成) ----
  try {
    const overdueThreshold = daysAgoStr(3);
    const overdue = db
      .prepare("SELECT COUNT(*) as c FROM tasks WHERE user_id = ? AND completed = 0 AND due_date IS NOT NULL AND due_date < ?")
      .get(userId, overdueThreshold).c;
    if (overdue > 0) {
      items.push({
        severity: 'warning',
        icon: '✅',
        text: `有 ${overdue} 件待辦事項已經逾期超過 3 天還沒完成`,
        tab: 'tasks',
      });
    }
  } catch (e) { /* ignore */ }

  // ---- 好幾天沒記心情 (最近一次紀錄距今 >= 3 天，或完全沒記過) ----
  try {
    const last = db.prepare('SELECT MAX(entry_date) as d FROM mood_entries WHERE user_id = ?').get(userId).d;
    if (last) {
      const gap = Math.floor((new Date(todayStr()) - new Date(last)) / (24 * 3600 * 1000));
      if (gap >= 3) {
        items.push({ severity: 'info', icon: '💗', text: `已經 ${gap} 天沒有記錄心情了，要不要花點時間打個分數？`, tab: 'mood' });
      }
    }
  } catch (e) { /* ignore */ }

  // 排序：critical 在最前面，其次 warning，最後 info
  const rank = { critical: 0, warning: 1, info: 2 };
  items.sort((a, b) => rank[a.severity] - rank[b.severity]);

  return items;
}

router.get('/insights/reminders', requireAuth, (req, res) => {
  const db = getDb();
  const userId = req.session.userId;
  const items = computeReminders(db, userId);
  res.json({ items, count: items.length });
});

// 本週動態：純程式計算，不叫 AI，把幾個模組本週的數字整理成幾句話。
router.get('/insights/weekly', requireAuth, (req, res) => {
  const db = getDb();
  const userId = req.session.userId;
  const from = daysAgoStr(7);
  const to = todayStr();
  const lines = [];
  const stats = {};

  try {
    const moodRows = db.prepare('SELECT score FROM mood_entries WHERE user_id = ? AND entry_date >= ?').all(userId, from);
    if (moodRows.length) {
      const avg = moodRows.reduce((s, r) => s + r.score, 0) / moodRows.length;
      stats.moodAvg = Math.round(avg * 10) / 10;
      stats.moodCount = moodRows.length;
      lines.push(`這週記錄了 ${moodRows.length} 次心情，平均分數 ${stats.moodAvg} 分`);
    } else {
      lines.push('這週還沒有記錄過心情');
    }
  } catch (e) { /* ignore */ }

  try {
    const fin = db
      .prepare(
        `SELECT SUM(CASE WHEN type='expense' THEN amount ELSE 0 END) as expense,
                SUM(CASE WHEN type='income' THEN amount ELSE 0 END) as income
         FROM finance_transactions WHERE user_id = ? AND tx_date >= ?`
      )
      .get(userId, from);
    stats.expense = Math.round(fin.expense || 0);
    stats.income = Math.round(fin.income || 0);
    if (stats.expense || stats.income) {
      lines.push(`這週支出 NT$${stats.expense.toLocaleString()}，收入 NT$${stats.income.toLocaleString()}`);
    }
  } catch (e) { /* ignore */ }

  try {
    const completed = db
      .prepare("SELECT COUNT(*) as c FROM tasks WHERE user_id = ? AND completed = 1 AND substr(completed_at,1,10) >= ?")
      .get(userId, from).c;
    const overdue = db
      .prepare("SELECT COUNT(*) as c FROM tasks WHERE user_id = ? AND completed = 0 AND due_date IS NOT NULL AND due_date < ?")
      .get(userId, to).c;
    stats.tasksCompleted = completed;
    stats.tasksOverdue = overdue;
    lines.push(`待辦完成了 ${completed} 件${overdue > 0 ? `，還有 ${overdue} 件已經逾期` : ''}`);
  } catch (e) { /* ignore */ }

  try {
    const events = db.prepare('SELECT COUNT(*) as c FROM calendar_events WHERE user_id = ? AND event_date >= ? AND event_date <= ?').get(userId, from, to).c;
    stats.eventCount = events;
    lines.push(`行事曆這週有 ${events} 筆行程`);
  } catch (e) { /* ignore */ }

  try {
    const diaryCount = db.prepare('SELECT COUNT(*) as c FROM diary_entries WHERE user_id = ? AND entry_date >= ?').get(userId, from).c;
    stats.diaryCount = diaryCount;
    if (diaryCount > 0) lines.push(`這週寫了 ${diaryCount} 篇日記`);
  } catch (e) { /* ignore */ }

  // 一句簡單、不做因果斷言的交叉觀察：心情分數較低的那幾天，平均支出是不是比較高
  // (單純算術比較，不是統計推論，資料不夠時就不顯示，避免看起來像下定論)
  try {
    const moodRows = db.prepare('SELECT entry_date, score FROM mood_entries WHERE user_id = ? AND entry_date >= ?').all(userId, from);
    const txRows = db.prepare("SELECT tx_date, SUM(amount) as total FROM finance_transactions WHERE user_id = ? AND type='expense' AND tx_date >= ? GROUP BY tx_date").all(userId, from);
    const spendByDate = {};
    txRows.forEach((r) => { spendByDate[r.tx_date] = r.total; });
    if (moodRows.length >= 4) {
      const withSpend = moodRows.map((m) => ({ score: m.score, spend: spendByDate[m.entry_date] || 0 }));
      const sorted = [...withSpend].sort((a, b) => a.score - b.score);
      const half = Math.floor(sorted.length / 2);
      const lowerHalf = sorted.slice(0, half);
      const upperHalf = sorted.slice(sorted.length - half);
      const avgLow = lowerHalf.reduce((s, r) => s + r.spend, 0) / lowerHalf.length;
      const avgHigh = upperHalf.reduce((s, r) => s + r.spend, 0) / upperHalf.length;
      if (avgLow > 0 && avgHigh > 0 && Math.abs(avgLow - avgHigh) / Math.max(avgLow, avgHigh) > 0.25) {
        if (avgLow > avgHigh) {
          lines.push(`初步觀察（非絕對因果）：這週心情分數比較低的那幾天，支出似乎偏高一些`);
        } else {
          lines.push(`初步觀察（非絕對因果）：這週心情分數比較高的那幾天，支出似乎偏高一些`);
        }
      }
    }
  } catch (e) { /* ignore */ }

  res.json({ rangeFrom: from, rangeTo: to, lines, stats });
});

router.computeReminders = computeReminders;
module.exports = router;
