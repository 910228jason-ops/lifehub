// 生理週期階段估算。
//
// 這是「估算」不是醫療診斷：用使用者自己記錄的經期開始日，推算大概落在週期的哪個階段，
// 目的是讓心情陪伴的主動關心跟模式分析能考慮「經前」這個常見會影響情緒的階段，
// 不是要精確預測排卵或做生育規劃。黃體期後段 (排卵後到下次月經前，大約最後 7 天) 通常
// 是經前症候群 (PMS) 比較容易出現的時間，這裡用這段當作 PMS 觀察窗。
//
// v0.81 重要修正：以前用「距離上次月經天數 % 週期長度」推算，月經一旦比預估晚來，
// 取餘數會直接「繞回去」假裝新週期已經開始，明明還沒來卻顯示「月經期」——這對看推算的
// 人 (尤其是另一半) 是完全誤導的資訊。現在改成：
//   1. 超過預估日期而沒有新紀錄 → 進入「遲到 (late)」狀態，誠實顯示「預估日期已過 N 天」，
//      排卵/易孕期推算同時標記為失準，不再繼續給一個確定的日期。
//   2. 遲到太久 (超過 3 週) → 進入「太久沒更新 (stale)」狀態，比較可能是忘了記錄而不是
//      真的遲到這麼久，推算暫停並提示記一次新的開始日就會恢復。
//   3. 預測從「單一日期」改成「日期 ± 波動範圍」：用最近幾次週期的實際波動 (標準差) 算出
//      「預估 8/30，前後約 ±3 天」，把「差個幾天很正常」內建在呈現方式裡，不會因為寫死
//      一個日期、晚一天就讓人開始緊張。

const DEFAULT_CYCLE_LENGTH = 28;
const DEFAULT_PERIOD_LENGTH = 5;
const PMS_WINDOW_DAYS = 7; // 下次月經前這幾天算「經前觀察窗」
const MIN_ENTRIES_FOR_AVG = 2;
const LATE_MAX_DAYS = 21; // 遲到超過這個天數，改判定成「太久沒記錄」而不是繼續累加遲到天數
const DEFAULT_RANGE_DAYS = 3; // 紀錄不夠多、算不出波動時的預設 ± 天數

function daysBetween(a, b) {
  return Math.round((new Date(b + 'T00:00:00Z') - new Date(a + 'T00:00:00Z')) / (1000 * 60 * 60 * 24));
}

function addDays(dateStr, n) {
  const d = new Date(dateStr + 'T00:00:00Z');
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
}

// entries: 依 period_start_date 由舊到新排序的 [{period_start_date, period_end_date}]
function cycleGaps(entries) {
  const gaps = [];
  for (let i = 1; i < entries.length; i++) {
    const gap = daysBetween(entries[i - 1].period_start_date, entries[i].period_start_date);
    if (gap > 0 && gap < 90) gaps.push(gap); // 過濾掉異常值 (例如漏記或輸入錯誤)
  }
  return gaps;
}

function estimateCycleLength(entries) {
  if (entries.length < MIN_ENTRIES_FOR_AVG) return DEFAULT_CYCLE_LENGTH;
  const gaps = cycleGaps(entries);
  if (!gaps.length) return DEFAULT_CYCLE_LENGTH;
  return Math.round(gaps.reduce((s, g) => s + g, 0) / gaps.length);
}

// 週期波動：最近幾次週期長度的標準差 → 「± 幾天」跟「規律度」。
// 只有一段間隔算不出波動 (樣本太少)，跟完全沒紀錄一樣回傳預設值。
function estimateVariability(entries) {
  const gaps = cycleGaps(entries);
  if (gaps.length < 2) return { rangeDays: DEFAULT_RANGE_DAYS, regularity: null, sampleCount: gaps.length };
  const avg = gaps.reduce((s, g) => s + g, 0) / gaps.length;
  const variance = gaps.reduce((s, g) => s + (g - avg) * (g - avg), 0) / gaps.length;
  const stdev = Math.sqrt(variance);
  const rangeDays = Math.min(7, Math.max(1, Math.round(stdev)));
  const regularity = stdev <= 2 ? 'regular' : stdev <= 4 ? 'medium' : 'variable';
  return { rangeDays, regularity, sampleCount: gaps.length };
}

function periodLengthOf(entry) {
  if (entry && entry.period_end_date) {
    const len = daysBetween(entry.period_start_date, entry.period_end_date) + 1;
    if (len > 0 && len <= 14) return len;
  }
  return DEFAULT_PERIOD_LENGTH;
}

// 依「這段週期實際長度」判斷 daysSince (從這次月經開始算起第幾天，0-based) 落在哪個階段。
function classifyPhase(daysSince, cycleLength, periodLength) {
  const ovulationDay = Math.max(periodLength + 1, cycleLength - 14); // 排卵後到下次月經約 14 天 (黃體期長度較固定)
  const pmsStart = cycleLength - PMS_WINDOW_DAYS;
  let phase;
  if (daysSince < periodLength) phase = 'menstrual';
  else if (daysSince < ovulationDay - 1) phase = 'follicular';
  else if (daysSince <= ovulationDay + 1) phase = 'ovulation';
  else phase = 'luteal';
  const isPmsWindow = phase === 'luteal' && daysSince >= pmsStart;
  return { phase, isPmsWindow };
}

// 目前 (今天) 的狀態：給主動關心 banner 跟自己/另一半的週期檢視用
function currentStatus(entriesAsc, todayStr) {
  if (!entriesAsc.length) return { hasData: false };
  const last = entriesAsc[entriesAsc.length - 1];
  const cycleLength = estimateCycleLength(entriesAsc);
  const periodLength = periodLengthOf(last);
  const { rangeDays, regularity, sampleCount } = estimateVariability(entriesAsc);
  const daysSince = daysBetween(last.period_start_date, todayStr);
  if (daysSince < 0) return { hasData: false }; // 資料異常 (未來日期)，不推算

  const predictedNextDate = addDays(last.period_start_date, cycleLength);
  const predictedRangeStart = addDays(predictedNextDate, -rangeDays);
  const predictedRangeEnd = addDays(predictedNextDate, rangeDays);

  const base = {
    hasData: true,
    hasEnoughDataForAvg: entriesAsc.length >= MIN_ENTRIES_FOR_AVG,
    cycleLength,
    daysSinceLastPeriod: daysSince,
    predictedNextDate,
    predictedRangeStart,
    predictedRangeEnd,
    rangeDays,
    regularity, // 'regular' | 'medium' | 'variable' | null (紀錄不夠多)
    regularitySampleCount: sampleCount,
  };

  // ---- 太久沒記錄：遲到超過 3 週，比較可能是忘了記而不是真的還沒來，推算暫停 ----
  if (daysSince >= cycleLength + LATE_MAX_DAYS) {
    return {
      ...base,
      isStale: true,
      isLate: false,
      phase: 'stale',
      isPmsWindow: false,
      isFertileWindow: false,
      fertileWindowValid: false,
      daysLate: daysSince - cycleLength,
    };
  }

  // ---- 遲到：過了預估日期還沒有新紀錄。不再用取餘數假裝新週期開始 ----
  if (daysSince >= cycleLength) {
    return {
      ...base,
      isLate: true,
      isStale: false,
      phase: 'late',
      isPmsWindow: false,
      daysLate: daysSince - cycleLength,
      // 遲到期間排卵/易孕期推算已經失準 (這個週期實際比預估長，排卵日不知道往後挪了多少)，
      // 誠實標記為無效，前端就不會再顯示一個看起來很確定其實已經不準的日期範圍。
      isFertileWindow: false,
      fertileWindowValid: false,
    };
  }

  // ---- 正常範圍內：跟以前一樣分階段，但不再需要取餘數 (daysSince < cycleLength 保證合法) ----
  const { phase, isPmsWindow } = classifyPhase(daysSince, cycleLength, periodLength);
  const daysUntilNextPeriod = cycleLength - daysSince;

  // 易孕期 (估算)：排卵日前後最容易受孕的一段時間，抓「排卵日往前 5 天到排卵日隔天」這個
  // 常見的估算範圍 (精子存活+卵子存活的粗略區間)，跟經期預測用同一套週期長度估算邏輯。
  // 這一樣是概略估算，不是排卵試紙/基礎體溫這種精確方法，僅供參考。
  const ovulationDay = Math.max(periodLength + 1, cycleLength - 14);
  const ovulationDate = addDays(last.period_start_date, ovulationDay);
  const fertileWindowStart = addDays(ovulationDate, -5);
  const fertileWindowEnd = addDays(ovulationDate, 1);
  const isFertileWindow = todayStr >= fertileWindowStart && todayStr <= fertileWindowEnd;

  // v0.83：「撐過一次不容易的週期」的被動認可——完全不需要任何人多做什麼，純粹從已經
  // 記錄的資料算出來。如果現在剛進入新的月經期(這次記錄的頭幾天內)，而且「上一段週期」
  // (上上次開始日到上次開始日的間隔) 比在那之前估算出來的平均週期明顯長一截，代表她剛
  // 經歷過一次比平常久的等待(對應到陪伴的人來說，很可能就是前一版加的「遲到」狀態)——
  // 現在她的新週期已經開始了，這件事值得被溫和地點出來，不用特地去翻歷史紀錄才看得到。
  let justEndedLongCycle = false;
  let justEndedLongCycleDays = 0;
  if (phase === 'menstrual' && entriesAsc.length >= 3) {
    const secondLast = entriesAsc[entriesAsc.length - 2];
    const lastGap = daysBetween(secondLast.period_start_date, last.period_start_date);
    const priorEntries = entriesAsc.slice(0, -1); // 不含這次剛結束的間隔，避免自己拉高自己的基準
    const priorAvg = estimateCycleLength(priorEntries);
    if (lastGap > 0 && lastGap - priorAvg >= 5) {
      justEndedLongCycle = true;
      justEndedLongCycleDays = lastGap - priorAvg;
    }
  }

  return {
    ...base,
    isLate: false,
    isStale: false,
    phase,
    isPmsWindow,
    daysUntilNextPeriod,
    nextPeriodDate: predictedNextDate,
    ovulationDateEstimate: ovulationDate,
    fertileWindowStart,
    fertileWindowEnd,
    isFertileWindow,
    fertileWindowValid: true,
    justEndedLongCycle,
    justEndedLongCycleDays,
  };
}

// v0.83：症狀模式——完全被動，讀已經記錄的資料，不需要任何人多記錄什麼。symptoms 欄位存的
// 是「勾選的標籤 + 自己打的備註」用逗號接起來的字串 (見 mood.js 的 POST /cycle)，這裡只統計
// 「已知標籤」出現的次數，忽略自由文字備註 (那些是私人觀察，不該被當統計資料處理，也可能
// 洩漏跟症狀無關的內容)。至少要有 MIN_SYMPTOM_SAMPLES 筆記錄才回傳，資料太少的話統計出來
// 的「最常見」沒有意義，還可能誤導。
const MIN_SYMPTOM_SAMPLES = 3;
function topSymptoms(entriesWithSymptoms, knownTags, limit = 3) {
  const knownSet = new Set(knownTags);
  const counts = {};
  let taggedEntryCount = 0;
  entriesWithSymptoms.forEach((e) => {
    if (!e.symptoms) return;
    const parts = String(e.symptoms).split(',').map((s) => s.trim()).filter((s) => knownSet.has(s));
    if (!parts.length) return;
    taggedEntryCount += 1;
    parts.forEach((p) => { counts[p] = (counts[p] || 0) + 1; });
  });
  if (taggedEntryCount < MIN_SYMPTOM_SAMPLES) return { hasEnoughData: false, sampleCount: taggedEntryCount, top: [] };
  const top = Object.entries(counts)
    .filter(([, count]) => count >= 2) // 只出現過一次的不列入「最常見」，避免單一離群值被誤讀成模式
    .sort((a, b) => b[1] - a[1])
    .slice(0, limit)
    .map(([symptom, count]) => ({ symptom, count }));
  return { hasEnoughData: top.length > 0, sampleCount: taggedEntryCount, top };
}

// 給模式分析用：估算「過去某一天」落在哪個階段 (用當時最接近的那段週期實際長度，比較準)
function phaseForDate(entriesAsc, dateStr) {
  if (!entriesAsc.length) return null;
  // 找出 <= dateStr 的最後一筆 period_start_date
  let idx = -1;
  for (let i = 0; i < entriesAsc.length; i++) {
    if (entriesAsc[i].period_start_date <= dateStr) idx = i;
    else break;
  }
  if (idx === -1) return null; // 這天在第一筆紀錄之前，沒有足夠資訊推算

  const start = entriesAsc[idx];
  const next = entriesAsc[idx + 1];
  const cycleLength = next ? daysBetween(start.period_start_date, next.period_start_date) : estimateCycleLength(entriesAsc);
  const periodLength = periodLengthOf(start);
  const daysSince = daysBetween(start.period_start_date, dateStr);
  if (daysSince < 0 || daysSince > 90) return null;

  const { phase } = classifyPhase(daysSince, Math.max(cycleLength, periodLength + 1), periodLength);
  return phase;
}

module.exports = { estimateCycleLength, estimateVariability, currentStatus, phaseForDate, topSymptoms, PMS_WINDOW_DAYS };
