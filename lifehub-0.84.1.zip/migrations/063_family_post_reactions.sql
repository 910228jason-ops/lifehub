-- v0.84.0：家庭公告欄的輕量反應。
--
-- 背景：討論「雙向的小回饋」這個需求時發現，家庭公告欄本來就可以讓另一半留言給你，
-- 不需要另外做一套「回饋」機制；但留言板現在只有「打字發公告」一種互動方式，對方沒力氣
-- 打字的時候就什麼都留不下——這正是我們不希望在陪伴者這邊發生的事，同樣不該發生在
-- 被陪伴的人身上。所以這裡補的是「不用打字也能留下一點什麼」的最小回應，跟現有公告欄
-- 共用同一個「圈子」範圍，不是另一套系統。
--
-- 一個人對一則貼文只能留一個反應 (UNIQUE)，選新的會直接取代舊的，不是疊加——這只是
-- 「我看到了、我在乎」的輕量表態，不是要做成社群按讚數的競賽。
CREATE TABLE IF NOT EXISTS family_post_reactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  post_id INTEGER NOT NULL REFERENCES family_posts(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  emoji TEXT NOT NULL,
  created_at TEXT NOT NULL,
  UNIQUE(post_id, user_id)
);
CREATE INDEX IF NOT EXISTS idx_family_post_reactions_post ON family_post_reactions(post_id);
