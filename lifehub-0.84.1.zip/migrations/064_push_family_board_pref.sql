-- v0.84.0：家庭公告欄新貼文的推播提醒開關，比照生日/另一半週期/自我照顧提醒同一套
-- 「預設關閉、使用者自己決定要不要推播」的做法。
ALTER TABLE user_prefs ADD COLUMN push_family_board_reminders INTEGER NOT NULL DEFAULT 0;
