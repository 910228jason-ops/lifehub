// 背景推播通知 (Web Push) 的 HTTP 端點 + 背景排程。
//
// 端點有四支：
//   GET  /push/vapid-public-key —— 前端訂閱時要帶的公鑰 (公開資訊，不需要登入也能拿)
//   POST /push/subscribe        —— 前端把瀏覽器 PushManager.subscribe() 拿到的訂閱資訊存起來
//   POST /push/unsubscribe      —— 使用者關閉通知時，刪掉這筆訂閱
//   POST /push/test             —— 立刻送一則測試通知給自己，不用等背景排程 (最長 30 分鐘)
//                                   才能確認手機/電腦真的收得到，方便剛開通時馬上驗證
//
// 背景排程 (每 30 分鐘跑一次)：對每個「至少有一筆有效訂閱」的使用者，重複使用
// insights.js 的 computeReminders() 算出目前有哪些提醒，跟上次送過的內容比對
// (push_notify_log)，內容有變化、或超過 24 小時沒送過，才真的推播一次，
// 避免同樣的事情反覆打擾使用者。
//
// 跟 feedback.js / insights.js 一樣，這裡不另外掛 app.mount()，而是被 debug.js
// 合併進已經掛在 /api 的 router，所以路徑實際上是 /api/push/*。
// 排程本身則放在這個檔案的最外層 (module 第一次被 require 時就啟動)，這樣完全
// 不用碰 server.js，跟這個專案「刻意不去動 server.js」的部署方式一致。

const { Router } = require('../mini-http');
const { getDb } = require('../services/db');
const { requireAuth } = require('../middleware/auth');
const { getOrCreateVapidKeys, sendNotification } = require('../services/webpush');
const insights = require('./insights');
const logger = require('../services/logger');

const router = Router();

router.get('/push/vapid-public-key', (req, res) => {
  const db = getDb();
  const { publicKeyB64 } = getOrCreateVapidKeys(db);
  res.json({ publicKey: publicKeyB64 });
});

router.post('/push/subscribe', requireAuth, (req, res) => {
  const { endpoint, keys } = req.body || {};
  if (!endpoint || !keys || !keys.p256dh || !keys.auth) {
    return res.status(400).json({ error: '缺少訂閱資訊 (endpoint/keys)' });
  }
  const db = getDb();
  const now = new Date().toISOString();
  db.prepare(
    `INSERT INTO push_subscriptions (user_id, endpoint, p256dh, auth, created_at)
     VALUES (?, ?, ?, ?, ?)
     ON CONFLICT(endpoint) DO UPDATE SET user_id = excluded.user_id, p256dh = excluded.p256dh, auth = excluded.auth`
  ).run(req.session.userId, endpoint, keys.p256dh, keys.auth, now);
  res.json({ ok: true });
});

router.post('/push/unsubscribe', requireAuth, (req, res) => {
  const { endpoint } = req.body || {};
  const db = getDb();
  if (endpoint) {
    db.prepare('DELETE FROM push_subscriptions WHERE user_id = ? AND endpoint = ?').run(req.session.userId, endpoint);
  } else {
    db.prepare('DELETE FROM push_subscriptions WHERE user_id = ?').run(req.session.userId);
  }
  res.json({ ok: true });
});

router.post('/push/test', requireAuth, async (req, res) => {
  const db = getDb();
  const subs = db.prepare('SELECT * FROM push_subscriptions WHERE user_id = ?').all(req.session.userId);
  if (!subs.length) {
    return res.status(400).json({ error: '目前沒有已訂閱的裝置，請先按「開啟背景推播通知」' });
  }
  const results = [];
  for (const sub of subs) {
    try {
      const r = await sendNotification(db, sub, {
        title: 'LifeHub 測試通知',
        body: '收到這則就代表背景推播設定成功了 🎉',
      });
      results.push({ ok: r.ok, status: r.status });
      if (!r.ok && (r.status === 404 || r.status === 410)) {
        db.prepare('DELETE FROM push_subscriptions WHERE id = ?').run(sub.id);
      }
    } catch (e) {
      logger.error('[push] 測試推播失敗', { userId: req.session.userId, message: e.message });
      results.push({ ok: false, error: e.message });
    }
  }
  const anyOk = results.some((r) => r.ok);
  res.json({ ok: anyOk, results });
});

// ---- 背景排程：每 30 分鐘算一次每個使用者的提醒，內容有變或超過 24hr 才推播 ----
const CHECK_INTERVAL_MS = 30 * 60 * 1000;
const HEARTBEAT_MS = 24 * 60 * 60 * 1000;

async function runNotifyCycle() {
  const db = getDb();
  let userIds = [];
  try {
    userIds = db.prepare('SELECT DISTINCT user_id FROM push_subscriptions').all().map((r) => r.user_id);
  } catch (e) {
    return; // migration 還沒套用/資料表不存在時直接跳過，等下一輪
  }

  for (const userId of userIds) {
    try {
      const items = insights.computeReminders(db, userId);
      if (!items.length) continue;

      const signature = JSON.stringify(items.map((i) => `${i.severity}:${i.text}`));
      const logRow = db.prepare('SELECT * FROM push_notify_log WHERE user_id = ?').get(userId);
      const now = Date.now();
      const lastSentAt = logRow && logRow.last_sent_at ? new Date(logRow.last_sent_at).getTime() : 0;
      const sameAsLast = logRow && logRow.last_signature === signature;
      if (sameAsLast && now - lastSentAt < HEARTBEAT_MS) continue; // 內容沒變、還沒到 24hr，不重複打擾

      const top = items.slice(0, 3);
      const title = items.length > 1 ? `LifeHub：${items.length} 件事需要留意` : 'LifeHub 提醒';
      const body = top.map((i) => `${i.icon || ''} ${i.text}`).join('\n');

      const subs = db.prepare('SELECT * FROM push_subscriptions WHERE user_id = ?').all(userId);
      for (const sub of subs) {
        try {
          const result = await sendNotification(db, sub, { title, body });
          if (!result.ok && (result.status === 404 || result.status === 410)) {
            // 訂閱已經失效 (裝置解除訂閱/清過瀏覽器資料)，清掉這筆，避免每次排程都白跑一趟
            db.prepare('DELETE FROM push_subscriptions WHERE id = ?').run(sub.id);
          }
        } catch (e) {
          logger.error('[push] 推播失敗', { userId, message: e.message });
        }
      }

      const nowIso = new Date().toISOString();
      db.prepare(
        `INSERT INTO push_notify_log (user_id, last_signature, last_sent_at) VALUES (?, ?, ?)
         ON CONFLICT(user_id) DO UPDATE SET last_signature = excluded.last_signature, last_sent_at = excluded.last_sent_at`
      ).run(userId, signature, nowIso);
    } catch (e) {
      logger.error('[push] 計算提醒失敗', { userId, message: e.message });
    }
  }
}

// ---- 精準時間提醒 (待辦事項的 remind_at)：例如跟 AI 助理說「2分鐘後提醒我裝水」----
// 跟上面「每 30 分鐘、內容有變才推播」的日常提醒邏輯不同，這裡要「準時」——每 15 秒掃一次
// 全部使用者裡「到期但還沒推播過」的任務 (remind_at <= 現在 AND remind_sent_at IS NULL)，
// 時間一到就立刻推播，不受內容比對/24小時節流限制 (使用者明確要求的一次性提醒，本來就該準時)。
const REMINDER_CHECK_INTERVAL_MS = 15 * 1000;

async function runTaskReminderCycle() {
  const db = getDb();
  let dueTasks = [];
  try {
    const nowIso = new Date().toISOString();
    dueTasks = db
      .prepare('SELECT * FROM tasks WHERE remind_at IS NOT NULL AND remind_sent_at IS NULL AND remind_at <= ? AND completed = 0')
      .all(nowIso);
  } catch (e) {
    return; // migration 還沒套用/資料表欄位不存在時直接跳過，等下一輪
  }
  if (!dueTasks.length) return;

  for (const task of dueTasks) {
    try {
      const subs = db.prepare('SELECT * FROM push_subscriptions WHERE user_id = ?').all(task.user_id);
      for (const sub of subs) {
        try {
          const result = await sendNotification(db, sub, {
            title: '⏰ LifeHub 提醒',
            body: task.title,
          });
          if (!result.ok && (result.status === 404 || result.status === 410)) {
            db.prepare('DELETE FROM push_subscriptions WHERE id = ?').run(sub.id);
          }
        } catch (e) {
          logger.error('[push] 精準提醒推播失敗', { taskId: task.id, message: e.message });
        }
      }
      // 就算使用者目前沒有任何有效訂閱 (例如還沒開啟背景推播)，還是要蓋上 remind_sent_at，
      // 不然這筆任務會被每 15 秒重複掃到、無限空跑；待辦事項本身仍然會照常留在清單上。
      db.prepare('UPDATE tasks SET remind_sent_at = ? WHERE id = ?').run(new Date().toISOString(), task.id);
    } catch (e) {
      logger.error('[push] 精準提醒處理失敗', { taskId: task.id, message: e.message });
    }
  }
}

// ---- 服藥提醒：health_meds.schedule_time 一直存在資料庫裡但沒有真的接上推播，這裡補上 ----
// 每分鐘掃一次「有設定服用時間、還在使用中」的藥，時間對上現在的 HH:MM 就推播，
// 用 health_med_reminder_log 記錄「這顆藥今天推播過了沒」避免同一天重複打擾。
// 如果當天已經打勾吃過了 (health_med_logs)，就不用再推播提醒，但一樣要標記成「今天處理過」，
// 不然接下來每分鐘都會重新判斷一次「已服用不用推播」，白白浪費查詢。
const MED_REMINDER_CHECK_INTERVAL_MS = 60 * 1000;

function normalizeTimeHHMM(t) {
  if (!t) return null;
  const m = String(t).trim().match(/^(\d{1,2}):(\d{2})/);
  if (!m) return null;
  return `${m[1].padStart(2, '0')}:${m[2]}`;
}

async function runMedReminderCycle() {
  const db = getDb();
  let meds = [];
  try {
    meds = db.prepare("SELECT * FROM health_meds WHERE active = 1 AND schedule_time IS NOT NULL AND schedule_time != ''").all();
  } catch (e) {
    return; // migration 還沒套用/資料表不存在時直接跳過，等下一輪
  }
  if (!meds.length) return;

  const now = new Date();
  const hhmm = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
  const today = now.toISOString().slice(0, 10);
  const nowIso = now.toISOString();

  for (const med of meds) {
    try {
      if (normalizeTimeHHMM(med.schedule_time) !== hhmm) continue;
      const already = db.prepare('SELECT 1 FROM health_med_reminder_log WHERE med_id = ? AND sent_date = ?').get(med.id, today);
      if (already) continue;

      const takenLog = db.prepare('SELECT taken FROM health_med_logs WHERE med_id = ? AND log_date = ?').get(med.id, today);
      if (!(takenLog && takenLog.taken)) {
        const subs = db.prepare('SELECT * FROM push_subscriptions WHERE user_id = ?').all(med.user_id);
        for (const sub of subs) {
          try {
            const result = await sendNotification(db, sub, {
              title: '💊 服藥提醒',
              body: `該吃「${med.name}」了${med.dose ? '（' + med.dose + '）' : ''}`,
            });
            if (!result.ok && (result.status === 404 || result.status === 410)) {
              db.prepare('DELETE FROM push_subscriptions WHERE id = ?').run(sub.id);
            }
          } catch (e) {
            logger.error('[push] 服藥提醒推播失敗', { medId: med.id, message: e.message });
          }
        }
      }
      db.prepare(
        `INSERT INTO health_med_reminder_log (med_id, sent_date, created_at) VALUES (?, ?, ?)
         ON CONFLICT(med_id, sent_date) DO NOTHING`
      ).run(med.id, today, nowIso);
    } catch (e) {
      logger.error('[push] 服藥提醒處理失敗', { medId: med.id, message: e.message });
    }
  }
}

const medReminderTimer = setInterval(() => {
  runMedReminderCycle().catch((e) => logger.error('[push] 服藥提醒排程執行失敗', { message: e.message }));
}, MED_REMINDER_CHECK_INTERVAL_MS);
medReminderTimer.unref();

// 開機後過一段時間才跑第一次 (避免跟 DB migration/伺服器啟動搶資源)，之後固定間隔重複。
// unref() 讓這個計時器不會阻止 process 正常結束 (例如測試腳本開機後又主動關閉)。
const initialTimer = setTimeout(() => {
  runNotifyCycle().catch((e) => logger.error('[push] 排程執行失敗', { message: e.message }));
  const interval = setInterval(() => {
    runNotifyCycle().catch((e) => logger.error('[push] 排程執行失敗', { message: e.message }));
  }, CHECK_INTERVAL_MS);
  interval.unref();
}, 60 * 1000);
initialTimer.unref();

const reminderTimer = setInterval(() => {
  runTaskReminderCycle().catch((e) => logger.error('[push] 精準提醒排程執行失敗', { message: e.message }));
}, REMINDER_CHECK_INTERVAL_MS);
reminderTimer.unref();

module.exports = router;
