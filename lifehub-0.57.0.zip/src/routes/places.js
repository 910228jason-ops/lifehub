// 地點資料庫 + 「臨時揪一波」快速出遊建議 (v0.55)。
//
// 設計背景：使用者想要「出遊前臨時不知道去哪」時，選地區/氛圍/交通方式，立刻從資料庫
// 抓幾個地點組成建議路線，不滿意就換一批，全程是資料庫查詢，不即時呼叫 AI —— 原因見
// migrations/043_places.sql 開頭的說明：AI 即時生成的方案在額度/成本上撐不住，改用
// 「政府開放資料 + 使用者社群貢獻」的靜態資料庫，查詢免費、沒有次數限制。
//
// 這是全 App 第一個「公開」資料：任何登入的使用者都能看到全部地點、都能新增/評分，
// 不像願望清單/固定行程模板是限定跟已連結的家人共用。新增地點/評分會透過既有的點數
// 系統給獎勵，把「幫忙充實資料庫」變成使用者本來就有動機做的事。

const { Router } = require('../mini-http');
const { getDb } = require('../services/db');
const { requireAuth } = require('../middleware/auth');
const { awardPoints } = require('../services/points');

const router = Router();

const MOOD_TAGS = ['relax', 'food', 'outdoor', 'shopping', 'photo'];
const TRANSPORT_TAGS = ['walk', 'drive', 'bike'];
const REPORT_THRESHOLD = 3; // 累積到這個人數回報「疑似歇業/資訊有誤」，自動轉成待確認狀態

function cleanTagList(raw, validSet) {
  const list = Array.isArray(raw) ? raw : String(raw || '').split(',');
  const cleaned = list.map((t) => String(t || '').trim()).filter((t) => validSet.includes(t));
  return cleaned.length ? `,${[...new Set(cleaned)].join(',')},` : '';
}

function tagsToArray(stored) {
  return String(stored || '')
    .split(',')
    .map((t) => t.trim())
    .filter(Boolean);
}

// 城市名稱正規化：使用者輸入「台北」「台北市」「臺北」「臺北市」在意義上是同一個城市，
// 但如果直接拿去做 SQL 精確比對 (city = ?)，四種寫法會被當成四個不同城市，新增/查詢/
// 「臨時揪一波」都會因為打法不同就查不到已經存在的資料——這正是使用者實際踩到的問題。
// 統一轉成「不帶市/縣後綴、臺一律轉台」的簡短寫法，新增時存這個正規化後的版本，查詢時
// 也一樣正規化再比對，兩邊才會對得上。跟 scripts/import_gov_places.js 的 normalizeCity
// 是同一套規則，之後政府資料匯入進來的城市名稱也會跟現有資料一致。
function normalizeCity(raw) {
  if (!raw) return '';
  let s = String(raw).trim();
  s = s.replace(/臺/g, '台');
  s = s.replace(/(市|縣)$/, '');
  return s;
}

// 幫一筆地點附上評分統計。評分數 < 3 筆的地點標示「評分還太少」，跟心情關聯分析那邊
// 已經用過的「至少 3 筆樣本才顯示」邏輯一致，避免一兩個人的評分就左右別人的判斷。
function withRatingStats(db, place) {
  const stats = db
    .prepare('SELECT COUNT(*) c, COALESCE(AVG(stars), 0) avg FROM place_ratings WHERE place_id = ?')
    .get(place.id);
  return {
    ...place,
    moodTags: tagsToArray(place.mood_tags),
    transportTags: tagsToArray(place.transport_tags),
    ratingCount: stats.c,
    avgRating: stats.c ? Math.round(stats.avg * 10) / 10 : null,
    ratingEnough: stats.c >= 3,
  };
}

router.get('/places', requireAuth, (req, res) => {
  const db = getDb();
  const { city, district, mood, transport, maxDuration, sort } = req.query || {};
  const clauses = ["status = 'active'"];
  const params = [];
  if (city) { clauses.push('city = ?'); params.push(normalizeCity(city)); }
  if (district) { clauses.push('district = ?'); params.push(district); }
  if (mood && MOOD_TAGS.includes(mood)) { clauses.push('mood_tags LIKE ?'); params.push(`%,${mood},%`); }
  if (transport && TRANSPORT_TAGS.includes(transport)) { clauses.push('transport_tags LIKE ?'); params.push(`%,${transport},%`); }
  if (maxDuration) { clauses.push('(visit_duration_min IS NULL OR visit_duration_min <= ?)'); params.push(Number(maxDuration)); }

  const rows = db.prepare(`SELECT * FROM places WHERE ${clauses.join(' AND ')} ORDER BY created_at DESC`).all(...params);
  let enriched = rows.map((p) => withRatingStats(db, p));
  if (sort === 'rating') {
    enriched.sort((a, b) => (b.avgRating || 0) - (a.avgRating || 0) || b.ratingCount - a.ratingCount);
  }
  res.json(enriched);
});

// 給前端做「城市下拉選單」用：只列出資料庫裡實際有資料、還在 active 狀態的城市，
// 使用者只能從真的查得到東西的城市裡選，不會再打錯字或打了資料庫裡沒有的寫法就撲空。
// 這個路由要放在 /places/:id 前面註冊，不然 mini-http 的路由是照註冊順序比對，
// "cities" 會先被 :id 那條規則吃掉，變成在找 id="cities" 的地點。
router.get('/places/cities', requireAuth, (req, res) => {
  const db = getDb();
  const rows = db.prepare(`SELECT city, COUNT(*) c FROM places WHERE status = 'active' GROUP BY city ORDER BY c DESC, city ASC`).all();
  res.json(rows.map((r) => ({ city: r.city, count: r.c })));
});

router.get('/places/:id', requireAuth, (req, res) => {
  const db = getDb();
  const place = db.prepare('SELECT * FROM places WHERE id = ?').get(req.params.id);
  if (!place) return res.status(404).json({ error: '找不到這個地點' });
  const ratings = db
    .prepare(
      `SELECT r.stars, r.note, r.created_at, u.name as user_name FROM place_ratings r
       JOIN users u ON u.id = r.user_id WHERE r.place_id = ? ORDER BY r.created_at DESC LIMIT 20`
    )
    .all(place.id);
  const myRating = db.prepare('SELECT stars, note FROM place_ratings WHERE place_id = ? AND user_id = ?').get(place.id, req.session.userId);
  const reportCount = db.prepare('SELECT COUNT(*) c FROM place_reports WHERE place_id = ?').get(place.id).c;
  res.json({ ...withRatingStats(db, place), ratings, myRating: myRating || null, reportCount });
});

router.post('/places', requireAuth, (req, res) => {
  const { name, city, district, address, moodTags, transportTags, hoursText, feeInfo, visitDurationMin, note } = req.body || {};
  const trimmedName = String(name || '').trim();
  const trimmedCity = normalizeCity(city);
  if (!trimmedName) return res.status(400).json({ error: '請輸入地點名稱' });
  if (!trimmedCity) return res.status(400).json({ error: '請輸入城市' });

  let duration = null;
  if (visitDurationMin !== undefined && visitDurationMin !== null && String(visitDurationMin).trim() !== '') {
    const n = Number(visitDurationMin);
    if (!Number.isFinite(n) || n < 0) return res.status(400).json({ error: '預估停留時間格式不正確' });
    duration = Math.round(n);
  }

  const db = getDb();
  const now = new Date().toISOString();
  const result = db
    .prepare(
      `INSERT INTO places (name, city, district, address, mood_tags, transport_tags, hours_text, fee_info, visit_duration_min, note, source, status, created_by_user_id, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'user', 'active', ?, ?, ?)`
    )
    .run(
      trimmedName,
      trimmedCity,
      (district && String(district).trim()) || null,
      (address && String(address).trim()) || null,
      cleanTagList(moodTags, MOOD_TAGS),
      cleanTagList(transportTags, TRANSPORT_TAGS),
      (hoursText && String(hoursText).trim()) || null,
      (feeInfo && String(feeInfo).trim()) || null,
      duration,
      (note && String(note).trim()) || null,
      req.session.userId,
      now,
      now
    );
  awardPoints(db, req.session.userId, 3, `add_place:${result.lastInsertRowid}`);
  const created = db.prepare('SELECT * FROM places WHERE id = ?').get(result.lastInsertRowid);
  res.json(withRatingStats(db, created));
});

router.put('/places/:id', requireAuth, (req, res) => {
  const db = getDb();
  const place = db.prepare('SELECT * FROM places WHERE id = ?').get(req.params.id);
  if (!place) return res.status(404).json({ error: '找不到這個地點' });
  if (place.created_by_user_id !== req.session.userId) return res.status(403).json({ error: '只有新增這個地點的人可以編輯' });

  const { name, district, address, moodTags, transportTags, hoursText, feeInfo, visitDurationMin, note } = req.body || {};
  const trimmedName = name != null ? String(name).trim() : place.name;
  if (!trimmedName) return res.status(400).json({ error: '請輸入地點名稱' });

  let duration = place.visit_duration_min;
  if (visitDurationMin !== undefined) {
    if (visitDurationMin === null || String(visitDurationMin).trim() === '') {
      duration = null;
    } else {
      const n = Number(visitDurationMin);
      if (!Number.isFinite(n) || n < 0) return res.status(400).json({ error: '預估停留時間格式不正確' });
      duration = Math.round(n);
    }
  }

  db.prepare(
    `UPDATE places SET name = ?, district = ?, address = ?, mood_tags = ?, transport_tags = ?, hours_text = ?, fee_info = ?, visit_duration_min = ?, note = ?, updated_at = ? WHERE id = ?`
  ).run(
    trimmedName,
    district !== undefined ? ((district && String(district).trim()) || null) : place.district,
    address !== undefined ? ((address && String(address).trim()) || null) : place.address,
    moodTags !== undefined ? cleanTagList(moodTags, MOOD_TAGS) : place.mood_tags,
    transportTags !== undefined ? cleanTagList(transportTags, TRANSPORT_TAGS) : place.transport_tags,
    hoursText !== undefined ? ((hoursText && String(hoursText).trim()) || null) : place.hours_text,
    feeInfo !== undefined ? ((feeInfo && String(feeInfo).trim()) || null) : place.fee_info,
    duration,
    note !== undefined ? ((note && String(note).trim()) || null) : place.note,
    new Date().toISOString(),
    place.id
  );
  const updated = db.prepare('SELECT * FROM places WHERE id = ?').get(place.id);
  res.json(withRatingStats(db, updated));
});

router.delete('/places/:id', requireAuth, (req, res) => {
  const db = getDb();
  const place = db.prepare('SELECT * FROM places WHERE id = ?').get(req.params.id);
  if (!place) return res.status(404).json({ error: '找不到這個地點' });
  if (place.created_by_user_id !== req.session.userId) return res.status(403).json({ error: '只有新增這個地點的人可以刪除' });
  db.prepare('DELETE FROM places WHERE id = ?').run(place.id);
  res.json({ ok: true });
});

// 評分：一人一地點一筆，重新評分是覆蓋，不是疊加。只有「第一次」評這個地點才加點數，
// 避免使用者一直改評分刷點數。
router.post('/places/:id/rate', requireAuth, (req, res) => {
  const db = getDb();
  const place = db.prepare('SELECT * FROM places WHERE id = ?').get(req.params.id);
  if (!place) return res.status(404).json({ error: '找不到這個地點' });
  const stars = Number((req.body || {}).stars);
  if (!Number.isInteger(stars) || stars < 1 || stars > 5) return res.status(400).json({ error: '星等要是 1-5 的整數' });
  const note = (req.body && req.body.note) || null;

  const db2 = db;
  const existing = db2.prepare('SELECT id FROM place_ratings WHERE place_id = ? AND user_id = ?').get(place.id, req.session.userId);
  const now = new Date().toISOString();
  if (existing) {
    db2.prepare('UPDATE place_ratings SET stars = ?, note = ?, updated_at = ? WHERE id = ?').run(stars, note, now, existing.id);
  } else {
    db2.prepare('INSERT INTO place_ratings (place_id, user_id, stars, note, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)').run(
      place.id, req.session.userId, stars, note, now, now
    );
    awardPoints(db2, req.session.userId, 1, `rate_place:${place.id}`);
  }
  res.json(withRatingStats(db2, db2.prepare('SELECT * FROM places WHERE id = ?').get(place.id)));
});

router.delete('/places/:id/rate', requireAuth, (req, res) => {
  const db = getDb();
  db.prepare('DELETE FROM place_ratings WHERE place_id = ? AND user_id = ?').run(req.params.id, req.session.userId);
  res.json({ ok: true });
});

// 回報「疑似歇業/資訊有誤」：一人一地點限一筆，累積到門檻自動轉成待確認狀態，
// 從「臨時揪一波」的建議結果中排除 (但地點本身沒有被刪除，詳細頁還是看得到，並標示提醒)。
router.post('/places/:id/report', requireAuth, (req, res) => {
  const db = getDb();
  const place = db.prepare('SELECT * FROM places WHERE id = ?').get(req.params.id);
  if (!place) return res.status(404).json({ error: '找不到這個地點' });
  const existing = db.prepare('SELECT id FROM place_reports WHERE place_id = ? AND user_id = ?').get(place.id, req.session.userId);
  if (existing) return res.status(400).json({ error: '你已經回報過這個地點了' });

  const reason = (req.body && req.body.reason) || null;
  db.prepare('INSERT INTO place_reports (place_id, user_id, reason, created_at) VALUES (?, ?, ?, ?)').run(
    place.id, req.session.userId, reason, new Date().toISOString()
  );
  const reportCount = db.prepare('SELECT COUNT(*) c FROM place_reports WHERE place_id = ?').get(place.id).c;
  if (reportCount >= REPORT_THRESHOLD && place.status === 'active') {
    db.prepare("UPDATE places SET status = 'needs_review', updated_at = ? WHERE id = ?").run(new Date().toISOString(), place.id);
  }
  res.json({ ok: true, reportCount });
});

// 「臨時揪一波」：依地區/氛圍/交通方式篩選，從排名前段的候選裡隨機挑幾個組成建議路線。
// exclude 可以帶上次已經看過的地點 id (逗號分隔)，重抽時盡量不要一直給同樣的組合；
// 候選不夠時才會允許重複，不會直接回傳空結果讓使用者卡住。
router.get('/places/suggest/route', requireAuth, (req, res) => {
  const db = getDb();
  const { city, district, mood, transport, maxDuration, count, exclude } = req.query || {};
  if (!city) return res.status(400).json({ error: '請提供 city' });
  const normalizedCity = normalizeCity(city);

  const clauses = ["status = 'active'", 'city = ?'];
  const params = [normalizedCity];
  if (district) { clauses.push('district = ?'); params.push(district); }
  if (mood && MOOD_TAGS.includes(mood)) { clauses.push('mood_tags LIKE ?'); params.push(`%,${mood},%`); }
  if (transport && TRANSPORT_TAGS.includes(transport)) { clauses.push('transport_tags LIKE ?'); params.push(`%,${transport},%`); }
  if (maxDuration) { clauses.push('(visit_duration_min IS NULL OR visit_duration_min <= ?)'); params.push(Number(maxDuration)); }

  const rows = db.prepare(`SELECT * FROM places WHERE ${clauses.join(' AND ')}`).all(...params);
  const enriched = rows
    .map((p) => withRatingStats(db, p))
    .sort((a, b) => (b.avgRating || 0) - (a.avgRating || 0) || b.ratingCount - a.ratingCount);

  const topPool = enriched.slice(0, 12); // 只從排名前段抽，避免抽到評分墊底的地點
  const excludeIds = new Set(String(exclude || '').split(',').map((s) => Number(s)).filter(Boolean));
  let candidates = topPool.filter((p) => !excludeIds.has(p.id));
  if (!candidates.length) candidates = topPool; // 候選被排除光了就重置，不要回傳空結果

  // Fisher-Yates 洗牌，從候選裡隨機挑幾個，讓「重抽」每次感覺不一樣，不是死板地永遠回同一批。
  const shuffled = [...candidates];
  for (let i = shuffled.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  const wantCount = Math.max(1, Math.min(6, Number(count) || 3));
  res.json({ route: shuffled.slice(0, wantCount), totalCandidates: enriched.length });
});

module.exports = router;
