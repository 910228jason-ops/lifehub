// LifeHub 背景推播用的 Service Worker。
//
// 這支檔案只做一件事：接住瀏覽器/系統送進來的 push 事件 (螢幕熄滅、App 沒開著也收得到)，
// 把伺服器加密送來的內容 (見 src/services/webpush.js) 解密還原成 JSON 後，用
// `registration.showNotification()` 顯示成系統通知；點下去就把使用者帶回 App。
//
// 沒有做離線快取 (App Shell caching) ——這個 App 本來就需要連線才能用 (要打 API)，
// 離線快取對這個專案目前沒有實際幫助，先不做，避免多一層「快取到舊版檔案」的風險。

self.addEventListener('install', (event) => {
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(self.clients.claim());
});

self.addEventListener('push', (event) => {
  let data = { title: '提醒', body: '有新的提醒，點開看看' };
  try {
    if (event.data) data = event.data.json();
  } catch (e) {
    try { data.body = event.data.text(); } catch (e2) { /* 忽略，用預設值 */ }
  }

  event.waitUntil(
    self.registration.showNotification(data.title || '提醒', {
      body: data.body || '',
      icon: data.icon || '/icons/icon-192.png',
      badge: '/icons/icon-192.png',
      tag: 'lifehub-reminder', // 同一個 tag：新的提醒進來時取代舊的，通知欄不會愈疊愈多
      renotify: true,
    })
  );
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientsList) => {
      for (const client of clientsList) {
        if ('focus' in client) return client.focus();
      }
      if (self.clients.openWindow) return self.clients.openWindow('/');
    })
  );
});
