// 誰是「管理者」(能看到所有使用者送出的意見回饋)。
// 用 email 判斷即可 (使用者本來就要用自己的帳號密碼登入，不需要另外設一組管理者密碼、
// 也不用把個人帳密交給別人管理)。預設寫死成專案擁有者的 email，若之後要換人，
// 用環境變數 ADMIN_EMAIL 覆蓋即可，不用改程式碼。
const ADMIN_EMAIL = (process.env.ADMIN_EMAIL || '910228jason@gmail.com').toLowerCase();

function isAdminEmail(email) {
  return !!email && String(email).toLowerCase() === ADMIN_EMAIL;
}

module.exports = { ADMIN_EMAIL, isAdminEmail };
