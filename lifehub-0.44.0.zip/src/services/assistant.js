// AI 助理：把使用者在「AI 助理」頁籤打的訊息，轉發給 AI 供應商取得回覆。
//
// 支援兩種供應商 (擇一設定即可)：
//   1. Google Gemini (推薦，有免費額度、不需要信用卡)：
//      前往 https://aistudio.google.com/app/apikey 用 Google 帳號免費申請一組 API Key，
//      貼到環境變數 GEMINI_API_KEY。
//   2. Anthropic Claude (品質最好，但採用量計費，需要信用卡)：
//      前往 https://console.anthropic.com 申請 API Key，貼到環境變數 ANTHROPIC_API_KEY。
// 兩個都沒設定時，這個功能會回傳清楚的申請教學而不是報錯崩潰；兩個都有設定時，
// 優先使用 Gemini (免費)。
//
// 這裡只做「最簡單的單輪/多輪對話轉發」，把使用者這支 App 的定位 (生活小幫手：
// 股票資訊、交通旅遊、日記、記帳、聊天、翻譯、生活建議等) 放進 system prompt，
// 讓回覆的語氣貼近這個 App 的助理人設；之後可以依需求擴充成「不同模式」
// (面試練習/翻譯/技術說明等)，只要調整 system prompt 或允許前端傳入不同模式參數即可。

const logger = require('./logger');

// 「AI 幫忙加待辦事項」——刻意不用各家供應商各自的 function-calling / tool-use API
// (Gemini、Anthropic 兩邊格式不一樣，維護成本較高)，改用最簡單、任何文字模型都能做到的
// 方式：請模型在判斷使用者是「想要被加進待辦清單的一件具體事情」時，在回覆的最後面
// 額外加一行固定格式的標記；前端 (assistant.js route) 會把這行標記從顯示文字中拆掉，
// 轉成一張「加入待辦事項？」的確認卡片，使用者按確認才會真的呼叫建立任務的 API——
// 絕對不會沒經過使用者同意就自動新增。
const TASK_SUGGESTION_MARKER = 'TASK_SUGGESTION';
const TASK_SUGGESTION_INSTRUCTION = `如果，且只有在使用者的訊息裡明確提到一件「之後要做、值得被記錄成待辦事項」的具體事情
(例如「幫我提醒我禮拜五要交報告」「記得下週三要回診」)，或是要求「在某個時間點之後提醒我做什麼事」
(例如「2分鐘後提醒我裝水」「30秒後提醒我」「1小時後叫我」)，才在你原本要回覆的內容「最後面另起一行」，
加上這個格式的標記 (使用者不會看到這行原始文字，會被轉換成一張確認卡片)：
[[${TASK_SUGGESTION_MARKER}: 待辦標題||YYYY-MM-DD 或留空||秒數 或留空]]
- 第一欄 (標題)：用你判斷最合適、精簡的敘述即可 (例如「裝水」「交報告」)，必填。
- 第二欄 (日期)：只有使用者提到明確的「哪一天」才填 YYYY-MM-DD，沒提到就留空，不要亂猜日期。
- 第三欄 (秒數)：只有使用者要求「在某個時間之後提醒我」這種需要準時跳出通知的情況才填，
  換算成「幾秒之後」的整數 (例如「2分鐘後」= 120，「30秒後」= 30，「1小時後」= 3600)；
  單純記錄待辦、沒有要求準時提醒的話，這欄留空，不要自己加。
兩欄可以都留空、也可以都填，依使用者實際說的內容判斷，不要自己延伸沒說過的細節。
如果使用者只是在閒聊、問問題、或沒有明確想被記錄的具體待辦，就完全不要加這行標記。
一次回覆最多只加一個標記。`;

// v0.40 新增：使用者反應希望這個助理只用在「日常生活/協助」這個定位上，不要被拿去做
// 產圖之類、跟這個 App 無關的用途。技術上這裡串接的是純文字的 Gemini generateContent
// API，本來就沒有接圖片/影片/語音生成的能力 (不管使用者怎麼問，都不可能真的生出圖片)，
// 但還是明確加這段界線，一來讓 AI 用清楚的話回應「這裡不支援」、不要含糊其辭讓使用者誤會
// 是暫時故障，二來避免使用者反覆換句話試探 (每次嘗試都是一次白白浪費的 API 呼叫)。
const SCOPE_BOUNDARY_INSTRUCTION = `你只支援純文字對話，沒有、也不能產生圖片、圖像、影片、音訊或任何非文字檔案。
如果使用者要求「畫一張圖」「產生/生成圖片」「做一段影片」「用 AI 生圖」之類的要求，
請直接、清楚地告訴他這裡不支援圖片/影片/語音生成，只能用文字幫忙 (不要含糊帶過或假裝在做)，
可以順便建議他改用其他有畫圖功能的工具，並詢問要不要換個文字能幫得上忙的方向。
同樣地，如果使用者的要求明顯跟「日常生活協助」無關 (例如要你生成大量無意義內容、寫病毒/攻擊性程式碼、
或其他惡意用途)，也請婉拒並簡短說明這裡是生活小幫手，不適合處理這類請求。`;

const SYSTEM_PROMPT = `你是 LifeHub 這款生活整合 App 內建的 AI 助理，個性親切、有效率。
使用者可能會問你：日常聊天、練習面試、幫忙想怎麼回訊息、分析對話、給不同角度建議、
規劃旅遊行程、安排待辦事項、健身飲食規劃、比較商品、推薦餐廳、找食譜、單位換算、
電腦軟體問題、股票法人買賣分析、新聞整理、技術面/基本面解釋、風險分析、多語言翻譯等。
請用繁體中文回答(除非使用者要求翻譯成其他語言)，語氣自然、簡潔，避免不必要的長篇大論。
如果使用者問的是投資建議，提醒你只能提供參考資訊、不是專業投資建議。

${SCOPE_BOUNDARY_INSTRUCTION}

${TASK_SUGGESTION_INSTRUCTION}`;

function getProvider() {
  if (process.env.GEMINI_API_KEY) return 'gemini';
  if (process.env.ANTHROPIC_API_KEY) return 'anthropic';
  return null;
}

function isConfigured() {
  return getProvider() !== null;
}

async function fetchWithTimeout(url, opts = {}, timeoutMs = 30000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, { ...opts, signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}

async function chatWithGemini(history, systemPrompt) {
  const contents = history
    .filter((m) => m && m.content && m.content.trim())
    .map((m) => ({ role: m.role === 'assistant' ? 'model' : 'user', parts: [{ text: m.content }] }));

  const model = process.env.GEMINI_MODEL || 'gemini-2.0-flash';
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${process.env.GEMINI_API_KEY}`;
  const res = await fetchWithTimeout(url, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({
      systemInstruction: { parts: [{ text: systemPrompt || SYSTEM_PROMPT }] },
      contents,
    }),
  });

  if (!res.ok) {
    const errText = await res.text().catch(() => '');
    logger.error('Gemini API 呼叫失敗', { status: res.status, body: errText.slice(0, 500) });
    throw new Error(`AI 助理呼叫失敗: HTTP ${res.status}`);
  }
  const json = await res.json();
  const parts = (json.candidates && json.candidates[0] && json.candidates[0].content && json.candidates[0].content.parts) || [];
  const reply = parts.map((p) => p.text || '').join('\n').trim();
  return { isConfigured: true, reply: reply || '(沒有取得回覆內容，可能是被安全過濾擋下，換個問法試試看)' };
}

async function chatWithAnthropic(history, systemPrompt) {
  const messages = history
    .filter((m) => m && m.content && m.content.trim())
    .map((m) => ({ role: m.role === 'assistant' ? 'assistant' : 'user', content: m.content }));

  const res = await fetchWithTimeout('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      'x-api-key': process.env.ANTHROPIC_API_KEY,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model: process.env.ANTHROPIC_MODEL || 'claude-3-5-haiku-20241022',
      max_tokens: 1024,
      system: systemPrompt || SYSTEM_PROMPT,
      messages,
    }),
  });

  if (!res.ok) {
    const errText = await res.text().catch(() => '');
    logger.error('Anthropic API 呼叫失敗', { status: res.status, body: errText.slice(0, 500) });
    throw new Error(`AI 助理呼叫失敗: HTTP ${res.status}`);
  }
  const json = await res.json();
  const reply = (json.content || []).map((b) => b.text || '').join('\n').trim();
  return { isConfigured: true, reply: reply || '(沒有取得回覆內容)' };
}

// 從回覆文字裡拆出 [[TASK_SUGGESTION: 標題||日期||秒數]] 標記 (如果有的話)，回傳
// { reply: 拆掉標記後給使用者看的文字, suggestedTask: {title, dueDate, remindAt} 或 null }。
// 用寬鬆的 regex (標記前後允許有空白/換行，日期跟秒數兩欄都各自獨立為可省略的區塊) 是因為
// 不同模型有時候格式會有些微差異 (例如舊格式只有兩欄、或某一欄空白時多打/少打一組 ||)。
const TASK_SUGGESTION_RE = new RegExp(
  `\\n?\\s*\\[\\[${TASK_SUGGESTION_MARKER}:\\s*([^|]+?)\\s*` +
  `(?:\\|\\|\\s*([0-9]{4}-[0-9]{2}-[0-9]{2})?\\s*)?` +
  `(?:\\|\\|\\s*([0-9]+)?\\s*)?` +
  `\\]\\]\\s*$`
);

// 秒數上限一天，避免模型換算錯誤 (或誤解成「幾天後」) 排出超大數字時，提醒被排到不合理的遙遠未來。
const MAX_REMINDER_SECONDS = 24 * 60 * 60;

function extractTaskSuggestion(replyText) {
  const text = String(replyText || '');
  const m = text.match(TASK_SUGGESTION_RE);
  if (!m) return { reply: text, suggestedTask: null };
  const title = m[1].trim();
  const dueDate = (m[2] || '').trim() || null;
  const secondsRaw = (m[3] || '').trim();
  if (!title) return { reply: text, suggestedTask: null };

  let remindAt = null;
  if (secondsRaw) {
    const secs = Math.min(Math.max(1, Number(secondsRaw) || 0), MAX_REMINDER_SECONDS);
    if (secs > 0) remindAt = new Date(Date.now() + secs * 1000).toISOString();
  }
  // 沒有明講日期、但有精準提醒時間的話，待辦事項的到期日就用提醒當天，這樣待辦清單上看起來才合理
  const resolvedDueDate = dueDate || (remindAt ? remindAt.slice(0, 10) : null);

  return { reply: text.slice(0, m.index).trim(), suggestedTask: { title, dueDate: resolvedDueDate, remindAt } };
}

// history: [{role: 'user'|'assistant', content: string}, ...]，最後一筆是使用者這次的新訊息
// opts.systemPrompt：可覆寫預設的助理人設 (例如心情陪伴模式用不同語氣與界線)
async function chat(history, opts = {}) {
  const provider = getProvider();
  if (!provider) {
    return {
      isConfigured: false,
      reply:
        '尚未設定 AI 助理的 API 金鑰。免費方案：前往 https://aistudio.google.com/app/apikey ' +
        '用 Google 帳號登入即可免費申請一組 Gemini API Key (不需要信用卡)，' +
        '貼到環境變數 GEMINI_API_KEY 後重新部署，就可以開始聊天了。',
    };
  }
  const result = provider === 'gemini'
    ? await chatWithGemini(history, opts.systemPrompt)
    : await chatWithAnthropic(history, opts.systemPrompt);

  if (result && result.reply) {
    const { reply, suggestedTask } = extractTaskSuggestion(result.reply);
    return { ...result, reply, suggestedTask };
  }
  return result;
}

function healthcheck() {
  const provider = getProvider();
  return provider ? { ok: true, provider } : { ok: false, reason: '未設定 GEMINI_API_KEY 或 ANTHROPIC_API_KEY' };
}

module.exports = { chat, isConfigured, healthcheck };
