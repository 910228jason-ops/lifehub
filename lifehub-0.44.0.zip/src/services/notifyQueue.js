// 推播的「靜音時段」+「短時間內合併成一則」共用邏輯。
//
// 背景：三支獨立的排程 (一般提醒/精準待辦提醒/服藥提醒，見 routes/push.js) 原本各自算好
// 內容就直接對每個訂閱裝置送出，彼此互不知道對方的存在。使用者實際使用時的抱怨是「連續跳出
// 好幾則通知，很有轟炸感」——例如同一分鐘內剛好待辦提醒跟服藥提醒都到期，就會连續跳兩則。
// 這支檔案提供一個所有推播來源都要經過的共用出口 queueNotification()，依「urgent」分兩條
// 完全不同的路徑處理：
//
//   1. 非緊急 (urgent: false)——使用者自己沒有指定精準時間的被動提醒 (帳單快到期/待辦逾期/
//      好幾天沒記心情/生日/另一半生理週期)：
//      - 靜音時段 (晚上 11 點到早上 10 點) 直接跳過，等隔天早上再看，不用半夜跳出來吵醒人。
//      - 沒被靜音時段擋下的話，會先進 90 秒的收集佇列，等收集窗結束後把同一個使用者這段
//        時間內累積的多筆非緊急通知「合併成一則」送出 (多筆時標題變成「X 則新提醒」)，
//        避免同一時段內好幾個被動提醒各自跳出來轟炸。
//   2. 緊急 (urgent: true)——使用者自己明確設定精準時間的待辦提醒、服藥提醒：這是使用者
//      主動要求「在這個時間點通知我」的內容，所以：
//      - 不受靜音時段限制 (吃藥時間就是設在半夜也照樣準時提醒)。
//      - 也「不」跟其他通知合併——使用者是特別為了這件事設定提醒，應該獨立、完整地顯示
//        (標題就是這件事本身)，不能被埋進「3 則新提醒」這種合併通知裡讓人抓不到重點，
//        所以緊急通知一律立刻各自送出，即使剛好跟別的緊急通知同一分鐘觸發也一樣。
//
// 三支排程只需要把「直接迴圈訂閱裝置送出」改成呼叫 queueNotification()，其餘 (加密、簽章、
// 失效訂閱清除) 都還是 webpush.js 負責，這裡只管「什麼時候送、送幾則」。

const logger = require('./logger');
const { sendNotification } = require('./webpush');

const BUNDLE_WINDOW_MS = 90 * 1000; // 90 秒內的「非緊急」通知合併成一則，短到不會讓使用者等太久才看到，長到足夠吸收同一批排程觸發的多筆提醒
const QUIET_HOURS_START = 23; // 晚上 11 點
const QUIET_HOURS_END = 10; // 早上 10 點 (不含，10:00 開始正常推播)

const pending = new Map(); // userId -> { items: [{title, body, icon}], timer }  ——只用來裝「非緊急」通知

function isQuietHoursNow(date = new Date()) {
  const h = date.getHours();
  // 跨午夜的區間 (23 點到隔天 10 點)：小時 >= 23 或 < 10 都算在靜音時段內
  return h >= QUIET_HOURS_START || h < QUIET_HOURS_END;
}

// 把一則通知內容實際送給某個使用者的每一台訂閱裝置——緊急的單筆立即送、非緊急的合併後
// 一起走這裡，行為 (加密送出/失效訂閱清除) 完全一樣，差別只在呼叫時機。
async function deliverToUser(db, userId, { title, body, icon }, logLabel) {
  const subs = db.prepare('SELECT * FROM push_subscriptions WHERE user_id = ?').all(userId);
  for (const sub of subs) {
    try {
      const result = await sendNotification(db, sub, { title, body, icon });
      if (!result.ok && (result.status === 404 || result.status === 410)) {
        db.prepare('DELETE FROM push_subscriptions WHERE id = ?').run(sub.id);
      }
    } catch (e) {
      logger.error(`[push] ${logLabel}送出失敗`, { userId, message: e.message });
    }
  }
}

async function flushUser(db, userId) {
  const entry = pending.get(userId);
  if (!entry) return;
  pending.delete(userId);
  const items = entry.items;
  if (!items.length) return;

  let title, body, icon;
  if (items.length === 1) {
    ({ title, body, icon } = items[0]);
  } else {
    // 合併成一則：標題講清楚「有幾件事」，內文把每一則的標題跟內容各列一行 (最多列 5 則，
    // 避免通知內容過長被系統截斷)，圖示沿用第一則的 (同一個使用者這段時間內圖示通常一樣)。
    title = `${items.length} 則新提醒`;
    body = items.slice(0, 5).map((i) => `${i.title}：${i.body}`).join('\n');
    icon = items[0].icon;
  }

  await deliverToUser(db, userId, { title, body, icon }, '合併推播');
}

// opts.urgent = true：使用者自己明確要求的提醒 (服藥提醒/使用者自訂精準時間的待辦提醒)。
// 這種不受靜音時段限制、也不進合併佇列，直接各自立刻送出，確保使用者看到的就是他自己
// 設定的那則通知，不會被合併成籠統的「X 則新提醒」。
//
// 其餘一律視為「非緊急」，靜音時段內直接跳過、不進佇列 (使用者隔天打開 App 首頁一樣看得到
// 對應的洞察內容，只是不會半夜推播打擾)；沒被擋下的話進 90 秒合併佇列。
//
// 回傳值 (true = 會送出/已排入佇列, false = 靜音時段跳過) 給呼叫端判斷要不要更新自己的
// 「已推播過」紀錄——如果直接無條件標記成「送過了」，靜音時段結束後同樣的提醒內容會被
// 誤判成「24小時內推播過」而永遠不會真的送出，這裡讓呼叫端只在真的會送出時才標記。
function queueNotification(db, userId, { title, body, icon, urgent = false }) {
  if (urgent) {
    deliverToUser(db, userId, { title, body, icon }, '緊急推播').catch((e) =>
      logger.error('[push] 緊急推播失敗', { userId, message: e.message })
    );
    return true;
  }
  if (isQuietHoursNow()) {
    logger.info('[push] 靜音時段 (23:00-10:00)，跳過非緊急通知', { userId, title });
    return false;
  }
  let entry = pending.get(userId);
  if (!entry) {
    entry = { items: [], timer: null };
    pending.set(userId, entry);
  }
  entry.items.push({ title, body, icon });
  if (entry.timer) clearTimeout(entry.timer);
  entry.timer = setTimeout(() => {
    flushUser(db, userId).catch((e) => logger.error('[push] 合併通知 flush 失敗', { userId, message: e.message }));
  }, BUNDLE_WINDOW_MS);
  entry.timer.unref(); // 不阻止 process 正常結束 (跟其他排程 timer 一致)
  return true;
}

module.exports = { queueNotification, isQuietHoursNow, BUNDLE_WINDOW_MS };
