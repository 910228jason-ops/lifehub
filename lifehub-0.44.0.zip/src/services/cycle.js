// 生理週期階段估算。
//
// 這是「估算」不是醫療診斷：用使用者自己記錄的經期開始日，推算大概落在週期的哪個階段，
// 目的是讓心情陪伴的主動關心跟模式分析能考慮「經前」這個常見會影響情緒的階段，
// 不是要精確預測排卵或做生育規劃。黃體期後段 (排卵後到下次月經前，大約最後 7 天) 通常
// 是經前症候群 (PMS) 比較容易出現的時間，這裡用這段當作 PMS 觀察窗。

const DEFAULT_CYCLE_LENGTH = 28;
const DEFAULT_PERIOD_LENGTH = 5;
const PMS_WINDOW_DAYS = 7; // 下次月經前這幾天算「經前觀察窗」
const MIN_ENTRIES_FOR_AVG = 2;

function daysBetween(a, b) {
  return Math.round((new Date(b + 'T00:00:00Z') - new Date(a + 'T00:00:00Z')) / (1000 * 60 * 60 * 24));
}

function addDays(dateStr, n) {
  const d = new Date(dateStr + 'T00:00:00Z');
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
}

// entries: 依 period_start_date 由舊到新排序的 [{period_start_date, period_end_date}]
function estimateCycleLength(entries) {
  if (entries.length < MIN_ENTRIES_FOR_AVG) return DEFAULT_CYCLE_LENGTH;
  const gaps = [];
  for (let i = 1; i < entries.length; i++) {
    const gap = daysBetween(entries[i - 1].period_start_date, entries[i].period_start_date);
    if (gap > 0 && gap < 90) gaps.push(gap); // 過濾掉異常值 (例如漏記或輸入錯誤)
  }
  if (!gaps.length) return DEFAULT_CYCLE_LENGTH;
  return Math.round(gaps.reduce((s, g) => s + g, 0) / gaps.length);
}

function periodLengthOf(entry) {
  if (entry && entry.period_end_date) {
    const len = daysBetween(entry.period_start_date, entry.period_end_date) + 1;
    if (len > 0 && len <= 14) return len;
  }
  return DEFAULT_PERIOD_LENGTH;
}

// 依「這段週期實際長度」判斷 daysSince (從這次月經開始算起第幾天，0-based) 落在哪個階段。
function classifyPhase(daysSince, cycleLength, periodLength) {
  const ovulationDay = Math.max(periodLength + 1, cycleLength - 14); // 排卵後到下次月經約 14 天 (黃體期長度較固定)
  const pmsStart = cycleLength - PMS_WINDOW_DAYS;
  let phase;
  if (daysSince < periodLength) phase = 'menstrual';
  else if (daysSince < ovulationDay - 1) phase = 'follicular';
  else if (daysSince <= ovulationDay + 1) phase = 'ovulation';
  else phase = 'luteal';
  const isPmsWindow = phase === 'luteal' && daysSince >= pmsStart;
  return { phase, isPmsWindow };
}

// 目前 (今天) 的狀態：給主動關心 banner 用
function currentStatus(entriesAsc, todayStr) {
  if (!entriesAsc.length) return { hasData: false };
  const last = entriesAsc[entriesAsc.length - 1];
  const cycleLength = estimateCycleLength(entriesAsc);
  const periodLength = periodLengthOf(last);
  const daysSince = daysBetween(last.period_start_date, todayStr);
  if (daysSince < 0) return { hasData: false }; // 資料異常 (未來日期)，不推算

  const cyclePos = daysSince % Math.max(cycleLength, 1);
  const { phase, isPmsWindow } = classifyPhase(cyclePos, cycleLength, periodLength);
  const daysUntilNextPeriod = cycleLength - cyclePos;
  const nextPeriodDate = addDays(todayStr, daysUntilNextPeriod);

  // 易孕期 (估算)：排卵日前後最容易受孕的一段時間，抓「排卵日往前 5 天到排卵日隔天」這個
  // 常見的估算範圍 (精子存活+卵子存活的粗略區間)，跟經期預測用同一套週期長度估算邏輯。
  // 這一樣是概略估算，不是排卵試紙/基礎體溫這種精確方法，僅供參考。
  // ovulationDay 是「這次月經開始後第幾天」，直接從最近一次記錄的開始日往後推算排卵日期，
  // 比用「距離今天還有幾天」再折算更簡單、也更不容易算錯 (不用處理已經過了這個週期排卵日的情況)。
  const ovulationDay = Math.max(periodLength + 1, cycleLength - 14);
  const ovulationDate = addDays(last.period_start_date, ovulationDay);
  const fertileWindowStart = addDays(ovulationDate, -5);
  const fertileWindowEnd = addDays(ovulationDate, 1);
  const isFertileWindow = todayStr >= fertileWindowStart && todayStr <= fertileWindowEnd;

  return {
    hasData: true,
    hasEnoughDataForAvg: entriesAsc.length >= MIN_ENTRIES_FOR_AVG,
    phase,
    isPmsWindow,
    cycleLength,
    daysSinceLastPeriod: daysSince,
    daysUntilNextPeriod,
    nextPeriodDate,
    ovulationDateEstimate: ovulationDate,
    fertileWindowStart,
    fertileWindowEnd,
    isFertileWindow,
  };
}

// 給模式分析用：估算「過去某一天」落在哪個階段 (用當時最接近的那段週期實際長度，比較準)
function phaseForDate(entriesAsc, dateStr) {
  if (!entriesAsc.length) return null;
  // 找出 <= dateStr 的最後一筆 period_start_date
  let idx = -1;
  for (let i = 0; i < entriesAsc.length; i++) {
    if (entriesAsc[i].period_start_date <= dateStr) idx = i;
    else break;
  }
  if (idx === -1) return null; // 這天在第一筆紀錄之前，沒有足夠資訊推算

  const start = entriesAsc[idx];
  const next = entriesAsc[idx + 1];
  const cycleLength = next ? daysBetween(start.period_start_date, next.period_start_date) : estimateCycleLength(entriesAsc);
  const periodLength = periodLengthOf(start);
  const daysSince = daysBetween(start.period_start_date, dateStr);
  if (daysSince < 0 || daysSince > 90) return null;

  const { phase } = classifyPhase(daysSince, Math.max(cycleLength, periodLength + 1), periodLength);
  return phase;
}

module.exports = { estimateCycleLength, currentStatus, phaseForDate, PMS_WINDOW_DAYS };
