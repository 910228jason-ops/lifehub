// 會學習的因應技巧庫。
//
// 設計方式：每個情緒標籤底下先放 2-3 個常見、實證有效的自我調節技巧 (呼吸/接地/認知/行為
// 各種類型都有涵蓋，但不含引導式呼吸動畫，純文字說明)。推薦時不是每次都固定給同一個，
// 而是看這個使用者過去對「這個標籤」底下的每個技巧給過的回饋 (有沒有幫助)，
// 優先給還沒試過的、或過去回饋比較正面的技巧，愈用愈準，變成專屬於這個人的工具箱。

const TECHNIQUE_LIBRARY = {
  焦慮: [
    { key: 'grounding-54321', title: '5-4-3-2-1 感官接地法', text: '找出你現在看得到的 5 樣東西、聽得到的 4 種聲音、摸得到的 3 種觸感、聞得到的 2 種氣味、嚐得到的 1 種味道。慢慢做，不用急，這是把注意力從腦中的擔心拉回「現在、這裡」的方法。' },
    { key: 'worry-time', title: '焦慮先記下來，晚點再處理', text: '把讓你焦慮的念頭寫下來（一句話就好），告訴自己「這個我晚點再想」，先把手邊在做的事完成。很多時候焦慮會因為知道「有被記住」而先降下來一點。' },
    { key: 'box-breathing-text', title: '簡單數息', text: '吸氣默數 1-2-3-4，停住默數 1-2-3-4，吐氣默數 1-2-3-4，重複幾次。不用做到很標準，重點是把注意力放在數數字上，讓身體慢下來。' },
  ],
  疲憊: [
    { key: 'permission-to-rest', title: '給自己「休息的許可」', text: '疲憊常常伴隨著「我應該要再撐一下」的念頭。試著跟自己說一句：「我現在真的累了，休息不是懶惰」，然後真的允許自己停下來幾分鐘，不做任何事。' },
    { key: 'micro-break', title: '5 分鐘的小休息', text: '離開現在的位置，喝口水、看看窗外、伸展一下身體。不用是完整的休息，5 分鐘的抽離常常就能讓接下來的狀態不一樣。' },
  ],
  難過: [
    { key: 'name-the-feeling', title: '把感覺說出來（或寫下來）', text: '試著用一句話描述現在的感覺，例如「我覺得很失落，因為……」。說出來或寫下來，本身就有讓情緒沒那麼滿溢的效果，不用急著解決它，先承認它就好。' },
    { key: 'self-compassion', title: '像對朋友一樣對自己說話', text: '想像一個你在乎的朋友遇到跟你一樣的事，你會跟他說什麼？試著把同樣溫柔的話，說給自己聽。' },
  ],
  煩躁: [
    { key: 'pause-before-react', title: '按下暫停鍵', text: '煩躁的時候很容易脫口說出之後會後悔的話。試著先離開現場、深呼吸一次，給自己 10 秒鐘，再決定要不要回應。' },
    { key: 'physical-release', title: '讓身體動一下', text: '煩躁常常是能量卡住了。快走幾分鐘、甩甩手、捏一下枕頭都可以，讓情緒有個出口，而不是憋著。' },
  ],
  孤單: [
    { key: 'small-reach-out', title: '一個小小的連結', text: '不用是很深的對話，傳一句簡單的訊息給任何一個你想到的人（哪怕只是「在幹嘛」），或者就在這裡跟 AI 陪伴聊聊，讓自己感覺不是一個人扛著。' },
    { key: 'self-companionship', title: '陪自己做一件小事', text: '泡杯喜歡的飲料、聽一首熟悉的歌、重看一集喜歡的節目。孤單的時候，好好陪自己也是一種陪伴。' },
  ],
  default: [
    { key: 'notice-and-name', title: '先注意到，再處理', text: '不用急著讓情緒消失，先花一點時間注意到「我現在感覺不太好」，這個注意本身就是照顧自己的第一步。' },
    { key: 'one-small-thing', title: '做一件很小的事', text: '不用想著要解決全部的問題，只要做一件很小、馬上做得到的事就好，例如喝口水、開扇窗、伸個懶腰。' },
  ],
};

function getTechniquesForTag(tag) {
  return TECHNIQUE_LIBRARY[tag] || TECHNIQUE_LIBRARY.default;
}

// 根據使用者過去對這個標籤底下每個技巧的回饋，挑一個最適合的：
//   1. 還沒試過的技巧優先 (讓每個技巧都有機會被使用者評價過)
//   2. 都試過的話，挑「有幫助」比例最高的
//   3. 完全平手時隨機選一個，避免每次都一樣
function pickTechnique(db, userId, tag) {
  const pool = getTechniquesForTag(tag);
  const rows = db
    .prepare('SELECT technique_key, helped FROM mood_technique_feedback WHERE user_id = ? AND tag = ?')
    .all(userId, tag);

  const stats = {};
  rows.forEach((r) => {
    if (!stats[r.technique_key]) stats[r.technique_key] = { helped: 0, total: 0 };
    stats[r.technique_key].total += 1;
    if (r.helped) stats[r.technique_key].helped += 1;
  });

  const untried = pool.filter((t) => !stats[t.key]);
  if (untried.length) {
    return untried[Math.floor(Math.random() * untried.length)];
  }

  let best = pool[0];
  let bestScore = -1;
  pool.forEach((t) => {
    const s = stats[t.key];
    const score = s ? s.helped / s.total : 0;
    if (score > bestScore) {
      bestScore = score;
      best = t;
    }
  });
  return best;
}

module.exports = { TECHNIQUE_LIBRARY, getTechniquesForTag, pickTechnique };
