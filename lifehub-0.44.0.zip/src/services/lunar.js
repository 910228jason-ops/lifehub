// 農曆換算 + 24節氣，純數學天文公式計算，不依賴任何外部套件、不用查表對照第三方資料庫。
//
// 這裡刻意選擇「用公式即時算」而不是「內嵌一份 1900~2100 年的農曆對照表」：
// 後者雖然是業界常見做法，但那份表格的數百個數字沒辦法在這個離線沙盒環境裡對照真的
// 天文資料來源逐一核對，抄錯一兩個字元也很難自己發現；改用可以推導、可以驗證的公式，
// 至少能拿幾個已知的公開日期 (例如民國幾年農曆新年是哪一天) 回頭驗證整套算法對不對，
// 而不是盲目相信一份記不清楚是否正確的表。準確度目標是「一般行事曆點綴用途」，
// 不是天文台等級的精度。

const SYNODIC_MONTH = 29.530588861; // 朔望月平均長度 (天)
const J2000 = 2451545.0; // 2000-01-01 12:00 UTC 的儒略日
const CN_OFFSET = 8 / 24; // 農曆以「中國標準時間 (UTC+8)」定義換日，不是 UTC 換日——
// 所有「某個精確時刻屬於哪一個曆日」的判斷都要先加這個偏移量，不然朔/節氣發生在
// UTC 深夜、但北京時間已經是隔天的情況，會整批被判斷成前一天，農曆初一就會算錯一天。

function toJulianDay(year, month, day, hour) {
  hour = hour || 0;
  if (month <= 2) { year -= 1; month += 12; }
  const A = Math.floor(year / 100);
  const B = 2 - A + Math.floor(A / 4);
  return Math.floor(365.25 * (year + 4716)) + Math.floor(30.6001 * (month + 1)) + day + hour / 24 + B - 1524.5;
}

function fromJulianDay(jd) {
  jd += 0.5;
  const Z = Math.floor(jd);
  const F = jd - Z;
  let A = Z;
  if (Z >= 2299161) {
    const alpha = Math.floor((Z - 1867216.25) / 36524.25);
    A = Z + 1 + alpha - Math.floor(alpha / 4);
  }
  const B = A + 1524;
  const C = Math.floor((B - 122.1) / 365.25);
  const D = Math.floor(365.25 * C);
  const E = Math.floor((B - D) / 30.6001);
  const day = B - D - Math.floor(30.6001 * E) + F;
  const month = E < 14 ? E - 1 : E - 13;
  const year = month > 2 ? C - 4716 : C - 4715;
  const dayFloor = Math.floor(day);
  // 回傳 UTC 日期 (只取到日，不含當天內的時分——這裡的計算目的都只需要「哪一天」)
  return { year, month, day: dayFloor };
}

function normalize360(deg) {
  deg = deg % 360;
  return deg < 0 ? deg + 360 : deg;
}

// 太陽視黃經 (低精度版，Jean Meeus《Astronomical Algorithms》Ch.25 的低精度公式，
// 誤差通常在 0.01 度以內，換算成節氣日期通常準到「當天」等級，足夠行事曆點綴使用)。
function sunApparentLongitude(jd) {
  const T = (jd - J2000) / 36525;
  const L0 = normalize360(280.46646 + 36000.76983 * T + 0.0003032 * T * T);
  const M = normalize360(357.52911 + 35999.05029 * T - 0.0001537 * T * T);
  const Mrad = (M * Math.PI) / 180;
  const C = (1.914602 - 0.004817 * T - 0.000014 * T * T) * Math.sin(Mrad)
    + (0.019993 - 0.000101 * T) * Math.sin(2 * Mrad)
    + 0.000289 * Math.sin(3 * Mrad);
  const trueLon = L0 + C;
  // 章動 + 光行差修正 (低精度版)
  const omega = 125.04 - 1934.136 * T;
  const lambda = trueLon - 0.00569 - 0.00478 * Math.sin((omega * Math.PI) / 180);
  return normalize360(lambda);
}

// 給定「太陽黃經目標角度」，用二分法在指定儒略日範圍內找出精確時刻 (誤差 < 幾分鐘等級)。
function findSolarLongitudeCrossing(targetDeg, jdGuess) {
  let lo = jdGuess - 3;
  let hi = jdGuess + 3;
  const angleDiff = (jd) => {
    let d = sunApparentLongitude(jd) - targetDeg;
    d = ((d + 180) % 360 + 360) % 360 - 180; // 折算到 -180~180，避免 359 跟 1 度誤判方向
    return d;
  };
  for (let i = 0; i < 40; i++) {
    const mid = (lo + hi) / 2;
    if (angleDiff(mid) < 0) lo = mid; else hi = mid;
  }
  return (lo + hi) / 2;
}

// 24 節氣依太陽黃經 0°、15°、30°...每 15 度一個，0°=春分。從「春分」往回推算全年。
const SOLAR_TERM_NAMES = [
  '春分', '清明', '穀雨', '立夏', '小滿', '芒種', '夏至', '小暑', '大暑', '立秋', '處暑', '白露',
  '秋分', '寒露', '霜降', '立冬', '小雪', '大雪', '冬至', '小寒', '大寒', '立春', '雨水', '驚蟄',
];

// 計算「從某年春分開始的一整輪 24 節氣」，回傳陣列 { year, month, day, name }。
// 注意：一輪 24 節氣是從春分算到隔年驚蟄，最後幾個 (小寒/大寒/立春/雨水/驚蟄) 會落在
// 隔年 1~3 月——這裡刻意「不」用 y===year 篩掉跨年的節氣，因為那些日期是真實存在的節氣，
// 只是碰巧屬於西曆的下一年而已 (先前版本這裡濾掉跨年節氣，導致農曆正月前後整段的
// 「中氣」判斷失準，連帶讓閏月演算法算錯——這是找 bug 時發現的真正成因)。
const solarTermCycleCache = new Map();
function getSolarTermCycle(cycleYear) {
  if (solarTermCycleCache.has(cycleYear)) return solarTermCycleCache.get(cycleYear);
  const result = [];
  // 春分約在 3/20 前後，用這天當第一個猜測值，之後每個節氣間隔約 15.2 天往後推。
  const jdGuess = toJulianDay(cycleYear, 3, 20, 12);
  for (let i = 0; i < 24; i++) {
    const targetDeg = normalize360(i * 15);
    const jd = findSolarLongitudeCrossing(targetDeg, jdGuess + i * 15.2184);
    const { year: y, month: m, day: d } = fromJulianDay(jd + CN_OFFSET);
    result.push({ year: y, month: m, day: d, name: SOLAR_TERM_NAMES[i] });
  }
  solarTermCycleCache.set(cycleYear, result);
  return result;
}

// 給某個「西曆年」用的節氣對照表 { 'MM-DD': '節氣名' }——組合「以這年春分起算的一輪」
// 跟「以前一年春分起算、尾巴跨到這年 1~3 月的一輪」，才能涵蓋這年 1~12 月全部節氣。
const solarTermCache = new Map();
function getSolarTermsForYear(year) {
  if (solarTermCache.has(year)) return solarTermCache.get(year);
  const result = {};
  [getSolarTermCycle(year), getSolarTermCycle(year - 1)].forEach((cycle) => {
    cycle.forEach((t) => {
      if (t.year === year) {
        result[`${String(t.month).padStart(2, '0')}-${String(t.day).padStart(2, '0')}`] = t.name;
      }
    });
  });
  solarTermCache.set(year, result);
  return result;
}

function getSolarTermForDate(year, month, day) {
  const terms = getSolarTermsForYear(year);
  return terms[`${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`] || null;
}

// ---- 農曆換算：以「朔望月 + 節氣」推導月份與日期 (傳統農曆定義法) ----
// 規則：以「朔」(新月，看不到月亮的那天) 為每個農曆月的第一天；冬至一定落在農曆十一月；
// 兩個「十一月」之間如果剛好夾了 13 個朔望月，就要插入閏月——插在「這個月沒有中氣
// (0°/30°/60°...的節氣，也就是 SOLAR_TERM_NAMES 裡索引為偶數的那些) 」的第一個月。

function findNewMoonsInRange(startJd, endJd) {
  // 用平均朔望月粗估「第幾次朔」，抓一個估計的朔望月序數 k 之後在附近二分搜尋太陽-月亮
  // 視黃經差 = 0 的時刻 (朔的定義)。這裡的月亮黃經公式同樣採 Meeus 低精度版本，
  // 只取最大的幾個週期項，精度約在數小時內，換算成「哪一天」通常是準的。
  const results = [];
  let k = Math.floor((startJd - 2451550.09766) / SYNODIC_MONTH) - 2;
  while (true) {
    const jd = newMoonJd(k);
    if (jd > endJd) break;
    if (jd >= startJd - 1) results.push(jd);
    k++;
  }
  return results;
}

function moonApparentLongitude(jd) {
  const T = (jd - J2000) / 36525;
  const L = normalize360(218.3164477 + 481267.88123421 * T);
  const D = normalize360(297.8501921 + 445267.1114034 * T);
  const M = normalize360(357.5291092 + 35999.0502909 * T);
  const Mp = normalize360(134.9633964 + 477198.8675055 * T);
  const rad = (x) => (x * Math.PI) / 180;
  // 只取振幅最大的幾個週期項 (Meeus Ch.47 節錄版)，足夠估出朔的日期。
  let dl = 6.288774 * Math.sin(rad(Mp));
  dl += 1.274027 * Math.sin(rad(2 * D - Mp));
  dl += 0.658314 * Math.sin(rad(2 * D));
  dl += 0.213618 * Math.sin(rad(2 * Mp));
  dl -= 0.185116 * Math.sin(rad(M));
  dl -= 0.114332 * Math.sin(rad(2 * D - 2 * Mp)) * 0; // 忽略更小項，避免過度複雜化
  return normalize360(L + dl);
}

// 找出「朔」(太陽與月亮黃經相同) 的精確時刻：先用平均新月公式粗估，再用二分法微調。
function newMoonJd(k) {
  const T = k / 1236.85;
  let jde = 2451550.09766 + SYNODIC_MONTH * k
    + 0.00015437 * T * T
    - 0.000000150 * T * T * T;
  // 二分法微調：找 (月亮黃經 - 太陽黃經) 跨越 0 的時刻
  let lo = jde - 1.5;
  let hi = jde + 1.5;
  const diff = (jd) => {
    let d = moonApparentLongitude(jd) - sunApparentLongitude(jd);
    d = ((d + 180) % 360 + 360) % 360 - 180;
    return d;
  };
  for (let i = 0; i < 40; i++) {
    const mid = (lo + hi) / 2;
    if (diff(mid) < 0) lo = mid; else hi = mid;
  }
  return (lo + hi) / 2;
}

const lunarYearCache = new Map();

// 算出西曆某年 (連同前後緩衝) 的農曆月份結構，回傳依日期排序的「每個農曆月第一天」清單，
// 每筆 { jd, monthNumber, isLeap }。monthNumber 1~12，isLeap 表示是不是閏月。
function buildLunarMonthsAroundYear(year) {
  if (lunarYearCache.has(year)) return lunarYearCache.get(year);

  // 抓「去年冬至前」到「明年冬至後」這段範圍的所有朔，確保涵蓋完整的農曆年架構。
  const rangeStartJd = toJulianDay(year - 1, 11, 1, 0);
  const rangeEndJd = toJulianDay(year + 1, 2, 1, 0);
  const newMoons = findNewMoonsInRange(rangeStartJd, rangeEndJd);

  // 每個朔望月區間 [newMoons[i], newMoons[i+1]) 就是一個農曆月，先找出每個月是否含中氣
  // (冬至/大寒/雨水...這些偶數索引節氣)，藉此判斷月份編號跟閏月。
  const months = [];
  for (let i = 0; i < newMoons.length - 1; i++) {
    // 朔望發生的精確時刻先轉成「北京時間的曆日」，再換算回 UTC 午夜的儒略日
    // 當作這個農曆月的起點 (跟下面逐日掃描迴圈用的 jd 基準一致)。
    const nmStart = fromJulianDay(newMoons[i] + CN_OFFSET);
    const nmEnd = fromJulianDay(newMoons[i + 1] + CN_OFFSET);
    const startJd = Math.floor(toJulianDay(nmStart.year, nmStart.month, nmStart.day, 0)) + 0.5;
    const endJd = Math.floor(toJulianDay(nmEnd.year, nmEnd.month, nmEnd.day, 0)) + 0.5;
    let hasZhongqi = false;
    // 逐日檢查這個月範圍內有沒有偶數索引節氣 (中氣)；月長最多 30 天，逐日檢查成本可接受。
    for (let jd = startJd; jd < endJd; jd++) {
      const { year: y, month: m, day: d } = fromJulianDay(jd);
      const termName = getSolarTermForDate(y, m, d);
      if (termName) {
        const idx = SOLAR_TERM_NAMES.indexOf(termName);
        if (idx % 2 === 0) { hasZhongqi = true; break; }
      }
    }
    months.push({ startJd, hasZhongqi, monthNumber: null, isLeap: false });
  }

  // 找出「冬至所在的月」當作基準，該月一定是十一月 (農曆定義)。
  let winterSolsticeMonthIdx = -1;
  for (let i = 0; i < months.length; i++) {
    const startJd = months[i].startJd;
    const endJd = i + 1 < months.length ? months[i + 1].startJd : startJd + 30;
    for (let jd = startJd; jd < endJd; jd++) {
      const { year: y, month: m, day: d } = fromJulianDay(jd);
      if (getSolarTermForDate(y, m, d) === '冬至') { winterSolsticeMonthIdx = i; break; }
    }
    if (winterSolsticeMonthIdx >= 0) break;
  }

  if (winterSolsticeMonthIdx < 0) {
    lunarYearCache.set(year, []);
    return [];
  }

  // 從冬至月 (十一月) 開始，往後編號月份；如果從這個十一月到下一個十一月之間有 13 個月，
  // 中間第一個「沒有中氣」的月就是閏月 (閏月編號沿用前一個月的編號，isLeap=true)。
  let monthNumber = 11;
  months[winterSolsticeMonthIdx].monthNumber = 11;
  let leapInserted = false;
  // 判斷這一段是否需要閏月：找下一個「冬至月」的位置，數中間隔了幾個朔望月
  let nextWinterIdx = -1;
  for (let i = winterSolsticeMonthIdx + 1; i < months.length; i++) {
    const startJd = months[i].startJd;
    const endJd = i + 1 < months.length ? months[i + 1].startJd : startJd + 30;
    for (let jd = startJd; jd < endJd; jd++) {
      const { year: y, month: m, day: d } = fromJulianDay(jd);
      if (getSolarTermForDate(y, m, d) === '冬至') { nextWinterIdx = i; break; }
    }
    if (nextWinterIdx >= 0) break;
  }
  const needsLeap = nextWinterIdx > 0 && (nextWinterIdx - winterSolsticeMonthIdx) === 13;

  for (let i = winterSolsticeMonthIdx + 1; i < months.length; i++) {
    if (needsLeap && !leapInserted && !months[i].hasZhongqi) {
      months[i].monthNumber = monthNumber; // 閏月沿用上個月編號
      months[i].isLeap = true;
      leapInserted = true;
    } else {
      monthNumber = monthNumber === 12 ? 1 : monthNumber + 1;
      months[i].monthNumber = monthNumber;
    }
  }
  // 往前補冬至月之前的月份編號 (往回推，12 月是十一月的前一個月，以此類推)
  monthNumber = 11;
  for (let i = winterSolsticeMonthIdx - 1; i >= 0; i--) {
    monthNumber = monthNumber === 1 ? 12 : monthNumber - 1;
    months[i].monthNumber = monthNumber;
  }

  lunarYearCache.set(year, months);
  return months;
}

const LUNAR_DAY_NAMES = ['初一', '初二', '初三', '初四', '初五', '初六', '初七', '初八', '初九', '初十',
  '十一', '十二', '十三', '十四', '十五', '十六', '十七', '十八', '十九', '二十',
  '廿一', '廿二', '廿三', '廿四', '廿五', '廿六', '廿七', '廿八', '廿九', '三十'];
const LUNAR_MONTH_NAMES = ['正月', '二月', '三月', '四月', '五月', '六月', '七月', '八月', '九月', '十月', '十一月', '十二月'];

// 主要對外介面：西曆日期 -> { monthName, dayName, isLeapMonth, isFirstDay, solarTerm }
// solarTerm：如果這天剛好是節氣交節日，會另外標出來 (跟農曆日期分開顯示，比照使用者
// 提供的截圖：節氣是獨立的紫色標籤，農曆日期是格子裡的小字)。
function getLunarInfo(year, month, day) {
  try {
    // 用 hour=0 (UTC 午夜) 跟月份邊界 (startJd) 採同一套基準，避免用中午當基準時
    // 換算來換算去多繞一手、多一個容易養出誤差的環節。
    const jd = Math.floor(toJulianDay(year, month, day, 0)) + 0.5;
    const months = buildLunarMonthsAroundYear(year);
    if (!months.length) return null;
    let target = null;
    for (let i = 0; i < months.length; i++) {
      const startJd = months[i].startJd;
      const endJd = i + 1 < months.length ? months[i + 1].startJd : startJd + 30;
      if (jd >= startJd && jd < endJd) { target = { ...months[i], dayIndex: Math.round(jd - startJd) }; break; }
    }
    if (!target || target.dayIndex < 0 || target.dayIndex > 29) return null;
    const solarTerm = getSolarTermForDate(year, month, day);
    return {
      monthName: LUNAR_MONTH_NAMES[(target.monthNumber - 1 + 12) % 12],
      dayName: LUNAR_DAY_NAMES[target.dayIndex],
      isLeapMonth: target.isLeap,
      isFirstDay: target.dayIndex === 0,
      solarTerm,
    };
  } catch (e) {
    return { monthName: null, dayName: null, isLeapMonth: false, isFirstDay: false, solarTerm: getSolarTermForDate(year, month, day) };
  }
}

module.exports = { getLunarInfo, getSolarTermForDate, getSolarTermsForYear };
