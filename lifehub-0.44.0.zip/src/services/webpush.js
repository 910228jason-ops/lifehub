// 背景推播通知 (Web Push)，手刻版——不依賴 web-push 套件。
//
// Web Push 標準本身分兩塊，都是標準演算法，Node 內建的 crypto 模組就有：
//   1. VAPID (RFC 8292)：用一組 ECDSA (P-256) 金鑰對，對每次推播請求簽一個 JWT，
//      讓推播服務 (FCM/APNs/Mozilla 各家) 知道這是「同一個已知的伺服器」在推送，
//      不需要另外申請帳號密碼。
//   2. 訊息加密 (RFC 8291 aes128gcm content-encoding)：推播內容本身要加密，只有訂閱者
//      的瀏覽器 (裝置上的私鑰) 解得開，伺服器沒辦法看到內容中繼站 (FCM 等) 也看不到。
//
// 手機螢幕熄滅、甚至 App 沒開著的時候還能跳出通知，靠的就是這個機制 (跟一般網頁
// `new Notification()` 完全不同——那個只有分頁開著才有用)。iOS 需要先「加入主畫面」
// 變成 PWA 之後、在 16.4 以上版本才支援。

const crypto = require('crypto');

function base64url(buf) {
  return buf.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}
function fromBase64url(str) {
  const padded = str.replace(/-/g, '+').replace(/_/g, '/') + '='.repeat((4 - (str.length % 4)) % 4);
  return Buffer.from(padded, 'base64');
}

// ---- VAPID 金鑰對：伺服器第一次需要用到時自己生一組，存進 app_settings，之後都重複用 ----
function generateVapidKeyPair() {
  const { publicKey, privateKey } = crypto.generateKeyPairSync('ec', { namedCurve: 'prime256v1' });
  // 匯出成「未壓縮點」格式 (0x04 + X(32) + Y(32))，這是瀏覽器 Push API / VAPID 標準要的格式，
  // 不是 Node 預設的 PEM/DER，要用 `jwk` 匯出再自己拼出未壓縮點，或直接用下面的方式取得。
  const pubJwk = publicKey.export({ format: 'jwk' });
  const pubRaw = Buffer.concat([Buffer.from([0x04]), fromBase64url(pubJwk.x), fromBase64url(pubJwk.y)]);
  const privJwk = privateKey.export({ format: 'jwk' });
  return {
    publicKeyB64: base64url(pubRaw),
    privateKeyB64: base64url(fromBase64url(privJwk.d)), // d (私鑰純量) 32 bytes
  };
}

function getOrCreateVapidKeys(db) {
  const rows = db.prepare("SELECT key, value FROM app_settings WHERE key IN ('vapid_public_key','vapid_private_key')").all();
  const map = {};
  rows.forEach((r) => { map[r.key] = r.value; });
  if (map.vapid_public_key && map.vapid_private_key) {
    return { publicKeyB64: map.vapid_public_key, privateKeyB64: map.vapid_private_key };
  }
  const pair = generateVapidKeyPair();
  const now = new Date().toISOString();
  const upsert = db.prepare('INSERT INTO app_settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value');
  upsert.run('vapid_public_key', pair.publicKeyB64);
  upsert.run('vapid_private_key', pair.privateKeyB64);
  upsert.run('vapid_created_at', now);
  return pair;
}

// 把 base64url 私鑰純量還原成 Node 可以拿來簽章的 KeyObject
function privateKeyObjectFromB64(privateKeyB64) {
  const d = fromBase64url(privateKeyB64);
  // 需要同時提供 public x/y 才能組出合法的 EC JWK 私鑰；從私鑰純量重新算出對應公鑰點。
  const ecdh = crypto.createECDH('prime256v1');
  ecdh.setPrivateKey(d);
  const pub = ecdh.getPublicKey(); // 未壓縮點 0x04+X+Y
  const x = pub.slice(1, 33);
  const y = pub.slice(33, 65);
  const jwk = { kty: 'EC', crv: 'P-256', d: base64url(d), x: base64url(x), y: base64url(y) };
  return crypto.createPrivateKey({ key: jwk, format: 'jwk' });
}

// ---- VAPID JWT：aud (推播服務的 origin) + exp (最長 24hr，這裡用 12hr) + sub (聯絡方式) ----
function buildVapidHeader(privateKeyB64, publicKeyB64, endpoint, subject) {
  const audience = new URL(endpoint).origin;
  const header = { typ: 'JWT', alg: 'ES256' };
  const payload = {
    aud: audience,
    exp: Math.floor(Date.now() / 1000) + 12 * 60 * 60,
    sub: subject || 'mailto:admin@example.com',
  };
  const unsigned = `${base64url(Buffer.from(JSON.stringify(header)))}.${base64url(Buffer.from(JSON.stringify(payload)))}`;
  const keyObj = privateKeyObjectFromB64(privateKeyB64);
  // dsaEncoding: 'ieee-p1363' 讓 Node 直接輸出 JWS 要的 r||s 原始格式 (各 32 bytes)，
  // 不用自己再從標準 DER 簽章格式解出 r/s 重新拼接。
  const signature = crypto.sign('sha256', Buffer.from(unsigned), { key: keyObj, dsaEncoding: 'ieee-p1363' });
  const jwt = `${unsigned}.${base64url(signature)}`;
  return `vapid t=${jwt}, k=${publicKeyB64}`;
}

// ---- 內容加密 (RFC 8291 aes128gcm)：見檔案開頭說明的兩層 HKDF 推導 ----
function hkdfExtract(salt, ikm) {
  return crypto.createHmac('sha256', salt).update(ikm).digest();
}
function hkdfExpand(prk, info, length) {
  // 這裡只需要單一個 block (32 bytes 內)，簡化版 HKDF-Expand：T(1) = HMAC(PRK, info || 0x01)
  const t = crypto.createHmac('sha256', prk).update(Buffer.concat([info, Buffer.from([1])])).digest();
  return t.slice(0, length);
}

function encryptPayload(plaintextObj, p256dhB64, authB64) {
  const uaPublic = fromBase64url(p256dhB64); // 訂閱者 (瀏覽器) 的公鑰，65 bytes 未壓縮點
  const authSecret = fromBase64url(authB64); // 16 bytes

  // 這一次推播專屬的暫時金鑰對 (每次推播都重新生一組，不重複使用)
  const ecdh = crypto.createECDH('prime256v1');
  ecdh.generateKeys();
  const asPublic = ecdh.getPublicKey(); // 65 bytes
  const sharedSecret = ecdh.computeSecret(uaPublic);

  const authInfo = Buffer.from('WebPush: info\0', 'utf8');
  const keyInfo = Buffer.concat([authInfo, uaPublic, asPublic]);
  const prkKey = hkdfExtract(authSecret, sharedSecret);
  const ikm = hkdfExpand(prkKey, keyInfo, 32);

  const salt = crypto.randomBytes(16);
  const prk = hkdfExtract(salt, ikm);
  const cek = hkdfExpand(prk, Buffer.from('Content-Encoding: aes128gcm\0', 'utf8'), 16);
  const nonce = hkdfExpand(prk, Buffer.from('Content-Encoding: nonce\0', 'utf8'), 12);

  const plaintext = Buffer.from(JSON.stringify(plaintextObj), 'utf8');
  // 單一 record (內容不會超過 4096 bytes 上限)：明文後面加一個 0x02 分隔位元組代表「最後一筆」
  const padded = Buffer.concat([plaintext, Buffer.from([0x02])]);

  const cipher = crypto.createCipheriv('aes-128-gcm', cek, nonce);
  const ciphertext = Buffer.concat([cipher.update(padded), cipher.final()]);
  const authTag = cipher.getAuthTag();

  const recordSize = Buffer.alloc(4);
  recordSize.writeUInt32BE(4096, 0);
  const idLen = Buffer.from([asPublic.length]);
  const header = Buffer.concat([salt, recordSize, idLen, asPublic]);

  return Buffer.concat([header, ciphertext, authTag]);
}

// 傳一份推播給單一訂閱裝置。失敗 (裝置已取消訂閱、endpoint 過期等) 時回傳 { ok:false, status }，
// 呼叫端可以用來清掉失效的訂閱紀錄，不會讓整個排程因為一筆壞掉的訂閱而中斷。
async function sendNotification(db, subscriptionRow, payloadObj, subject) {
  const vapid = getOrCreateVapidKeys(db);
  const body = encryptPayload(payloadObj, subscriptionRow.p256dh, subscriptionRow.auth);
  const authHeader = buildVapidHeader(vapid.privateKeyB64, vapid.publicKeyB64, subscriptionRow.endpoint, subject);

  const res = await fetch(subscriptionRow.endpoint, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/octet-stream',
      'Content-Encoding': 'aes128gcm',
      TTL: '86400',
      Authorization: authHeader,
    },
    body,
  });
  return { ok: res.ok, status: res.status };
}

module.exports = { getOrCreateVapidKeys, sendNotification, encryptPayload, buildVapidHeader };
