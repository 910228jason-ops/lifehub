// 密碼雜湊工具：只用 Node.js 內建 crypto 模組 (scrypt)，不依賴任何外部套件。
// 格式: scrypt$<saltHex>$<hashHex>

const crypto = require('crypto');

function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(String(password), salt, 64).toString('hex');
  return `scrypt$${salt}$${hash}`;
}

function verifyPassword(password, stored) {
  if (!stored || !stored.startsWith('scrypt$')) return false;
  const [, salt, hash] = stored.split('$');
  const check = crypto.scryptSync(String(password), salt, 64).toString('hex');
  const a = Buffer.from(hash, 'hex');
  const b = Buffer.from(check, 'hex');
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(a, b);
}

// 忘記密碼用的「備用重設碼」：因為這個專案沒有接寄信服務，用這組只顯示一次的高強度
// 隨機碼取代「寄重設連結到信箱」。字元集刻意避開容易看錯的 0/O、1/I/L，手動輸入比較不會出錯。
const RECOVERY_CODE_ALPHABET = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
function generateRecoveryCode() {
  const groups = [];
  for (let g = 0; g < 4; g++) {
    let group = '';
    for (let i = 0; i < 4; i++) {
      group += RECOVERY_CODE_ALPHABET[crypto.randomInt(RECOVERY_CODE_ALPHABET.length)];
    }
    groups.push(group);
  }
  return groups.join('-'); // 例如 A7K9-QX3M-...
}

module.exports = { hashPassword, verifyPassword, generateRecoveryCode };
