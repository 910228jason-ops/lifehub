// 台股資料服務
// 資料來源皆為「公開、免申請金鑰」的官方/準官方資料源：
//   1. 上市個股每日收盤行情：openapi.twse.com.tw (臺灣證券交易所 OpenAPI，官方)
//   2. 三大法人買賣超：www.twse.com.tw/rwd/zh/fund/T86 (證交所網站資料，業界廣泛使用)
// 限制：以上兩者都是「每日盤後」更新一次(通常約下午2:30~4點後才有當日資料)，
// 並非逐筆撮合的「盤中即時」報價。若要真正的盤中即時報價，需要額外申請
// 券商/資訊供應商的「即時報價授權」(通常需付費且需簽署合約)，本原型先以
// 「每日資料 + 明確標示更新時間」的方式呈現，避免誤導使用者以為是逐秒跳動的報價。

// 使用 Node.js 18+ 內建的全域 fetch()，不依賴 node-fetch 套件。
const logger = require('./logger');

const CACHE_TTL_MS = 5 * 60 * 1000; // 5 分鐘快取，避免對證交所頻繁請求
const cache = new Map();

async function fetchWithTimeout(url, opts = {}, timeoutMs = 10000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, { ...opts, signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}

async function cachedFetchJson(url) {
  const hit = cache.get(url);
  if (hit && Date.now() - hit.at < CACHE_TTL_MS) return hit.data;

  const res = await fetchWithTimeout(url, {
    headers: { 'User-Agent': 'Mozilla/5.0 (LifeHub prototype; contact: user)' },
  });
  if (!res.ok) throw new Error(`TWSE 回應錯誤: HTTP ${res.status}`);
  const data = await res.json();
  cache.set(url, { data, at: Date.now() });
  return data;
}

// 全上市股票每日收盤資料 (欄位: Code, Name, ClosingPrice, Change, TradeVolume ...)
async function getAllDailyQuotes() {
  const url = 'https://openapi.twse.com.tw/v1/exchangeReport/STOCK_DAY_ALL';
  return cachedFetchJson(url);
}

// 讓使用者可以直接打公司名稱 (例如「華邦電」) 而不是一定要記住代號 (例如「2344」)。
// 比對順序：純數字視為代號直接找 → 名稱完全相符 → 名稱前綴相符 → 名稱包含比對。
async function resolveCode(query) {
  const q = String(query || '').trim();
  if (!q) return null;
  const all = await getAllDailyQuotes();
  if (/^\d+$/.test(q)) {
    const exact = all.find((r) => r.Code === q);
    return exact ? { code: exact.Code, name: exact.Name } : null;
  }
  const exactName = all.find((r) => r.Name === q);
  if (exactName) return { code: exactName.Code, name: exactName.Name };
  const starts = all.find((r) => r.Name && r.Name.startsWith(q));
  if (starts) return { code: starts.Code, name: starts.Name };
  const contains = all.find((r) => r.Name && r.Name.includes(q));
  if (contains) return { code: contains.Code, name: contains.Name };
  return null;
}

async function getQuote(code) {
  const all = await getAllDailyQuotes();
  const row = all.find((r) => r.Code === code);
  if (!row) return null;
  return {
    code: row.Code,
    name: row.Name,
    closingPrice: Number(row.ClosingPrice) || null,
    change: Number(row.Change) || 0,
    openingPrice: Number(row.OpeningPrice) || null,
    highestPrice: Number(row.HighestPrice) || null,
    lowestPrice: Number(row.LowestPrice) || null,
    tradeVolume: Number(row.TradeVolume) || 0,
    date: row.Date,
  };
}

// 三大法人買賣超 (指定日期，格式 YYYYMMDD；不帶日期則為最近一個交易日)
// 除了三大法人「合計」，也拆解出 外資(外陸資)/投信/自營商 三個分項，
// 這樣前端可以像 Yahoo 股市一樣顯示「今天是誰在買、誰在賣」。
async function getInstitutionalDaily(dateStr) {
  const url = dateStr
    ? `https://www.twse.com.tw/rwd/zh/fund/T86?date=${dateStr}&selectType=ALL&response=json`
    : `https://www.twse.com.tw/rwd/zh/fund/T86?selectType=ALL&response=json`;
  const json = await cachedFetchJson(url);
  if (!json || !json.data) return { date: dateStr || null, rows: [] };

  // fields 順序依證交所回傳為準，這裡用 fields 陣列動態對應，避免欄位順序改變時程式壞掉
  const fields = json.fields || [];
  const idx = (name) => fields.indexOf(name);
  const codeIdx = idx('證券代號');
  const nameIdx = idx('證券名稱');
  const totalIdx = fields.findIndex((f) => f.includes('三大法人買賣超股數'));
  const foreignIdx = fields.findIndex((f) => f.includes('外陸資買賣超股數')); // 不含外資自營商
  const trustIdx = idx('投信買賣超股數');
  const dealerIdx = idx('自營商買賣超股數'); // 合計欄 (自行買賣+避險)

  const num = (v) => Number(String(v ?? '0').replace(/,/g, '')) || 0;
  const rows = (json.data || []).map((r) => ({
    code: r[codeIdx],
    name: r[nameIdx],
    netBuySell: num(r[totalIdx]),
    foreign: foreignIdx >= 0 ? num(r[foreignIdx]) : null,
    trust: trustIdx >= 0 ? num(r[trustIdx]) : null,
    dealer: dealerIdx >= 0 ? num(r[dealerIdx]) : null,
  }));
  return { date: json.date || dateStr || null, rows };
}

async function getInstitutionalForStock(code) {
  const { date, rows } = await getInstitutionalDaily();
  const row = rows.find((r) => r.code === code);
  return { date, netBuySell: row ? row.netBuySell : 0, name: row ? row.name : null };
}

// 取得近 N 個交易日的法人買賣超趨勢。
// 效能備註：這裡原本是「逐日、逐一 await」呼叫證交所 API (最多可能到 30 次序列請求，
// 每次最久等 10 秒逾時)，實測下來單一檔股票就要等 30 秒以上，是股票頁面卡頓的主因。
// 改成先算出候選交易日清單 (跳過週末)，再用 Promise.allSettled 平行送出所有請求 —
// 因為每個日期各自的結果本來就有 5 分鐘快取 (見 cachedFetchJson)，多檔股票之間也能
// 共用同一天的快取，不需要對證交所重複打相同的日期。假日/未開市的日期證交所會回傳
// 空資料，直接忽略即可。
async function getInstitutionalTrend(code, days = 10) {
  const candidateDates = [];
  let d = new Date();
  let guard = 0;
  while (candidateDates.length < days * 2 && guard < days * 4) {
    guard++;
    const dow = d.getDay();
    if (dow !== 0 && dow !== 6) {
      candidateDates.push(
        `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}`
      );
    }
    d.setDate(d.getDate() - 1);
  }

  const settled = await Promise.allSettled(candidateDates.map((dateStr) => getInstitutionalDaily(dateStr)));

  const results = [];
  settled.forEach((outcome, i) => {
    const dateStr = candidateDates[i];
    if (outcome.status !== 'fulfilled') {
      logger.warn('取得法人趨勢單日資料失敗', { dateStr, error: outcome.reason && outcome.reason.message });
      return;
    }
    const { rows, date } = outcome.value;
    const row = rows.find((r) => r.code === code);
    if (row) {
      results.push({ date: date || dateStr, dateStr, netBuySell: row.netBuySell, foreign: row.foreign, trust: row.trust, dealer: row.dealer });
    }
  });

  results.sort((a, b) => (a.dateStr < b.dateStr ? -1 : a.dateStr > b.dateStr ? 1 : 0));
  return results.slice(-days).map(({ dateStr, ...rest }) => rest);
}

// 規則式「參考訊號」— 明確聲明僅供參考，非投資建議
function computeSignal(trend) {
  if (!trend || trend.length < 3) return { label: '資料不足', detail: '', tone: 'neutral' };
  const last3 = trend.slice(-3);
  const sumLast3 = last3.reduce((s, t) => s + t.netBuySell, 0);
  const increasing = last3.every((t, i) => i === 0 || t.netBuySell >= last3[i - 1].netBuySell);

  if (sumLast3 > 0 && increasing) {
    return { label: '法人買超轉強(僅供參考)', detail: `近3日合計買超 ${sumLast3.toLocaleString()} 股，且逐日增加`, tone: 'positive' };
  }
  if (sumLast3 < 0) {
    return { label: '法人賣超(僅供參考)', detail: `近3日合計賣超 ${Math.abs(sumLast3).toLocaleString()} 股`, tone: 'negative' };
  }
  return { label: '法人動向不明顯', detail: `近3日合計 ${sumLast3.toLocaleString()} 股`, tone: 'neutral' };
}

// 單一個股「當月」歷史每日收盤價 (證交所官方端點，公開免金鑰)。
// monthsBack=0 為當月，1 為上個月，以此類推；用來湊出足夠天數計算均線。
async function getStockHistoryMonth(code, monthsBack = 0) {
  const d = new Date();
  d.setMonth(d.getMonth() - monthsBack, 1);
  const dateStr = `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}01`;
  const url = `https://www.twse.com.tw/exchangeReport/STOCK_DAY?date=${dateStr}&stockNo=${code}&response=json`;
  const json = await cachedFetchJson(url);
  if (!json || !Array.isArray(json.data)) return [];
  // 欄位固定為：日期,成交股數,成交金額,開盤價,最高價,最低價,收盤價,漲跌價差,成交筆數
  const num = (v) => Number(String(v ?? '').replace(/,/g, '')) || null;
  return json.data.map((r) => ({
    date: r[0],
    tradeVolume: num(r[1]),
    openingPrice: num(r[3]),
    highestPrice: num(r[4]),
    lowestPrice: num(r[5]),
    closingPrice: num(r[6]),
  })).filter((r) => r.closingPrice != null);
}

// 取得近 2 個月的歷史收盤價 (當月資料不足時會自動往前抓上個月，湊足算均線用的天數)
async function getStockHistory(code) {
  const [thisMonth, lastMonth] = await Promise.all([
    getStockHistoryMonth(code, 0).catch(() => []),
    getStockHistoryMonth(code, 1).catch(() => []),
  ]);
  return [...lastMonth, ...thisMonth];
}

// 均線趨勢 — 這是「描述性統計指標」，不是價格預測。MA5(近5日均價) 相對 MA20(近20日均價)
// 的位置只能說明「近期價格相對於較長期平均是偏強還是偏弱」，不代表未來漲跌，
// 所有文字都刻意避免使用「預測」、「將會」等字眼。
function computeMovingAverageTrend(history) {
  if (!history || history.length < 20) {
    return { available: false, reason: '歷史資料不足 20 個交易日，無法計算均線' };
  }
  const closes = history.map((h) => h.closingPrice);
  const avg = (arr) => arr.reduce((a, b) => a + b, 0) / arr.length;
  const ma5 = avg(closes.slice(-5));
  const ma20 = avg(closes.slice(-20));
  const diffPct = ((ma5 - ma20) / ma20) * 100;
  let label, tone;
  if (diffPct > 1) { label = '短期均線在長期均線之上 (偏強)'; tone = 'positive'; }
  else if (diffPct < -1) { label = '短期均線在長期均線之下 (偏弱)'; tone = 'negative'; }
  else { label = '短期與長期均線接近 (盤整)'; tone = 'neutral'; }
  return {
    available: true,
    ma5: Math.round(ma5 * 100) / 100,
    ma20: Math.round(ma20 * 100) / 100,
    diffPct: Math.round(diffPct * 100) / 100,
    label, tone,
    disclaimer: '均線是描述「近期價格相對位置」的統計指標，不是未來走勢預測，過去表現不代表未來結果。',
  };
}

// ---------- 更多技術指標 (全部是「描述近況的統計指標」，不是價格預測，也不是投資建議) ----------
// 這裡刻意都只回傳「目前數值 + 中性的白話描述」，不做「買進/賣出」這種字眼，
// 跟均線指標 (computeMovingAverageTrend) 遵循同一套原則。

// RSI (相對強弱指標)：用近 N 日漲跌幅算「近期上漲力道相對下跌力道的比例」，
// 常見解讀是 >70 偏「超買區」、<30 偏「超賣區」，但這只是統計上的相對位置，不代表接下來會漲或跌。
function computeRSI(history, period = 14) {
  if (!history || history.length < period + 1) {
    return { available: false, reason: `歷史資料不足 ${period + 1} 個交易日，無法計算 RSI` };
  }
  const closes = history.map((h) => h.closingPrice);
  let gains = 0, losses = 0;
  for (let i = closes.length - period; i < closes.length; i++) {
    const diff = closes[i] - closes[i - 1];
    if (diff > 0) gains += diff; else losses -= diff;
  }
  const avgGain = gains / period;
  const avgLoss = losses / period;
  const rsi = avgLoss === 0 ? 100 : 100 - 100 / (1 + avgGain / avgLoss);
  let label, tone;
  if (rsi >= 70) { label = '偏「相對高檔」區間 (統計上常見的觀察門檻，非賣出訊號)'; tone = 'warning'; }
  else if (rsi <= 30) { label = '偏「相對低檔」區間 (統計上常見的觀察門檻，非買進訊號)'; tone = 'warning'; }
  else { label = '中性區間'; tone = 'neutral'; }
  return { available: true, value: Math.round(rsi * 10) / 10, period, label, tone, disclaimer: 'RSI 是描述近期漲跌力道相對比例的統計指標，不是價格預測，過去表現不代表未來結果。' };
}

// KD 隨機指標：台灣投資人常用的另一種「相對高低位置」描述指標，一樣是統計位置、不是預測。
function computeKD(history, period = 9) {
  if (!history || history.length < period) {
    return { available: false, reason: `歷史資料不足 ${period} 個交易日，無法計算 KD` };
  }
  let k = 50, d = 50; // 起始值採業界常見慣例
  const series = [];
  for (let i = period - 1; i < history.length; i++) {
    const win = history.slice(i - period + 1, i + 1);
    const highs = win.map((h) => h.highestPrice).filter((v) => v != null);
    const lows = win.map((h) => h.lowestPrice).filter((v) => v != null);
    if (!highs.length || !lows.length) continue;
    const highN = Math.max(...highs);
    const lowN = Math.min(...lows);
    const close = history[i].closingPrice;
    const rsv = highN === lowN ? 50 : ((close - lowN) / (highN - lowN)) * 100;
    k = (2 / 3) * k + (1 / 3) * rsv;
    d = (2 / 3) * d + (1 / 3) * k;
    series.push({ date: history[i].date, k, d });
  }
  if (!series.length) return { available: false, reason: '資料不足以計算 KD' };
  const last = series[series.length - 1];
  let label, tone;
  if (last.k >= 80) { label = 'K值偏「相對高檔」區間 (統計觀察門檻，非賣出訊號)'; tone = 'warning'; }
  else if (last.k <= 20) { label = 'K值偏「相對低檔」區間 (統計觀察門檻，非買進訊號)'; tone = 'warning'; }
  else { label = 'K值處於中性區間'; tone = 'neutral'; }
  const crossNote = last.k > last.d ? 'K值目前在D值之上' : last.k < last.d ? 'K值目前在D值之下' : 'K值與D值接近';
  return {
    available: true,
    k: Math.round(last.k * 10) / 10,
    d: Math.round(last.d * 10) / 10,
    label, tone, crossNote,
    disclaimer: 'KD 是描述近期價格相對高低位置的統計指標，不是價格預測，過去表現不代表未來結果。',
  };
}

// MACD：用短天期與長天期指數移動平均線的差距，描述「動能」相對強弱，同樣不是預測。
function ema(values, period) {
  const k = 2 / (period + 1);
  let prev = values[0];
  const out = [prev];
  for (let i = 1; i < values.length; i++) {
    prev = values[i] * k + prev * (1 - k);
    out.push(prev);
  }
  return out;
}
function computeMACD(history) {
  if (!history || history.length < 35) {
    return { available: false, reason: '歷史資料不足 35 個交易日，無法計算 MACD' };
  }
  const closes = history.map((h) => h.closingPrice);
  const ema12 = ema(closes, 12);
  const ema26 = ema(closes, 26);
  const dif = closes.map((_, i) => ema12[i] - ema26[i]);
  const dea = ema(dif, 9);
  const hist = dif.map((v, i) => v - dea[i]);
  const lastDif = dif[dif.length - 1];
  const lastDea = dea[dea.length - 1];
  const lastHist = hist[hist.length - 1];
  let label, tone;
  if (lastDif > lastDea) { label = 'DIF 在 DEA 之上 (動能偏多方，統計描述非預測)'; tone = 'positive'; }
  else if (lastDif < lastDea) { label = 'DIF 在 DEA 之下 (動能偏空方，統計描述非預測)'; tone = 'negative'; }
  else { label = 'DIF 與 DEA 接近'; tone = 'neutral'; }
  return {
    available: true,
    dif: Math.round(lastDif * 100) / 100,
    dea: Math.round(lastDea * 100) / 100,
    histogram: Math.round(lastHist * 100) / 100,
    label, tone,
    disclaimer: 'MACD 是描述短長期動能差距的統計指標，不是價格預測，過去表現不代表未來結果。',
  };
}

// 成交量趨勢 (「量縮/量增」)：比較近5日均量 vs 前5日均量，這是使用者特別想看的「量有沒有縮」。
function computeVolumeTrend(history) {
  if (!history || history.length < 10) {
    return { available: false, reason: '歷史資料不足 10 個交易日，無法比較成交量趨勢' };
  }
  const volumes = history.map((h) => h.tradeVolume).filter((v) => v != null);
  if (volumes.length < 10) return { available: false, reason: '缺少成交量資料' };
  const recent5 = volumes.slice(-5);
  const prev5 = volumes.slice(-10, -5);
  const avg = (arr) => arr.reduce((s, v) => s + v, 0) / arr.length;
  const recentAvg = avg(recent5);
  const prevAvg = avg(prev5);
  const diffPct = prevAvg === 0 ? 0 : ((recentAvg - prevAvg) / prevAvg) * 100;
  let label, tone;
  if (diffPct >= 20) { label = `近5日均量較前5日放大約 ${Math.round(diffPct)}% (量增)`; tone = 'warning'; }
  else if (diffPct <= -20) { label = `近5日均量較前5日縮減約 ${Math.round(Math.abs(diffPct))}% (量縮)`; tone = 'neutral'; }
  else { label = '近5日均量與前5日相近 (量能持平)'; tone = 'neutral'; }
  return {
    available: true,
    recentAvgVolume: Math.round(recentAvg),
    prevAvgVolume: Math.round(prevAvg),
    diffPct: Math.round(diffPct * 10) / 10,
    label,
    tone,
    disclaimer: '成交量趨勢是描述近期量能相對變化的統計資訊，不是價格預測。',
  };
}

// 法人買賣超「量有沒有縮」：比較近3日合計買賣超股數的絕對值 vs 再前3日，
// 用來回答使用者想看的「法人力道是變強還是在收斂」。
function computeInstitutionalVolumeTrend(trend) {
  if (!trend || trend.length < 6) {
    return { available: false, reason: '法人資料不足 6 個交易日，無法比較力道變化' };
  }
  const recent3 = trend.slice(-3);
  const prev3 = trend.slice(-6, -3);
  const sumAbs = (arr) => arr.reduce((s, t) => s + Math.abs(t.netBuySell), 0);
  const recentSum = sumAbs(recent3);
  const prevSum = sumAbs(prev3);
  const diffPct = prevSum === 0 ? 0 : ((recentSum - prevSum) / prevSum) * 100;
  let label;
  if (diffPct >= 20) label = `近3日法人買賣力道較前3日放大約 ${Math.round(diffPct)}%`;
  else if (diffPct <= -20) label = `近3日法人買賣力道較前3日收斂約 ${Math.round(Math.abs(diffPct))}% (量縮)`;
  else label = '近3日法人買賣力道與前3日相近';
  return { available: true, recentSum, prevSum, diffPct: Math.round(diffPct * 10) / 10, label };
}

// 個股估值資訊：本益比 / 殖利率 / 股價淨值比 (證交所官方 OpenAPI，公開免金鑰，每日盤後更新)
async function getValuation(code) {
  const url = 'https://openapi.twse.com.tw/v1/exchangeReport/BWIBBU_ALL';
  const all = await cachedFetchJson(url);
  const row = (all || []).find((r) => r.Code === code);
  if (!row) return null;
  return {
    code: row.Code,
    name: row.Name,
    peRatio: Number(row.PEratio) || null,          // 本益比
    dividendYield: Number(row.DividendYield) || null, // 殖利率(%)
    pbRatio: Number(row.PBratio) || null,          // 股價淨值比
  };
}

// 台股加權指數 (大盤/台指)：證交所官方「市場成交資訊」，含每日收盤指數與漲跌點數
async function getTaiex() {
  const url = 'https://openapi.twse.com.tw/v1/exchangeReport/FMTQIK';
  const all = await cachedFetchJson(url);
  if (!Array.isArray(all) || !all.length) throw new Error('加權指數資料格式不如預期');
  const last = all[all.length - 1];
  const prev = all.length > 1 ? all[all.length - 2] : null;
  const num = (v) => Number(String(v ?? '').replace(/,/g, '')) || null;
  const index = num(last.TAIEX);
  const prevIndex = prev ? num(prev.TAIEX) : null;
  return {
    symbol: '台股加權指數 (TAIEX)',
    date: last.Date,
    index,
    change: index != null && prevIndex != null ? Math.round((index - prevIndex) * 100) / 100 : num(last.Change),
    tradeValue: num(last.TradeValue), // 當日成交金額(元)
  };
}

// 近 40 個交易日收盤價 + 每日滾動 MA5/MA20，給前端畫「股價走勢 + 均線」圖用
async function getHistoryWithMA(code) {
  const history = await getStockHistory(code);
  const points = history.map((h, i) => {
    const win5 = history.slice(Math.max(0, i - 4), i + 1);
    const win20 = history.slice(Math.max(0, i - 19), i + 1);
    const avg = (arr) => Math.round((arr.reduce((s, x) => s + x.closingPrice, 0) / arr.length) * 100) / 100;
    return {
      date: h.date,
      close: h.closingPrice,
      ma5: win5.length === 5 ? avg(win5) : null,
      ma20: win20.length === 20 ? avg(win20) : null,
    };
  });
  return points.slice(-40);
}

// ---------- 簡易選股/篩選 ----------
// 用證交所官方「全上市個股」估值資料 (本益比/殖利率/股價淨值比) + 當日行情做排序篩選，
// 這是「資料整理」不是「選股建議」：只依使用者指定的條件排序，不做任何買賣判斷語氣。
async function screenStocks(opts = {}) {
  const { sortBy = 'dividendYield', order = 'desc', minDividendYield, maxPE, limit = 20 } = opts;
  const [valuations, quotes] = await Promise.all([
    cachedFetchJson('https://openapi.twse.com.tw/v1/exchangeReport/BWIBBU_ALL'),
    getAllDailyQuotes(),
  ]);
  const quoteByCode = {};
  (quotes || []).forEach((q) => { quoteByCode[q.Code] = q; });

  let rows = (valuations || [])
    .map((r) => {
      const q = quoteByCode[r.Code];
      return {
        code: r.Code,
        name: r.Name,
        peRatio: Number(r.PEratio) || null,
        dividendYield: Number(r.DividendYield) || null,
        pbRatio: Number(r.PBratio) || null,
        closingPrice: q ? Number(q.ClosingPrice) || null : null,
        change: q ? Number(q.Change) || 0 : 0,
        tradeVolume: q ? Number(q.TradeVolume) || 0 : 0,
      };
    })
    .filter((r) => r.closingPrice != null);

  if (minDividendYield != null) rows = rows.filter((r) => r.dividendYield != null && r.dividendYield >= minDividendYield);
  if (maxPE != null) rows = rows.filter((r) => r.peRatio != null && r.peRatio > 0 && r.peRatio <= maxPE);

  const sortKey = ['dividendYield', 'peRatio', 'pbRatio', 'change', 'tradeVolume'].includes(sortBy) ? sortBy : 'dividendYield';
  rows = rows
    .filter((r) => r[sortKey] != null)
    .sort((a, b) => (order === 'asc' ? a[sortKey] - b[sortKey] : b[sortKey] - a[sortKey]));

  return {
    disclaimer: '這是依你指定的條件對證交所公開估值/行情資料做排序整理，屬於資料篩選工具，不是選股建議，投資決策請自行判斷並留意風險。',
    count: rows.length,
    results: rows.slice(0, Math.min(50, limit)),
  };
}

async function healthcheck() {
  try {
    const all = await getAllDailyQuotes();
    return { ok: true, sampleCount: Array.isArray(all) ? all.length : 0 };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

module.exports = {
  getAllDailyQuotes,
  getQuote,
  resolveCode,
  getInstitutionalDaily,
  getInstitutionalForStock,
  getInstitutionalTrend,
  computeSignal,
  getStockHistory,
  computeMovingAverageTrend,
  computeRSI,
  computeKD,
  computeMACD,
  computeVolumeTrend,
  computeInstitutionalVolumeTrend,
  getValuation,
  getTaiex,
  getHistoryWithMA,
  screenStocks,
  healthcheck,
};
