// 遊戲化點數的共用小工具。刻意做成兩個函式就好：
//   awardPoints()      —— 無條件加點 (呼叫端自己要先確認「這件事值得加點」)
//   awardOncePerDay()  —— 同一個 reason 同一天只加一次，給「記帳」這種一天可能記很多筆、
//                          但不希望使用者狂記帳灌點數的情境用。
// 「待辦完成」的防刷點數則不是用這個 (見 tasks.js 的 points_awarded 欄位)，因為那個是
// 「每一筆任務終身只能加一次」，跟「每天一次」是不同的節流方式，各自在呼叫端處理比較清楚。
function awardPoints(db, userId, delta, reason) {
  const now = new Date().toISOString();
  const existing = db.prepare('SELECT user_id FROM user_points WHERE user_id = ?').get(userId);
  if (existing) {
    db.prepare('UPDATE user_points SET balance = balance + ?, updated_at = ? WHERE user_id = ?').run(delta, now, userId);
  } else {
    db.prepare('INSERT INTO user_points (user_id, balance, updated_at) VALUES (?, ?, ?)').run(userId, delta, now);
  }
  db.prepare('INSERT INTO point_transactions (user_id, delta, reason, created_at) VALUES (?, ?, ?, ?)').run(userId, delta, reason, now);
}

function awardOncePerDay(db, userId, delta, reason) {
  const today = new Date().toISOString().slice(0, 10);
  const existing = db
    .prepare("SELECT 1 FROM point_transactions WHERE user_id = ? AND reason = ? AND substr(created_at, 1, 10) = ? LIMIT 1")
    .get(userId, reason, today);
  if (existing) return false;
  awardPoints(db, userId, delta, reason);
  return true;
}

function getBalance(db, userId) {
  const row = db.prepare('SELECT balance FROM user_points WHERE user_id = ?').get(userId);
  return row ? row.balance : 0;
}

module.exports = { awardPoints, awardOncePerDay, getBalance };
