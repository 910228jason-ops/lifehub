const { Router } = require('../mini-http');
const tdx = require('../services/tdx');
const flights = require('../services/flights');
const itinerary = require('../services/itinerary');
const deeplinks = require('../services/deeplinks');
const { getDb } = require('../services/db');
const { requireAuth } = require('../middleware/auth');
const logger = require('../services/logger');

const router = Router();

router.get('/train/:mode/board', requireAuth, async (req, res) => {
  const mode = req.params.mode === 'thsr' ? 'THSR' : 'TRA';
  const station = req.query.station;
  if (!station) return res.status(400).json({ error: '請提供 station 車站名稱' });
  try {
    const data = await tdx.getRealtimeBoard(mode, station, {
      to: req.query.to,
      date: req.query.date,
      timeFrom: req.query.timeFrom,
      timeTo: req.query.timeTo,
      trainNo: req.query.trainNo,
    });
    res.json(data);
  } catch (e) {
    logger.error('取得交通即時資料失敗', { error: e.message });
    res.status(502).json({ error: '交通資料取得失敗', detail: e.message });
  }
});

// ---- 收藏車次 ----
router.get('/train/favorites', requireAuth, (req, res) => {
  const db = getDb();
  res.json(db.prepare('SELECT * FROM favorite_trains WHERE user_id = ? ORDER BY created_at DESC').all(req.session.userId));
});

router.post('/train/favorites', requireAuth, (req, res) => {
  const { mode, trainNo, fromStation, toStation, departureTime, note } = req.body || {};
  if (!mode || !trainNo || !fromStation) return res.status(400).json({ error: '缺少必要欄位 (mode/trainNo/fromStation)' });
  const db = getDb();
  try {
    const info = db
      .prepare(
        `INSERT INTO favorite_trains (user_id, mode, train_no, from_station, to_station, departure_time, note, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(req.session.userId, mode, trainNo, fromStation, toStation || null, departureTime || null, note || null, new Date().toISOString());
    res.json({ id: info.lastInsertRowid });
  } catch (e) {
    res.status(409).json({ error: '這個車次已經收藏過了' });
  }
});

router.delete('/train/favorites/:id', requireAuth, (req, res) => {
  const db = getDb();
  db.prepare('DELETE FROM favorite_trains WHERE id = ? AND user_id = ?').run(req.params.id, req.session.userId);
  res.json({ ok: true });
});

// ---- 機票/訂房各家深連結 ----
router.get('/flights/providers', requireAuth, (req, res) => {
  const { from, to, date } = req.query;
  if (!from || !to) return res.status(400).json({ error: '請提供 from / to' });
  res.json({ from, to, date, providers: deeplinks.flightProviders(from, to, date) });
});

router.get('/hotels/providers', requireAuth, (req, res) => {
  const { city, checkin, checkout } = req.query;
  if (!city) return res.status(400).json({ error: '請提供 city' });
  res.json({ city, checkin, checkout, providers: deeplinks.hotelProviders(city, checkin, checkout) });
});

// 保留舊的示範比價端點 (向下相容)
router.get('/flights/bundle', requireAuth, async (req, res) => {
  const { from, to, date } = req.query;
  if (!from || !to) return res.status(400).json({ error: '請提供 from / to' });
  const data = await flights.getCheapestBundle(from, to, date || new Date().toISOString().slice(0, 10));
  res.json(data);
});

router.post('/itinerary', requireAuth, (req, res) => {
  const { from, to, days } = req.body || {};
  if (!from || !to) return res.status(400).json({ error: '請提供 from / to' });
  res.json(itinerary.generate(from, to, days));
});

// ---------- 行前打包清單 ----------
router.get('/packing', requireAuth, (req, res) => {
  const db = getDb();
  const { tripId } = req.query;
  const rows = tripId
    ? db.prepare('SELECT * FROM packing_items WHERE user_id = ? AND trip_id = ? ORDER BY category, id').all(req.session.userId, tripId)
    : db.prepare('SELECT * FROM packing_items WHERE user_id = ? AND trip_id IS NULL ORDER BY category, id').all(req.session.userId);
  res.json(rows);
});

router.post('/packing', requireAuth, (req, res) => {
  const { item, category, tripId } = req.body || {};
  if (!item || !String(item).trim()) return res.status(400).json({ error: '請填寫項目名稱' });
  const db = getDb();
  const now = new Date().toISOString();
  const result = db.prepare('INSERT INTO packing_items (user_id, trip_id, item, category, checked, created_at) VALUES (?, ?, ?, ?, 0, ?)').run(
    req.session.userId, tripId || null, String(item).trim(), category || '其他', now
  );
  res.json({ id: result.lastInsertRowid, ok: true });
});

router.put('/packing/:id', requireAuth, (req, res) => {
  const { checked } = req.body || {};
  const db = getDb();
  db.prepare('UPDATE packing_items SET checked = ? WHERE id = ? AND user_id = ?').run(checked ? 1 : 0, req.params.id, req.session.userId);
  res.json({ ok: true });
});

router.delete('/packing/:id', requireAuth, (req, res) => {
  const db = getDb();
  db.prepare('DELETE FROM packing_items WHERE id = ? AND user_id = ?').run(req.params.id, req.session.userId);
  res.json({ ok: true });
});

// 常用打包清單範本，依目的地類型給一個起手式，使用者可以自由增刪
const PACKING_TEMPLATES = {
  general: ['護照/證件', '手機充電器', '現金/信用卡', '常備藥品', '換洗衣物'],
  beach: ['泳衣', '防曬乳', '拖鞋', '太陽眼鏡'],
  cold: ['保暖外套', '手套', '暖暖包', '護唇膏'],
  business: ['筆電/充電器', '正式服裝', '名片'],
};
router.get('/packing/template/:type', requireAuth, (req, res) => {
  res.json({ items: PACKING_TEMPLATES[req.params.type] || PACKING_TEMPLATES.general });
});

// ---------- 旅遊分帳 ----------
router.get('/trips', requireAuth, (req, res) => {
  const db = getDb();
  const rows = db.prepare('SELECT * FROM trips WHERE user_id = ? ORDER BY created_at DESC').all(req.session.userId);
  res.json(rows);
});

router.post('/trips', requireAuth, (req, res) => {
  const { name, baseCurrency, startDate, endDate, participantNames } = req.body || {};
  if (!name || !String(name).trim()) return res.status(400).json({ error: '請填寫旅程名稱' });
  const db = getDb();
  const now = new Date().toISOString();
  const result = db.prepare('INSERT INTO trips (user_id, name, base_currency, start_date, end_date, settled, created_at) VALUES (?, ?, ?, ?, ?, 0, ?)').run(
    req.session.userId, String(name).trim(), (baseCurrency || 'TWD').toUpperCase(), startDate || null, endDate || null, now
  );
  const tripId = result.lastInsertRowid;
  const names = Array.isArray(participantNames) && participantNames.length ? participantNames : ['我'];
  const insertP = db.prepare('INSERT INTO trip_participants (trip_id, name, is_me) VALUES (?, ?, ?)');
  names.forEach((n, i) => insertP.run(tripId, String(n).trim() || `旅伴${i + 1}`, i === 0 ? 1 : 0));
  res.json({ id: tripId, ok: true });
});

router.delete('/trips/:id', requireAuth, (req, res) => {
  const db = getDb();
  db.prepare('DELETE FROM trips WHERE id = ? AND user_id = ?').run(req.params.id, req.session.userId);
  res.json({ ok: true });
});

router.put('/trips/:id', requireAuth, (req, res) => {
  const { settled } = req.body || {};
  const db = getDb();
  db.prepare('UPDATE trips SET settled = ? WHERE id = ? AND user_id = ?').run(settled ? 1 : 0, req.params.id, req.session.userId);
  res.json({ ok: true });
});

function getTripOr404(db, tripId, userId) {
  return db.prepare('SELECT * FROM trips WHERE id = ? AND user_id = ?').get(tripId, userId);
}

router.get('/trips/:id/participants', requireAuth, (req, res) => {
  const db = getDb();
  const trip = getTripOr404(db, req.params.id, req.session.userId);
  if (!trip) return res.status(404).json({ error: '找不到這趟旅程' });
  res.json(db.prepare('SELECT * FROM trip_participants WHERE trip_id = ? ORDER BY id').all(req.params.id));
}
);

router.post('/trips/:id/participants', requireAuth, (req, res) => {
  const { name } = req.body || {};
  if (!name || !String(name).trim()) return res.status(400).json({ error: '請填寫名字' });
  const db = getDb();
  const trip = getTripOr404(db, req.params.id, req.session.userId);
  if (!trip) return res.status(404).json({ error: '找不到這趟旅程' });
  const result = db.prepare('INSERT INTO trip_participants (trip_id, name, is_me) VALUES (?, ?, 0)').run(req.params.id, String(name).trim());
  res.json({ id: result.lastInsertRowid, ok: true });
});

router.delete('/trips/:id/participants/:pid', requireAuth, (req, res) => {
  const db = getDb();
  const trip = getTripOr404(db, req.params.id, req.session.userId);
  if (!trip) return res.status(404).json({ error: '找不到這趟旅程' });
  db.prepare('DELETE FROM trip_participants WHERE id = ? AND trip_id = ?').run(req.params.pid, req.params.id);
  res.json({ ok: true });
});

router.get('/trips/:id/expenses', requireAuth, (req, res) => {
  const db = getDb();
  const trip = getTripOr404(db, req.params.id, req.session.userId);
  if (!trip) return res.status(404).json({ error: '找不到這趟旅程' });
  const expenses = db
    .prepare(
      `SELECT e.*, p.name as payer_name FROM trip_expenses e
       JOIN trip_participants p ON p.id = e.payer_id
       WHERE e.trip_id = ? ORDER BY e.expense_date DESC, e.id DESC`
    )
    .all(req.params.id);
  const shareStmt = db.prepare(
    `SELECT s.*, p.name as participant_name FROM trip_expense_shares s JOIN trip_participants p ON p.id = s.participant_id WHERE s.expense_id = ?`
  );
  expenses.forEach((e) => { e.shares = shareStmt.all(e.id); });
  res.json(expenses);
});

// 新增一筆花費：預設由選定的參與者均分 (以旅程 base_currency 計價)，
// 也可以傳入 customShares (物件 {participantId: 金額}) 自訂每人分攤多少
router.post('/trips/:id/expenses', requireAuth, (req, res) => {
  const { payerId, description, amount, currency, exchangeRate, expenseDate, participantIds, customShares } = req.body || {};
  const amt = Number(amount);
  if (!payerId || !amt || amt <= 0) return res.status(400).json({ error: '請填寫墊款人與金額' });
  const db = getDb();
  const trip = getTripOr404(db, req.params.id, req.session.userId);
  if (!trip) return res.status(404).json({ error: '找不到這趟旅程' });

  const rate = Number(exchangeRate) > 0 ? Number(exchangeRate) : 1;
  const baseAmount = Math.round(amt * rate * 100) / 100;
  const allParticipants = db.prepare('SELECT id FROM trip_participants WHERE trip_id = ?').all(req.params.id).map((p) => p.id);
  const sharers = Array.isArray(participantIds) && participantIds.length ? participantIds : allParticipants;

  let shares;
  if (customShares && typeof customShares === 'object' && Object.keys(customShares).length) {
    shares = Object.entries(customShares).map(([pid, v]) => ({ participantId: Number(pid), shareAmount: Number(v) }));
    const sum = shares.reduce((s, x) => s + x.shareAmount, 0);
    if (Math.abs(sum - baseAmount) > 1) {
      return res.status(400).json({ error: `自訂分攤總和 (${sum}) 跟花費金額 (${baseAmount}) 對不起來，請確認` });
    }
  } else {
    const per = Math.round((baseAmount / sharers.length) * 100) / 100;
    shares = sharers.map((pid, i) => ({
      participantId: pid,
      // 最後一人吃掉四捨五入的零頭，確保總和精確等於 baseAmount
      shareAmount: i === sharers.length - 1 ? Math.round((baseAmount - per * (sharers.length - 1)) * 100) / 100 : per,
    }));
  }

  const now = new Date().toISOString();
  const result = db
    .prepare('INSERT INTO trip_expenses (trip_id, payer_id, description, amount, currency, exchange_rate, expense_date, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)')
    .run(req.params.id, payerId, description || null, amt, (currency || trip.base_currency).toUpperCase(), rate, expenseDate || now.slice(0, 10), now);
  const expenseId = result.lastInsertRowid;
  const insertShare = db.prepare('INSERT INTO trip_expense_shares (expense_id, participant_id, share_amount) VALUES (?, ?, ?)');
  shares.forEach((s) => insertShare.run(expenseId, s.participantId, s.shareAmount));
  res.json({ id: expenseId, ok: true });
});

router.delete('/trips/:id/expenses/:eid', requireAuth, (req, res) => {
  const db = getDb();
  const trip = getTripOr404(db, req.params.id, req.session.userId);
  if (!trip) return res.status(404).json({ error: '找不到這趟旅程' });
  db.prepare('DELETE FROM trip_expenses WHERE id = ? AND trip_id = ?').run(req.params.eid, req.params.id);
  res.json({ ok: true });
});

// 結算：算出每個人「墊了多少-該付多少」的淨額，並用貪心演算法配對成最少筆數的轉帳建議，
// 不管是「一人先墊全部」還是「大家輪流出」都適用，因為記錄的是每一筆花費各自的墊款人
router.get('/trips/:id/settlement', requireAuth, (req, res) => {
  const db = getDb();
  const trip = getTripOr404(db, req.params.id, req.session.userId);
  if (!trip) return res.status(404).json({ error: '找不到這趟旅程' });

  const participants = db.prepare('SELECT * FROM trip_participants WHERE trip_id = ?').all(req.params.id);
  const paidByParticipant = {};
  const owedByParticipant = {};
  participants.forEach((p) => { paidByParticipant[p.id] = 0; owedByParticipant[p.id] = 0; });

  const expenses = db.prepare('SELECT * FROM trip_expenses WHERE trip_id = ?').all(req.params.id);
  expenses.forEach((e) => {
    paidByParticipant[e.payer_id] = (paidByParticipant[e.payer_id] || 0) + Math.round(e.amount * e.exchange_rate * 100) / 100;
  });
  const shares = db
    .prepare(`SELECT s.* FROM trip_expense_shares s JOIN trip_expenses e ON e.id = s.expense_id WHERE e.trip_id = ?`)
    .all(req.params.id);
  shares.forEach((s) => { owedByParticipant[s.participant_id] = (owedByParticipant[s.participant_id] || 0) + s.share_amount; });

  const net = participants.map((p) => ({
    id: p.id,
    name: p.name,
    paid: Math.round((paidByParticipant[p.id] || 0) * 100) / 100,
    owed: Math.round((owedByParticipant[p.id] || 0) * 100) / 100,
    net: Math.round(((paidByParticipant[p.id] || 0) - (owedByParticipant[p.id] || 0)) * 100) / 100,
  }));

  // 貪心配對：欠最多的人付給被欠最多的人，最小化轉帳筆數
  const creditors = net.filter((n) => n.net > 0.5).map((n) => ({ ...n })).sort((a, b) => b.net - a.net);
  const debtors = net.filter((n) => n.net < -0.5).map((n) => ({ ...n, net: -n.net })).sort((a, b) => b.net - a.net);
  const transfers = [];
  let ci = 0, di = 0;
  while (ci < creditors.length && di < debtors.length) {
    const c = creditors[ci], d = debtors[di];
    const amount = Math.round(Math.min(c.net, d.net) * 100) / 100;
    if (amount > 0.5) transfers.push({ from: d.name, to: c.name, amount });
    c.net -= amount; d.net -= amount;
    if (c.net <= 0.5) ci++;
    if (d.net <= 0.5) di++;
  }

  res.json({
    baseCurrency: trip.base_currency,
    balances: net,
    transfers,
    disclaimer: '結算金額是依照每筆花費記錄的墊款人與分攤方式計算，實際付款方式由你們自行決定。',
  });
});

module.exports = router;
