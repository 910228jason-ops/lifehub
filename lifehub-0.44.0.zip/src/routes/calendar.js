const crypto = require('crypto');
const { Router } = require('../mini-http');
const { getDb } = require('../services/db');
const { requireAuth } = require('../middleware/auth');
const { getLunarInfo } = require('../services/lunar');

const router = Router();

const RECURRENCE_OPTIONS = ['daily', 'weekly', 'monthly', 'yearly'];

function addInterval(dateStr, recurrence, interval, n) {
  // 從 dateStr 開始，往後跳 n 次「recurrence 週期 × interval」，回傳新的 YYYY-MM-DD。
  const d = new Date(dateStr + 'T00:00:00Z');
  const step = interval * n;
  if (recurrence === 'daily') d.setUTCDate(d.getUTCDate() + step);
  else if (recurrence === 'weekly') d.setUTCDate(d.getUTCDate() + 7 * step);
  else if (recurrence === 'monthly') d.setUTCMonth(d.getUTCMonth() + step);
  else if (recurrence === 'yearly') d.setUTCFullYear(d.getUTCFullYear() + step);
  return d.toISOString().slice(0, 10);
}

// 把「重複行程」的單一基準列展開成查詢範圍 [from,to] 內所有實際出現的日期。
// 展開出來的每一筆都保留同一個 id (代表同一個系列)，前端編輯/刪除時是整個系列一起動，
// 不支援「只改這一次」這種更複雜的單次例外——對個人使用的行事曆來說先夠用，之後真的
// 需要再加。guard 上限是防呆 (例如每天重複又忘記設結束日期，避免無限展開拖垮效能)。
function expandRecurringEvents(baseEvents, from, to) {
  const out = [];
  baseEvents.forEach((ev) => {
    if (!ev.recurrence || !RECURRENCE_OPTIONS.includes(ev.recurrence)) {
      if (ev.event_date >= from && ev.event_date <= to) out.push(ev);
      return;
    }
    const interval = Math.max(1, ev.recurrence_interval || 1);
    const daysPerCycle = { daily: 1, weekly: 7, monthly: 30, yearly: 365 }[ev.recurrence] * interval;
    const roughDaysDiff = (new Date(from + 'T00:00:00Z') - new Date(ev.event_date + 'T00:00:00Z')) / 86400000;
    // 先快轉到第一個可能落在 from 之前一點點的次數，避免從第 0 次逐一累加到 from 太慢
    // (例如每天重複、from 是三年後的情況)。
    let n = roughDaysDiff > 0 ? Math.max(0, Math.floor(roughDaysDiff / daysPerCycle) - 2) : 0;
    let cur = addInterval(ev.event_date, ev.recurrence, interval, n);
    let guard = 0;
    while (cur <= to && guard < 400) {
      guard++;
      if (ev.recurrence_end && cur > ev.recurrence_end) break;
      if (cur >= from && cur >= ev.event_date) {
        out.push({ ...ev, event_date: cur, is_recurring_instance: cur !== ev.event_date });
      }
      n++;
      cur = addInterval(ev.event_date, ev.recurrence, interval, n);
    }
  });
  return out;
}

// 帳單到期日、待辦截止日、人際關係重要日子 (生日/紀念日)——這三類本來就有自己的資料表，
// 不重複存進 calendar_events，而是查詢行事曆某個月份範圍時「即時算出來」疊加顯示，
// 標成唯讀 (readonly)，前端不能直接在行事曆刪除/編輯這些，要到原本的分頁去動。
// 這樣才不用「新增行程時再手動抄一次帳單到期日」，兩邊資料源永遠是同一份、不會兜不起來。
function buildAutoEntries(db, userId, from, to) {
  const entries = [];
  const fromD = new Date(from + 'T00:00:00Z');
  const toD = new Date(to + 'T00:00:00Z');

  // ---- 帳單：每個月的 due_day，clamp 到當月實際天數 (例如 2 月沒有 30 號) ----
  try {
    const bills = db.prepare('SELECT * FROM bills WHERE user_id = ? AND active = 1').all(userId);
    if (bills.length) {
      const paidRows = db.prepare('SELECT bill_id, paid_period FROM bill_payments WHERE user_id = ?').all(userId);
      const paidSet = new Set(paidRows.map((r) => `${r.bill_id}:${r.paid_period}`));
      for (let y = fromD.getUTCFullYear(); y <= toD.getUTCFullYear(); y++) {
        const mStart = y === fromD.getUTCFullYear() ? fromD.getUTCMonth() : 0;
        const mEnd = y === toD.getUTCFullYear() ? toD.getUTCMonth() : 11;
        for (let m = mStart; m <= mEnd; m++) {
          const lastDayOfMonth = new Date(Date.UTC(y, m + 1, 0)).getUTCDate();
          bills.forEach((b) => {
            const day = Math.min(b.due_day, lastDayOfMonth);
            const dateStr = `${y}-${String(m + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
            if (dateStr < from || dateStr > to) return;
            const period = `${y}-${String(m + 1).padStart(2, '0')}`;
            const paid = paidSet.has(`${b.id}:${period}`);
            entries.push({
              id: `bill-${b.id}-${period}`, event_date: dateStr, start_time: null,
              title: `🧾 ${b.name}${paid ? '（已繳）' : ''}`, note: `NT$${Number(b.amount).toLocaleString()}`,
              category: 'auto-bill', readonly: true, sourceTab: 'bills',
            });
          });
        }
      }
    }
  } catch (e) { /* 帳單模組資料不存在時忽略，不影響其他來源 */ }

  // ---- 待辦事項：有設定截止日、還沒完成的 ----
  try {
    const tasks = db
      .prepare("SELECT id, title, due_date FROM tasks WHERE user_id = ? AND completed = 0 AND due_date IS NOT NULL AND due_date >= ? AND due_date <= ?")
      .all(userId, from, to);
    tasks.forEach((t) => {
      entries.push({
        id: `task-${t.id}`, event_date: t.due_date, start_time: null,
        title: `✅ ${t.title}`, note: null, category: 'auto-task', readonly: true, sourceTab: 'tasks',
      });
    });
  } catch (e) { /* ignore */ }

  // ---- 人際關係：生日 (relationships.birthday) + 重要日期 (important_dates)，都是 MM-DD 每年重複 ----
  try {
    const rels = db.prepare("SELECT id, name, birthday FROM relationships WHERE user_id = ? AND birthday IS NOT NULL").all(userId);
    const importantDates = db
      .prepare(
        `SELECT d.*, r.name as relationship_name FROM important_dates d
         LEFT JOIN relationships r ON r.id = d.relationship_id WHERE d.user_id = ?`
      )
      .all(userId);
    const yearlyItems = [
      ...rels.map((r) => ({ monthDay: r.birthday, label: `🎂 ${r.name} 生日` })),
      ...importantDates.map((d) => ({ monthDay: d.month_day, label: `🎉 ${d.relationship_name ? d.relationship_name + ' · ' : ''}${d.label}` })),
    ];
    for (let y = fromD.getUTCFullYear(); y <= toD.getUTCFullYear(); y++) {
      yearlyItems.forEach((item) => {
        if (!/^\d{2}-\d{2}$/.test(item.monthDay)) return;
        const dateStr = `${y}-${item.monthDay}`;
        if (dateStr < from || dateStr > to) return;
        entries.push({
          id: `reldate-${item.monthDay}-${y}-${item.label}`, event_date: dateStr, start_time: null,
          title: item.label, note: null, category: 'auto-date', readonly: true, sourceTab: 'relationships',
        });
      });
    }
  } catch (e) { /* ignore */ }

  return entries;
}

router.get('/', requireAuth, (req, res) => {
  const db = getDb();
  const { from, to } = req.query;
  let rows;
  if (from && to) {
    // 抓「event_date <= to」的所有列 (含重複行程的基準列，即使基準日期在 from 之前也要抓，
    // 才能展開出落在 [from,to] 範圍內的後續重複次數)，交給 expandRecurringEvents 篩選。
    rows = db
      .prepare(
        `SELECT * FROM calendar_events WHERE user_id = ? AND event_date <= ?
         AND (recurrence IS NOT NULL OR event_date >= ?) ORDER BY event_date, start_time`
      )
      .all(req.session.userId, to, from);
    rows = expandRecurringEvents(rows, from, to);
    rows = rows.concat(buildAutoEntries(db, req.session.userId, from, to));
    rows.sort((a, b) => (a.event_date + (a.start_time || '')).localeCompare(b.event_date + (b.start_time || '')));
  } else {
    rows = db
      .prepare('SELECT * FROM calendar_events WHERE user_id = ? ORDER BY event_date, start_time LIMIT 200')
      .all(req.session.userId);
  }
  res.json(rows);
});

// 某個月份範圍內每一天的農曆日期／節氣標籤，跟 GET / 分開拉，因為這份資料完全不依賴
// 使用者的個人資料 (純日期算天文)，理論上還可以在前端快取，不用每次都重新算。
router.get('/lunar-info', requireAuth, (req, res) => {
  const { from, to } = req.query;
  if (!from || !to) return res.status(400).json({ error: '缺少 from/to' });
  const result = {};
  const cur = new Date(from + 'T00:00:00Z');
  const end = new Date(to + 'T00:00:00Z');
  let guard = 0;
  while (cur <= end && guard < 400) {
    guard++;
    const y = cur.getUTCFullYear(), m = cur.getUTCMonth() + 1, d = cur.getUTCDate();
    const info = getLunarInfo(y, m, d);
    const dateStr = `${y}-${String(m).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
    if (info) {
      result[dateStr] = {
        label: info.isFirstDay ? `${info.isLeapMonth ? '閏' : ''}${info.monthName}` : info.dayName,
        solarTerm: info.solarTerm,
      };
    }
    cur.setUTCDate(cur.getUTCDate() + 1);
  }
  res.json(result);
});

router.post('/', requireAuth, (req, res) => {
  const { event_date, start_time, title, note, category, recurrence, recurrenceInterval, recurrenceEnd } = req.body || {};
  if (!event_date || !title) return res.status(400).json({ error: '缺少必要欄位 (event_date/title)' });
  const rec = RECURRENCE_OPTIONS.includes(recurrence) ? recurrence : null;
  const ri = Math.max(1, Number(recurrenceInterval) || 1);
  const db = getDb();
  const now = new Date().toISOString();
  const info = db
    .prepare(
      `INSERT INTO calendar_events (user_id, event_date, start_time, title, note, category, created_at, updated_at, recurrence, recurrence_interval, recurrence_end)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    )
    .run(req.session.userId, event_date, start_time || null, title, note || null, category || 'other', now, now, rec, ri, rec ? (recurrenceEnd || null) : null);
  res.json({ id: info.lastInsertRowid });
});

router.put('/:id', requireAuth, (req, res) => {
  const { event_date, start_time, title, note, category, recurrence, recurrenceInterval, recurrenceEnd } = req.body || {};
  const rec = RECURRENCE_OPTIONS.includes(recurrence) ? recurrence : null;
  const ri = Math.max(1, Number(recurrenceInterval) || 1);
  const db = getDb();
  db.prepare(
    `UPDATE calendar_events SET event_date = ?, start_time = ?, title = ?, note = ?, category = ?, updated_at = ?,
     recurrence = ?, recurrence_interval = ?, recurrence_end = ? WHERE id = ? AND user_id = ?`
  ).run(
    event_date, start_time || null, title, note || null, category || 'other', new Date().toISOString(),
    rec, ri, rec ? (recurrenceEnd || null) : null, req.params.id, req.session.userId
  );
  res.json({ ok: true });
});

router.delete('/:id', requireAuth, (req, res) => {
  const db = getDb();
  db.prepare('DELETE FROM calendar_events WHERE id = ? AND user_id = ?').run(req.params.id, req.session.userId);
  res.json({ ok: true });
});

// ---- .ics 訂閱：讓 Apple/Google 行事曆可以直接訂閱，之後新增的行程手機原生行事曆會自動同步 ----
router.post('/ics-token', requireAuth, (req, res) => {
  const db = getDb();
  const token = crypto.randomBytes(24).toString('base64url');
  db.prepare('UPDATE users SET ics_token = ? WHERE id = ?').run(token, req.session.userId);
  res.json({ token });
});

router.post('/ics-token/revoke', requireAuth, (req, res) => {
  const db = getDb();
  db.prepare('UPDATE users SET ics_token = NULL WHERE id = ?').run(req.session.userId);
  res.json({ ok: true });
});

router.get('/ics-token', requireAuth, (req, res) => {
  const db = getDb();
  const row = db.prepare('SELECT ics_token FROM users WHERE id = ?').get(req.session.userId);
  res.json({ token: (row && row.ics_token) || null });
});

function icsEscape(str) {
  return String(str || '').replace(/\\/g, '\\\\').replace(/;/g, '\\;').replace(/,/g, '\\,').replace(/\n/g, '\\n');
}

// 訂閱網址本身不能用一般登入 session 保護 (行事曆 App 是背景定期用固定網址去抓，
// 不會先幫你登入)，改用網址帶的隨機 token 當驗證方式；沒有 token 或 token 不對就直接
// 回 404，不透露「這個 token 存不存在」這種訊息，避免被拿來亂猜。
router.get('/export.ics', (req, res) => {
  const token = req.query.token;
  if (!token) return res.status(404).end('Not found');
  const db = getDb();
  const user = db.prepare('SELECT id FROM users WHERE ics_token = ?').get(token);
  if (!user) return res.status(404).end('Not found');

  // 匯出範圍：過去 90 天到未來 365 天，避免無上限查詢拖垮效能，這個範圍對「訂閱同步」
  // 這種用途來說已經很夠用 (太久以前的行程本來就沒有同步的必要)。
  const today = new Date();
  const from = new Date(today); from.setDate(from.getDate() - 90);
  const to = new Date(today); to.setDate(to.getDate() + 365);
  const fromStr = from.toISOString().slice(0, 10);
  const toStr = to.toISOString().slice(0, 10);

  let rows = db
    .prepare(
      `SELECT * FROM calendar_events WHERE user_id = ? AND event_date <= ?
       AND (recurrence IS NOT NULL OR event_date >= ?) ORDER BY event_date, start_time`
    )
    .all(user.id, toStr, fromStr);
  rows = expandRecurringEvents(rows, fromStr, toStr);
  rows = rows.concat(buildAutoEntries(db, user.id, fromStr, toStr));

  const lines = ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//LifeHub//Calendar//ZH-TW', 'CALSCALE:GREGORIAN', 'X-WR-CALNAME:LifeHub'];
  rows.forEach((ev) => {
    const dateCompact = ev.event_date.replace(/-/g, '');
    const uid = `${typeof ev.id === 'string' ? ev.id : `event-${ev.id}`}-${dateCompact}@lifehub`;
    lines.push('BEGIN:VEVENT');
    lines.push(`UID:${uid}`);
    if (ev.start_time) {
      const [hh, mm] = ev.start_time.split(':');
      lines.push(`DTSTART:${dateCompact}T${hh}${mm}00`);
    } else {
      lines.push(`DTSTART;VALUE=DATE:${dateCompact}`);
    }
    lines.push(`SUMMARY:${icsEscape(ev.title)}`);
    if (ev.note) lines.push(`DESCRIPTION:${icsEscape(ev.note)}`);
    lines.push('END:VEVENT');
  });
  lines.push('END:VCALENDAR');

  res.setHeader('Content-Type', 'text/calendar; charset=utf-8');
  res.setHeader('Content-Disposition', 'attachment; filename="lifehub.ics"');
  res.end(lines.join('\r\n'));
});

module.exports = router;
