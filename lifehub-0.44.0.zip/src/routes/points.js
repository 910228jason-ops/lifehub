// 遊戲化點數 + 獎勵兌換頁面 (v0.43)。
//
// 點數本身不能直接調整 (沒有「手動加點」的 API)，只會在完成待辦/寫日記/記心情/記帳這幾個
// 既有行為時自動加點 (見 tasks.js/diary.js/mood.js/finance.js 裡對 services/points.js 的呼叫)，
// 這裡只負責「查詢點數/管理獎勵項目/兌換」。
//
// 獎勵項目完全由使用者自訂 (標題 + 花費點數)，系統不預設任何獎勵內容——每個人想犒賞自己的
// 東西差異很大 (有人想要「看一集劇」，有人想要「買一杯手搖飲」)，預設清單多半用不到，不如
// 讓使用者自己決定「多少點換什麼」。

const { Router } = require('../mini-http');
const { getDb } = require('../services/db');
const { requireAuth } = require('../middleware/auth');
const { getBalance } = require('../services/points');

const router = Router();

router.get('/points', requireAuth, (req, res) => {
  const db = getDb();
  const balance = getBalance(db, req.session.userId);
  const transactions = db
    .prepare('SELECT delta, reason, created_at FROM point_transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT 50')
    .all(req.session.userId);
  res.json({ balance, transactions });
});

router.get('/points/rewards', requireAuth, (req, res) => {
  const db = getDb();
  const rewards = db.prepare('SELECT * FROM point_rewards WHERE user_id = ? ORDER BY cost ASC').all(req.session.userId);
  res.json({ rewards, balance: getBalance(db, req.session.userId) });
});

router.post('/points/rewards', requireAuth, (req, res) => {
  const { title, cost } = req.body || {};
  const trimmed = String(title || '').trim();
  const costNum = Number(cost);
  if (!trimmed) return res.status(400).json({ error: '請輸入獎勵名稱' });
  if (!Number.isInteger(costNum) || costNum <= 0) return res.status(400).json({ error: '花費點數必須是大於 0 的整數' });
  const db = getDb();
  const result = db
    .prepare('INSERT INTO point_rewards (user_id, title, cost, created_at) VALUES (?, ?, ?, ?)')
    .run(req.session.userId, trimmed, costNum, new Date().toISOString());
  res.json({ id: result.lastInsertRowid });
});

router.put('/points/rewards/:id', requireAuth, (req, res) => {
  const db = getDb();
  const reward = db.prepare('SELECT * FROM point_rewards WHERE id = ? AND user_id = ?').get(req.params.id, req.session.userId);
  if (!reward) return res.status(404).json({ error: '找不到這個獎勵項目' });
  const { title, cost } = req.body || {};
  const trimmed = String(title || '').trim();
  const costNum = Number(cost);
  if (!trimmed) return res.status(400).json({ error: '請輸入獎勵名稱' });
  if (!Number.isInteger(costNum) || costNum <= 0) return res.status(400).json({ error: '花費點數必須是大於 0 的整數' });
  db.prepare('UPDATE point_rewards SET title = ?, cost = ? WHERE id = ?').run(trimmed, costNum, reward.id);
  res.json({ ok: true });
});

router.delete('/points/rewards/:id', requireAuth, (req, res) => {
  const db = getDb();
  db.prepare('DELETE FROM point_rewards WHERE id = ? AND user_id = ?').run(req.params.id, req.session.userId);
  res.json({ ok: true });
});

router.post('/points/rewards/:id/redeem', requireAuth, (req, res) => {
  const db = getDb();
  const reward = db.prepare('SELECT * FROM point_rewards WHERE id = ? AND user_id = ?').get(req.params.id, req.session.userId);
  if (!reward) return res.status(404).json({ error: '找不到這個獎勵項目' });
  const balance = getBalance(db, req.session.userId);
  if (balance < reward.cost) return res.status(400).json({ error: `點數不夠，還差 ${reward.cost - balance} 點` });

  const now = new Date().toISOString();
  db.prepare('UPDATE user_points SET balance = balance - ?, updated_at = ? WHERE user_id = ?').run(reward.cost, now, req.session.userId);
  db.prepare('INSERT INTO point_transactions (user_id, delta, reason, created_at) VALUES (?, ?, ?, ?)').run(
    req.session.userId, -reward.cost, `redeem:${reward.title}`, now
  );
  db.prepare('INSERT INTO point_redemptions (user_id, reward_id, reward_title, cost, created_at) VALUES (?, ?, ?, ?, ?)').run(
    req.session.userId, reward.id, reward.title, reward.cost, now
  );
  res.json({ ok: true, newBalance: getBalance(db, req.session.userId) });
});

router.get('/points/redemptions', requireAuth, (req, res) => {
  const db = getDb();
  const rows = db
    .prepare('SELECT reward_title, cost, created_at FROM point_redemptions WHERE user_id = ? ORDER BY created_at DESC LIMIT 50')
    .all(req.session.userId);
  res.json({ redemptions: rows });
});

module.exports = router;
