// 意見回饋：任何登入的使用者都能送出 (問題回報/建議/其他)，但只有管理者帳號
// (見 src/services/admin.js) 能看到全部人的列表——一般使用者送出後看不到列表，
// 也看不到別人 (或自己) 之前寫過什麼，避免大家的回饋內容互相看得到造成尷尬。
//
// 注意：這支路由沒有在 server.js 用 app.mount() 單獨掛載，而是被 debug.js
// (已掛載在 /api) 合併進去，變成 /api/feedback——因為這個專案的部署流程是把
// zip 內容貼進 GitHub 網頁編輯器，「刻意不去動 server.js」，所以新功能盡量透過
// 擴充已經掛載好的路由檔案來加，不用每次新增功能都要多動一支 server.js。

const { Router } = require('../mini-http');
const { getDb } = require('../services/db');
const { requireAuth } = require('../middleware/auth');
const { isAdminEmail } = require('../services/admin');

const router = Router();

const CATEGORIES = new Set(['bug', 'suggestion', 'other']);

router.post('/feedback', requireAuth, (req, res) => {
  const { message, category } = req.body || {};
  const text = String(message || '').trim();
  if (!text) return res.status(400).json({ error: '請輸入回饋內容' });
  if (text.length > 2000) return res.status(400).json({ error: '內容太長了 (上限 2000 字)' });
  const cat = CATEGORIES.has(category) ? category : 'other';

  const db = getDb();
  const now = new Date().toISOString();
  db.prepare('INSERT INTO feedback (user_id, category, message, created_at) VALUES (?, ?, ?, ?)').run(
    req.session.userId,
    cat,
    text,
    now
  );
  res.json({ ok: true });
});

router.get('/feedback', requireAuth, (req, res) => {
  const db = getDb();
  const me = db.prepare('SELECT email FROM users WHERE id = ?').get(req.session.userId);
  if (!isAdminEmail(me && me.email)) {
    return res.status(403).json({ error: '沒有權限查看' });
  }
  const rows = db
    .prepare(
      `SELECT feedback.id, feedback.category, feedback.message, feedback.created_at,
              users.name AS user_name, users.email AS user_email
       FROM feedback
       JOIN users ON users.id = feedback.user_id
       ORDER BY feedback.id DESC
       LIMIT 500`
    )
    .all();
  res.json({ items: rows });
});

// 刪除單筆回饋：只有管理者能刪 (伺服器端再檢查一次 email，不是只靠前端不顯示刪除鈕)。
// 刪掉的是回饋本身，不影響送出這筆回饋的使用者帳號或其他資料。
router.delete('/feedback/:id', requireAuth, (req, res) => {
  const db = getDb();
  const me = db.prepare('SELECT email FROM users WHERE id = ?').get(req.session.userId);
  if (!isAdminEmail(me && me.email)) {
    return res.status(403).json({ error: '沒有權限刪除' });
  }
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) return res.status(400).json({ error: '無效的 id' });
  const info = db.prepare('DELETE FROM feedback WHERE id = ?').run(id);
  if (info.changes === 0) return res.status(404).json({ error: '找不到這筆回饋 (可能已經被刪過了)' });
  res.json({ ok: true });
});

module.exports = router;
