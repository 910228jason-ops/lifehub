const { Router } = require('../mini-http');
const { getDb } = require('../services/db');
const { requireAuth } = require('../middleware/auth');

const router = Router();

function todayStr() { return new Date().toISOString().slice(0, 10); }

// ---------- 睡眠 ----------

router.get('/sleep', requireAuth, (req, res) => {
  const db = getDb();
  const { from, to } = req.query;
  let rows;
  if (from && to) {
    rows = db.prepare('SELECT * FROM health_sleep_entries WHERE user_id = ? AND entry_date BETWEEN ? AND ? ORDER BY entry_date ASC').all(req.session.userId, from, to);
  } else {
    rows = db.prepare('SELECT * FROM health_sleep_entries WHERE user_id = ? ORDER BY entry_date DESC LIMIT 60').all(req.session.userId);
  }
  res.json(rows);
});

router.put('/sleep/:date', requireAuth, (req, res) => {
  const { date } = req.params;
  const { hours, note } = req.body || {};
  const hoursNum = Number(hours);
  if (!date || Number.isNaN(hoursNum) || hoursNum < 0 || hoursNum > 24) {
    return res.status(400).json({ error: '請提供有效的日期與 0-24 之間的睡眠時數' });
  }
  const db = getDb();
  const now = new Date().toISOString();
  db.prepare(
    `INSERT INTO health_sleep_entries (user_id, entry_date, hours, note, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?)
     ON CONFLICT(user_id, entry_date) DO UPDATE SET hours = excluded.hours, note = excluded.note, updated_at = excluded.updated_at`
  ).run(req.session.userId, date, hoursNum, note || null, now, now);
  res.json({ ok: true });
});

router.get('/sleep/summary', requireAuth, (req, res) => {
  const db = getDb();
  const n = Math.min(Math.max(Number(req.query.days) || 30, 1), 180);
  const since = new Date();
  since.setDate(since.getDate() - n);
  const sinceStr = since.toISOString().slice(0, 10);
  const rows = db.prepare('SELECT entry_date, hours FROM health_sleep_entries WHERE user_id = ? AND entry_date >= ? ORDER BY entry_date ASC').all(req.session.userId, sinceStr);
  const avg = rows.length ? Math.round((rows.reduce((s, r) => s + r.hours, 0) / rows.length) * 10) / 10 : null;
  res.json({ series: rows, average: avg, count: rows.length });
});

// ---------- 服藥 ----------

router.get('/meds', requireAuth, (req, res) => {
  const db = getDb();
  const rows = db.prepare('SELECT * FROM health_meds WHERE user_id = ? AND active = 1 ORDER BY id ASC').all(req.session.userId);
  res.json(rows);
});

router.post('/meds', requireAuth, (req, res) => {
  const { name, dose, scheduleTime } = req.body || {};
  if (!name || !String(name).trim()) return res.status(400).json({ error: '請提供藥品名稱' });
  const db = getDb();
  const now = new Date().toISOString();
  const result = db.prepare('INSERT INTO health_meds (user_id, name, dose, schedule_time, active, created_at) VALUES (?, ?, ?, ?, 1, ?)').run(
    req.session.userId, String(name).trim(), dose || null, scheduleTime || null, now
  );
  res.json({ id: result.lastInsertRowid, ok: true });
});

router.delete('/meds/:id', requireAuth, (req, res) => {
  const db = getDb();
  db.prepare('UPDATE health_meds SET active = 0 WHERE id = ? AND user_id = ?').run(req.params.id, req.session.userId);
  res.json({ ok: true });
});

// 當天服藥打勾：用 (med_id, log_date) 當 key，重複打同一天會直接覆蓋，不會產生多筆
router.put('/meds/:id/log', requireAuth, (req, res) => {
  const db = getDb();
  const med = db.prepare('SELECT id FROM health_meds WHERE id = ? AND user_id = ?').get(req.params.id, req.session.userId);
  if (!med) return res.status(404).json({ error: '找不到這筆藥品' });
  const date = (req.body && req.body.date) || todayStr();
  const taken = req.body && req.body.taken != null ? (req.body.taken ? 1 : 0) : 1;
  const now = new Date().toISOString();
  db.prepare(
    `INSERT INTO health_med_logs (user_id, med_id, log_date, taken, created_at) VALUES (?, ?, ?, ?, ?)
     ON CONFLICT(med_id, log_date) DO UPDATE SET taken = excluded.taken`
  ).run(req.session.userId, req.params.id, date, taken, now);
  res.json({ ok: true });
});

router.get('/meds/today', requireAuth, (req, res) => {
  const db = getDb();
  const date = req.query.date || todayStr();
  const meds = db.prepare('SELECT * FROM health_meds WHERE user_id = ? AND active = 1 ORDER BY id ASC').all(req.session.userId);
  const logs = db.prepare('SELECT med_id, taken FROM health_med_logs WHERE user_id = ? AND log_date = ?').all(req.session.userId, date);
  const takenByMed = {};
  logs.forEach((l) => { takenByMed[l.med_id] = !!l.taken; });
  res.json(meds.map((m) => ({ ...m, takenToday: !!takenByMed[m.id] })));
});

module.exports = router;
