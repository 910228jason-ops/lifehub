const { Router } = require('../mini-http');
const assistant = require('../services/assistant');
const { getDb } = require('../services/db');
const { requireAuth } = require('../middleware/auth');
const logger = require('../services/logger');

const router = Router();

// 對話記錄存在資料庫、以使用者為單位，這樣重新整理頁面或換裝置登入都還在，
// 跟日記/記帳/行事曆的持久化方式一致。只保留「最近」300 則，避免單一使用者無限長。
// 注意：要拿到「最近」的訊息，SQL 要先用 id DESC 撈出最新的 N 筆，再用 JS reverse()
// 還原成正常的時間順序 —— 如果直接用 id ASC LIMIT，撈到的永遠是最早的 N 筆，
// 對話一旦超過上限，AI 就會卡在很久以前的內容、看不到最近講的東西 (這是先前版本的 bug，這裡修掉)。
const MAX_HISTORY = 300;

function fetchRecentHistory(db, table, userId, limit) {
  const rows = db
    .prepare(`SELECT role, content, created_at FROM ${table} WHERE user_id = ? ORDER BY id DESC LIMIT ?`)
    .all(userId, limit);
  return rows.reverse();
}

router.get('/history', requireAuth, (req, res) => {
  const db = getDb();
  res.json(fetchRecentHistory(db, 'assistant_messages', req.session.userId, MAX_HISTORY));
});

router.post('/chat', requireAuth, async (req, res) => {
  const { message } = req.body || {};
  if (!message || !String(message).trim()) {
    return res.status(400).json({ error: '請提供 message' });
  }
  const db = getDb();
  const now = new Date().toISOString();
  db.prepare('INSERT INTO assistant_messages (user_id, role, content, created_at) VALUES (?, ?, ?, ?)').run(
    req.session.userId,
    'user',
    message,
    now
  );

  const history = fetchRecentHistory(db, 'assistant_messages', req.session.userId, MAX_HISTORY);

  try {
    const result = await assistant.chat(history);
    db.prepare('INSERT INTO assistant_messages (user_id, role, content, created_at) VALUES (?, ?, ?, ?)').run(
      req.session.userId,
      'assistant',
      result.reply,
      new Date().toISOString()
    );
    res.json(result);
  } catch (e) {
    logger.error('AI 助理對話失敗', { error: e.message });
    res.status(502).json({ error: 'AI 助理暫時無法回應，請稍後再試', detail: e.message });
  }
});

// ---- 首頁摘要 ----
// 手動觸發 (按鈕按下才呼叫 AI，不是每次載入首頁就打 API)，彙整帳單/行程/任務/人際/記帳超支，
// 組成一段自然語言摘要。依使用者裝置當下的時段 (早/午/晚/深夜) 調整語氣跟關注重點，
// 讓首頁不會每次都長一樣、也不會一直是「早安簡報」的固定形式。
const PERIOD_PROMPTS = {
  morning: { label: '早晨', tone: '像剛睡醒的人在喝第一杯咖啡前，快速幫他抓重點、語氣清爽俐落，帶點迎接新的一天的感覺。' },
  afternoon: { label: '午後', tone: '像朋友在下午茶時間跟他核對一下今天過得如何、還有什麼待辦，語氣放鬆、不趕。' },
  evening: { label: '傍晚', tone: '像一天忙完準備收工，幫他快速盤點今天還沒處理完的事、明天要注意的事，語氣溫和、帶點今天辛苦了的感覺。' },
  night: { label: '深夜', tone: '語氣放輕放慢，提醒明天的重點就好，不要塞太多資訊，並自然帶一句早點休息 (但不要說教)。' },
};

function briefingSystemPrompt(period) {
  const p = PERIOD_PROMPTS[period] || PERIOD_PROMPTS.morning;
  return `你是 LifeHub 的生活助理，現在要幫使用者寫一段「${p.label}摘要」。使用者提供了幾個模塊目前的狀態資料 (帳單、行程、任務、記帳、人際)，
請把這些整理成一段 3-5 句的自然語言摘要，${p.tone}
不要用條列式，把資訊自然地編織成一段話。如果某個項目沒有資料就別提，不要硬湊。
如果人際互動的部分有資料，只是單純提一下、語氣要跟其他資訊一樣輕鬆平等，絕對不要用催促或「應該要」的語氣要求使用者去聯絡誰，決定權在使用者身上。
如果各項目都沒什麼特別的事，就輕鬆地說一切都在掌握中，不用硬找話題。
請一律用繁體中文回覆，不要加任何開場白或「以下是摘要」這種話，直接就是內容本身。`;
}

router.post('/briefing', requireAuth, async (req, res) => {
  const db = getDb();
  const userId = req.session.userId;
  const period = ['morning', 'afternoon', 'evening', 'night'].includes(req.body && req.body.period) ? req.body.period : 'morning';
  const todayStr = new Date().toISOString().slice(0, 10);
  const monthLike = `${todayStr.slice(0, 7)}%`;

  const bills = db.prepare('SELECT id FROM bills WHERE user_id = ? AND active = 1').all(userId);
  const billPayments = db.prepare(
    `SELECT bill_id FROM bill_payments WHERE user_id = ? AND paid_period = ?`
  ).all(userId, todayStr.slice(0, 7));
  const paidIds = new Set(billPayments.map((p) => p.bill_id));
  const billRows = db.prepare('SELECT name, due_day, amount FROM bills WHERE user_id = ? AND active = 1').all(userId);
  const todayDay = new Date(todayStr + 'T00:00:00Z').getUTCDate();
  const billsDueSoon = billRows
    .filter((b) => !paidIds.has(b.id) && b.due_day - todayDay >= 0 && b.due_day - todayDay <= 5)
    .map((b) => `${b.name} (${b.due_day}號到期，NT$${b.amount})`);

  const events = db
    .prepare('SELECT title, start_time FROM calendar_events WHERE user_id = ? AND event_date = ? ORDER BY start_time ASC')
    .all(userId, todayStr)
    .map((e) => (e.start_time ? `${e.start_time} ${e.title}` : e.title));

  const tasksDue = db
    .prepare("SELECT title FROM tasks WHERE user_id = ? AND completed = 0 AND due_date IS NOT NULL AND due_date <= ?")
    .all(userId, todayStr)
    .map((t) => t.title);

  const rels = db.prepare('SELECT * FROM relationships WHERE user_id = ?').all(userId);
  const lastRows = db
    .prepare('SELECT relationship_id, MAX(interaction_date) as last_date FROM relationship_interactions WHERE user_id = ? GROUP BY relationship_id')
    .all(userId);
  const lastByRel = {};
  lastRows.forEach((r) => { lastByRel[r.relationship_id] = r.last_date; });
  const DEFAULT_INTERVAL = { family: 30, friend: 45, colleague: 60, other: 60 };
  const today = new Date(todayStr + 'T00:00:00Z');
  const dueContacts = rels
    .filter((r) => {
      const lastDate = lastByRel[r.id];
      const interval = r.reminder_interval_days || DEFAULT_INTERVAL[r.relation_type] || DEFAULT_INTERVAL.other;
      if (!lastDate) return true;
      const days = Math.round((today - new Date(lastDate + 'T00:00:00Z')) / (1000 * 60 * 60 * 24));
      return days >= interval;
    })
    .map((r) => r.name)
    .slice(0, 3);

  const budgets = db.prepare('SELECT category, monthly_limit FROM finance_budgets WHERE user_id = ?').all(userId);
  const spendRows = db
    .prepare("SELECT category, SUM(amount) as total FROM finance_transactions WHERE user_id = ? AND tx_date LIKE ? AND type = 'expense' GROUP BY category")
    .all(userId, monthLike);
  const spendByCategory = {};
  spendRows.forEach((r) => { spendByCategory[r.category] = r.total; });
  const overBudget = budgets
    .filter((b) => (spendByCategory[b.category] || 0) > b.monthly_limit)
    .map((b) => `${b.category} 已超出預算 (花了 NT$${Math.round(spendByCategory[b.category])}，預算 NT$${b.monthly_limit})`);

  const parts = [];
  if (billsDueSoon.length) parts.push(`近期帳單: ${billsDueSoon.join('、')}`);
  if (events.length) parts.push(`今天行程: ${events.join('、')}`);
  if (tasksDue.length) parts.push(`到期/逾期任務: ${tasksDue.join('、')}`);
  if (overBudget.length) parts.push(`記帳提醒: ${overBudget.join('、')}`);
  if (dueContacts.length) parts.push(`好一陣子沒特別聯繫的人 (僅供參考): ${dueContacts.join('、')}`);

  if (!parts.length) {
    return res.json({ isConfigured: true, reply: '目前沒有特別緊急的事項，帳單、行程、任務都在掌握中，順順過今天就好。' });
  }

  try {
    const result = await assistant.chat([{ role: 'user', content: parts.join('\n') }], { systemPrompt: briefingSystemPrompt(period) });
    res.json(result);
  } catch (e) {
    logger.error('首頁摘要產生失敗', { error: e.message });
    res.status(502).json({ error: '摘要暫時無法產生，請稍後再試', detail: e.message });
  }
});

router.delete('/history', requireAuth, (req, res) => {
  const db = getDb();
  db.prepare('DELETE FROM assistant_messages WHERE user_id = ?').run(req.session.userId);
  res.json({ ok: true });
});

module.exports = router;
