// 家庭公告欄 (v0.42)：直接重用 partnerLink.js 已經有的邀請碼配對系統
// (partner_links / partner_link_invites)，不重新設計一套「家庭群組」機制。
//
// 圈子的定義：對使用者 U 來說，「家庭公告欄」看得到的貼文 = U 自己發的 + U 直接連結
// 的每一個人發的 (一層，不做遞移擴散——如果 A 連結 B、B 又連結 C，A 不會自動看到 C 發的貼文，
// 這跟現有 shared-calendar/shared-tasks 這幾支 API「只看一層」的行為一致，維持整個專案裡
// 「連結」這個概念的行為一致，也比較容易理解「我看得到誰的東西」)。
//
// 任何一位圈內成員都可以看到彼此的貼文、也都可以把貼文「置頂」(公告欄本質上是共用的佈告板，
// 不是誰的私人動態牆)，但只有作者本人可以編輯/刪除自己發的貼文，避免誤刪別人的內容。

const { Router } = require('../mini-http');
const { getDb } = require('../services/db');
const { requireAuth } = require('../middleware/auth');

const router = Router();

function getLinkedUserIds(db, userId) {
  const rows = db
    .prepare('SELECT user_a_id, user_b_id FROM partner_links WHERE user_a_id = ? OR user_b_id = ?')
    .all(userId, userId);
  return rows.map((r) => (r.user_a_id === userId ? r.user_b_id : r.user_a_id));
}

// 圈子 = 自己 + 直接連結的人。回傳含自己在內的完整 id 清單，方便 SQL IN () 查詢，
// 也回傳「圈子大小 (不含自己)」給前端判斷要不要顯示「還沒連結任何人」的引導畫面。
function getCircle(db, userId) {
  const linked = getLinkedUserIds(db, userId);
  return { memberIds: [userId, ...linked], circleSize: linked.length };
}

function userLabel(db, userId, selfId) {
  if (userId === selfId) return '我';
  const u = db.prepare('SELECT name, email FROM users WHERE id = ?').get(userId);
  return (u && (u.name || u.email)) || '（帳號已刪除）';
}

router.get('/family-board', requireAuth, (req, res) => {
  const db = getDb();
  const selfId = req.session.userId;
  const { memberIds, circleSize } = getCircle(db, selfId);
  const placeholders = memberIds.map(() => '?').join(',');
  const rows = db
    .prepare(`SELECT * FROM family_posts WHERE author_user_id IN (${placeholders}) ORDER BY pinned DESC, created_at DESC LIMIT 200`)
    .all(...memberIds);
  const posts = rows.map((r) => ({
    id: r.id,
    content: r.content,
    pinned: !!r.pinned,
    createdAt: r.created_at,
    updatedAt: r.updated_at,
    authorUserId: r.author_user_id,
    authorLabel: userLabel(db, r.author_user_id, selfId),
    isMine: r.author_user_id === selfId,
  }));
  res.json({ posts, circleSize });
});

router.post('/family-board', requireAuth, (req, res) => {
  const { content } = req.body || {};
  const trimmed = String(content || '').trim();
  if (!trimmed) return res.status(400).json({ error: '公告內容不能空白' });
  if (trimmed.length > 2000) return res.status(400).json({ error: '內容太長了，請控制在 2000 字以內' });
  const db = getDb();
  const now = new Date().toISOString();
  const result = db
    .prepare('INSERT INTO family_posts (author_user_id, content, pinned, created_at, updated_at) VALUES (?, ?, 0, ?, ?)')
    .run(req.session.userId, trimmed, now, now);
  res.json({ id: result.lastInsertRowid });
});

router.put('/family-board/:id', requireAuth, (req, res) => {
  const db = getDb();
  const post = db.prepare('SELECT * FROM family_posts WHERE id = ?').get(req.params.id);
  if (!post) return res.status(404).json({ error: '找不到這則公告' });
  if (post.author_user_id !== req.session.userId) return res.status(403).json({ error: '只能編輯自己發的公告' });
  const { content } = req.body || {};
  const trimmed = String(content || '').trim();
  if (!trimmed) return res.status(400).json({ error: '公告內容不能空白' });
  db.prepare('UPDATE family_posts SET content = ?, updated_at = ? WHERE id = ?').run(trimmed, new Date().toISOString(), post.id);
  res.json({ ok: true });
});

router.delete('/family-board/:id', requireAuth, (req, res) => {
  const db = getDb();
  const post = db.prepare('SELECT * FROM family_posts WHERE id = ?').get(req.params.id);
  if (!post) return res.status(404).json({ error: '找不到這則公告' });
  if (post.author_user_id !== req.session.userId) return res.status(403).json({ error: '只能刪除自己發的公告' });
  db.prepare('DELETE FROM family_posts WHERE id = ?').run(post.id);
  res.json({ ok: true });
});

// 置頂/取消置頂：任何圈內成員都可以做 (公告欄是共用佈告板)，但要先確認這則貼文真的
// 在自己的圈子範圍內，不能透過猜 id 去置頂/取消置頂跟自己完全無關的人的貼文。
router.post('/family-board/:id/pin', requireAuth, (req, res) => {
  const db = getDb();
  const selfId = req.session.userId;
  const post = db.prepare('SELECT * FROM family_posts WHERE id = ?').get(req.params.id);
  if (!post) return res.status(404).json({ error: '找不到這則公告' });
  const { memberIds } = getCircle(db, selfId);
  if (!memberIds.includes(post.author_user_id)) return res.status(403).json({ error: '這則公告不在你的圈子範圍內' });
  const nextPinned = post.pinned ? 0 : 1;
  db.prepare('UPDATE family_posts SET pinned = ?, updated_at = ? WHERE id = ?').run(nextPinned, new Date().toISOString(), post.id);
  res.json({ ok: true, pinned: !!nextPinned });
});

module.exports = router;
