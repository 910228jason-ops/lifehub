-- v0.22.0：待辦事項拆解成小任務 + 首頁跨模組洞察/主動提醒功能所需的資料表

-- 小任務：一筆待辦事項底下可以拆成多筆小任務，各自獨立打勾，
-- 用「已完成小任務數 / 總小任務數」算這筆任務的進度百分比。
CREATE TABLE IF NOT EXISTS task_subtasks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  task_id INTEGER NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  completed INTEGER NOT NULL DEFAULT 0,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_task_subtasks_task ON task_subtasks(task_id);
