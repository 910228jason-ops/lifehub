-- v0.33.0：把「幫另一半記錄生理週期」這種單向資料代填，擴充成真正的雙向帳號連結機制，
-- 讓兩個各自有帳號的人 (伴侶/家人) 可以互相「看到」對方分享出來的行事曆、待辦事項，
-- 用邀請碼建立連結，任一方隨時可以解除，且目前設計是唯讀分享 (不能互相修改對方的資料)。

CREATE TABLE IF NOT EXISTS partner_link_invites (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  inviter_user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  code TEXT UNIQUE NOT NULL,
  created_at TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  used_by_user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  used_at TEXT
);

CREATE TABLE IF NOT EXISTS partner_links (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_a_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  user_b_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL,
  UNIQUE(user_a_id, user_b_id)
);
