-- v0.32.0：底部導覽列「首頁、股票、記帳、待辦」原本是寫死釘住的，改成使用者可以自訂
-- 最多 3 個常駐項目 (首頁固定不可移除，不算在這裡面)，存成 JSON 陣列的 tab key 清單。
ALTER TABLE user_prefs ADD COLUMN bottom_nav_pinned_json TEXT NOT NULL DEFAULT '[]';
