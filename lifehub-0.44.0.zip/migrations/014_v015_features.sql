-- v0.15.0：財務(訂閱偵測/淨資產趨勢)、待辦(重複性任務/每週回顧)、
--          人際關係(重要日期通用版)、交通旅遊(行前打包清單/旅遊分帳含多幣別)

-- 重複性任務：新增一次就能自動產生下一次，不用每次手動輸入
ALTER TABLE tasks ADD COLUMN recurrence TEXT CHECK (recurrence IN ('daily','weekly','monthly'));
ALTER TABLE tasks ADD COLUMN recurrence_interval INTEGER NOT NULL DEFAULT 1;

-- 重要日期：比生日更通用，可以是紀念日、對方的特殊日子，也可以不綁定特定聯絡人
CREATE TABLE IF NOT EXISTS important_dates (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  relationship_id INTEGER REFERENCES relationships(id) ON DELETE CASCADE,
  label TEXT NOT NULL,
  month_day TEXT NOT NULL, -- MM-DD，每年重複
  note TEXT,
  created_at TEXT NOT NULL
);

-- 行前打包清單：可綁定某趟旅程，也可以是獨立的常用清單
CREATE TABLE IF NOT EXISTS packing_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  trip_id INTEGER,
  item TEXT NOT NULL,
  category TEXT,
  checked INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);

-- 旅遊分帳：一趟旅程、參與的人 (不需要對方也有帳號)、花費 (支援多幣別+匯率換算成旅程基準幣別)
CREATE TABLE IF NOT EXISTS trips (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  base_currency TEXT NOT NULL DEFAULT 'TWD',
  start_date TEXT,
  end_date TEXT,
  settled INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS trip_participants (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  trip_id INTEGER NOT NULL REFERENCES trips(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  is_me INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS trip_expenses (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  trip_id INTEGER NOT NULL REFERENCES trips(id) ON DELETE CASCADE,
  payer_id INTEGER NOT NULL REFERENCES trip_participants(id) ON DELETE CASCADE,
  description TEXT,
  amount REAL NOT NULL CHECK (amount > 0),
  currency TEXT NOT NULL DEFAULT 'TWD',
  exchange_rate REAL NOT NULL DEFAULT 1, -- 1 單位 currency = 多少 base_currency
  expense_date TEXT,
  created_at TEXT NOT NULL
);

-- 這筆花費由哪些人分攤、各自分攤金額 (以旅程 base_currency 計價)
CREATE TABLE IF NOT EXISTS trip_expense_shares (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  expense_id INTEGER NOT NULL REFERENCES trip_expenses(id) ON DELETE CASCADE,
  participant_id INTEGER NOT NULL REFERENCES trip_participants(id) ON DELETE CASCADE,
  share_amount REAL NOT NULL
);
