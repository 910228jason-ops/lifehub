-- v0.43.0：遊戲化點數 + 獎勵兌換頁面。
-- 設計刻意簡單：點數只是「完成待辦/寫日記/記心情/記帳」這幾個既有行為的附加小獎勵，不是
-- 另外一套要花心力維護的任務系統；獎勵項目 (多少點換什麼) 完全由使用者自己定義跟兌換，
-- 系統不預設任何獎勵內容 (每個人想犒賞自己的東西差異很大，預設清單多半用不到)。
CREATE TABLE IF NOT EXISTS user_points (
  user_id INTEGER PRIMARY KEY,
  balance INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL
);

-- 點數流水帳：每一筆加點/扣點都留紀錄，才能在「點數紀錄」頁面讓使用者看得懂點數是怎麼來的、
-- 怎麼花掉的，不是只有一個看不出所以然的總數字。
CREATE TABLE IF NOT EXISTS point_transactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  delta INTEGER NOT NULL,
  reason TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_point_tx_user ON point_transactions(user_id, created_at);

CREATE TABLE IF NOT EXISTS point_rewards (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  title TEXT NOT NULL,
  cost INTEGER NOT NULL,
  created_at TEXT NOT NULL
);

-- 兌換紀錄把當時的獎勵名稱/花費點數另外存一份 (不只存 reward_id)，
-- 這樣就算之後使用者把那個獎勵項目刪掉或改名，兌換歷史紀錄還是讀得懂當初換了什麼。
CREATE TABLE IF NOT EXISTS point_redemptions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  reward_id INTEGER,
  reward_title TEXT NOT NULL,
  cost INTEGER NOT NULL,
  created_at TEXT NOT NULL
);

-- 待辦事項加一個「這筆有沒有已經因為完成而加過點數」的標記，避免使用者靠「打勾→取消勾選→
-- 再打勾」反覆刷點數；一旦加過就永遠標記為 1，不會因為之後取消完成又被清掉。
ALTER TABLE tasks ADD COLUMN points_awarded INTEGER NOT NULL DEFAULT 0;
