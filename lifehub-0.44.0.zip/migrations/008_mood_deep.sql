-- v0.9.0：心情陪伴深化第二階段
--   1) mood_thought_records：CBT 式思考記錄 (卡住的時候，陪你走一遍認知重塑練習)
--   2) mood_technique_feedback：因應技巧的使用回饋，讓推薦愈用愈準
--   3) mood_patterns：跨模塊 (心情/行事曆/記帳/日記) 深層模式分析的快取結果
--   4) mood_chat_memory：AI 陪伴對話的長期記憶摘要 (聊太久之前的重點不會被忘記)

CREATE TABLE IF NOT EXISTS mood_thought_records (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  situation TEXT,
  thought TEXT NOT NULL,
  emotion TEXT,
  intensity INTEGER CHECK (intensity BETWEEN 1 AND 10),
  evidence_for TEXT,
  evidence_against TEXT,
  reframe TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS mood_technique_feedback (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  tag TEXT NOT NULL,
  technique_key TEXT NOT NULL,
  helped INTEGER NOT NULL CHECK (helped IN (0, 1)),
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS mood_patterns (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  signals_json TEXT NOT NULL,
  insights TEXT NOT NULL,
  generated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS mood_chat_memory (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  chunk_from_id INTEGER NOT NULL,
  chunk_to_id INTEGER NOT NULL,
  summary TEXT NOT NULL,
  created_at TEXT NOT NULL
);
