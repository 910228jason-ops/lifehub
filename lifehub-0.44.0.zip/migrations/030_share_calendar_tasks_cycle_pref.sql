-- v0.39.0：把「已連結的家人/伴侶預設就能看到我的行事曆/待辦/生理週期狀態」這件事，
-- 也比照 v0.36.0 心情統計那個「自己單方面決定」的開關做法，讓使用者可以自己選擇要不要
-- 收回這個權限。DEFAULT 1 (開啟) 是為了維持舊帳號原本「連結了就自動看得到」的行為，不會
-- 因為這次改版讓既有的分享突然消失，使用者要關掉的話自己去「個人化設定」關就好。
ALTER TABLE user_prefs ADD COLUMN share_calendar_with_partner INTEGER NOT NULL DEFAULT 1;
ALTER TABLE user_prefs ADD COLUMN share_tasks_with_partner INTEGER NOT NULL DEFAULT 1;
ALTER TABLE user_prefs ADD COLUMN share_cycle_with_partner INTEGER NOT NULL DEFAULT 1;
