-- v0.5.0：行事曆事項加上分類 (例如 飲食/電影/運動/工作)，月曆檢視要用顏色小方塊呈現

ALTER TABLE calendar_events ADD COLUMN category TEXT NOT NULL DEFAULT 'other';
