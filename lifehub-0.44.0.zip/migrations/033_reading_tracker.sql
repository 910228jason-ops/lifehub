-- v0.44.0：讀書分類底下的閱讀/戲劇進度追蹤。type 用來區分「書」跟「戲劇/影集」，
-- 因為兩者共同的欄位其實一樣多 (標題/狀態/進度/評分/心得)，不需要兩張分開的表。
CREATE TABLE IF NOT EXISTS reading_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  type TEXT NOT NULL DEFAULT 'book',
  title TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'want',
  progress TEXT,
  rating INTEGER,
  note TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_reading_items_user ON reading_items(user_id, status);
