-- v0.29.0：首頁「全部功能」捷徑格 + 手機底部「更多」選單新增可自訂排序，
-- 順序存成 JSON 陣列字串，用法跟既有的 module_order_json 一致。
ALTER TABLE user_prefs ADD COLUMN more_nav_order_json TEXT NOT NULL DEFAULT '[]';
