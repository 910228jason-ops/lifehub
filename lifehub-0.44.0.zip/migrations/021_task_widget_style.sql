-- 首頁「待辦事項」卡片的顯示樣式偏好 (grouped=分組統計條/progress=完成進度環/focus=今日焦點)，
-- 使用者可以直接在首頁卡片上切換、即時比較效果，選定後存起來，下次登入/換裝置都會記得。
-- 預設用 progress (進度環)，這是使用者看過三種 mockup 後選定的樣式。
ALTER TABLE user_prefs ADD COLUMN task_widget_style TEXT DEFAULT 'progress';
