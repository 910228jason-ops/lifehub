-- v0.25.0：行事曆重複行程、匯出成 .ics 訂閱網址。
--
-- 重複行程比照待辦事項 (tasks.recurrence) 的欄位設計，但邏輯不一樣：待辦是「完成後才
-- 產生下一筆」，行事曆則是「查詢某個月份範圍時，直接展開成當月所有符合的日期」，這樣
-- 使用者不用先勾完這次才看得到下一次，例如「每週一固定會議」這個月剩下的每個週一都要
-- 一次全部看得到。見 src/routes/calendar.js 的 expandRecurringEvents()。
ALTER TABLE calendar_events ADD COLUMN recurrence TEXT CHECK (recurrence IN ('daily','weekly','monthly','yearly'));
ALTER TABLE calendar_events ADD COLUMN recurrence_interval INTEGER NOT NULL DEFAULT 1;
ALTER TABLE calendar_events ADD COLUMN recurrence_end TEXT; -- YYYY-MM-DD，留空代表不設結束日期 (一直重複下去)

-- .ics 訂閱：讓 Apple/Google 行事曆可以直接訂閱這個網址，之後新增的行程手機原生行事曆
-- 會自動同步進去，不用兩邊各記一次。訂閱網址不能用一般登入 session 保護 (行事曆 App
-- 是用固定網址去抓，不會幫你登入)，所以另外產生一組不會被猜到的隨機 token 當作網址密碼；
-- 外流風險只有「被看到你的行程標題」，沒有帳號密碼等級的風險，但還是設計成「使用者自己
-- 主動按一下才會產生 token」，不產生就不會有這個網址存在。
ALTER TABLE users ADD COLUMN ics_token TEXT;
CREATE UNIQUE INDEX IF NOT EXISTS idx_users_ics_token ON users(ics_token) WHERE ics_token IS NOT NULL;
