-- v0.12.0：五個跨模塊深度功能所需的資料庫調整
--   財務目標、人際關係提醒週期、任務精力標籤

CREATE TABLE IF NOT EXISTS finance_goals (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  target_amount REAL NOT NULL,
  target_date TEXT,
  start_date TEXT NOT NULL,
  archived INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);

ALTER TABLE relationships ADD COLUMN reminder_interval_days INTEGER;

ALTER TABLE tasks ADD COLUMN energy_level TEXT CHECK (energy_level IN ('low','medium','high'));
