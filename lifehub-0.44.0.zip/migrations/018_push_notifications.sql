-- v0.23.0：背景推播通知 (Web Push)。
-- 沒有另外裝 web-push 這類套件 (沙盒環境連不到 npm registry，即使能連，這專案本來就
-- 堅持零外部依賴)：VAPID 簽章、訊息加密都是標準的 ECDSA/ECDH，直接用 Node 內建的
-- crypto 模組手刻，效果一樣，見 src/services/webpush.js。

-- 簡單的 key-value 設定表，目前只用來存伺服器自動產生的 VAPID 金鑰對 (不需要使用者
-- 自己申請/貼上任何金鑰，第一次有人開通推播時，伺服器自己生一組、存起來、之後都重複用)。
CREATE TABLE IF NOT EXISTS app_settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

-- 每個裝置訂閱一筆：同一個使用者在手機/電腦分開訂閱都可以，各自收各自的推播。
CREATE TABLE IF NOT EXISTS push_subscriptions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  endpoint TEXT NOT NULL UNIQUE,
  p256dh TEXT NOT NULL,
  auth TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_push_subscriptions_user ON push_subscriptions(user_id);

-- 記錄每個使用者上一次收到推播的內容摘要跟時間，避免背景排程每次都重複推同一件事、
-- 或太頻繁打擾 (見 src/routes/push.js 的排程邏輯：內容沒變 或 距離上次不到設定的間隔就不送)。
CREATE TABLE IF NOT EXISTS push_notify_log (
  user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  last_signature TEXT,
  last_sent_at TEXT
);
