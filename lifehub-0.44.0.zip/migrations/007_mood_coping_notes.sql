-- v0.8.0：心情陪伴深化 —— 安心小卡 (使用者自己收藏、或從 AI 對話存下來的安撫小提醒)

CREATE TABLE IF NOT EXISTS mood_coping_notes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  content TEXT NOT NULL,
  created_at TEXT NOT NULL
);
