-- v0.7.0：心情陪伴模組
-- mood_entries：每天一筆心情紀錄 (1-10 分，10 分最好)，可複選標籤、可寫原因、可對到當天日記。
-- mood_chat_messages：獨立於一般 AI 助理的「情緒陪伴」對話記錄，語氣與安全機制跟一般助理不同，
--   分開存放才不會讓兩種對話混在一起，使用者也可以分別清除。

CREATE TABLE IF NOT EXISTS mood_entries (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  entry_date TEXT NOT NULL,
  score INTEGER NOT NULL CHECK (score BETWEEN 1 AND 10),
  tags TEXT,
  note TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  UNIQUE(user_id, entry_date)
);

CREATE TABLE IF NOT EXISTS mood_chat_messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role TEXT NOT NULL CHECK (role IN ('user','assistant')),
  content TEXT NOT NULL,
  flagged INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);
