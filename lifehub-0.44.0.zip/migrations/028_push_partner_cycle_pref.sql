-- v0.35.0：另一半的生理週期狀態 (快來月經了/經前觀察窗) 現在也能接進主動提醒系統，
-- 比照生日提醒的做法，預設只出現在首頁、要不要額外推播由使用者自己決定 (預設關閉)。
ALTER TABLE user_prefs ADD COLUMN push_partner_cycle_reminders INTEGER NOT NULL DEFAULT 0;
