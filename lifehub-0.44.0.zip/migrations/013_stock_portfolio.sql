-- v0.13.0：完善股票模塊——庫存損益追蹤、股利紀錄、到價提醒。
-- 損益用「移動加權平均成本法」在程式端計算 (不額外存「目前庫存/均價」這種衍生欄位，
-- 直接從交易紀錄算，跟財務目標的做法一致，避免資料不同步)。

CREATE TABLE IF NOT EXISTS stock_transactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  code TEXT NOT NULL,
  name TEXT,
  trade_date TEXT NOT NULL,
  side TEXT NOT NULL CHECK (side IN ('buy', 'sell')),
  shares INTEGER NOT NULL CHECK (shares > 0),
  price REAL NOT NULL CHECK (price >= 0),
  fee REAL NOT NULL DEFAULT 0,
  tax REAL NOT NULL DEFAULT 0,
  note TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS stock_dividends (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  code TEXT NOT NULL,
  name TEXT,
  pay_date TEXT NOT NULL,
  amount REAL NOT NULL CHECK (amount >= 0),
  note TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS stock_price_alerts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  code TEXT NOT NULL,
  name TEXT,
  target_price REAL NOT NULL,
  direction TEXT NOT NULL CHECK (direction IN ('above', 'below')),
  active INTEGER NOT NULL DEFAULT 1,
  triggered_at TEXT,
  created_at TEXT NOT NULL
);
