-- v0.29.0：服藥提醒背景推播——health_meds 本來就有 schedule_time 欄位，但一直沒有真的接到
-- 推播排程上，只是靜靜存在資料庫裡沒作用。這張表記錄「這顆藥今天有沒有已經推播過提醒」，
-- 避免背景排程每分鐘掃一次的時候同一天重複推播同一顆藥。
CREATE TABLE IF NOT EXISTS health_med_reminder_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  med_id INTEGER NOT NULL REFERENCES health_meds(id) ON DELETE CASCADE,
  sent_date TEXT NOT NULL,
  created_at TEXT NOT NULL,
  UNIQUE(med_id, sent_date)
);
