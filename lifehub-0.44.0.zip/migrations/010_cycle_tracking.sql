-- v0.11.0：生理週期紀錄 (選填功能)，用來讓「跨模塊模式分析」跟「主動關心」
-- 也能考慮經前 (黃體期後段) 這個常見會影響情緒的階段。完全選填，不會預設要求填寫。

CREATE TABLE IF NOT EXISTS cycle_entries (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  period_start_date TEXT NOT NULL,
  period_end_date TEXT,
  symptoms TEXT,
  created_at TEXT NOT NULL
);
