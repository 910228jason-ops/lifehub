-- v0.17.0：使用者意見回饋
-- 任何登入的使用者都能送出回饋 (問題回報/建議/其他)，但只有管理者帳號 (見
-- src/services/admin.js 的 ADMIN_EMAIL) 能看到全部人的回饋列表，其他人只能送出、
-- 看不到自己以外(甚至也看不到自己送出過)的列表內容。
CREATE TABLE IF NOT EXISTS feedback (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  category TEXT NOT NULL DEFAULT 'other',
  message TEXT NOT NULL,
  created_at TEXT NOT NULL
);
