-- 待辦事項的「精準時間提醒」：使用者可以手動設定、或透過 AI 助理說「N 分鐘/秒後提醒我 XXX」
-- 由 AI 判斷相對時間換算成絕對時間戳記寫進 remind_at。背景排程 (src/routes/push.js) 每 15 秒
-- 掃一次到期但還沒推播過 (remind_sent_at IS NULL) 的任務，推播後蓋上 remind_sent_at，避免重複推播。
ALTER TABLE tasks ADD COLUMN remind_at TEXT; -- ISO 8601 完整時間戳記 (含秒)，NULL = 沒有設定精準提醒
ALTER TABLE tasks ADD COLUMN remind_sent_at TEXT; -- 已經推播過的時間戳記，NULL = 還沒推播(或還沒到時間)
CREATE INDEX IF NOT EXISTS idx_tasks_remind_pending ON tasks(remind_at) WHERE remind_at IS NOT NULL AND remind_sent_at IS NULL;
