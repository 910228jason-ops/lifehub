-- v0.42.0：家庭公告欄。重用既有的 partner_links 邀請碼配對系統 (partnerLink.js)，不用
-- 再另外設計一套「家庭群組」的邀請機制——一個使用者只要透過邀請碼跟任何人建立連結 (原本
-- 系統就支援跟多個人同時連結，不限單一伴侶)，這些連結對象彼此之間的公告貼文就會互相看得到，
-- 形成一個「以我為中心」的公告圈子，不需要額外的「家庭」實體或群組管理介面。
CREATE TABLE IF NOT EXISTS family_posts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  author_user_id INTEGER NOT NULL,
  content TEXT NOT NULL,
  pinned INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_family_posts_author ON family_posts(author_user_id);
