-- v0.12.1：生理週期紀錄新增「這是在幫誰記錄」欄位。
-- 有些使用者記錄的不是自己的經期，而是在幫另一半記錄方便提醒對方，
-- 這種情況不該被拿去分析「使用者自己」的心情關聯，所以需要區分開來。

ALTER TABLE cycle_entries ADD COLUMN tracking_for TEXT NOT NULL DEFAULT 'self' CHECK (tracking_for IN ('self', 'partner'));
