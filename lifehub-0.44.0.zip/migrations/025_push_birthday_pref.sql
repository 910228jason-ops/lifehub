-- v0.30.0：生日提醒預設只出現在首頁，要不要「推播」出去讓使用者自己決定 (預設關閉，
-- 首頁本來就看得到，不用強迫每個人都收到生日推播通知)。
ALTER TABLE user_prefs ADD COLUMN push_birthday_reminders INTEGER NOT NULL DEFAULT 0;
