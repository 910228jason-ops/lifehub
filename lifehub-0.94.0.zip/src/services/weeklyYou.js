// v0.93「這週的你」：用幾句「只講事實」的話整理這週 (星期一到今天)，跟上週比較。
// 資料全部來自使用者已經有的紀錄 (說出來、心情分數、待辦、記帳、帳單)，不需要多記任何東西，也不用 AI。
// 每週日 20:00 (台灣時間) 推播一次，預設關閉 (push_weekly_you)。
const { twToday, addDaysStr, TW_OFFSET_MS } = require('./twtime');
const speak = require('./speak');

const WEEKDAY = ['日', '一', '二', '三', '四', '五', '六'];
const wd = (ymd) => `週${WEEKDAY[new Date(ymd + 'T00:00:00Z').getUTCDay()]}`;
const twStartIso = (ymd) => new Date(Date.parse(ymd + 'T00:00:00Z') - TW_OFFSET_MS).toISOString();

function safe(fn, fallback) { try { return fn(); } catch (e) { return fallback; } }

function build(db, userId, today = twToday()) {
  const ws = speak.weekStart(today);
  const lastWs = addDaysStr(ws, -7);
  const days = Array.from({ length: 7 }, (_, i) => addDaysStr(ws, i));
  const nextWs = addDaysStr(ws, 7);

  // 說出來
  const speakThis = safe(() => db.prepare('SELECT entry_date, text, feelings, topics FROM speak_entries WHERE user_id = ? AND entry_date >= ? AND entry_date < ?').all(userId, ws, nextWs), []);
  const speakLast = safe(() => db.prepare('SELECT COUNT(*) AS c FROM speak_entries WHERE user_id = ? AND entry_date >= ? AND entry_date < ?').get(userId, lastWs, ws).c, 0);

  // 心情分數 (1-10)
  const moods = safe(() => db.prepare('SELECT entry_date, score FROM mood_entries WHERE user_id = ? AND entry_date >= ? AND entry_date < ?').all(userId, ws, nextWs), []);
  const moodByDay = days.map((d) => { const m = moods.find((x) => x.entry_date === d); return { date: d, label: wd(d).slice(1), score: m ? m.score : null }; });

  // 常提到的感受與主題
  const count = {};
  for (const r of speakThis) {
    String(r.feelings).split(',').filter(Boolean).forEach((k) => { const l = speak.feelingLabel(k); count[l] = (count[l] || 0) + 1; });
    String(r.topics).split(',').filter(Boolean).forEach((t) => { count[t] = (count[t] || 0) + 1; });
  }
  const topWords = Object.entries(count).filter(([, n]) => n >= 2).sort((a, b) => b[1] - a[1]).slice(0, 2).map(([w]) => w);

  // 生活
  const tasksDone = safe(() => db.prepare("SELECT COUNT(*) AS c FROM tasks WHERE user_id = ? AND completed = 1 AND date(completed_at, '+8 hours') >= ? AND date(completed_at, '+8 hours') < ?").get(userId, ws, nextWs).c, 0);
  const spend = safe(() => db.prepare("SELECT category, SUM(amount) AS total FROM finance_transactions WHERE user_id = ? AND type = 'expense' AND tx_date >= ? AND tx_date < ? GROUP BY category ORDER BY total DESC").all(userId, ws, nextWs), []);
  const spendTotal = spend.reduce((s, r) => s + r.total, 0);
  const todayDay = Number(today.slice(8, 10));
  const bills = safe(() => db.prepare('SELECT b.name, b.due_day FROM bills b WHERE b.user_id = ? AND b.active = 1 AND b.id NOT IN (SELECT bill_id FROM bill_payments WHERE user_id = ? AND paid_period = ?) ORDER BY b.due_day ASC').all(userId, userId, today.slice(0, 7)), []);
  const nextBill = bills.find((b) => b.due_day >= todayDay && b.due_day - todayDay <= 7);

  const longest = speakThis.slice().sort((a, b) => b.text.length - a.text.length)[0];

  // 句子：只講事實
  const lines = [];
  if (speakThis.length || speakLast) {
    const diff = speakThis.length - speakLast;
    lines.push(`這週你說出來 ${speakThis.length} 次${speakLast || speakThis.length ? (diff > 0 ? `，比上週多 ${diff} 次` : diff < 0 ? `，比上週少 ${-diff} 次` : '，跟上週一樣') : ''}。`);
  }
  const scored = moodByDay.filter((d) => d.score != null);
  if (scored.length >= 2) {
    const min = Math.min(...scored.map((d) => d.score));
    const max = Math.max(...scored.map((d) => d.score));
    if (max > min) {
      const lows = scored.filter((d) => d.score === min).map((d) => wd(d.date));
      const highs = scored.filter((d) => d.score === max).map((d) => wd(d.date));
      lines.push(`${lows.join('、')}的心情分數比較低，${highs.join('、')}最高。`);
    }
  }
  if (topWords.length) lines.push(`你最常提到的是${topWords.map((w) => `「${w}」`).join('和')}。`);
  if (!lines.length) lines.push('這週還沒有說出來或心情紀錄。想說什麼的時候，首頁的輸入框隨時都在。');

  return {
    range: { from: ws, to: addDaysStr(ws, 6) },
    lines,
    moodByDay,
    life: {
      tasksDone,
      spendTotal: Math.round(spendTotal),
      topCategory: spend[0] ? spend[0].category : null,
      nextBill: nextBill ? { name: nextBill.name, date: `${Number(today.slice(5, 7))}/${nextBill.due_day}` } : null,
    },
    longest: longest ? { date: longest.entry_date, excerpt: longest.text.length > 40 ? longest.text.slice(0, 40) + '…' : longest.text } : null,
    speakCount: speakThis.length,
  };
}

// 推播用的一句話
function pushBody(w) {
  return w.lines.slice(0, 2).join('');
}

module.exports = { build, pushBody, twStartIso };
