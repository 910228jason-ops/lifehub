// v0.94「專案樹」：把一件大事拆成「階段 → 步驟」，每個計畫有一個「下一步」。
// 資料沿用 kanban_boards (計畫) / kanban_cards (階段 kind='stage'、步驟 kind='step')，見 migration 070。
// 「下一步」= 使用者手動指定 (is_next=1) 且還沒完成的步驟；沒有的話自動取依階段順序、步驟順序的第一個未完成步驟。
// 範本是固定內容 (不用 AI)，選了就自動拆好，之後都可以改。

const TEMPLATES = {
  move: {
    name: '搬家',
    stages: [
      ['找房子', ['看房', '比較租金與地點', '簽約']],
      ['準備搬運', ['列出要帶的家具', '丟掉不要的東西', '聯絡搬家公司估價', '買紙箱和膠帶', '打包衣服和書']],
      ['搬家當天', ['確認搬家公司時間', '清點箱子']],
      ['搬完之後', ['更改地址（銀行、帳單、網購）', '整理新家']],
    ],
  },
  trip: {
    name: '出國旅行',
    stages: [
      ['規劃', ['決定日期和地點', '確認護照效期', '訂機票', '訂住宿']],
      ['出發前', ['換外幣', '買網路卡或 eSIM', '保旅遊險']],
      ['打包', ['整理行李清單', '準備充電器和轉接頭']],
      ['回來之後', ['整理這趟的花費']],
    ],
  },
  job: {
    name: '找工作',
    stages: [
      ['準備', ['整理履歷', '整理作品集', '列出想去的公司']],
      ['投遞', ['投履歷', '追蹤回覆']],
      ['面試', ['準備自我介紹', '查公司資料', '練習常見問題']],
      ['決定', ['比較條件', '回覆錄取', '辦理離職或報到']],
    ],
  },
  exam: {
    name: '準備考試',
    stages: [
      ['規劃', ['確認考試日期與範圍', '排讀書計畫']],
      ['讀書', ['讀完第一輪', '整理筆記', '做考古題', '複習錯題']],
      ['考前', ['準備准考證與文具', '確認考場與交通', '考前一晚早點睡']],
    ],
  },
  room: {
    name: '整理房間',
    stages: [
      ['分類', ['整理衣服', '整理書和文件', '整理雜物']],
      ['處理', ['丟掉或捐出不要的', '收納要留的']],
      ['維持', ['每週整理一次']],
    ],
  },
};

function templateList() {
  return Object.entries(TEMPLATES).map(([key, t]) => ({
    key, name: t.name, stageCount: t.stages.length, stepCount: t.stages.reduce((n, [, steps]) => n + steps.length, 0),
    stages: t.stages.map(([title]) => title),
  }));
}

function nowIso() { return new Date().toISOString(); }

function addStage(db, boardId, title) {
  const max = db.prepare("SELECT MAX(sort_order) m FROM kanban_cards WHERE board_id = ? AND kind = 'stage'").get(boardId).m || 0;
  const now = nowIso();
  return db.prepare("INSERT INTO kanban_cards (board_id, title, note, column_key, sort_order, created_at, updated_at, kind) VALUES (?, ?, '', 'todo', ?, ?, ?, 'stage')")
    .run(boardId, title, max + 1, now, now).lastInsertRowid;
}

function addStep(db, boardId, stageId, title, dueDate) {
  const max = db.prepare("SELECT MAX(sort_order) m FROM kanban_cards WHERE board_id = ? AND parent_id = ? AND kind = 'step'").get(boardId, stageId).m || 0;
  const now = nowIso();
  return db.prepare("INSERT INTO kanban_cards (board_id, title, note, column_key, sort_order, created_at, updated_at, kind, parent_id, due_date) VALUES (?, ?, '', 'todo', ?, ?, ?, 'step', ?, ?)")
    .run(boardId, title, max + 1, now, now, stageId, dueDate || null).lastInsertRowid;
}

function createPlan(db, userId, { name, targetDate, template }) {
  const board = db.prepare('INSERT INTO kanban_boards (user_id, name, created_at, target_date) VALUES (?, ?, ?, ?)').run(userId, name, nowIso(), targetDate || null).lastInsertRowid;
  const t = TEMPLATES[template];
  if (t) {
    for (const [stageTitle, steps] of t.stages) {
      const sid = addStage(db, board, stageTitle);
      for (const s of steps) addStep(db, board, sid, s);
    }
  } else {
    addStage(db, board, '步驟');
  }
  return board;
}

// 整棵樹：階段 (依 sort_order) → 步驟 (依 sort_order)，加上下一步
function tree(db, board, selfId, labelFn) {
  const cards = db.prepare('SELECT * FROM kanban_cards WHERE board_id = ? ORDER BY sort_order ASC, id ASC').all(board.id);
  const stages = cards.filter((c) => c.kind === 'stage');
  const steps = cards.filter((c) => c.kind !== 'stage');
  const next = nextStep(db, board.id, cards);
  const mapStep = (s) => ({
    id: s.id, title: s.title, done: s.column_key === 'done', dueDate: s.due_date, isNext: next && next.id === s.id,
    assigneeUserId: s.assignee_user_id || null, assigneeLabel: s.assignee_user_id && labelFn ? labelFn(s.assignee_user_id) : null,
  });
  const out = stages.map((st) => {
    const own = steps.filter((s) => s.parent_id === st.id).map(mapStep);
    return { id: st.id, title: st.title, steps: own, doneCount: own.filter((s) => s.done).length };
  });
  // 沒有階段的步驟 (理論上 migration 已經處理，保險起見放到最後)
  const orphans = steps.filter((s) => !stages.some((st) => st.id === s.parent_id)).map(mapStep);
  if (orphans.length) out.push({ id: null, title: '其他步驟', steps: orphans, doneCount: orphans.filter((s) => s.done).length });
  return {
    id: board.id, name: board.name, targetDate: board.target_date || null,
    stages: out, total: steps.length, done: steps.filter((s) => s.column_key === 'done').length,
    next: next ? { id: next.id, title: next.title, dueDate: next.due_date } : null,
  };
}

function nextStep(db, boardId, cardsIn) {
  const cards = cardsIn || db.prepare('SELECT * FROM kanban_cards WHERE board_id = ? ORDER BY sort_order ASC, id ASC').all(boardId);
  const stages = cards.filter((c) => c.kind === 'stage');
  const stageOrder = new Map(stages.map((s, i) => [s.id, i]));
  const open = cards.filter((c) => c.kind !== 'stage' && c.column_key !== 'done');
  const pinned = open.find((c) => c.is_next);
  if (pinned) return pinned;
  open.sort((a, b) => (stageOrder.get(a.parent_id) ?? 999) - (stageOrder.get(b.parent_id) ?? 999) || a.sort_order - b.sort_order || a.id - b.id);
  return open[0] || null;
}

function summary(db, board) {
  const cards = db.prepare('SELECT * FROM kanban_cards WHERE board_id = ? ORDER BY sort_order ASC, id ASC').all(board.id);
  const steps = cards.filter((c) => c.kind !== 'stage');
  const next = nextStep(db, board.id, cards);
  const lastDone = steps.filter((s) => s.column_key === 'done').map((s) => s.updated_at).sort().pop() || null;
  return {
    id: board.id, name: board.name, targetDate: board.target_date || null,
    total: steps.length, done: steps.filter((s) => s.column_key === 'done').length,
    next: next ? { id: next.id, title: next.title, dueDate: next.due_date } : null,
    finishedAt: steps.length && !next ? lastDone : null,
  };
}

module.exports = { TEMPLATES, templateList, createPlan, addStage, addStep, tree, nextStep, summary };
