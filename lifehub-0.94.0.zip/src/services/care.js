// v0.93「想到的人」：生日 (今天、明天) 與「依使用者自己設定的間隔想起某人」，附一句可以複製傳出去的開頭。
// 資料都是人際關係分頁已經記過的 (姓名、關係、生日、備註、聯絡紀錄、提醒間隔)，不用 AI。
// 「依間隔想起」只看使用者「自己設定過間隔」的人，而且整個功能預設關閉 (care_interval_reminders)。
// 不用「好久沒聯絡」這種帶壓力的說法，只講事實 (上次聯絡是哪天)。
const { twToday, addDaysStr, twTodayDate } = require('./twtime');

const OPENERS = {
  birthday: {
    family: ['生日快樂！最近好嗎？這週有空一起吃個飯嗎？', '生日快樂！祝你新的一歲健康順心。'],
    friend: ['生日快樂！最近過得怎麼樣？找天出來聚聚。', '生日快樂！新的一歲一切順利。'],
    colleague: ['生日快樂！祝你新的一歲一切順利。'],
    other: ['生日快樂！祝你新的一歲一切順利。'],
  },
  interval: {
    family: ['最近好嗎？這週末要不要一起吃個飯？', '想到你，最近身體還好嗎？'],
    friend: ['最近好嗎？有空出來喝個咖啡。', '突然想到你，最近在忙什麼？'],
    colleague: ['最近好嗎？有空一起吃個午餐。'],
    other: ['最近好嗎？想到你就傳個訊息。'],
  },
};

function daysUntilMonthDay(md, today) {
  const [mm, dd] = String(md || '').split('-').map(Number);
  if (!mm || !dd) return null;
  const y = today.getUTCFullYear();
  let next = Date.UTC(y, mm - 1, dd);
  if (next < today.getTime()) next = Date.UTC(y + 1, mm - 1, dd);
  return Math.round((next - today.getTime()) / 86400000);
}

function list(db, userId, opts = {}) {
  const today = twToday();
  const todayDate = twTodayDate();
  let intervalOn = false;
  try { intervalOn = !!db.prepare('SELECT care_interval_reminders FROM user_prefs WHERE user_id = ?').get(userId).care_interval_reminders; } catch (e) { /* ignore */ }
  const rels = db.prepare('SELECT * FROM relationships WHERE user_id = ?').all(userId);
  const items = [];
  for (const r of rels) {
    if (r.care_snooze_until && r.care_snooze_until > today) continue;
    const type = OPENERS.birthday[r.relation_type] ? r.relation_type : 'other';
    const d = r.birthday ? daysUntilMonthDay(r.birthday, todayDate) : null;
    if (d === 0 || d === 1) {
      items.push({ id: r.id, name: r.name, kind: 'birthday', when: d === 0 ? '今天生日' : '明天生日', note: r.note || null, openers: OPENERS.birthday[type] });
      continue;
    }
    if (intervalOn && r.reminder_interval_days) {
      const last = db.prepare('SELECT MAX(interaction_date) AS d FROM relationship_interactions WHERE relationship_id = ? AND user_id = ?').get(r.id, userId).d;
      const base = last || String(r.created_at).slice(0, 10);
      const due = addDaysStr(base, r.reminder_interval_days);
      if (due <= today) {
        items.push({
          id: r.id, name: r.name, kind: 'interval',
          when: last ? `上次聯絡是 ${Number(last.slice(5, 7))}/${Number(last.slice(8, 10))}` : '還沒有聯絡紀錄',
          detail: `你設定每 ${r.reminder_interval_days} 天想起${r.name}一次。`,
          note: r.note || null, openers: OPENERS.interval[type],
        });
      }
    }
  }
  return { items, intervalOn };
}

function markContacted(db, userId, relId) {
  const r = db.prepare('SELECT id FROM relationships WHERE id = ? AND user_id = ?').get(relId, userId);
  if (!r) return false;
  db.prepare('INSERT INTO relationship_interactions (user_id, relationship_id, interaction_date, note, created_at) VALUES (?, ?, ?, ?, ?)').run(
    userId, relId, twToday(), '從「想到的人」標記已聯絡', new Date().toISOString()
  );
  db.prepare('UPDATE relationships SET care_snooze_until = ? WHERE id = ?').run(addDaysStr(twToday(), 1), relId);
  return true;
}

function snooze(db, userId, relId, days = 7) {
  const r = db.prepare('UPDATE relationships SET care_snooze_until = ? WHERE id = ? AND user_id = ?').run(addDaysStr(twToday(), days), relId, userId);
  return r.changes > 0;
}

module.exports = { list, markContacted, snooze };
