// v0.93「說出來」：不靠 AI 的個人化回應。
//
// 使用者在首頁輸入框說的話，如果不是記帳、也不像待辦，就當成「心裡話」收下 (speak_entries，
// 同時附加到當天日記)，並立刻回一段話。回應由四種素材組成，全部是規則與使用者自己的資料：
//   ack       收到了 (依使用者選的稱呼與語氣)
//   facts     使用者自己的紀錄：這是這週第幾次寫下「累」、上一次是哪天
//   own       使用者「寫給自己的話」(心情偏低時還給他)
//   companion 一句固定的陪伴短句 (依感受分類、語氣挑選；使用者可關掉)
//   crisis    出現危機字眼時一定附上求助專線 (不受任何設定影響)
// 「這句有幫到我／不需要這種」會記到 speak_feedback，某種素材被嫌棄得多，之後就比較少出現。
// 設計原則 (AI_HANDOFF)：只講看得到的事實，不猜測、不說教、不假裝懂。
const { twToday, addDaysStr } = require('./twtime');

const FEELINGS = [
  { key: 'tired', label: '累', re: /累|疲|好睏|想睡|沒力|沒體力|耗盡|撐不住/, negative: true },
  { key: 'sad', label: '難過', re: /難過|傷心|想哭|哭了|心痛|失落|沮喪|低落/, negative: true },
  { key: 'lonely', label: '孤單', re: /孤單|寂寞|沒人懂|被忽略|沒人陪/, negative: true },
  { key: 'stress', label: '壓力', re: /壓力|焦慮|好煩|很煩|煩死|緊張|擔心|喘不過氣|好忙/, negative: true },
  { key: 'miss', label: '想念', re: /想念|懷念|好想[她他你]|好想見/, negative: true },
  { key: 'angry', label: '生氣', re: /生氣|火大|氣死|不爽|討厭/, negative: true },
  { key: 'happy', label: '開心', re: /開心|快樂|高興|不錯|很好|順利|成功|感謝|幸福|好棒|太好了/, negative: false },
  { key: 'calm', label: '平靜', re: /平靜|放鬆|還好|普通|平淡|安心/, negative: false },
];

const TOPICS = [
  ['工作', /工作|上班|加班|老闆|主管|同事|報告|會議|公司|案子/],
  ['家人', /家人|爸|媽|家裡|弟|妹|哥|姊|姐|阿公|阿嬤/],
  ['朋友', /朋友|同學/],
  ['感情', /感情|分手|喜歡的人|對象|曖昧|前任/],
  ['錢', /錢|薪水|帳單|花費|存款|房租/],
  ['身體', /身體|生病|頭痛|感冒|睡不著|失眠|吃藥|看醫生/],
  ['學習', /考試|讀書|上課|作業/],
];

const COMPANION = {
  tired: ['今天先到這裡也可以。', '累的時候，休息就是今天最重要的事。', '能把累說出來，已經很好了。'],
  sad: ['難過的時候，不用急著好起來。', '謝謝你願意寫下來。'],
  lonely: ['你寫下來的話，這裡都收著。', '想找人說話的時候，也可以傳個訊息給一個信任的人。'],
  stress: ['一次只做一件事就好。', '先深呼吸一下，再看下一步。'],
  miss: ['想念的時候，寫下來也是一種整理。'],
  angry: ['先讓自己有個空間冷靜一下。'],
  happy: ['值得記住的一刻。', '這樣的日子也要記得。'],
  calm: ['平平靜靜的一天也很好。'],
  none: ['收著了。'],
};

const TONES = ['gentle', 'brief', 'numbers'];
const DEFAULT_SETTINGS = { nickname: '', tone: 'gentle', showFacts: true, showOwnWords: true, showCompanion: false };
const WEEKDAY = ['日', '一', '二', '三', '四', '五', '六'];

function classify(text) {
  const t = String(text || '');
  return {
    feelings: FEELINGS.filter((f) => f.re.test(t)).map((f) => f.key),
    topics: TOPICS.filter(([, re]) => re.test(t)).map(([label]) => label),
  };
}

function feelingLabel(key) {
  const f = FEELINGS.find((x) => x.key === key);
  return f ? f.label : key;
}

// 台灣日期所在那週的星期一
function weekStart(ymd = twToday()) {
  const dow = new Date(ymd + 'T00:00:00Z').getUTCDay();
  return addDaysStr(ymd, -((dow + 6) % 7));
}

// 「週一」「昨天」「10/28」這種好讀的日期 (只講事實)
function dayLabel(ymd, today = twToday()) {
  if (ymd === today) return '今天';
  if (ymd === addDaysStr(today, -1)) return '昨天';
  if (ymd >= weekStart(today)) return `週${WEEKDAY[new Date(ymd + 'T00:00:00Z').getUTCDay()]}`;
  return `${Number(ymd.slice(5, 7))}/${Number(ymd.slice(8, 10))}`;
}

function getSettings(db, userId) {
  let s = {};
  try {
    const row = db.prepare('SELECT speak_settings_json FROM user_prefs WHERE user_id = ?').get(userId);
    s = JSON.parse((row && row.speak_settings_json) || '{}');
  } catch (e) { s = {}; }
  return { ...DEFAULT_SETTINGS, ...s };
}

function saveSettings(db, userId, input) {
  const cur = getSettings(db, userId);
  const next = {
    nickname: input.nickname !== undefined ? String(input.nickname || '').trim().slice(0, 20) : cur.nickname,
    tone: TONES.includes(input.tone) ? input.tone : cur.tone,
    showFacts: input.showFacts !== undefined ? !!input.showFacts : cur.showFacts,
    showOwnWords: input.showOwnWords !== undefined ? !!input.showOwnWords : cur.showOwnWords,
    showCompanion: input.showCompanion !== undefined ? !!input.showCompanion : cur.showCompanion,
  };
  db.prepare('UPDATE user_prefs SET speak_settings_json = ? WHERE user_id = ?').run(JSON.stringify(next), userId);
  return next;
}

// 某種素材「被嫌棄」得多就少放：(有幫到 + 1) / (有幫到 + 不需要 + 2) < 0.3 就不放
function partWeights(db, userId) {
  const rows = db.prepare('SELECT parts, helpful FROM speak_feedback WHERE user_id = ? ORDER BY id DESC LIMIT 60').all(userId);
  const score = {};
  for (const r of rows) {
    for (const p of String(r.parts).split(',').filter(Boolean)) {
      score[p] = score[p] || { up: 0, down: 0 };
      if (r.helpful) score[p].up++; else score[p].down++;
    }
  }
  const w = {};
  for (const p of ['facts', 'own', 'companion']) {
    const s = score[p] || { up: 0, down: 0 };
    w[p] = (s.up + 1) / (s.up + s.down + 2);
  }
  return w;
}

function pick(list, seed) {
  return list[Math.abs(seed) % list.length];
}

// 組回應。entry 是剛存好的 speak_entries 那一列
function buildReply(db, userId, entry, opts = {}) {
  const settings = getSettings(db, userId);
  const weights = partWeights(db, userId);
  const allow = (p) => weights[p] >= 0.3;
  const today = twToday();
  const name = settings.nickname || opts.fallbackName || '';
  const feelings = String(entry.feelings).split(',').filter(Boolean);
  const primary = feelings[0] || null;
  const negative = feelings.some((k) => (FEELINGS.find((f) => f.key === k) || {}).negative);
  const parts = [];

  // ack
  const ack = settings.tone === 'brief' ? '收到。' : settings.tone === 'numbers' ? '已記下。' : `收到了${name ? `，${name}` : ''}。`;
  parts.push({ type: 'ack', text: ack });

  // facts：使用者自己的紀錄
  if (settings.showFacts && allow('facts')) {
    const ws = weekStart(today);
    if (primary) {
      const rows = db.prepare(
        "SELECT entry_date FROM speak_entries WHERE user_id = ? AND (',' || feelings || ',') LIKE ? AND id != ? ORDER BY id DESC"
      ).all(userId, `%,${primary},%`, entry.id);
      const thisWeek = rows.filter((r) => r.entry_date >= ws).length + 1;
      const label = feelingLabel(primary);
      const prev = rows[0];
      let text;
      if (settings.tone === 'numbers') text = `本週第 ${thisWeek} 次「${label}」${prev ? `；上一次 ${dayLabel(prev.entry_date, today)}` : '；第一次記下'}。`;
      else text = `這是你這週第 ${thisWeek} 次寫下「${label}」${prev ? `，上一次是${dayLabel(prev.entry_date, today)}` : ''}。`;
      parts.push({ type: 'facts', text });
    } else {
      const n = db.prepare('SELECT COUNT(*) AS c FROM speak_entries WHERE user_id = ? AND entry_date >= ?').get(userId, ws).c;
      parts.push({ type: 'facts', text: settings.tone === 'numbers' ? `本週第 ${n} 則。` : `這是你這週第 ${n} 次說出來。` });
    }
  }

  // own：寫給自己的話 (心情偏低時)
  if (negative && settings.showOwnWords && allow('own')) {
    const note = db.prepare('SELECT * FROM self_notes WHERE user_id = ? ORDER BY COALESCE(last_shown_at, \'\') ASC, id ASC LIMIT 1').get(userId);
    if (note) {
      db.prepare('UPDATE self_notes SET last_shown_at = ? WHERE id = ?').run(new Date().toISOString(), note.id);
      const d = note.created_at.slice(0, 10);
      parts.push({ type: 'own', label: `你在 ${Number(d.slice(5, 7))}/${Number(d.slice(8, 10))} 寫給自己的話`, text: `「${note.text}」` });
    }
  }

  // companion：固定的陪伴短句 (「只講數字」語氣不放)
  if (settings.showCompanion && settings.tone !== 'numbers' && allow('companion')) {
    const list = COMPANION[primary || 'none'] || COMPANION.none;
    parts.push({ type: 'companion', text: pick(list, entry.id) });
  }

  // crisis：一定附上
  if (opts.crisis) {
    parts.push({
      type: 'crisis',
      text: '如果你現在真的很難受，可以打給會好好聽你說的人：安心專線 1925 (24 小時)、生命線 1995 (24 小時)、張老師專線 1980。不用覺得是在麻煩別人。',
    });
  }

  return { parts, feelings: feelings.map(feelingLabel), topics: String(entry.topics).split(',').filter(Boolean) };
}

module.exports = { FEELINGS, TOPICS, classify, feelingLabel, weekStart, dayLabel, getSettings, saveSettings, buildReply, DEFAULT_SETTINGS };
