// v0.94「專案樹」API (/api/plans/*)。資料沿用專案看板的資料表，舊的 /api/kanban-boards 保留相容。
// 路由由 src/routes/debug.js 併進 /api (不動 server.js)。
const { Router } = require('../mini-http');
const { getDb } = require('../services/db');
const { requireAuth } = require('../middleware/auth');
const pt = require('../services/projectTree');

const router = Router();
const YMD = /^\d{4}-\d{2}-\d{2}$/;

function ownBoard(db, id, userId) {
  return db.prepare('SELECT * FROM kanban_boards WHERE id = ? AND user_id = ?').get(id, userId);
}
function circleMemberIds(db, userId) {
  const rows = db.prepare('SELECT user_a_id, user_b_id FROM partner_links WHERE user_a_id = ? OR user_b_id = ?').all(userId, userId);
  return [userId, ...rows.map((r) => (r.user_a_id === userId ? r.user_b_id : r.user_a_id))];
}
function labelFor(db, selfId) {
  return (id) => {
    if (id === selfId) return '我';
    const u = db.prepare('SELECT name, email FROM users WHERE id = ?').get(id);
    return (u && (u.name || u.email)) || '（帳號已刪除）';
  };
}
function cleanDate(d) { return d && YMD.test(String(d)) ? String(d) : null; }

router.get('/plans/templates', requireAuth, (req, res) => res.json(pt.templateList()));

router.get('/plans', requireAuth, (req, res) => {
  const db = getDb();
  const boards = db.prepare('SELECT * FROM kanban_boards WHERE user_id = ? ORDER BY created_at DESC').all(req.session.userId);
  const list = boards.map((b) => pt.summary(db, b));
  // 進行中的在前 (有下一步)，完成的在後
  list.sort((a, b) => (a.next ? 0 : 1) - (b.next ? 0 : 1));
  res.json(list);
});

// 首頁「計畫的下一步」
router.get('/plans/next-steps', requireAuth, (req, res) => {
  const db = getDb();
  const boards = db.prepare('SELECT * FROM kanban_boards WHERE user_id = ? ORDER BY created_at ASC').all(req.session.userId);
  res.json(boards.map((b) => pt.summary(db, b)).filter((s) => s.next));
});

router.post('/plans', requireAuth, (req, res) => {
  const name = String((req.body || {}).name || '').trim().slice(0, 60);
  if (!name) return res.status(400).json({ error: '請輸入要完成什麼事' });
  const db = getDb();
  const id = pt.createPlan(db, req.session.userId, { name, targetDate: cleanDate(req.body.targetDate), template: req.body.template });
  res.json({ id });
});

router.get('/plans/:id', requireAuth, (req, res) => {
  const db = getDb();
  const board = ownBoard(db, req.params.id, req.session.userId);
  if (!board) return res.status(404).json({ error: '找不到這個計畫' });
  const selfId = req.session.userId;
  const label = labelFor(db, selfId);
  res.json({ ...pt.tree(db, board, selfId, label), members: circleMemberIds(db, selfId).map((id) => ({ id, label: label(id) })) });
});

router.put('/plans/:id', requireAuth, (req, res) => {
  const db = getDb();
  const board = ownBoard(db, req.params.id, req.session.userId);
  if (!board) return res.status(404).json({ error: '找不到這個計畫' });
  const b = req.body || {};
  const name = b.name !== undefined ? String(b.name).trim().slice(0, 60) : board.name;
  if (!name) return res.status(400).json({ error: '名稱不能空白' });
  db.prepare('UPDATE kanban_boards SET name = ?, target_date = ? WHERE id = ?').run(name, b.targetDate !== undefined ? cleanDate(b.targetDate) : board.target_date, board.id);
  res.json({ ok: true });
});

router.delete('/plans/:id', requireAuth, (req, res) => {
  const db = getDb();
  const board = ownBoard(db, req.params.id, req.session.userId);
  if (!board) return res.status(404).json({ error: '找不到這個計畫' });
  db.prepare('DELETE FROM kanban_cards WHERE board_id = ?').run(board.id);
  db.prepare('DELETE FROM kanban_boards WHERE id = ?').run(board.id);
  res.json({ ok: true });
});

// ---- 階段 ----
router.post('/plans/:id/stages', requireAuth, (req, res) => {
  const db = getDb();
  const board = ownBoard(db, req.params.id, req.session.userId);
  if (!board) return res.status(404).json({ error: '找不到這個計畫' });
  const title = String((req.body || {}).title || '').trim().slice(0, 60);
  if (!title) return res.status(400).json({ error: '請輸入階段名稱' });
  res.json({ id: pt.addStage(db, board.id, title) });
});

function ownCard(db, board, cardId, kind) {
  return db.prepare('SELECT * FROM kanban_cards WHERE id = ? AND board_id = ? AND kind = ?').get(cardId, board.id, kind);
}

router.put('/plans/:id/stages/:sid', requireAuth, (req, res) => {
  const db = getDb();
  const board = ownBoard(db, req.params.id, req.session.userId);
  const st = board && ownCard(db, board, req.params.sid, 'stage');
  if (!st) return res.status(404).json({ error: '找不到這個階段' });
  const title = String((req.body || {}).title || '').trim().slice(0, 60);
  if (!title) return res.status(400).json({ error: '名稱不能空白' });
  db.prepare('UPDATE kanban_cards SET title = ?, updated_at = ? WHERE id = ?').run(title, new Date().toISOString(), st.id);
  res.json({ ok: true });
});

router.delete('/plans/:id/stages/:sid', requireAuth, (req, res) => {
  const db = getDb();
  const board = ownBoard(db, req.params.id, req.session.userId);
  const st = board && ownCard(db, board, req.params.sid, 'stage');
  if (!st) return res.status(404).json({ error: '找不到這個階段' });
  db.prepare('DELETE FROM kanban_cards WHERE board_id = ? AND (id = ? OR parent_id = ?)').run(board.id, st.id, st.id);
  res.json({ ok: true });
});

// ---- 步驟 ----
router.post('/plans/:id/steps', requireAuth, (req, res) => {
  const db = getDb();
  const board = ownBoard(db, req.params.id, req.session.userId);
  if (!board) return res.status(404).json({ error: '找不到這個計畫' });
  const b = req.body || {};
  const st = ownCard(db, board, b.stageId, 'stage');
  if (!st) return res.status(400).json({ error: '找不到要加到哪個階段' });
  const title = String(b.title || '').trim().slice(0, 100);
  if (!title) return res.status(400).json({ error: '請輸入步驟' });
  res.json({ id: pt.addStep(db, board.id, st.id, title, cleanDate(b.dueDate)) });
});

router.put('/plans/:id/steps/:stepId', requireAuth, (req, res) => {
  const db = getDb();
  const selfId = req.session.userId;
  const board = ownBoard(db, req.params.id, selfId);
  const step = board && ownCard(db, board, req.params.stepId, 'step');
  if (!step) return res.status(404).json({ error: '找不到這個步驟' });
  const b = req.body || {};
  const title = b.title !== undefined ? String(b.title).trim().slice(0, 100) : step.title;
  if (!title) return res.status(400).json({ error: '步驟不能空白' });
  let assignee = step.assignee_user_id;
  if (b.assigneeUserId !== undefined) {
    if (b.assigneeUserId === null || b.assigneeUserId === '') assignee = null;
    else if (circleMemberIds(db, selfId).includes(Number(b.assigneeUserId))) assignee = Number(b.assigneeUserId);
    else return res.status(400).json({ error: '只能指派給自己或已連結的家人' });
  }
  const done = b.done !== undefined ? !!b.done : step.column_key === 'done';
  db.prepare('UPDATE kanban_cards SET title = ?, due_date = ?, assignee_user_id = ?, column_key = ?, is_next = ?, updated_at = ? WHERE id = ?').run(
    title, b.dueDate !== undefined ? cleanDate(b.dueDate) : step.due_date, assignee, done ? 'done' : 'todo',
    done ? 0 : step.is_next, new Date().toISOString(), step.id
  );
  const next = pt.nextStep(db, board.id);
  res.json({ ok: true, next: next ? { id: next.id, title: next.title, dueDate: next.due_date } : null, planName: board.name });
});

// 設成下一步 (每個計畫只有一個)
router.post('/plans/:id/steps/:stepId/next', requireAuth, (req, res) => {
  const db = getDb();
  const board = ownBoard(db, req.params.id, req.session.userId);
  const step = board && ownCard(db, board, req.params.stepId, 'step');
  if (!step) return res.status(404).json({ error: '找不到這個步驟' });
  db.prepare('UPDATE kanban_cards SET is_next = 0 WHERE board_id = ?').run(board.id);
  db.prepare("UPDATE kanban_cards SET is_next = 1, column_key = 'todo' WHERE id = ?").run(step.id);
  res.json({ ok: true });
});

router.delete('/plans/:id/steps/:stepId', requireAuth, (req, res) => {
  const db = getDb();
  const board = ownBoard(db, req.params.id, req.session.userId);
  const step = board && ownCard(db, board, req.params.stepId, 'step');
  if (!step) return res.status(404).json({ error: '找不到這個步驟' });
  db.prepare('DELETE FROM kanban_cards WHERE id = ?').run(step.id);
  res.json({ ok: true });
});

module.exports = router;
