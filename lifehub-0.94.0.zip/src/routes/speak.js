// v0.93「說出來」、回應方式、寫給自己的話、這週的你、想到的人。
// 路由由 src/routes/debug.js 併進 /api (不動 server.js)；被 require 時順便啟動「這週的你」週日推播排程。
const { Router } = require('../mini-http');
const { getDb } = require('../services/db');
const { requireAuth } = require('../middleware/auth');
const logger = require('../services/logger');
const speak = require('../services/speak');
const weeklyYou = require('../services/weeklyYou');
const care = require('../services/care');
const { twToday, twShift } = require('../services/twtime');

const router = Router();
const MAX_TEXT = 2000;

function userName(db, userId) {
  const u = db.prepare('SELECT name FROM users WHERE id = ?').get(userId);
  return (u && u.name) || '';
}

// 把這句話附加到當天的日記 (日記本來就是一天一篇)，回傳附加的那一行，復原時用
function appendToDiary(db, userId, text) {
  const t = twShift();
  const line = `〔${String(t.getUTCHours()).padStart(2, '0')}:${String(t.getUTCMinutes()).padStart(2, '0')}〕${text}`;
  const today = twToday();
  const now = new Date().toISOString();
  const row = db.prepare('SELECT id, content FROM diary_entries WHERE user_id = ? AND entry_date = ?').get(userId, today);
  if (row) db.prepare('UPDATE diary_entries SET content = ?, updated_at = ? WHERE id = ?').run(row.content ? `${row.content}\n\n${line}` : line, now, row.id);
  else db.prepare('INSERT INTO diary_entries (user_id, entry_date, content, created_at, updated_at) VALUES (?, ?, ?, ?, ?)').run(userId, today, line, now, now);
  return line;
}

function removeFromDiary(db, userId, date, line) {
  if (!line) return;
  const row = db.prepare('SELECT id, content FROM diary_entries WHERE user_id = ? AND entry_date = ?').get(userId, date);
  if (!row) return;
  const next = row.content.replace(`\n\n${line}`, '').replace(line, '').trim();
  if (!next) db.prepare('DELETE FROM diary_entries WHERE id = ?').run(row.id);
  else db.prepare('UPDATE diary_entries SET content = ?, updated_at = ? WHERE id = ?').run(next, new Date().toISOString(), row.id);
}

// ---- 說出來 ----
router.post('/speak', requireAuth, (req, res) => {
  const text = String((req.body && req.body.text) || '').trim().slice(0, MAX_TEXT);
  if (!text) return res.status(400).json({ error: '想說什麼都可以，但要先寫點東西' });
  const db = getDb();
  const userId = req.session.userId;
  const { feelings, topics } = speak.classify(text);
  const diaryLine = appendToDiary(db, userId, text);
  const info = db.prepare(
    'INSERT INTO speak_entries (user_id, entry_date, text, feelings, topics, diary_line, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)'
  ).run(userId, twToday(), text, feelings.join(','), topics.join(','), diaryLine, new Date().toISOString());
  const entry = db.prepare('SELECT * FROM speak_entries WHERE id = ?').get(info.lastInsertRowid);
  const crisis = require('../services/mood').detectCrisisSignal(text);
  if (crisis) logger.info('[speak] 偵測到危機字眼，已附上求助資源', {});
  const reply = speak.buildReply(db, userId, entry, { crisis, fallbackName: userName(db, userId) });
  res.json({ id: entry.id, ...reply, savedTo: `日記${reply.feelings.length ? ` · 感受「${reply.feelings.join('、')}」` : ''}` });
});

// 復原：刪掉這句話，也從日記裡拿掉
router.delete('/speak/:id', requireAuth, (req, res) => {
  const db = getDb();
  const e = db.prepare('SELECT * FROM speak_entries WHERE id = ? AND user_id = ?').get(req.params.id, req.session.userId);
  if (!e) return res.status(404).json({ error: '找不到這則' });
  removeFromDiary(db, req.session.userId, e.entry_date, e.diary_line);
  db.prepare('DELETE FROM speak_entries WHERE id = ?').run(e.id);
  res.json({ ok: true });
});

// 分錯了：改成待辦
router.post('/speak/:id/to-task', requireAuth, (req, res) => {
  const db = getDb();
  const e = db.prepare('SELECT * FROM speak_entries WHERE id = ? AND user_id = ?').get(req.params.id, req.session.userId);
  if (!e) return res.status(404).json({ error: '找不到這則' });
  removeFromDiary(db, req.session.userId, e.entry_date, e.diary_line);
  db.prepare('DELETE FROM speak_entries WHERE id = ?').run(e.id);
  const info = db.prepare("INSERT INTO tasks (user_id, title, priority, completed, created_at) VALUES (?, ?, 'medium', 0, ?)").run(
    req.session.userId, e.text.slice(0, 200), new Date().toISOString()
  );
  res.json({ ok: true, taskId: info.lastInsertRowid });
});

router.post('/speak/:id/feedback', requireAuth, (req, res) => {
  const db = getDb();
  const e = db.prepare('SELECT id FROM speak_entries WHERE id = ? AND user_id = ?').get(req.params.id, req.session.userId);
  const parts = (Array.isArray(req.body && req.body.parts) ? req.body.parts : []).filter((p) => ['facts', 'own', 'companion'].includes(p));
  if (!e || !parts.length) return res.status(400).json({ error: '沒有可以回饋的內容' });
  db.prepare('INSERT INTO speak_feedback (user_id, speak_id, parts, helpful, created_at) VALUES (?, ?, ?, ?, ?)').run(
    req.session.userId, e.id, parts.join(','), req.body.helpful ? 1 : 0, new Date().toISOString()
  );
  res.json({ ok: true });
});

// ---- 回應方式設定 (含這週的你推播、依間隔想起某人) ----
router.get('/speak/settings', requireAuth, (req, res) => {
  const db = getDb();
  const p = db.prepare('SELECT push_weekly_you, care_interval_reminders FROM user_prefs WHERE user_id = ?').get(req.session.userId) || {};
  res.json({
    ...speak.getSettings(db, req.session.userId),
    defaultName: userName(db, req.session.userId),
    pushWeeklyYou: !!p.push_weekly_you,
    careIntervalReminders: !!p.care_interval_reminders,
  });
});

router.put('/speak/settings', requireAuth, (req, res) => {
  const db = getDb();
  const b = req.body || {};
  const s = speak.saveSettings(db, req.session.userId, b);
  if (b.pushWeeklyYou !== undefined) db.prepare('UPDATE user_prefs SET push_weekly_you = ? WHERE user_id = ?').run(b.pushWeeklyYou ? 1 : 0, req.session.userId);
  if (b.careIntervalReminders !== undefined) db.prepare('UPDATE user_prefs SET care_interval_reminders = ? WHERE user_id = ?').run(b.careIntervalReminders ? 1 : 0, req.session.userId);
  res.json({ ok: true, ...s });
});

// ---- 寫給自己的話 ----
router.get('/self-notes', requireAuth, (req, res) => {
  res.json(getDb().prepare('SELECT id, text, created_at FROM self_notes WHERE user_id = ? ORDER BY id ASC').all(req.session.userId));
});

router.post('/self-notes', requireAuth, (req, res) => {
  const text = String((req.body && req.body.text) || '').trim().slice(0, 200);
  if (!text) return res.status(400).json({ error: '請寫一句話' });
  const db = getDb();
  const n = db.prepare('SELECT COUNT(*) AS c FROM self_notes WHERE user_id = ?').get(req.session.userId).c;
  if (n >= 30) return res.status(400).json({ error: '最多 30 句' });
  const info = db.prepare('INSERT INTO self_notes (user_id, text, created_at) VALUES (?, ?, ?)').run(req.session.userId, text, new Date().toISOString());
  res.json({ id: info.lastInsertRowid });
});

router.delete('/self-notes/:id', requireAuth, (req, res) => {
  getDb().prepare('DELETE FROM self_notes WHERE id = ? AND user_id = ?').run(req.params.id, req.session.userId);
  res.json({ ok: true });
});

// ---- 這週的你 ----
router.get('/weekly-you', requireAuth, (req, res) => {
  res.json(weeklyYou.build(getDb(), req.session.userId));
});

// ---- 想到的人 ----
router.get('/care', requireAuth, (req, res) => {
  res.json(care.list(getDb(), req.session.userId));
});

router.post('/care/:id/contacted', requireAuth, (req, res) => {
  if (!care.markContacted(getDb(), req.session.userId, req.params.id)) return res.status(404).json({ error: '找不到這個人' });
  res.json({ ok: true });
});

router.post('/care/:id/snooze', requireAuth, (req, res) => {
  if (!care.snooze(getDb(), req.session.userId, req.params.id, 7)) return res.status(404).json({ error: '找不到這個人' });
  res.json({ ok: true });
});

// ---- 「這週的你」週日 20:00 推播 (預設關閉) ----
function runWeeklyYouPush() {
  const t = twShift();
  if (t.getUTCDay() !== 0 || t.getUTCHours() < 20) return;
  const db = getDb();
  const week = speak.weekStart(twToday());
  let users = [];
  try {
    users = db.prepare('SELECT user_id FROM user_prefs WHERE push_weekly_you = 1 AND (weekly_you_sent_week IS NULL OR weekly_you_sent_week != ?)').all(week);
  } catch (e) { return; }
  for (const { user_id: userId } of users) {
    try {
      const w = weeklyYou.build(db, userId);
      require('../services/notifyQueue').queueNotification(db, userId, { title: '這週的你', body: weeklyYou.pushBody(w), icon: '/icons/icon-192.png', urgent: false });
      db.prepare('UPDATE user_prefs SET weekly_you_sent_week = ? WHERE user_id = ?').run(week, userId);
    } catch (e) {
      logger.error('[weeklyYou] 推播失敗', { message: e.message });
    }
  }
}
if (!process.env.LIFEHUB_DISABLE_SCHEDULERS) {
  const timer = setInterval(runWeeklyYouPush, 10 * 60 * 1000);
  timer.unref();
}

module.exports = router;
module.exports.runWeeklyYouPush = runWeeklyYouPush;
