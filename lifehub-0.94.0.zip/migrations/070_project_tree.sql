-- v0.94.0：「專案看板」改成「專案樹」——把一件大事拆成「階段 → 步驟」，每個計畫標一個「下一步」，
-- 下一步會出現在首頁「今天要做」。沿用原本的資料表：kanban_boards = 計畫，kanban_cards = 階段或步驟。
--   kind      'stage' 階段 / 'step' 步驟
--   parent_id 步驟屬於哪個階段 (kanban_cards.id)
--   is_next   使用者手動指定的「下一步」(每個計畫最多一個；沒指定時自動取第一個還沒完成的步驟)
--   due_date  步驟的日期 (選填)
-- 完成與否沿用 column_key = 'done'。
ALTER TABLE kanban_boards ADD COLUMN target_date TEXT;
ALTER TABLE kanban_cards ADD COLUMN kind TEXT NOT NULL DEFAULT 'step';
ALTER TABLE kanban_cards ADD COLUMN parent_id INTEGER;
ALTER TABLE kanban_cards ADD COLUMN is_next INTEGER NOT NULL DEFAULT 0;
ALTER TABLE kanban_cards ADD COLUMN due_date TEXT;

-- 舊看板：每個有卡片的看板建一個「步驟」階段，把原本的卡片都放進去 (順序：待辦、進行中、完成)
INSERT INTO kanban_cards (board_id, title, note, column_key, sort_order, created_at, updated_at, kind)
SELECT DISTINCT board_id, '步驟', '', 'todo', 0, strftime('%Y-%m-%dT%H:%M:%fZ', 'now'), strftime('%Y-%m-%dT%H:%M:%fZ', 'now'), 'stage'
FROM kanban_cards WHERE kind = 'step';

UPDATE kanban_cards
SET parent_id = (SELECT s.id FROM kanban_cards s WHERE s.board_id = kanban_cards.board_id AND s.kind = 'stage' ORDER BY s.id LIMIT 1),
    sort_order = (CASE column_key WHEN 'todo' THEN 0 WHEN 'in_progress' THEN 1000 ELSE 2000 END) + sort_order
WHERE kind = 'step' AND parent_id IS NULL;

CREATE INDEX IF NOT EXISTS idx_kanban_cards_parent ON kanban_cards (board_id, parent_id, sort_order);
