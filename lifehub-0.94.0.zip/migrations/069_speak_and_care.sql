-- v0.93.0「說出來」：不靠 AI 的個人化回應、這週的你、關心身邊的人。
--
-- speak_entries：首頁輸入框收下的「心裡話」(沒有金額、也不像待辦的句子)。
-- feelings / topics 是規則比對出來的標籤 (逗號分隔，例如 "tired,stress" / "工作")，用來算
-- 「這是你這週第幾次寫下『累』」、這週的你最常提到什麼。diary_line 是同一句附加到當天日記的那一行，
-- 復原時用來把它從日記裡拿掉。
CREATE TABLE IF NOT EXISTS speak_entries (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  entry_date TEXT NOT NULL,
  text TEXT NOT NULL,
  feelings TEXT NOT NULL DEFAULT '',
  topics TEXT NOT NULL DEFAULT '',
  diary_line TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_speak_entries_user_date ON speak_entries (user_id, entry_date);

-- speak_feedback：「這句有幫到我／不需要這種」。parts 是那次回應用到的素材 (facts,own,companion)，
-- 用來慢慢調整之後的回應要放哪些素材 (簡單的計數，不是 AI)。
CREATE TABLE IF NOT EXISTS speak_feedback (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  speak_id INTEGER,
  parts TEXT NOT NULL,
  helpful INTEGER NOT NULL,
  created_at TEXT NOT NULL
);

-- self_notes：使用者「寫給自己的話」，心情低的時候還給他。
CREATE TABLE IF NOT EXISTS self_notes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  text TEXT NOT NULL,
  last_shown_at TEXT,
  created_at TEXT NOT NULL
);

-- 回應方式 (稱呼、語氣、要放哪些素材)、這週的你推播、依間隔想起某人。後兩者預設關閉。
ALTER TABLE user_prefs ADD COLUMN speak_settings_json TEXT NOT NULL DEFAULT '{}';
ALTER TABLE user_prefs ADD COLUMN push_weekly_you INTEGER NOT NULL DEFAULT 0;
ALTER TABLE user_prefs ADD COLUMN weekly_you_sent_week TEXT;
ALTER TABLE user_prefs ADD COLUMN care_interval_reminders INTEGER NOT NULL DEFAULT 0;

-- 「這次先不用」：某個人在這天之前不再出現在「想到的人」
ALTER TABLE relationships ADD COLUMN care_snooze_until TEXT;
