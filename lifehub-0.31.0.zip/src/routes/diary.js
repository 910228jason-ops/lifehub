const { Router } = require('../mini-http');
const { getDb } = require('../services/db');
const { requireAuth } = require('../middleware/auth');

const router = Router();

// 把資料庫存的 JSON 字串 tags 解回陣列，順便把「心情模組實際記錄的分數」(mood_entries，
// 跟日記自己的 mood 欄位是分開的兩份資料) 一起帶出來，讓日記列表可以直接顯示情緒關聯，
// 不用另外呼叫心情模組的 API 再自己比對日期。
function attachMoodAndTags(rows, db, userId) {
  if (!rows.length) return rows;
  const dates = [...new Set(rows.map((r) => r.entry_date))];
  const placeholders = dates.map(() => '?').join(',');
  const moodRows = db
    .prepare(`SELECT entry_date, score FROM mood_entries WHERE user_id = ? AND entry_date IN (${placeholders})`)
    .all(userId, ...dates);
  const moodByDate = new Map(moodRows.map((m) => [m.entry_date, m.score]));
  return rows.map((r) => ({
    ...r,
    tags: r.tags ? JSON.parse(r.tags) : [],
    moodScore: moodByDate.has(r.entry_date) ? moodByDate.get(r.entry_date) : null,
  }));
}

router.get('/', requireAuth, (req, res) => {
  const db = getDb();
  const { from, to, q, tag } = req.query;
  const clauses = ['user_id = ?'];
  const params = [req.session.userId];
  if (from && to) {
    clauses.push('entry_date BETWEEN ? AND ?');
    params.push(from, to);
  }
  if (q && q.trim()) {
    clauses.push('content LIKE ?');
    params.push(`%${q.trim()}%`);
  }
  if (tag && tag.trim()) {
    // tags 存成 JSON 陣列字串 (例如 '["工作","旅行"]')，用 LIKE 比對標籤名稱本身即可，
    // 資料量不大不需要為此正規化成獨立的標籤表。
    clauses.push('tags LIKE ?');
    params.push(`%"${tag.trim()}"%`);
  }
  const limitClause = from && to ? '' : ' LIMIT 100';
  const rows = db
    .prepare(`SELECT * FROM diary_entries WHERE ${clauses.join(' AND ')} ORDER BY entry_date DESC${limitClause}`)
    .all(...params);
  res.json(attachMoodAndTags(rows, db, req.session.userId));
});

router.get('/:date', requireAuth, (req, res) => {
  const db = getDb();
  const row = db
    .prepare('SELECT * FROM diary_entries WHERE user_id = ? AND entry_date = ?')
    .get(req.session.userId, req.params.date);
  if (!row) return res.json(null);
  res.json(attachMoodAndTags([row], db, req.session.userId)[0]);
});

router.put('/:date', requireAuth, (req, res) => {
  const { content, mood, tags } = req.body || {};
  const tagsJson = Array.isArray(tags)
    ? JSON.stringify(tags.filter((t) => t && String(t).trim()).map((t) => String(t).trim()))
    : null;
  const db = getDb();
  const now = new Date().toISOString();
  const existing = db
    .prepare('SELECT id FROM diary_entries WHERE user_id = ? AND entry_date = ?')
    .get(req.session.userId, req.params.date);

  if (existing) {
    db.prepare('UPDATE diary_entries SET content = ?, mood = ?, tags = ?, updated_at = ? WHERE id = ?').run(
      content || '',
      mood || null,
      tagsJson,
      now,
      existing.id
    );
  } else {
    db.prepare(
      'INSERT INTO diary_entries (user_id, entry_date, content, mood, tags, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)'
    ).run(req.session.userId, req.params.date, content || '', mood || null, tagsJson, now, now);
  }
  res.json({ ok: true });
});

router.delete('/:date', requireAuth, (req, res) => {
  const db = getDb();
  db.prepare('DELETE FROM diary_entries WHERE user_id = ? AND entry_date = ?').run(
    req.session.userId,
    req.params.date
  );
  res.json({ ok: true });
});

// 從本機文字檔匯入日記 (前端以 <input type="file"> 讀取內容後以純文字 POST 上來，
// 這裡只負責寫入指定日期，避免在伺服器端直接存取使用者電腦檔案系統)
router.post('/import', requireAuth, (req, res) => {
  const { date, content } = req.body || {};
  if (!date || typeof content !== 'string') return res.status(400).json({ error: '缺少 date 或 content' });
  const db = getDb();
  const now = new Date().toISOString();
  const existing = db
    .prepare('SELECT id FROM diary_entries WHERE user_id = ? AND entry_date = ?')
    .get(req.session.userId, date);
  if (existing) {
    db.prepare('UPDATE diary_entries SET content = ?, updated_at = ? WHERE id = ?').run(content, now, existing.id);
  } else {
    db.prepare(
      'INSERT INTO diary_entries (user_id, entry_date, content, created_at, updated_at) VALUES (?, ?, ?, ?, ?)'
    ).run(req.session.userId, date, content, now, now);
  }
  res.json({ ok: true });
});

module.exports = router;
