-- v0.91.0：AI 用量觀測 + AI 助理的長期記憶。
--
-- ai_usage_log：每次呼叫 AI 記一筆 (哪個功能、誰、送出/回覆 token、花多久、成功或失敗)，
-- 給管理者看用量趨勢與異常 (例如模型被停用、額度用完)。只存數字與錯誤摘要，不存對話內容。
CREATE TABLE IF NOT EXISTS ai_usage_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,
  feature TEXT NOT NULL,
  provider TEXT NOT NULL,
  model TEXT,
  input_tokens INTEGER,
  output_tokens INTEGER,
  duration_ms INTEGER,
  ok INTEGER NOT NULL,
  error TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_ai_usage_log_created ON ai_usage_log (created_at);

-- assistant_chat_memory：AI 助理對話「比較久以前」的重點摘要，結構跟心靈對話的 mood_chat_memory 一樣。
-- 每次只把最近 30 則對話原文交給 AI，更早的內容靠這些摘要記得重點 (使用者可以在設定頁查看/清除)。
CREATE TABLE IF NOT EXISTS assistant_chat_memory (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  chunk_from_id INTEGER NOT NULL,
  chunk_to_id INTEGER NOT NULL,
  summary TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_assistant_chat_memory_user ON assistant_chat_memory (user_id, chunk_to_id);
