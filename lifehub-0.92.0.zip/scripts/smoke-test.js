#!/usr/bin/env node
// v0.89：發版前的自動檢查。只用 Node 內建模組，不需要 npm 套件、不需要瀏覽器。
//
// 用法 (在專案根目錄，或在「把要出的 zip 解壓出來的全新資料夾」裡)：
//   node scripts/smoke-test.js
//
// 會做的事：
// 1. `node --check` 所有後端 .js，並把前端 app.js / sw.js 當成 script 編譯一次 (抓語法錯誤)。
// 2. 用暫存資料庫在隨機 port 啟動一份伺服器 (不碰 data/app.db、不跑異地備份)，註冊一個測試帳號。
// 3. 從 src/routes/*.js 自動找出所有「不帶參數」的 GET API，逐一打一次：不能回 5xx、要能解析成 JSON。
//    需要外部網路的 (交通、旅遊、AI、地點) 回 5xx 只列為警告，因為本機可能沒有金鑰或網路。
// 4. 首頁、app.js、style.css、sw.js、manifest.json 要能拿到；/api/health 的版本號要等於 package.json。
// 5. 功能檢查：生日倒數用台灣時間算 (今天 = 0)、異地備份的「還原驗證」能抓出被竄改的檔案。
// 6. (v0.90) 用假時鐘把伺服器設在「UTC 跟台灣不同天」的時間點，確認打卡/吃藥記在台灣的今天。
// 7. (v0.90) 安全防護：CSP、沒有內嵌事件、登出所有裝置、登入次數限制、弱金鑰自動換掉、
//    發版簽章 (release-sign / server.js bootstrap / safe-update，後者需要 git)。
//
// 全部通過 exit code 0；有任何失敗 exit code 1，最後列出失敗清單。
'use strict';
const fs = require('fs');
const os = require('os');
const path = require('path');
const vm = require('vm');
const zlib = require('zlib');
const crypto = require('crypto');
const { spawn, spawnSync } = require('child_process');

const ROOT = path.join(__dirname, '..');
const PKG = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
// 會連外部服務的 API：本機沒有金鑰/網路時 5xx 是正常的，只警告不算失敗。
const EXTERNAL_PREFIXES = ['/api/travel', '/api/assistant', '/api/places', '/api/transit', '/api/tdx', '/api/flights', '/api/tarot/ai'];
// 會改資料或觸發外部動作的 GET (少數舊 API 用 GET 做事)，不要打。
const SKIP_PATHS = new Set(['/api/auth/logout']);

const failures = [];
const warnings = [];
let passed = 0;
function ok(msg) { passed++; console.log(`  ✓ ${msg}`); }
function fail(msg) { failures.push(msg); console.log(`  ✗ ${msg}`); }
function warn(msg) { warnings.push(msg); console.log(`  ! ${msg}`); }

function listJs(dir) {
  const out = [];
  for (const ent of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, ent.name);
    if (ent.isDirectory()) { if (ent.name !== 'node_modules') out.push(...listJs(p)); } else if (ent.name.endsWith('.js')) out.push(p);
  }
  return out;
}

// ---------- 1. 語法 ----------
function checkSyntax() {
  console.log('\n[1] 語法檢查');
  const files = [path.join(ROOT, 'server.js'), ...listJs(path.join(ROOT, 'src')), ...listJs(path.join(ROOT, 'scripts'))];
  let bad = 0;
  for (const f of files) {
    const r = spawnSync(process.execPath, ['--check', f], { encoding: 'utf8' });
    if (r.status !== 0) { bad++; fail(`node --check ${path.relative(ROOT, f)}\n${r.stderr.trim()}`); }
  }
  if (!bad) ok(`後端 ${files.length} 個 .js 語法正確`);
  for (const rel of ['public/js/app.js', 'public/sw.js']) {
    try { new vm.Script(fs.readFileSync(path.join(ROOT, rel), 'utf8'), { filename: rel }); ok(`${rel} 可以編譯`); } catch (e) { fail(`${rel} 編譯失敗：${e.message}`); }
  }
}

// ---------- 從原始碼找出所有 GET 路由 ----------
function collectGetRoutes() {
  const serverSrc = fs.readFileSync(path.join(ROOT, 'server.js'), 'utf8');
  const prefixByFile = {};
  for (const m of serverSrc.matchAll(/app\.mount\('([^']+)',\s*require\('\.\/src\/routes\/([\w-]+)'\)\)/g)) prefixByFile[m[2]] = m[1];
  // debug.js 把其他 routes 檔併進 /api (require('./xxx').routes.forEach...)
  const debugSrc = fs.readFileSync(path.join(ROOT, 'src/routes/debug.js'), 'utf8');
  const apiPrefix = prefixByFile.debug || '/api';
  for (const m of debugSrc.matchAll(/require\('\.\/([\w-]+)'\)\.routes\.forEach/g)) prefixByFile[m[1]] = apiPrefix;
  const routes = [];
  for (const [file, prefix] of Object.entries(prefixByFile)) {
    const f = path.join(ROOT, 'src/routes', `${file}.js`);
    if (!fs.existsSync(f)) continue;
    const src = fs.readFileSync(f, 'utf8');
    for (const m of src.matchAll(/router\.get\(\s*'([^']+)'/g)) {
      if (m[1].includes(':') || m[1].includes('*')) continue;
      const p = (prefix + (m[1] === '/' ? '' : m[1])) || '/';
      if (!SKIP_PATHS.has(p)) routes.push(p);
    }
  }
  return [...new Set(routes)].sort();
}

// ---------- 啟動測試伺服器 ----------
function freePort() {
  return new Promise((resolve) => {
    const s = require('net').createServer();
    s.listen(0, '127.0.0.1', () => { const { port } = s.address(); s.close(() => resolve(port)); });
  });
}

async function startServer(tmpDir, preArgs = [], extraEnv = {}) {
  const port = await freePort();
  const logFile = path.join(tmpDir, 'server.log');
  const log = fs.openSync(logFile, 'w');
  const child = spawn(process.execPath, [...preArgs, 'server.js'], {
    cwd: ROOT,
    env: {
      ...process.env,
      PORT: String(port),
      DB_PATH: path.join(tmpDir, 'app.db'),
      SESSION_SECRET: 'smoke-test',
      LIFEHUB_DISABLE_OFFSITE_BACKUP: '1',
      LIFEHUB_BOOT_OK_DELAY_MS: String(24 * 3600 * 1000), // 不要寫 .bootstrap 狀態
      GEMINI_API_KEY: '', ANTHROPIC_API_KEY: '',
      HOST: '',
      // v0.91 起預設只開放受邀註冊；大部分檢查需要自由註冊測試帳號，所以預設打開，邀請制另外測
      REGISTRATION_OPEN: '1',
      ...extraEnv,
    },
    stdio: ['ignore', log, log],
  });
  const base = `http://127.0.0.1:${port}`;
  for (let i = 0; i < 60; i++) {
    if (child.exitCode != null) break;
    try { const r = await fetch(base + '/api/health'); if (r.ok) return { child, base, logFile }; } catch (e) { /* 還沒好 */ }
    await new Promise((r) => setTimeout(r, 250));
  }
  child.kill();
  throw new Error(`伺服器 15 秒內沒有啟動，log：\n${fs.readFileSync(logFile, 'utf8').slice(-2000)}`);
}

function makeClient(base) {
  let cookie = '';
  return async function req(method, p, body) {
    const r = await fetch(base + p, {
      method,
      headers: { ...(cookie ? { Cookie: cookie } : {}), ...(body ? { 'Content-Type': 'application/json' } : {}) },
      body: body ? JSON.stringify(body) : undefined,
      signal: AbortSignal.timeout(10000),
    });
    const set = r.headers.getSetCookie ? r.headers.getSetCookie() : [];
    if (set.length) cookie = set.map((c) => c.split(';')[0]).join('; ');
    const text = await r.text();
    let json = null;
    try { json = text ? JSON.parse(text) : null; } catch (e) { /* 不是 JSON */ }
    return { status: r.status, text, json, type: r.headers.get('content-type') || '' };
  };
}

function taipeiMonthDay(offsetDays) {
  const d = new Date(Date.now() + 8 * 3600 * 1000 + offsetDays * 86400000);
  return d.toISOString().slice(5, 10);
}

async function checkServer() {
  console.log('\n[2] 啟動測試伺服器');
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'lifehub-smoke-'));
  const { child, base, logFile } = await startServer(tmpDir);
  ok(`伺服器在 ${base} 啟動 (暫存資料庫 ${tmpDir})`);
  const req = makeClient(base);
  try {
    const h = await req('GET', '/api/health');
    if (h.json && h.json.version === PKG.version) ok(`/api/health 版本 ${h.json.version} = package.json`);
    else fail(`/api/health 版本 ${h.json && h.json.version} ≠ package.json ${PKG.version}`);

    console.log('\n[3] 靜態檔案');
    for (const p of ['/', '/js/app.js', '/css/style.css', '/sw.js', '/manifest.json']) {
      const r = await req('GET', p);
      if (r.status === 200 && r.text.length > 0) ok(`${p} (${r.text.length} 字元)`); else fail(`${p} 回 ${r.status}`);
    }

    const email = `smoke-${Date.now()}@example.test`;
    const reg = await req('POST', '/api/auth/register', { email, password: 'smoke-test-123', name: '測試' });
    if (reg.status >= 400) throw new Error(`註冊測試帳號失敗：${reg.status} ${reg.text.slice(0, 200)}`);
    await req('POST', '/api/auth/login', { email, password: 'smoke-test-123' });
    const me = await req('GET', '/api/auth/me');
    if (me.status !== 200) throw new Error(`登入後 /api/auth/me 回 ${me.status}`);
    ok('註冊並登入測試帳號');

    console.log('\n[4] 所有不帶參數的 GET API');
    const routes = collectGetRoutes();
    for (const p of routes) {
      let r;
      try { r = await req('GET', p); } catch (e) { r = { status: 0, text: e.message, type: '' }; }
      const external = EXTERNAL_PREFIXES.some((x) => p.startsWith(x));
      if (r.status >= 500 || r.status === 0) {
        (external ? warn : fail)(`${p} 回 ${r.status || '逾時'}${external ? ' (需要外部服務)' : ''}：${r.text.slice(0, 120)}`);
      } else if (r.type.includes('application/json') && r.json === null && r.text) {
        fail(`${p} 宣稱是 JSON 但解析失敗`);
      }
    }
    ok(`打過 ${routes.length} 個 GET API`);

    console.log('\n[5] 生日倒數 (台灣時間)');
    await req('POST', '/api/relationships', { name: '今天壽星', birthday: taipeiMonthDay(0) });
    await req('POST', '/api/relationships', { name: '五天後', birthday: taipeiMonthDay(5) });
    await req('POST', '/api/relationships', { name: '一個月後', birthday: taipeiMonthDay(30) });
    const up = await req('GET', '/api/relationships/upcoming-dates?days=14&limit=3');
    const got = (up.json || []).map((x) => `${x.label}:${x.daysUntil}`).join(', ');
    if (got === '今天壽星的生日:0, 五天後的生日:5') ok(`upcoming-dates → ${got}`);
    else fail(`upcoming-dates 預期「今天壽星的生日:0, 五天後的生日:5」，實際「${got}」`);

    const serverErrors = fs.readFileSync(logFile, 'utf8').split('\n').filter((l) => /TypeError|ReferenceError|SyntaxError|Unhandled/.test(l));
    if (serverErrors.length) fail(`伺服器 log 有程式錯誤：\n    ${serverErrors.slice(0, 5).join('\n    ')}`);
    else ok('伺服器 log 沒有程式錯誤');
  } finally {
    // 等伺服器真的結束再往下 (下一步要直接打開它的資料庫；Windows 上檔案還被占用會 disk I/O error)
    const exited = new Promise((r) => { if (child.exitCode != null) r(); else child.once('exit', r); });
    child.kill();
    await Promise.race([exited, new Promise((r) => setTimeout(r, 5000))]);
  }
  return tmpDir;
}

// ---------- 異地備份的還原驗證 (不連 GCS，只測加解密跟檢查邏輯) ----------
function checkBackupVerify(tmpDir) {
  console.log('\n[6] 異地備份還原驗證');
  process.env.DB_PATH = path.join(tmpDir, 'app.db');
  process.env.LIFEHUB_DISABLE_OFFSITE_BACKUP = '1';
  process.env.BACKUP_KEY = crypto.randomBytes(32).toString('base64');
  const offsite = require(path.join(ROOT, 'src/services/offsiteBackup'));
  const { DatabaseSync } = require('node:sqlite');
  const key = Buffer.from(process.env.BACKUP_KEY, 'base64');
  const dbFile = path.join(tmpDir, 'app.db');
  const db = new DatabaseSync(dbFile);
  const counts = offsite.tableCounts(db);
  db.close();
  const payload = offsite.encrypt(zlib.gzipSync(fs.readFileSync(dbFile)), key);
  try { offsite.verifyRestorable(payload, payload, key, counts); ok(`正常備份可以還原 (${Object.keys(counts).length} 張資料表筆數一致)`); } catch (e) { fail(`正常備份驗證失敗：${e.message}`); }
  const tampered = Buffer.from(payload); tampered[tampered.length - 1] ^= 1;
  try { offsite.verifyRestorable(tampered, payload, key, counts); fail('被竄改的檔案沒有被抓到'); } catch (e) { ok(`抓到被竄改的檔案：${e.message}`); }
  try { offsite.verifyRestorable(payload, payload, crypto.randomBytes(32), counts); fail('錯的金鑰沒有被抓到'); } catch (e) { ok(`抓到錯的金鑰：${e.message}`); }
  const wrongCounts = { ...counts, tasks: (counts.tasks || 0) + 1 };
  try { offsite.verifyRestorable(payload, payload, key, wrongCounts); fail('筆數不一致沒有被抓到'); } catch (e) { ok(`抓到筆數不一致：${e.message}`); }
}

// ---------- v0.90：伺服器的「今天」一律是台灣日期 ----------
// 用 --require 載入一個假時鐘，讓伺服器以為現在是 UTC 2026-11-05 23:30 (= 台灣 11/06 早上 7:30)，
// 這個時間點 UTC 日期跟台灣日期不同，用 UTC 算「今天」的程式一定會露餡。
const FAKE_NOW_UTC = '2026-11-05T23:30:00.000Z';
const FAKE_TW_DATE = '2026-11-06';
const FAKE_CLOCK_SRC = `
const RealDate = Date;
const OFFSET = RealDate.parse(${JSON.stringify(FAKE_NOW_UTC)}) - RealDate.now();
class FakeDate extends RealDate {
  constructor(...a) { if (a.length === 0) super(RealDate.now() + OFFSET); else super(...a); }
  static now() { return RealDate.now() + OFFSET; }
}
globalThis.Date = FakeDate;
`;

async function checkTaipeiTime() {
  console.log('\n[7] 伺服器日期用台灣時間');
  const tw = require(path.join(ROOT, 'src/services/twtime'));
  const cases = [
    [tw.twDateStr(new Date('2026-11-05T23:30:00Z')), '2026-11-06', 'UTC 23:30 → 台灣日期'],
    [tw.twDateStr(new Date('2026-11-05T15:59:59Z')), '2026-11-05', 'UTC 15:59 → 台灣日期'],
    [tw.twDateStr(new Date('2026-11-30T16:00:00Z')), '2026-12-01', '跨月'],
    [tw.twHHMM(new Date('2026-11-05T00:05:00Z')), '08:05', '台灣幾點'],
    [tw.addDaysStr('2026-12-31', 1), '2027-01-01', '跨年加一天'],
    [tw.addDaysStr('2026-03-01', -1), '2026-02-28', '往前一天'],
    [tw.addMonthsStr('2026-11-30', -3), '2026-08-30', '往前 3 個月'],
  ];
  const bad = cases.filter(([got, want]) => got !== want);
  if (bad.length) bad.forEach(([got, want, label]) => fail(`twtime ${label}：預期 ${want}，實際 ${got}`));
  else ok(`twtime 日期換算 ${cases.length} 個案例正確`);

  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'lifehub-twtime-'));
  const clockFile = path.join(tmpDir, 'fake-clock.js');
  fs.writeFileSync(clockFile, FAKE_CLOCK_SRC);
  const { child, base, logFile } = await startServer(tmpDir, ['--require', clockFile]);
  const req = makeClient(base);
  try {
    const email = `tw-${process.pid}@example.test`;
    await req('POST', '/api/auth/register', { email, password: 'smoke-test-123', name: '時區' });

    const h = await req('POST', '/api/habits', { title: '喝水', icon: '💧' });
    await req('POST', `/api/habits/${h.json && h.json.id}/toggle`);
    const habits = await req('GET', '/api/habits');
    const habit = (habits.json || [])[0] || {};
    const doneDates = (habit.week || []).filter((d) => d.done).map((d) => d.date);
    if (habit.doneToday && doneDates.join() === FAKE_TW_DATE) ok(`台灣早上 7:30 打卡記在 ${FAKE_TW_DATE}`);
    else fail(`習慣打卡日期錯誤：doneToday=${habit.doneToday}，打卡日期 ${doneDates.join() || '(無)'}，預期 ${FAKE_TW_DATE}`);

    const med = await req('POST', '/api/health-track/meds', { name: '維他命', dose: '1 顆', scheduleTime: '07:30' });
    await req('PUT', `/api/health-track/meds/${med.json && med.json.id}/log`, { taken: true });
    const meds = await req('GET', '/api/health-track/meds/today');
    const m = (meds.json || [])[0] || {};
    if (m.takenToday) ok('服藥打勾記在台灣的今天');
    else fail(`服藥打勾沒有算在台灣的今天：${meds.text.slice(0, 160)}`);

    // v0.92：帳單「還有幾天到期」也要用台灣日期 (台灣 11/06，10 號到期 → 4 天；用 UTC 會算成 5 天)
    await req('POST', '/api/bills', { name: '電話費', amount: 499, dueDay: 10, category: '電信' });
    const up = await req('GET', '/api/bills/upcoming');
    const phone = ((up.json && up.json.bills) || []).find((b) => b.name === '電話費') || {};
    if (phone.daysUntilDue === 4) ok('帳單到期天數用台灣日期算 (4 天)');
    else fail(`帳單到期天數不對：${phone.daysUntilDue}，預期 4`);

    const serverErrors = fs.readFileSync(logFile, 'utf8').split('\n').filter((l) => /TypeError|ReferenceError|SyntaxError|Unhandled/.test(l));
    if (serverErrors.length) fail(`假時鐘伺服器 log 有程式錯誤：\n    ${serverErrors.slice(0, 5).join('\n    ')}`);
    else ok('假時鐘伺服器 log 沒有程式錯誤');
  } finally {
    child.kill();
    await new Promise((r) => setTimeout(r, 300));
    fs.rmSync(tmpDir, { recursive: true, force: true });
  }
}

// ---------- v0.90：安全防護 ----------
// 最小 zip 產生器 (不壓縮)，只給測試用
function makeZip(entries) {
  const locals = [], centrals = [];
  let offset = 0;
  for (const [name, content] of Object.entries(entries)) {
    const data = Buffer.from(content);
    const nameBuf = Buffer.from(name, 'utf8');
    const crc = zlib.crc32(data);
    const lh = Buffer.alloc(30);
    lh.writeUInt32LE(0x04034b50, 0); lh.writeUInt16LE(20, 4); lh.writeUInt16LE(0x0800, 6);
    lh.writeUInt32LE(crc, 14); lh.writeUInt32LE(data.length, 18); lh.writeUInt32LE(data.length, 22); lh.writeUInt16LE(nameBuf.length, 26);
    const ch = Buffer.alloc(46);
    ch.writeUInt32LE(0x02014b50, 0); ch.writeUInt16LE(20, 4); ch.writeUInt16LE(20, 6); ch.writeUInt16LE(0x0800, 8);
    ch.writeUInt32LE(crc, 16); ch.writeUInt32LE(data.length, 20); ch.writeUInt32LE(data.length, 24); ch.writeUInt16LE(nameBuf.length, 28);
    ch.writeUInt32LE(offset, 42);
    locals.push(lh, nameBuf, data);
    centrals.push(ch, nameBuf);
    offset += 30 + nameBuf.length + data.length;
  }
  const cd = Buffer.concat(centrals);
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(Object.keys(entries).length, 8); end.writeUInt16LE(Object.keys(entries).length, 10);
  end.writeUInt32LE(cd.length, 12); end.writeUInt32LE(offset, 16);
  return Buffer.concat([...locals, cd, end]);
}

async function checkSecurity() {
  console.log('\n[8] 安全防護 (v0.90)');

  // ---- 前端：沒有內嵌事件、data-onclick 都對得到函式 ----
  const html = fs.readFileSync(path.join(ROOT, 'public/index.html'), 'utf8');
  const appJs = fs.readFileSync(path.join(ROOT, 'public/js/app.js'), 'utf8');
  const inline = html.match(/<[^>]*\son[a-z]+\s*=/gi) || [];
  const inlineScripts = (html.match(/<script(?![^>]*\ssrc=)[^>]*>/gi) || []);
  if (!inline.length && !inlineScripts.length) ok('index.html 沒有內嵌 script / onclick (CSP 擋得住)');
  else fail(`index.html 還有內嵌事件或 script：${[...inline, ...inlineScripts].slice(0, 3).join(' ')}`);
  const specs = [...html.matchAll(/data-onclick="([^"]+)"/g)].map((m) => m[1]);
  const missing = specs.filter((s) => s !== 'event.stopPropagation()').map((s) => (/^([A-Za-z_$][\w$]*)\(/.exec(s) || [])[1])
    .filter((name) => !name || !new RegExp(`^(async )?function ${name}\\(`, 'm').test(appJs));
  if (!missing.length) ok(`${specs.length} 個 data-onclick 都對得到 app.js 的函式`);
  else fail(`data-onclick 找不到函式：${missing.join(', ')}`);

  // ---- 發版簽章：release-sign 簽的東西 bootstrap / safe-update 的格式都認得 ----
  const rs = require(path.join(ROOT, 'scripts/release-sign'));
  const { publicKey, privateKey } = crypto.generateKeyPairSync('ed25519');
  const other = crypto.generateKeyPairSync('ed25519');
  const zipBuf = makeZip({ 'package.json': JSON.stringify({ version: '9.9.9' }), 'MARKER.txt': 'signed-release' });
  const sig = rs.signRelease(zipBuf, 'lifehub-9.9.9.zip', privateKey);
  const expectFail = (label, fn) => { try { fn(); fail(`${label}沒有被擋下`); } catch (e) { ok(`擋下${label}：${e.message}`); } };
  try { rs.verifyRelease(zipBuf, 'lifehub-9.9.9.zip', sig, publicKey); ok('正確簽章驗證通過'); } catch (e) { fail(`正確簽章驗證失敗：${e.message}`); }
  const tampered = Buffer.from(zipBuf); tampered[tampered.length - 30] ^= 1;
  expectFail('被改過的 zip', () => rs.verifyRelease(tampered, 'lifehub-9.9.9.zip', sig, publicKey));
  expectFail('別人的金鑰簽的 zip', () => rs.verifyRelease(zipBuf, 'lifehub-9.9.9.zip', rs.signRelease(zipBuf, 'lifehub-9.9.9.zip', other.privateKey), publicKey));
  expectFail('改檔名冒充其他版本', () => rs.verifyRelease(zipBuf, 'lifehub-9.9.10.zip', sig, publicKey));
  const safeUpdateSrc = fs.readFileSync(path.join(ROOT, 'scripts/safe-update.js'), 'utf8');
  const serverSrc = fs.readFileSync(path.join(ROOT, 'server.js'), 'utf8');
  if (safeUpdateSrc.includes("const FORMAT = 'LIFEHUB-RELEASE-1'") && serverSrc.includes('LIFEHUB-RELEASE-1\\nfile=${zipName}\\nversion=${m[1]}\\nsha256=${hash}\\n'))
    ok('release-sign / safe-update / server.js 的簽章格式一致');
  else fail('release-sign / safe-update / server.js 的簽章格式不一致');

  // ---- bootstrap：有公鑰時，沒簽章 / 簽錯的 zip 不解壓，簽對才解壓 ----
  const bootDir = fs.mkdtempSync(path.join(os.tmpdir(), 'lifehub-boot-'));
  try {
    const root = path.join(bootDir, 'app');
    for (const d of ['src', 'public', 'migrations']) fs.cpSync(path.join(ROOT, d), path.join(root, d), { recursive: true });
    for (const f of ['server.js', 'package.json']) fs.copyFileSync(path.join(ROOT, f), path.join(root, f));
    const pubFile = path.join(bootDir, 'release-public.pem');
    fs.writeFileSync(pubFile, publicKey.export({ type: 'spki', format: 'pem' }));
    const zipName = 'lifehub-9.9.9.zip';
    const bootZip = makeZip({ 'MARKER.txt': 'extracted' });
    fs.writeFileSync(path.join(root, zipName), bootZip);
    const runBoot = () => spawnSync(process.execPath, ['-e', "require('./server.js'); setTimeout(() => process.exit(0), 300)"], {
      cwd: root, encoding: 'utf8', timeout: 20000,
      env: { ...process.env, LIFEHUB_RELEASE_PUBKEY_FILE: pubFile, PORT: '0', DB_PATH: path.join(bootDir, 'app.db'), LIFEHUB_DISABLE_OFFSITE_BACKUP: '1', LIFEHUB_BOOT_OK_DELAY_MS: '86400000', SESSION_SECRET: '' },
    });
    const marker = path.join(root, 'MARKER.txt');
    let r = runBoot();
    if (!fs.existsSync(marker) && /沒有通過簽章檢查/.test(r.stderr)) ok('bootstrap：沒有 .sig 的 zip 不解壓');
    else fail(`bootstrap 解壓了沒簽章的 zip：${(r.stderr || '').slice(-300)}`);
    fs.writeFileSync(path.join(root, zipName + '.sig'), JSON.stringify(rs.signRelease(bootZip, zipName, other.privateKey)));
    r = runBoot();
    if (!fs.existsSync(marker)) ok('bootstrap：別人簽的 zip 不解壓'); else fail('bootstrap 解壓了別人簽的 zip');
    fs.writeFileSync(path.join(root, zipName + '.sig'), JSON.stringify(rs.signRelease(bootZip, zipName, privateKey)));
    r = runBoot();
    if (fs.existsSync(marker)) ok('bootstrap：簽章正確的 zip 正常解壓'); else fail(`bootstrap 沒解壓簽章正確的 zip：${(r.stderr || r.stdout || '').slice(-300)}`);
  } finally {
    fs.rmSync(bootDir, { recursive: true, force: true });
  }

  // ---- safe-update：需要 git，沒有就略過 ----
  const hasGit = spawnSync('git', ['--version']).status === 0;
  if (!hasGit) warn('這台沒有 git，略過 safe-update 的端對端測試 (請在有 git 的環境再跑一次)');
  else await checkSafeUpdate(rs, makeZip, publicKey, privateKey, other.privateKey);

  // ---- 伺服器：安全標頭、登出所有裝置、嘗試次數限制、弱金鑰自動換掉 ----
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'lifehub-sec-'));
  const { child, base } = await startServer(tmpDir); // SESSION_SECRET='smoke-test' (太短) → 應該自動產生 session.secret
  try {
    const page = await fetch(base + '/');
    const csp = page.headers.get('content-security-policy') || '';
    if (/script-src 'self'(;|$)/.test(csp) && /connect-src 'self'/.test(csp) && /frame-ancestors 'none'/.test(csp) && page.headers.get('x-content-type-options') === 'nosniff')
      ok('首頁有 CSP (script-src/connect-src 只限本站、禁止被 iframe) 與 nosniff');
    else fail(`安全標頭不完整：${csp || '(沒有 CSP)'}`);
    if (fs.existsSync(path.join(tmpDir, 'session.secret'))) ok('SESSION_SECRET 太弱時自動產生 session.secret');
    else fail('SESSION_SECRET 太弱，但沒有自動產生 session.secret');

    const email = `sec-${process.pid}@example.test`;
    const phone = makeClient(base), laptop = makeClient(base);
    await phone('POST', '/api/auth/register', { email, password: 'smoke-test-123', name: '安全' });
    await laptop('POST', '/api/auth/login', { email, password: 'smoke-test-123' });
    const before = await laptop('GET', '/api/auth/me');
    const out = await phone('POST', '/api/auth/logout-all');
    const laptopAfter = await laptop('GET', '/api/auth/me');
    const phoneAfter = await phone('GET', '/api/auth/me');
    if (before.json && before.json.user && out.status === 200 && laptopAfter.json && laptopAfter.json.user === null && phoneAfter.json && phoneAfter.json.user)
      ok('登出所有其他裝置：別台的登入失效，按的這台維持登入');
    else fail(`登出所有裝置結果不對：laptop 前=${!!(before.json && before.json.user)} 後=${JSON.stringify(laptopAfter.json)} phone 後=${!!(phoneAfter.json && phoneAfter.json.user)}`);

    const guess = makeClient(base);
    let statuses = [];
    for (let i = 0; i < 9; i++) statuses.push((await guess('POST', '/api/auth/login', { email, password: 'wrong-' + i })).status);
    const right = await guess('POST', '/api/auth/login', { email, password: 'smoke-test-123' });
    if (statuses.slice(0, 8).every((s) => s === 401) && statuses[8] === 429 && right.status === 429) ok('密碼猜錯 8 次後暫停登入 (429)，連正確密碼也先擋');
    else fail(`登入次數限制不對：${statuses.join(',')} 正確密碼→${right.status}`);
    const rc = makeClient(base);
    statuses = [];
    for (let i = 0; i < 9; i++) statuses.push((await rc('POST', '/api/auth/forgot-password', { email, recoveryCode: 'AAAA-BBBB-CCCC-' + i, newPassword: 'whatever-123' })).status);
    if (statuses[8] === 429) ok('備用重設碼猜錯 8 次後暫停 (429)');
    else fail(`備用重設碼次數限制不對：${statuses.join(',')}`);

    await checkHotfix0901(base, tmpDir);
  } finally {
    child.kill();
    await new Promise((r) => setTimeout(r, 300));
    fs.rmSync(tmpDir, { recursive: true, force: true });
  }
}

// ---------- v0.90.1 安全 hotfix ----------
async function checkHotfix0901(base, tmpDir) {
  console.log('\n[9] v0.90.1 安全修正');
  const raw = async (method, p, { body, headers = {}, cookie } = {}) => {
    const r = await fetch(base + p, {
      method,
      headers: { ...headers, ...(cookie ? { Cookie: cookie } : {}), ...(body ? { 'Content-Type': 'application/json' } : {}) },
      body: body ? JSON.stringify(body) : undefined,
      signal: AbortSignal.timeout(10000),
    });
    const set = r.headers.getSetCookie ? r.headers.getSetCookie() : [];
    return { status: r.status, json: await r.json().catch(() => null), setCookie: set, headers: r.headers };
  };

  // ---- 管理者不能被冒用 ----
  const ADMIN = '910228jason@gmail.com';
  const owner = await raw('POST', '/api/auth/register', { body: { email: ADMIN, password: 'owner-pass-123' } });
  if (owner.status === 200 && owner.json && owner.json.isAdmin === true) ok('管理者本人註冊後是管理者');
  else fail(`管理者本人註冊結果不對：${owner.status} ${JSON.stringify(owner.json)}`);
  const fakes = ['910228Jason@gmail.com', ' 910228JASON@GMAIL.COM ', '910228jason@Gmail.com'];
  const fakeStatuses = [];
  for (const email of fakes) fakeStatuses.push((await raw('POST', '/api/auth/register', { body: { email, password: 'attacker-pass-1' } })).status);
  if (fakeStatuses.every((s) => s === 409)) ok(`大小寫/空白不同的管理者 email 無法註冊 (${fakeStatuses.join(',')})`);
  else fail(`大小寫不同的管理者 email 還能註冊：${fakeStatuses.join(',')}`);
  const ownerLogin = await raw('POST', '/api/auth/login', { body: { email: ' 910228JASON@gmail.com ', password: 'owner-pass-123' } });
  if (ownerLogin.status === 200 && ownerLogin.json.isAdmin) ok('本人用大小寫不同的 email 也能登入 (email 不分大小寫)');
  else fail(`本人用大寫 email 登入失敗：${ownerLogin.status}`);

  const { DatabaseSync } = require('node:sqlite');
  const { hashPassword } = require(path.join(ROOT, 'src/services/passwords'));
  const db = new DatabaseSync(path.join(tmpDir, 'app.db'));
  let blocked = false;
  try { db.prepare('INSERT INTO users (email, password_hash, name, created_at) VALUES (?, ?, ?, ?)').run('910228JASON@gmail.com', hashPassword('x-pass-123'), 'x', new Date().toISOString()); } catch (e) { blocked = /UNIQUE/i.test(e.message); }
  db.close();
  if (blocked) ok('資料庫層也擋下大小寫不同的重複 email (唯一索引)');
  else fail('資料庫沒有擋下大小寫不同的重複 email');

  // 改版前就已經存在的冒牌帳號：管理者判定要選「最早建立的那一個」
  const admin = require(path.join(ROOT, 'src/services/admin'));
  const mem = new DatabaseSync(':memory:');
  mem.exec('CREATE TABLE users (id INTEGER PRIMARY KEY, email TEXT UNIQUE)');
  mem.prepare('INSERT INTO users (id, email) VALUES (5, ?)').run(ADMIN);
  mem.prepare('INSERT INTO users (id, email) VALUES (9, ?)').run('910228Jason@gmail.com');
  if (admin.isAdminUser(mem, 5) && !admin.isAdminUser(mem, 9)) ok('舊資料裡已存在的冒牌帳號不會被當成管理者');
  else fail('舊資料裡的冒牌帳號仍被當成管理者');
  mem.close();

  const stranger = await raw('POST', '/api/auth/register', { body: { email: `stranger-${process.pid}@example.test`, password: 'stranger-123' } });
  const strangerCookie = (stranger.setCookie[0] || '').split(';')[0];
  const adminApis = ['/api/backup/offsite/status', '/api/feedback', '/api/admin/users'];
  const adminStatuses = [];
  for (const p of adminApis) adminStatuses.push((await raw('GET', p, { cookie: strangerCookie })).status);
  if (adminStatuses.every((s) => s === 403)) ok('一般帳號打管理者 API 都回 403');
  else fail(`一般帳號打管理者 API：${adminApis.map((p, i) => `${p}=${adminStatuses[i]}`).join(' ')}`);

  // ---- 真實 IP：經過代理時用 X-Forwarded-For 最後一段分開計數 ----
  const attackerIp = '203.0.113.7';
  for (let i = 0; i < 30; i++) {
    await raw('POST', '/api/auth/login', { body: { email: `nobody${i}@example.test`, password: 'x' }, headers: { 'X-Forwarded-For': attackerIp } });
  }
  const attackerNext = await raw('POST', '/api/auth/login', { body: { email: 'nobody-x@example.test', password: 'x' }, headers: { 'X-Forwarded-For': `198.51.100.99, ${attackerIp}` } });
  const family = await raw('POST', '/api/auth/login', { body: { email: ADMIN, password: 'owner-pass-123' }, headers: { 'X-Forwarded-For': '198.51.100.20' } });
  if (attackerNext.status === 429 && family.status === 200) ok('攻擊者 IP 錯 30 次只擋他自己 (偽造前段也沒用)，家人照常登入');
  else fail(`IP 計數不對：攻擊者第 31 次=${attackerNext.status}，家人登入=${family.status}`);

  // ---- HTTPS：HSTS 與 Secure cookie ----
  const httpsHdr = { 'X-Forwarded-Proto': 'https', 'X-Forwarded-For': '198.51.100.21' };
  const page = await raw('GET', '/', { headers: httpsHdr });
  const plain = await raw('GET', '/');
  if (/max-age=\d+/.test(page.headers.get('strict-transport-security') || '') && !plain.headers.get('strict-transport-security')) ok('HTTPS 才送 HSTS，本機 http 不送');
  else fail(`HSTS 不對：https=${page.headers.get('strict-transport-security')} http=${plain.headers.get('strict-transport-security')}`);
  const httpsLogin = await raw('POST', '/api/auth/login', { body: { email: ADMIN, password: 'owner-pass-123' }, headers: httpsHdr });
  const httpLogin = await raw('POST', '/api/auth/login', { body: { email: ADMIN, password: 'owner-pass-123' } });
  if (/;\s*Secure/i.test(httpsLogin.setCookie.join()) && !/;\s*Secure/i.test(httpLogin.setCookie.join())) ok('HTTPS 登入的 cookie 有 Secure');
  else fail(`Secure 不對：https=${httpsLogin.setCookie.join()} http=${httpLogin.setCookie.join()}`);
  const oldCookie = (httpLogin.setCookie[0] || '').split(';')[0];
  const upgraded = await raw('GET', '/api/auth/me', { cookie: oldCookie, headers: httpsHdr });
  if (upgraded.json && upgraded.json.user && /;\s*Secure/i.test(upgraded.setCookie.join())) ok('改版前發的舊 cookie 在 HTTPS 下會自動換成 Secure');
  else fail(`舊 cookie 沒有升級成 Secure：${upgraded.setCookie.join() || '(沒有 Set-Cookie)'}`);
}

// ---------- v0.91：家人邀請制、AI 用量與記憶、常用功能、只聽本機 ----------
async function checkV091() {
  console.log('\n[10] v0.91 邀請制 / AI 用量與記憶 / 常用功能 / 只聽本機');

  // 假的 Gemini：記下每次收到的請求；訊息含 FAIL 時回 404 (模擬模型被停用)
  const aiRequests = [];
  const fake = require('http').createServer((rq, rs) => {
    let body = '';
    rq.on('data', (c) => { body += c; });
    rq.on('end', () => {
      let j = {};
      try { j = JSON.parse(body); } catch (e) { /* ignore */ }
      aiRequests.push(j);
      const lastText = JSON.stringify((j.contents || []).slice(-1));
      if (lastText.includes('FAIL')) {
        rs.writeHead(404, { 'content-type': 'application/json' });
        rs.end(JSON.stringify({ error: { message: 'models/gemini-old is not found' } }));
        return;
      }
      const sys = JSON.stringify(j.systemInstruction || {});
      const text = sys.includes('整理長期記憶') ? '使用者每天早上喝咖啡' : '好的';
      rs.writeHead(200, { 'content-type': 'application/json' });
      rs.end(JSON.stringify({ candidates: [{ content: { parts: [{ text }] } }], usageMetadata: { promptTokenCount: 120, candidatesTokenCount: 30 } }));
    });
  });
  await new Promise((r) => fake.listen(0, '127.0.0.1', r));
  const fakeBase = `http://127.0.0.1:${fake.address().port}`;

  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'lifehub-v091-'));
  const OWNER = 'owner-v091@example.test';
  const { child, base } = await startServer(tmpDir, [], {
    REGISTRATION_OPEN: '', ADMIN_EMAIL: OWNER, GEMINI_API_KEY: 'fake-key', GEMINI_API_BASE: fakeBase, GEMINI_MODEL: 'gemini-test',
  });
  try {
    // ---- 邀請制 ----
    const owner = makeClient(base), fam = makeClient(base), stranger = makeClient(base), fam2 = makeClient(base);
    const first = await owner('POST', '/api/auth/register', { email: OWNER, password: 'owner-123', name: '爸爸' });
    const regState = await stranger('GET', '/api/auth/registration');
    const noInvite = await stranger('POST', '/api/auth/register', { email: 'stranger@example.test', password: 'stranger-1' });
    const badInvite = await stranger('POST', '/api/auth/register', { email: 'stranger@example.test', password: 'stranger-1', inviteCode: 'ZZZZZZZZ' });
    if (first.status === 200 && regState.json && regState.json.open === false && noInvite.status === 403 && badInvite.status === 403)
      ok('第一個帳號可以直接註冊；之後沒有邀請、或邀請碼錯誤都不能註冊');
    else fail(`邀請制不對：第一個=${first.status} open=${regState.json && regState.json.open} 無邀請=${noInvite.status} 錯的碼=${badInvite.status}`);

    const inv = await owner('POST', '/api/partner-link/invite');
    const code = inv.json && inv.json.code;
    const peek = await stranger('GET', `/api/auth/invite/${code}`);
    const reg = await fam('POST', '/api/auth/register', { email: 'mom@example.test', password: 'mom-1234', name: '媽媽', inviteCode: code.toLowerCase() });
    const links = await owner('GET', '/api/partner-link');
    const reuse = await fam2('POST', '/api/auth/register', { email: 'other@example.test', password: 'other-123', inviteCode: code });
    if (code && code.length === 8 && peek.json && peek.json.valid && peek.json.inviterName === '爸爸' && reg.status === 200 && reg.json.linkedWith === '爸爸'
        && links.json && links.json.links.some((l) => l.name === '媽媽') && reuse.status === 403)
      ok('邀請連結：看得到誰邀請、註冊後自動連結成家人、同一個邀請不能用第二次');
    else fail(`邀請連結流程不對：code=${code} peek=${JSON.stringify(peek.json)} reg=${reg.status} ${JSON.stringify(reg.json && reg.json.linkedWith)} reuse=${reuse.status}`);

    // ---- AI：只送最近 30 則、記憶摘要、用量紀錄 ----
    for (let i = 0; i < 25; i++) await owner('POST', '/api/assistant/chat', { message: `第 ${i + 1} 句：今天也喝了咖啡` });
    await new Promise((r) => setTimeout(r, 500)); // 記憶整理在回覆之後才跑
    await owner('POST', '/api/assistant/chat', { message: '我早上都喝什麼？' });
    const chatReqs = aiRequests.filter((j) => !JSON.stringify(j.systemInstruction || {}).includes('整理長期記憶'));
    const lastChat = chatReqs[chatReqs.length - 1] || {};
    const maxContents = Math.max(...chatReqs.map((j) => (j.contents || []).length));
    const info = await owner('GET', '/api/ai/info');
    const assistantMemory = ((info.json && info.json.memory) || []).find((m) => m.channel === 'assistant') || { items: [] };
    if (maxContents <= 30 && assistantMemory.items.length >= 1 && JSON.stringify(lastChat.systemInstruction || {}).includes('使用者每天早上喝咖啡'))
      ok(`AI 每次最多只看 30 則 (實際最多 ${maxContents})，更早的整理成記憶並帶進對話`);
    else fail(`AI 對話長度/記憶不對：最多 ${maxContents} 則，記憶 ${assistantMemory.items.length} 則，最後一次系統提示有沒有記憶：${JSON.stringify(lastChat.systemInstruction || {}).includes('喝咖啡')}`);

    const failed = await owner('POST', '/api/assistant/chat', { message: 'FAIL 測試' });
    const moodChat = await owner('POST', '/api/mood/chat', { message: '今天有點累' });
    if (moodChat.status === 200 && moodChat.json && moodChat.json.reply) ok('心靈對話改用共用記憶後正常回覆');
    else fail(`心靈對話失敗：${moodChat.status} ${moodChat.text.slice(0, 120)}`);
    const usage = await owner('GET', '/api/admin/ai-usage');
    const famUsage = await fam('GET', '/api/admin/ai-usage');
    const u = usage.json || { totals: {}, byFeature: [], recentErrors: [] };
    const features = u.byFeature.map((f) => f.feature);
    if (failed.status === 502 && u.totals.calls >= 27 && u.totals.inputTokens >= 120 * 26 && features.includes('assistant_chat') && features.includes('memory_summary') && features.includes('mood_chat')
        && u.recentErrors.some((e) => /404 .*not found/.test(e.error || '')) && famUsage.status === 403)
      ok(`AI 用量有記錄 (${u.totals.calls} 次、送出 ${u.totals.inputTokens} token)，看得到失敗原因；一般帳號看不到用量`);
    else fail(`AI 用量紀錄不對：${JSON.stringify({ calls: u.totals.calls, input: u.totals.inputTokens, features, errors: u.recentErrors, fam: famUsage.status })}`);

    const cleared = await owner('DELETE', '/api/ai/memory/assistant');
    await owner('POST', '/api/assistant/chat', { message: '清除後再聊一句' });
    await new Promise((r) => setTimeout(r, 300));
    const info2 = await owner('GET', '/api/ai/info');
    const mem2 = ((info2.json && info2.json.memory) || []).find((m) => m.channel === 'assistant') || { items: [1] };
    if (cleared.status === 200 && mem2.items.length === 0) ok('清除 AI 記憶後不會馬上又從舊對話長回來');
    else fail(`清除記憶不對：${cleared.status}，清除後還有 ${mem2.items.length} 則`);

    // ---- 常用功能 ----
    const ownerUsage = await owner('GET', '/api/tab-usage/mine');
    const famTabs = await fam('GET', '/api/tab-usage/mine');
    if (ownerUsage.json && ownerUsage.json.usedTabs.includes('assistant') && famTabs.json && !famTabs.json.usedTabs.includes('assistant'))
      ok('「常用」依自己有沒有資料判斷 (用過 AI 助理的人才算)');
    else fail(`usedTabs 不對：owner=${JSON.stringify(ownerUsage.json && ownerUsage.json.usedTabs)} fam=${JSON.stringify(famTabs.json && famTabs.json.usedTabs)}`);

    // ---- 只聽本機 ----
    const port = Number(new URL(base).port);
    const lan = Object.values(os.networkInterfaces()).flat().find((n) => n && n.family === 'IPv4' && !n.internal);
    if (!lan) warn('這台沒有對外網卡，略過「只聽本機」檢查');
    else {
      const reachable = await new Promise((resolve) => {
        const s = require('net').connect({ host: lan.address, port, timeout: 1500 }, () => { s.destroy(); resolve(true); });
        s.on('error', () => resolve(false));
        s.on('timeout', () => { s.destroy(); resolve(false); });
      });
      if (!reachable) ok(`伺服器只聽本機：從 ${lan.address} 連不進來`);
      else fail(`伺服器還聽在對外網卡 ${lan.address}`);
    }
  } finally {
    const exited = new Promise((r) => { if (child.exitCode != null) r(); else child.once('exit', r); });
    child.kill();
    await Promise.race([exited, new Promise((r) => setTimeout(r, 5000))]);
    fake.close();
    fs.rmSync(tmpDir, { recursive: true, force: true });
  }
}

async function checkSafeUpdate(rs, makeZipFn, publicKey, privateKey, otherPrivateKey) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'lifehub-su-'));
  const g = (cwd, ...args) => {
    const r = spawnSync('git', ['-c', 'user.email=smoke@test', '-c', 'user.name=smoke', '-c', 'init.defaultBranch=main', ...args], { cwd, encoding: 'utf8' });
    if (r.status !== 0) throw new Error(`git ${args.join(' ')}：${r.stderr}`);
    return r.stdout;
  };
  try {
    const origin = path.join(dir, 'origin.git'), work = path.join(dir, 'work'), vm = path.join(dir, 'vm');
    const keyFile = path.join(dir, 'release-public.pem');
    fs.writeFileSync(keyFile, publicKey.export({ type: 'spki', format: 'pem' }));
    g(dir, 'init', '--bare', origin);
    g(dir, 'clone', origin, work);
    const release = (version, extra = {}, key = privateKey, force = false) => {
      for (const f of fs.readdirSync(work)) if (/\.zip(\.sig)?$/.test(f)) fs.rmSync(path.join(work, f));
      const name = `lifehub-${version}.zip`;
      const zip = makeZipFn({ 'package.json': JSON.stringify({ version }), 'server.js': `// v${version}\n` });
      fs.writeFileSync(path.join(work, name), zip);
      fs.writeFileSync(path.join(work, name + '.sig'), JSON.stringify(rs.signRelease(zip, name, key)));
      for (const [f, c] of Object.entries(extra)) fs.writeFileSync(path.join(work, f), c);
      g(work, 'add', '-A'); g(work, 'commit', '-qm', `release ${version}`); g(work, 'push', '-q', ...(force ? ['-f'] : []), 'origin', 'HEAD:main');
    };
    fs.writeFileSync(path.join(work, 'package.json'), JSON.stringify({ version: '1.0.0' }));
    release('1.0.0', { 'server.js': '// v1.0.0\n' });
    g(dir, 'clone', '-q', origin, vm);
    const su = (...args) => spawnSync(process.execPath, [path.join(ROOT, 'scripts/safe-update.js'), '--repo', vm, '--key', keyFile, '--allow-inside-repo', ...args], { encoding: 'utf8' });
    const head = () => g(vm, 'rev-parse', 'HEAD').trim();

    release('1.1.0', { 'server.js': '// v1.1.0\n' });
    let r = su();
    if (r.status === 0 && fs.readFileSync(path.join(vm, 'server.js'), 'utf8').trim() === '// v1.1.0') ok('safe-update：簽章正確、server.js 跟 zip 一致 → 更新');
    else fail(`safe-update 沒有接受正常的更新：${r.stderr || r.stdout}`);

    let before = head();
    release('1.2.0', { 'server.js': '// 攻擊者改的\n' });
    r = su();
    if (r.status !== 0 && head() === before && /跟 zip 裡的版本不一樣/.test(r.stderr)) ok('safe-update：repo 裡的 server.js 被偷改 → 拒絕');
    else fail(`safe-update 沒擋下被偷改的 server.js：${r.stderr || r.stdout}`);

    release('1.3.0', { 'server.js': '// v1.3.0\n' }, otherPrivateKey);
    r = su();
    if (r.status !== 0 && head() === before && /簽章驗證失敗/.test(r.stderr)) ok('safe-update：別人簽的 zip → 拒絕');
    else fail(`safe-update 沒擋下別人簽的 zip：${r.stderr || r.stdout}`);

    release('1.0.5', { 'server.js': '// v1.0.5\n' });
    r = su();
    if (r.status !== 0 && head() === before && /拒絕降版/.test(r.stderr)) ok('safe-update：舊版 zip 重放 → 拒絕降版');
    else fail(`safe-update 沒擋下降版：${r.stderr || r.stdout}`);

    // 歷史被改寫 (force push)
    g(work, 'reset', '-q', '--hard', 'HEAD~4');
    release('1.4.0', { 'server.js': '// v1.4.0\n' }, privateKey, true);
    r = su();
    if (r.status !== 0 && head() === before && /歷史被改寫/.test(r.stderr)) ok('safe-update：force push 改寫歷史 → 拒絕');
    else fail(`safe-update 沒擋下 force push：${r.stderr || r.stdout}`);

    const r2 = spawnSync(process.execPath, [path.join(ROOT, 'scripts/safe-update.js'), '--repo', ROOT, '--key', keyFile], { encoding: 'utf8' });
    if (r2.status !== 0) ok('safe-update：放在 repo 裡面 / 公鑰位置不對時拒絕執行');
    else fail('safe-update 在 repo 裡面也照常執行');
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
}

(async () => {
  console.log(`LifeHub ${PKG.version} 發版前檢查 (Node ${process.version})`);
  checkSyntax();
  let tmpDir = null;
  try { tmpDir = await checkServer(); } catch (e) { fail(e.message); }
  if (tmpDir) { try { checkBackupVerify(tmpDir); } catch (e) { fail(`還原驗證檢查無法執行：${e.message}`); } }
  try { await checkTaipeiTime(); } catch (e) { fail(`台灣時間檢查無法執行：${e.message}`); }
  try { await checkSecurity(); } catch (e) { fail(`安全防護檢查無法執行：${e.message}`); }
  try { await checkV091(); } catch (e) { fail(`v0.91 檢查無法執行：${e.message}`); }
  console.log(`\n結果：${passed} 項通過、${failures.length} 項失敗、${warnings.length} 項警告`);
  if (failures.length) { console.log('\n失敗：'); failures.forEach((f) => console.log(`  - ${f.split('\n')[0]}`)); }
  if (tmpDir) fs.rmSync(tmpDir, { recursive: true, force: true });
  process.exit(failures.length ? 1 : 0);
})();
