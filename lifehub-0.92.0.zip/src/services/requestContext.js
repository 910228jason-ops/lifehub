// v0.91：每個 API 請求的「背景資訊」(誰、哪個路徑)，用 Node 內建的 AsyncLocalStorage 傳遞。
// 用途：AI 用量紀錄 (services/aiUsage.js) 要知道「這次 AI 呼叫是誰、從哪個功能來的」，
// 但呼叫 AI 的地方散在心情、塔羅、助理等好幾個檔案，與其每個呼叫端都多傳兩個參數，
// 不如由 mini-http 在處理請求時統一放進這裡，AI 服務自己取用。背景排程沒有請求，取到的是 undefined。
const { AsyncLocalStorage } = require('async_hooks');

const storage = new AsyncLocalStorage();

function run(ctx, fn) {
  return storage.run(ctx, fn);
}

function current() {
  return storage.getStore() || null;
}

module.exports = { run, current };
