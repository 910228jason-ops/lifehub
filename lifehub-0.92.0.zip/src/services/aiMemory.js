// v0.91：AI 對話的長期記憶 (AI 助理 + 心靈對話共用)。
//
// 原本每次聊天都把最近 300 則訊息整串送給 AI：越聊越慢、越耗 token，也一直重複送出很多私人內容。
// 現在改成：
//   - AI 只看最近 WINDOW (30) 則原文。
//   - 比 30 則更早、還沒整理過的訊息，累積到 MIN_GAP (10) 則以上，就在回覆送出之後 (不讓使用者等)
//     請 AI 把最舊的一批 (最多 CHUNK_MAX 則) 濃縮成 1-3 句重點，存在資料庫。
//   - 聊天時把最近 RECALL 筆重點附在系統提示裡，AI 就算看不到很久以前的原文，也還記得重點。
// 存在資料庫 (不是另外的檔案)：跟其他資料一起每天加密異地備份，使用者也能在「設定 → AI 與隱私」
// 查看、清除。心靈對話原本就有 mood_chat_memory (v0.40 左右)，這裡沿用同一張表並修掉兩個問題：
//   1. AI 回「無重要記憶點」時沒有存任何東西，下一次又會拿同一批去整理 (卡住)。現在存一筆空摘要往前推進。
//   2. 原本是「總筆數剛好是 40 的倍數」才整理，跟「AI 看得到的範圍」沒有對齊；現在只整理 AI 看不到的那段。
const logger = require('./logger');

const WINDOW = 30;
const MIN_GAP = 10;
const CHUNK_MAX = 40;
const RECALL = 6;

const ASSISTANT_SUMMARY_PROMPT = `你在幫「生活助理 AI」整理長期記憶。以下是使用者跟 AI 之間比較久以前的一段對話，
請把對未來繼續幫助這位使用者「真的有用」的重點濃縮成 1-3 句話 (例如：使用者的習慣與偏好、正在進行的計畫或待辦、
提過的重要日期或人、對 AI 回答方式的要求)。不要記錄密碼、金鑰、帳號、身分證字號、卡號這類敏感資訊，也不要摘要瑣碎閒聊。
如果整段沒有值得記住的重點，就回答「無重要記憶點」。請一律用繁體中文，只回傳摘要本身。`;

async function summarizeAssistantChunk(messages) {
  const transcript = messages.map((m) => `${m.role === 'user' ? '使用者' : 'AI'}: ${m.content}`).join('\n');
  return require('./assistant').chat(
    [{ role: 'user', content: `這是一段對話紀錄：\n${transcript}\n請幫我濃縮成重點摘要。` }],
    { systemPrompt: ASSISTANT_SUMMARY_PROMPT, feature: 'memory_summary' }
  );
}

const CHANNELS = {
  assistant: {
    messages: 'assistant_messages',
    memory: 'assistant_chat_memory',
    label: 'AI 助理',
    summarize: summarizeAssistantChunk,
  },
  mood: {
    messages: 'mood_chat_messages',
    memory: 'mood_chat_memory',
    label: '心靈對話',
    summarize: (chunk) => require('./mood').summarizeChatChunk(chunk),
  },
};

function channelOf(name) {
  const c = CHANNELS[name];
  if (!c) throw new Error(`未知的對話類型：${name}`);
  return c;
}

// AI 這次看得到的最近 WINDOW 則原文 (時間由舊到新)
function recentForAi(db, name, userId) {
  const c = channelOf(name);
  return db
    .prepare(`SELECT id, role, content, created_at FROM ${c.messages} WHERE user_id = ? ORDER BY id DESC LIMIT ?`)
    .all(userId, WINDOW)
    .reverse();
}

const running = new Set(); // 同一個人同一種對話同時只整理一次

async function maybeSummarize(db, name, userId) {
  const c = channelOf(name);
  const key = `${name}:${userId}`;
  if (running.has(key)) return null;
  running.add(key);
  try {
    // AI 看得到的範圍裡最舊的那一則；不到 WINDOW 則代表全部都看得到，不用整理
    const windowStart = db
      .prepare(`SELECT id FROM ${c.messages} WHERE user_id = ? ORDER BY id DESC LIMIT 1 OFFSET ?`)
      .get(userId, WINDOW - 1);
    if (!windowStart) return null;
    const last = db.prepare(`SELECT MAX(chunk_to_id) AS m FROM ${c.memory} WHERE user_id = ?`).get(userId);
    const afterId = (last && last.m) || 0;
    const gap = db
      .prepare(`SELECT id, role, content FROM ${c.messages} WHERE user_id = ? AND id > ? AND id < ? ORDER BY id ASC LIMIT ?`)
      .all(userId, afterId, windowStart.id, CHUNK_MAX);
    if (gap.length < MIN_GAP) return null;

    const result = await c.summarize(gap);
    if (!result || !result.isConfigured) return null; // 沒設定 AI：不往前推進，之後有 AI 再整理
    const reply = String(result.reply || '').trim();
    const summary = !reply || reply.includes('無重要記憶點') ? '' : reply.slice(0, 600);
    db.prepare(`INSERT INTO ${c.memory} (user_id, chunk_from_id, chunk_to_id, summary, created_at) VALUES (?, ?, ?, ?, ?)`).run(
      userId, gap[0].id, gap[gap.length - 1].id, summary, new Date().toISOString()
    );
    return summary;
  } catch (e) {
    logger.error('對話記憶摘要產生失敗', { channel: name, error: e.message });
    return null; // 不影響聊天本身
  } finally {
    running.delete(key);
  }
}

// 要附在系統提示裡的重點 (最近 RECALL 筆非空摘要)
function buildContext(db, name, userId) {
  const c = channelOf(name);
  const rows = db
    .prepare(`SELECT summary FROM ${c.memory} WHERE user_id = ? AND summary != '' ORDER BY id DESC LIMIT ?`)
    .all(userId, RECALL)
    .reverse();
  if (!rows.length) return null;
  return rows.map((r) => `- ${r.summary}`).join('\n');
}

// 給「設定 → AI 與隱私」顯示：每種對話目前記得的重點
function listAll(db, userId) {
  return Object.entries(CHANNELS).map(([name, c]) => ({
    channel: name,
    label: c.label,
    items: db
      .prepare(`SELECT id, summary, created_at FROM ${c.memory} WHERE user_id = ? AND summary != '' ORDER BY id DESC LIMIT 50`)
      .all(userId),
  }));
}

// 清除記憶：刪掉所有摘要，並留一筆「空摘要」標記到目前最新的訊息為止——
// 不然下次聊天時，還留在對話紀錄裡的舊訊息又會被重新整理成記憶，等於沒清。
function clear(db, name, userId) {
  const c = channelOf(name);
  const removed = db.prepare(`DELETE FROM ${c.memory} WHERE user_id = ? AND summary != ''`).run(userId).changes;
  const maxRow = db.prepare(`SELECT MAX(id) AS m FROM ${c.messages} WHERE user_id = ?`).get(userId);
  if (maxRow && maxRow.m) {
    db.prepare(`INSERT INTO ${c.memory} (user_id, chunk_from_id, chunk_to_id, summary, created_at) VALUES (?, 0, ?, '', ?)`).run(
      userId, maxRow.m, new Date().toISOString()
    );
  }
  return removed;
}

module.exports = { WINDOW, CHANNELS, recentForAi, maybeSummarize, buildContext, listAll, clear };
