// v0.91：AI 用量觀測。每次呼叫 AI 記一筆 ai_usage_log (只有數字與錯誤摘要，不存對話內容)，
// 管理者在「設定 → AI 與隱私」看得到這個月的用量、哪個功能用最多、最近的失敗原因。
//
// 異常提醒 (推播給管理者，一天各最多一次)：
//   - 今天 AI 失敗 >= 3 次 (例如模型被 Google 停用、金鑰失效、額度用完)
//   - 今天送出 + 回覆的 token 超過 AI_DAILY_TOKEN_ALERT (預設 500,000)
// 不設硬性上限 (使用者決定先觀測)，所以這裡只記錄、提醒，不會擋掉任何呼叫。
const { getDb } = require('./db');
const logger = require('./logger');
const { twToday, TW_OFFSET_MS } = require('./twtime');

// 路由 → 功能代號。新增會呼叫 AI 的路由時，在這裡加一行，管理者頁面才會顯示好懂的名稱。
const FEATURE_BY_ROUTE = {
  '/api/assistant/chat': 'assistant_chat',
  '/api/assistant/briefing': 'briefing',
  '/api/mood/chat': 'mood_chat',
  '/api/mood/weekly-review': 'mood_weekly',
  '/api/mood/monthly-review': 'mood_monthly',
  '/api/mood/patterns/refresh': 'mood_patterns',
  '/api/tarot/draws/:id/ai-reading': 'tarot',
};

const FEATURE_LABELS = {
  assistant_chat: 'AI 助理對話',
  briefing: '首頁摘要',
  mood_chat: '心靈對話',
  mood_weekly: '心情週回顧',
  mood_monthly: '心情月回顧',
  mood_patterns: '心情模式分析',
  mood_other: '心情其他',
  tarot: '塔羅解讀',
  memory_summary: '對話記憶整理',
  background: '背景排程',
  other: '其他',
};

function featureFor(route, explicit) {
  if (explicit) return explicit;
  if (!route) return 'background';
  if (FEATURE_BY_ROUTE[route]) return FEATURE_BY_ROUTE[route];
  if (route.startsWith('/api/mood')) return 'mood_other';
  return 'other';
}

const DAILY_TOKEN_ALERT = Number(process.env.AI_DAILY_TOKEN_ALERT || 500000);
const DAILY_FAIL_ALERT = 3;
const alerted = new Map(); // `${date}:${kind}` -> true (重開機後可能重複提醒一次，可接受)

// 台灣今天 00:00 對應的 UTC ISO 字串 (created_at 存的是 UTC)
function twDayStartIso(ymd = twToday()) {
  return new Date(Date.parse(ymd + 'T00:00:00Z') - TW_OFFSET_MS).toISOString();
}

function record(entry) {
  try {
    const db = getDb();
    db.prepare(
      `INSERT INTO ai_usage_log (user_id, feature, provider, model, input_tokens, output_tokens, duration_ms, ok, error, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      entry.userId || null, entry.feature, entry.provider, entry.model || null,
      entry.inputTokens == null ? null : entry.inputTokens,
      entry.outputTokens == null ? null : entry.outputTokens,
      entry.durationMs == null ? null : entry.durationMs,
      entry.ok ? 1 : 0, entry.error ? String(entry.error).slice(0, 300) : null,
      new Date().toISOString()
    );
    checkAlerts(db);
  } catch (e) {
    // 紀錄失敗不能影響 AI 功能本身 (例如 migration 還沒套用)
    logger.error('[aiUsage] 無法寫入 AI 用量紀錄', { message: e.message });
  }
}

function checkAlerts(db) {
  const today = twToday();
  const since = twDayStartIso(today);
  const row = db.prepare(
    `SELECT SUM(CASE WHEN ok = 0 THEN 1 ELSE 0 END) AS failed,
            COALESCE(SUM(COALESCE(input_tokens,0) + COALESCE(output_tokens,0)), 0) AS tokens
     FROM ai_usage_log WHERE created_at >= ?`
  ).get(since);
  const fire = (kind, title, body) => {
    const key = `${today}:${kind}`;
    if (alerted.has(key)) return;
    alerted.set(key, true);
    try {
      const adminId = require('./admin').adminUserId(db);
      if (!adminId) return;
      require('./notifyQueue').queueNotification(db, adminId, { title, body, icon: '/icons/icon-192.png', urgent: false });
      logger.info(`[aiUsage] 已提醒管理者：${title}`, {});
    } catch (e) { /* 推播失敗不影響 */ }
  };
  if ((row.failed || 0) >= DAILY_FAIL_ALERT) {
    const last = db.prepare('SELECT error FROM ai_usage_log WHERE ok = 0 AND created_at >= ? ORDER BY id DESC LIMIT 1').get(since);
    fire('fail', `AI 今天失敗 ${row.failed} 次`, `最近一次：${(last && last.error) || '未知錯誤'}。到「設定 → AI 與隱私」看詳情。`);
  }
  if (row.tokens > DAILY_TOKEN_ALERT) {
    fire('tokens', 'AI 今天用量偏高', `今天已用 ${Math.round(row.tokens / 1000)}k token (提醒門檻 ${Math.round(DAILY_TOKEN_ALERT / 1000)}k)。`);
  }
}

// 管理者報表
function report(db, days = 30) {
  const since = new Date(Date.now() - days * 86400000).toISOString();
  const totals = db.prepare(
    `SELECT COUNT(*) AS calls, SUM(CASE WHEN ok = 0 THEN 1 ELSE 0 END) AS failed,
            COALESCE(SUM(input_tokens),0) AS inputTokens, COALESCE(SUM(output_tokens),0) AS outputTokens,
            CAST(AVG(CASE WHEN ok = 1 THEN duration_ms END) AS INTEGER) AS avgMs
     FROM ai_usage_log WHERE created_at >= ?`
  ).get(since);
  const byFeature = db.prepare(
    `SELECT feature, COUNT(*) AS calls, SUM(CASE WHEN ok = 0 THEN 1 ELSE 0 END) AS failed,
            COALESCE(SUM(COALESCE(input_tokens,0) + COALESCE(output_tokens,0)),0) AS tokens
     FROM ai_usage_log WHERE created_at >= ? GROUP BY feature ORDER BY tokens DESC, calls DESC`
  ).all(since).map((r) => ({ ...r, label: FEATURE_LABELS[r.feature] || r.feature }));
  const byUser = db.prepare(
    `SELECT COALESCE(u.name, u.email, '背景排程') AS name, COUNT(*) AS calls,
            COALESCE(SUM(COALESCE(l.input_tokens,0) + COALESCE(l.output_tokens,0)),0) AS tokens
     FROM ai_usage_log l LEFT JOIN users u ON u.id = l.user_id
     WHERE l.created_at >= ? GROUP BY l.user_id ORDER BY tokens DESC LIMIT 10`
  ).all(since);
  const daily = db.prepare(
    `SELECT date(created_at, '+8 hours') AS date, COUNT(*) AS calls, SUM(CASE WHEN ok = 0 THEN 1 ELSE 0 END) AS failed,
            COALESCE(SUM(COALESCE(input_tokens,0) + COALESCE(output_tokens,0)),0) AS tokens
     FROM ai_usage_log WHERE created_at >= ? GROUP BY date ORDER BY date ASC`
  ).all(since);
  const recentErrors = db.prepare(
    'SELECT created_at, feature, error FROM ai_usage_log WHERE ok = 0 ORDER BY id DESC LIMIT 5'
  ).all().map((r) => ({ ...r, label: FEATURE_LABELS[r.feature] || r.feature }));
  const today = db.prepare(
    `SELECT COUNT(*) AS calls, SUM(CASE WHEN ok = 0 THEN 1 ELSE 0 END) AS failed,
            COALESCE(SUM(COALESCE(input_tokens,0) + COALESCE(output_tokens,0)),0) AS tokens
     FROM ai_usage_log WHERE created_at >= ?`
  ).get(twDayStartIso());
  return {
    days, totals: { ...totals, failed: totals.failed || 0 }, today: { ...today, failed: today.failed || 0 },
    byFeature, byUser, daily, recentErrors,
    alertTokenThreshold: DAILY_TOKEN_ALERT,
  };
}

module.exports = { record, report, featureFor, FEATURE_LABELS };
