// v0.91：家人邀請 (邀請連結註冊 + 自動連結)。邀請碼沿用 v0.33 的 partner_link_invites：
// 24 小時有效、只能用一次。
//
// 註冊規則：
//   - 資料庫裡還沒有任何帳號 (第一次架站) → 開放註冊，第一個帳號就是建立者。
//   - 環境變數 REGISTRATION_OPEN=1 → 開放註冊 (之後真的要公開時用)。
//   - 其他情況 → 一定要帶有效的邀請碼才能註冊；註冊成功後自動跟邀請人連結成家人。
// 背景：家庭用 App 原本任何知道網址的人都能註冊，v0.90.1 修掉的管理者冒用漏洞就是靠這個進來的。
const crypto = require('crypto');

// 8 碼，避開容易看錯的 0/O、1/I/L (原本 6 碼十六進位)
const CODE_ALPHABET = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
function generateCode() {
  let s = '';
  for (let i = 0; i < 8; i++) s += CODE_ALPHABET[crypto.randomInt(CODE_ALPHABET.length)];
  return s;
}

function normalizeCode(code) {
  return String(code || '').trim().toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 16);
}

function registrationOpen(db) {
  if (process.env.REGISTRATION_OPEN === '1') return true;
  const row = db.prepare('SELECT COUNT(*) AS c FROM users').get();
  return !row || row.c === 0;
}

// 回傳 { invite, inviterName } 或 { error }
function findValidInvite(db, code) {
  const c = normalizeCode(code);
  if (!c) return { error: '缺少邀請碼' };
  const invite = db.prepare('SELECT * FROM partner_link_invites WHERE code = ?').get(c);
  if (!invite) return { error: '找不到這個邀請，請確認連結是否完整' };
  if (invite.used_by_user_id) return { error: '這個邀請已經被使用過了，請家人重新產生一個' };
  if (new Date(invite.expires_at).getTime() < Date.now()) return { error: '這個邀請已經過期，請家人重新產生一個' };
  const inviter = db.prepare('SELECT name, email FROM users WHERE id = ?').get(invite.inviter_user_id);
  if (!inviter) return { error: '邀請人的帳號已不存在' };
  return { invite, inviterName: inviter.name || String(inviter.email).split('@')[0] };
}

// 標記邀請已使用 (用條件更新避免同一個碼被兩個人同時用掉)，並建立家人連結
function consumeInviteAndLink(db, invite, userId) {
  const now = new Date().toISOString();
  const r = db.prepare('UPDATE partner_link_invites SET used_by_user_id = ?, used_at = ? WHERE id = ? AND used_by_user_id IS NULL').run(userId, now, invite.id);
  if (!r.changes) return false;
  const a = Math.min(invite.inviter_user_id, userId);
  const b = Math.max(invite.inviter_user_id, userId);
  const existing = db.prepare('SELECT id FROM partner_links WHERE user_a_id = ? AND user_b_id = ?').get(a, b);
  if (!existing) db.prepare('INSERT INTO partner_links (user_a_id, user_b_id, created_at) VALUES (?, ?, ?)').run(a, b, now);
  return true;
}

module.exports = { generateCode, normalizeCode, registrationOpen, findValidInvite, consumeInviteAndLink };
