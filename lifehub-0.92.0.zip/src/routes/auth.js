const { Router } = require('../mini-http');
const { hashPassword, verifyPassword, generateRecoveryCode } = require('../services/passwords');
const { getDb } = require('../services/db');
const logger = require('../services/logger');
const { isAdminUser, normalizeEmail } = require('../services/admin');
const { requireAuth } = require('../middleware/auth');
const sec = require('../services/sessionSecurity');
const familyInvite = require('../services/familyInvite');

const router = Router();

function tooManyAttempts(res, minutes) {
  return res.status(429).json({ error: `嘗試太多次了，請 ${minutes} 分鐘後再試` });
}

// v0.90.1：email 一律「去頭尾空白 + 轉小寫」後再存、再比對。原本註冊檢查重複時分大小寫，
// `910228Jason@gmail.com` 會被當成新帳號，搭配舊的管理者判斷就能冒充管理者。
// 舊資料庫裡可能已經有大小寫不同的重複帳號 (改版前註冊的)，所以查詢用 lower(trim(email))，
// 登入時如果對到好幾個帳號，用「密碼對得上的那一個」(依建立順序)。
function findUsersByEmail(db, email) {
  const e = normalizeEmail(email);
  if (!e) return [];
  return db.prepare('SELECT * FROM users WHERE lower(trim(email)) = ? ORDER BY id ASC').all(e);
}

// 資料庫層的保險：不分大小寫的 email 唯一索引。舊資料裡已經有重複時建不起來，不能讓它擋住開機，
// 只記一筆警告 (程式層的重複檢查照樣有效)。
try {
  getDb().exec('CREATE UNIQUE INDEX IF NOT EXISTS idx_users_email_normalized ON users (lower(trim(email)))');
} catch (e) {
  logger.error('[auth] 無法建立不分大小寫的 email 唯一索引 (資料庫裡已經有大小寫不同的重複 email)，請管理者檢查', { message: e.message });
}

// v0.91：登入畫面要知道「現在能不能直接註冊」(只有第一次架站、或設了 REGISTRATION_OPEN=1 才能)
router.get('/registration', (req, res) => {
  res.json({ open: familyInvite.registrationOpen(getDb()) });
});

// v0.91：打開邀請連結時，顯示「誰邀請你」。不需要登入；查不到也算嘗試次數，避免被拿來列舉邀請碼。
router.get('/invite/:code', (req, res) => {
  const wait = sec.checkAttemptAllowed('invite', req, null);
  if (wait) return tooManyAttempts(res, wait);
  const found = familyInvite.findValidInvite(getDb(), req.params.code);
  if (found.error) {
    sec.recordFailure('invite', req, null);
    return res.json({ valid: false, reason: found.error });
  }
  res.json({ valid: true, inviterName: found.inviterName, expiresAt: found.invite.expires_at });
});

router.post('/register', (req, res) => {
  const { password, name } = req.body || {};
  const email = normalizeEmail((req.body || {}).email);
  if (!email || !password) return res.status(400).json({ error: '請輸入 email 與密碼' });
  if (email.length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ error: 'email 格式不正確' });
  if (String(password).length < 6) return res.status(400).json({ error: '密碼至少需 6 碼' });

  const db = getDb();
  // v0.91：只開放受邀的家人註冊 (規則見 services/familyInvite.js)。邀請碼猜錯也算嘗試次數，避免被拿來亂猜。
  let invite = null;
  if (!familyInvite.registrationOpen(db) || (req.body && req.body.inviteCode)) {
    const wait = sec.checkAttemptAllowed('invite', req, null);
    if (wait) return tooManyAttempts(res, wait);
    const found = familyInvite.findValidInvite(db, req.body && req.body.inviteCode);
    if (found.error) {
      sec.recordFailure('invite', req, null);
      const closed = !(req.body && req.body.inviteCode);
      return res.status(403).json({ error: closed ? 'LifeHub 只開放家人使用。要建立帳號，請向家人索取邀請連結。' : found.error, inviteRequired: true });
    }
    invite = found.invite;
  }
  if (findUsersByEmail(db, email).length) return res.status(409).json({ error: '此 email 已被註冊' });

  const hash = hashPassword(password);
  // 這個專案沒有接寄信服務，忘記密碼時沒辦法「寄重設連結到信箱」，改用這組只顯示這一次的
  // 備用重設碼——存的是雜湊值，明碼只在這次註冊回應裡出現一次，前端要提醒使用者截圖/記下來。
  const recoveryCode = generateRecoveryCode();
  const recoveryCodeHash = hashPassword(recoveryCode);
  const now = new Date().toISOString();
  const info = db
    .prepare('INSERT INTO users (email, password_hash, name, created_at, recovery_code_hash) VALUES (?, ?, ?, ?, ?)')
    .run(email, hash, name || email.split('@')[0], now, recoveryCodeHash);

  // 新帳號的深色模式偏好預設用「自動 (跟系統)」，比固定寫死淺色更貼近使用者第一次打開的體感；
  // 這個更新之前就存在的舊帳號會維持資料庫欄位原本的 'light' 預設值，不會被這裡影響。
  db.prepare('INSERT INTO user_prefs (user_id, theme) VALUES (?, ?)').run(info.lastInsertRowid, 'auto');

  // 用邀請連結註冊：自動跟邀請人連結成家人。剛好被別人同時用掉的話，帳號照樣建立，只是不會自動連結。
  let linkedWith = null;
  if (invite && familyInvite.consumeInviteAndLink(db, invite, info.lastInsertRowid)) {
    const inviter = db.prepare('SELECT name, email FROM users WHERE id = ?').get(invite.inviter_user_id);
    linkedWith = inviter ? inviter.name || String(inviter.email).split('@')[0] : null;
  }

  req.session.userId = info.lastInsertRowid;
  req.session.epoch = 0;
  logger.info('新使用者註冊', { userId: info.lastInsertRowid, viaInvite: !!invite });
  res.json({
    id: info.lastInsertRowid,
    email,
    name: name || email.split('@')[0],
    isAdmin: isAdminUser(db, info.lastInsertRowid),
    recoveryCode,
    linkedWith,
  });
});

router.post('/login', (req, res) => {
  const { password } = req.body || {};
  const email = normalizeEmail((req.body || {}).email);
  // v0.90：同一個 email / IP 短時間內猜錯太多次就暫停，避免被拿去一直猜密碼
  const wait = sec.checkAttemptAllowed('login', req, email);
  if (wait) return tooManyAttempts(res, wait);
  const db = getDb();
  const user = findUsersByEmail(db, email).find((u) => verifyPassword(password || '', u.password_hash));
  if (!user) {
    sec.recordFailure('login', req, email);
    return res.status(401).json({ error: 'email 或密碼錯誤' });
  }
  sec.clearFailures('login', email);
  req.session.userId = user.id;
  req.session.epoch = user.session_epoch || 0;
  // v0.63：記錄「上次登入時間」，之前這個系統完全沒有追蹤過這件事，有人問「最近誰開過這個
  // App」都答不出來。用 try/catch 包起來——寫入失敗 (例如 migration 還沒套用) 也不該擋掉
  // 正常登入流程。
  try {
    const now = new Date().toISOString();
    db.prepare('UPDATE users SET last_login_at = ? WHERE id = ?').run(now, user.id);
    // v0.64：額外記一筆登入事件 (只存 user_id + 時間)，last_login_at 只留得住「最後一次」，
    // 沒辦法回答「上週/上上週有幾個人在用」這種隨時間變化的問題，管理者儀表板要靠這張表算。
    db.prepare('INSERT INTO login_events (user_id, created_at) VALUES (?, ?)').run(user.id, now);
  } catch (e) { /* ignore */ }
  res.json({ id: user.id, email: user.email, name: user.name, isAdmin: isAdminUser(db, user.id) });
});

router.post('/logout', (req, res) => {
  req.session = null;
  res.json({ ok: true });
});

router.get('/me', (req, res) => {
  if (!req.session || !req.session.userId) return res.json({ user: null });
  const db = getDb();
  const user = db.prepare('SELECT id, email, name FROM users WHERE id = ?').get(req.session.userId);
  if (!user) return res.json({ user: null });
  res.json({ user: { ...user, isAdmin: isAdminUser(db, user.id) } });
});

// 忘記密碼：email + 備用重設碼 + 新密碼，三個都對才能重設。
// 用跟登入錯誤一樣的錯誤訊息 (不特別說「email 不存在」還是「重設碼錯誤」)，避免被拿來
// 反查哪些 email 有註冊過。成功重設後，這組重設碼就失效 (改成 null)，逼使用者登入後
// 再去設定頁重新產生一組新的——避免重設碼被看過一次之後可以無限次重複使用。
router.post('/forgot-password', (req, res) => {
  const { recoveryCode, newPassword } = req.body || {};
  const email = normalizeEmail((req.body || {}).email);
  if (!email || !recoveryCode || !newPassword) {
    return res.status(400).json({ error: '請填寫 email、備用重設碼與新密碼' });
  }
  if (String(newPassword).length < 6) return res.status(400).json({ error: '新密碼至少需 6 碼' });

  const wait = sec.checkAttemptAllowed('recovery', req, email);
  if (wait) return tooManyAttempts(res, wait);
  const db = getDb();
  const user = findUsersByEmail(db, email).find((u) => verifyPassword(String(recoveryCode).trim(), u.recovery_code_hash));
  if (!user) {
    sec.recordFailure('recovery', req, email);
    return res.status(401).json({ error: 'email 或備用重設碼不正確' });
  }
  sec.clearFailures('recovery', email);

  db.prepare('UPDATE users SET password_hash = ?, recovery_code_hash = NULL WHERE id = ?').run(
    hashPassword(newPassword),
    user.id
  );
  // v0.90：重設密碼代表「可能有人知道舊密碼」，所有裝置上的舊登入一起作廢
  try { sec.bumpEpoch(db, user.id); } catch (e) { /* migration 未套用時忽略 */ }
  logger.info('使用者用備用重設碼重設密碼', { userId: user.id });
  res.json({ ok: true });
});

// v0.90：登出所有其他裝置。手機掉了、或懷疑電腦中毒被偷 cookie 時用：所有已發出的登入 cookie
// 失效，只有「現在按這個按鈕的這台」繼續保持登入。
router.post('/logout-all', requireAuth, (req, res) => {
  const db = getDb();
  const epoch = sec.bumpEpoch(db, req.session.userId);
  req.session.epoch = epoch;
  logger.info('使用者登出所有其他裝置', { userId: req.session.userId });
  res.json({ ok: true });
});

// 重新產生備用重設碼：給已經登入的使用者用 (包含「這次更新之前就註冊過、還沒有重設碼」的舊帳號)。
// 舊碼會直接被新碼取代，明碼只在這次回應出現一次。
router.post('/recovery-code', requireAuth, (req, res) => {
  const db = getDb();
  const recoveryCode = generateRecoveryCode();
  db.prepare('UPDATE users SET recovery_code_hash = ? WHERE id = ?').run(hashPassword(recoveryCode), req.session.userId);
  res.json({ recoveryCode });
});

module.exports = router;
