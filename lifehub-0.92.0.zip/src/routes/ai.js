// v0.91：AI 與隱私 (/api/ai/*) + 管理者 AI 用量 (/api/admin/ai-usage)。
// 路由由 src/routes/debug.js 併進 /api (不動 server.js)。
const { Router } = require('../mini-http');
const { getDb } = require('../services/db');
const { requireAuth } = require('../middleware/auth');
const { isAdminUser } = require('../services/admin');
const aiMemory = require('../services/aiMemory');
const aiUsage = require('../services/aiUsage');

const router = Router();

// 設定頁「AI 與隱私」：目前用哪家 AI、AI 記得的重點
router.get('/ai/info', requireAuth, (req, res) => {
  const db = getDb();
  const provider = process.env.GEMINI_API_KEY ? 'gemini' : process.env.ANTHROPIC_API_KEY ? 'anthropic' : null;
  res.json({
    provider,
    memory: aiMemory.listAll(db, req.session.userId),
    windowSize: aiMemory.WINDOW,
    isAdmin: isAdminUser(db, req.session.userId),
  });
});

router.delete('/ai/memory/:channel', requireAuth, (req, res) => {
  if (!aiMemory.CHANNELS[req.params.channel]) return res.status(400).json({ error: '未知的對話類型' });
  const removed = aiMemory.clear(getDb(), req.params.channel, req.session.userId);
  res.json({ ok: true, removed });
});

// 管理者：AI 用量 (預設最近 30 天)
router.get('/admin/ai-usage', requireAuth, (req, res) => {
  const db = getDb();
  if (!isAdminUser(db, req.session.userId)) return res.status(403).json({ error: '沒有權限查看' });
  const days = Math.min(Math.max(Number(req.query.days) || 30, 1), 90);
  res.json(aiUsage.report(db, days));
});

module.exports = router;
