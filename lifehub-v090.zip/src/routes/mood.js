const { Router } = require('../mini-http');
const { getDb } = require('../services/db');
const { requireAuth } = require('../middleware/auth');
const mood = require('../services/mood');
const techniques = require('../services/moodTechniques');
const patterns = require('../services/moodPatterns');
const logger = require('../services/logger');

const router = Router();

// 對話記錄一樣要用「最近 N 則」的邏輯，跟 assistant.js 同一套修法：
// 先用 id DESC 撈最新的 N 筆，再用 JS reverse() 還原時間順序，
// 避免對話一旦超過上限，AI 就卡在很久以前的內容 (先前版本的 bug)。
const MAX_CHAT_HISTORY = 300;

function fetchRecentChatHistory(db, userId, limit) {
  const rows = db
    .prepare('SELECT role, content, created_at FROM mood_chat_messages WHERE user_id = ? ORDER BY id DESC LIMIT ?')
    .all(userId, limit);
  return rows.reverse();
}

function todayStr() {
  return new Date().toISOString().slice(0, 10);
}

// ---------- 每日心情紀錄 ----------

router.get('/entries', requireAuth, (req, res) => {
  const db = getDb();
  const { from, to } = req.query;
  let rows;
  if (from && to) {
    rows = db
      .prepare('SELECT * FROM mood_entries WHERE user_id = ? AND entry_date BETWEEN ? AND ? ORDER BY entry_date ASC')
      .all(req.session.userId, from, to);
  } else {
    rows = db
      .prepare('SELECT * FROM mood_entries WHERE user_id = ? ORDER BY entry_date DESC LIMIT 60')
      .all(req.session.userId);
  }
  res.json(rows);
});

// 用日期當 key 做 upsert：同一天重複記錄會直接更新，而不是新增多筆。
router.put('/entries/:date', requireAuth, (req, res) => {
  const { date } = req.params;
  const { score, tags, note } = req.body || {};
  const scoreNum = Number(score);
  if (!date || !Number.isInteger(scoreNum) || scoreNum < 1 || scoreNum > 10) {
    return res.status(400).json({ error: '請提供有效的日期與 1-10 的心情分數' });
  }
  const db = getDb();
  const now = new Date().toISOString();
  const tagsStr = Array.isArray(tags) ? tags.join(',') : (tags || null);
  db.prepare(
    `INSERT INTO mood_entries (user_id, entry_date, score, tags, note, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?)
     ON CONFLICT(user_id, entry_date) DO UPDATE SET score = excluded.score, tags = excluded.tags, note = excluded.note, updated_at = excluded.updated_at`
  ).run(req.session.userId, date, scoreNum, tagsStr, note || null, now, now);
  res.json({ ok: true });
});

router.get('/summary', requireAuth, (req, res) => {
  const db = getDb();
  const { days } = req.query;
  const n = Math.min(Math.max(Number(days) || 30, 1), 180);
  const since = new Date();
  since.setDate(since.getDate() - n);
  const sinceStr = since.toISOString().slice(0, 10);

  const rows = db
    .prepare('SELECT entry_date, score, tags FROM mood_entries WHERE user_id = ? AND entry_date >= ? ORDER BY entry_date ASC')
    .all(req.session.userId, sinceStr);

  const avg = rows.length ? rows.reduce((s, r) => s + r.score, 0) / rows.length : null;
  const tagCounts = {};
  rows.forEach((r) => {
    (r.tags || '').split(',').filter(Boolean).forEach((t) => { tagCounts[t] = (tagCounts[t] || 0) + 1; });
  });
  const topTags = Object.entries(tagCounts).sort((a, b) => b[1] - a[1]).slice(0, 5).map(([tag, count]) => ({ tag, count }));

  // ---- 主動關心訊號 ----
  // 1) gapDays：距離「上一次」有紀錄的日子過了幾天，太久沒紀錄就溫和提醒一下 (不是責備)。
  // 2) needsCare：最近連續幾筆分數偏低時，主動給一句關心的話，而不是等使用者自己來找 AI。
  const lastEntry = db
    .prepare('SELECT entry_date FROM mood_entries WHERE user_id = ? ORDER BY entry_date DESC LIMIT 1')
    .get(req.session.userId);
  let gapDays = null;
  if (lastEntry) {
    const last = new Date(lastEntry.entry_date + 'T00:00:00Z');
    const now = new Date(todayStr() + 'T00:00:00Z');
    gapDays = Math.round((now - last) / (1000 * 60 * 60 * 24));
  }

  const recentScores = rows.slice(-3).map((r) => r.score);
  const recentAvg = recentScores.length ? recentScores.reduce((s, v) => s + v, 0) / recentScores.length : null;
  let needsCare = false;
  let careMessage = null;
  if (recentScores.length >= 2 && recentAvg != null && recentAvg <= 4) {
    needsCare = true;
    careMessage = '這幾天感覺你過得比較辛苦，要不要來這裡聊聊？不用勉強，我在這裡。';
  } else if (gapDays != null && gapDays >= 5) {
    careMessage = `已經 ${gapDays} 天沒有記錄心情了，最近還好嗎？有空的話回來寫一筆吧。`;
  }

  res.json({
    series: rows,
    average: avg != null ? Math.round(avg * 10) / 10 : null,
    topTags,
    count: rows.length,
    gapDays,
    needsCare,
    careMessage,
  });
});

// ---------- 心情 × 行事曆 洞察 ----------
// 粗略比對「當天行事曆事項數量」跟「當天心情分數」的關係，
// 給一句自然語言的觀察 (不是嚴謹統計，只是給使用者一個參考角度)。
router.get('/insights', requireAuth, (req, res) => {
  const db = getDb();
  const since = new Date();
  since.setDate(since.getDate() - 30);
  const sinceStr = since.toISOString().slice(0, 10);

  const moodRows = db
    .prepare('SELECT entry_date, score FROM mood_entries WHERE user_id = ? AND entry_date >= ?')
    .all(req.session.userId, sinceStr);

  if (moodRows.length < 5) {
    return res.json({ available: false, message: '心情紀錄還太少，再多記幾天，這裡會幫你看看跟行程的關聯。' });
  }

  const eventRows = db
    .prepare('SELECT event_date, COUNT(*) as cnt FROM calendar_events WHERE user_id = ? AND event_date >= ? GROUP BY event_date')
    .all(req.session.userId, sinceStr);
  const eventCountByDate = {};
  eventRows.forEach((r) => { eventCountByDate[r.event_date] = r.cnt; });

  const BUSY_THRESHOLD = 3;
  const busyScores = [];
  const calmScores = [];
  moodRows.forEach((r) => {
    const cnt = eventCountByDate[r.entry_date] || 0;
    if (cnt >= BUSY_THRESHOLD) busyScores.push(r.score);
    else calmScores.push(r.score);
  });

  if (!busyScores.length || !calmScores.length) {
    return res.json({ available: false, message: '再累積一些不同忙碌程度的日子，這裡會幫你看看跟行程的關聯。' });
  }

  const avgBusy = Math.round((busyScores.reduce((s, v) => s + v, 0) / busyScores.length) * 10) / 10;
  const avgCalm = Math.round((calmScores.reduce((s, v) => s + v, 0) / calmScores.length) * 10) / 10;
  const diff = Math.round((avgCalm - avgBusy) * 10) / 10;

  let message;
  if (diff >= 1) {
    message = `行程比較滿的日子 (當天 ${BUSY_THRESHOLD} 件事以上)，平均心情分數是 ${avgBusy} 分；行程比較鬆的日子平均是 ${avgCalm} 分。忙碌的日子心情容易比較低，排行程時可以留一點喘息空間給自己。`;
  } else if (diff <= -1) {
    message = `有趣的是，行程比較滿的日子平均心情反而是 ${avgBusy} 分，比較鬆的日子是 ${avgCalm} 分——對你來說，充實地忙可能反而是件好事。`;
  } else {
    message = `行程忙碌程度 (忙碌日平均 ${avgBusy} 分／較鬆日平均 ${avgCalm} 分) 跟你的心情分數目前看起來沒有明顯關聯，心情可能更多受其他事情影響。`;
  }

  res.json({ available: true, avgBusy, avgCalm, busyDays: busyScores.length, calmDays: calmScores.length, message });
});

// ---------- 這週 AI 回顧 ----------

router.post('/weekly-review', requireAuth, async (req, res) => {
  const db = getDb();
  const since = new Date();
  since.setDate(since.getDate() - 7);
  const sinceStr = since.toISOString().slice(0, 10);
  const entries = db
    .prepare('SELECT entry_date, score, tags, note FROM mood_entries WHERE user_id = ? AND entry_date >= ? ORDER BY entry_date ASC')
    .all(req.session.userId, sinceStr);

  try {
    const result = await mood.generateWeeklyReview(entries);
    res.json(result);
  } catch (e) {
    logger.error('心情週回顧產生失敗', { error: e.message });
    res.status(502).json({ error: '這週回顧暫時無法產生，請稍後再試', detail: e.message });
  }
});

// ---------- 這個月 AI 回顧 ----------

router.post('/monthly-review', requireAuth, async (req, res) => {
  const db = getDb();
  const month = (req.body && req.body.month) || todayStr().slice(0, 7); // YYYY-MM
  const entries = db
    .prepare("SELECT entry_date, score, tags, note FROM mood_entries WHERE user_id = ? AND entry_date LIKE ? ORDER BY entry_date ASC")
    .all(req.session.userId, `${month}%`);

  try {
    const result = await mood.generateMonthlyReview(entries, month);
    res.json({ month, ...result });
  } catch (e) {
    logger.error('心情月回顧產生失敗', { error: e.message });
    res.status(502).json({ error: '這個月的回顧暫時無法產生，請稍後再試', detail: e.message });
  }
});

// ---------- 會學習的因應技巧庫 ----------

router.get('/techniques/suggest', requireAuth, (req, res) => {
  const { tag } = req.query;
  if (!tag) return res.status(400).json({ error: '請提供 tag' });
  const db = getDb();
  const technique = techniques.pickTechnique(db, req.session.userId, tag);
  res.json({ tag, technique });
});

router.post('/techniques/feedback', requireAuth, (req, res) => {
  const { tag, techniqueKey, helped } = req.body || {};
  if (!tag || !techniqueKey || typeof helped !== 'boolean') {
    return res.status(400).json({ error: '請提供 tag、techniqueKey、helped' });
  }
  const db = getDb();
  db.prepare('INSERT INTO mood_technique_feedback (user_id, tag, technique_key, helped, created_at) VALUES (?, ?, ?, ?, ?)').run(
    req.session.userId,
    tag,
    techniqueKey,
    helped ? 1 : 0,
    new Date().toISOString()
  );
  res.json({ ok: true });
});

// ---------- CBT 式思考記錄 ----------
// 定位提醒：這是自助認知練習輔助工具，不是心理治療或診斷；AI 的建議只是「一個可能的角度」，
// 使用者永遠可以不採用、自己寫 reframe。

router.get('/thought-records', requireAuth, (req, res) => {
  const db = getDb();
  const rows = db
    .prepare('SELECT id, situation, thought, emotion, intensity, evidence_for, evidence_against, reframe, created_at FROM mood_thought_records WHERE user_id = ? ORDER BY id DESC')
    .all(req.session.userId);
  res.json(rows);
});

router.post('/thought-records', requireAuth, (req, res) => {
  const { situation, thought, emotion, intensity, evidenceFor, evidenceAgainst, reframe } = req.body || {};
  if (!thought || !String(thought).trim()) {
    return res.status(400).json({ error: '請至少填寫「腦中出現的念頭」' });
  }
  const intensityNum = intensity != null && intensity !== '' ? Number(intensity) : null;
  if (intensityNum != null && (!Number.isInteger(intensityNum) || intensityNum < 1 || intensityNum > 10)) {
    return res.status(400).json({ error: '情緒強度請填 1-10 的整數' });
  }
  const db = getDb();
  const now = new Date().toISOString();
  const result = db
    .prepare(
      `INSERT INTO mood_thought_records (user_id, situation, thought, emotion, intensity, evidence_for, evidence_against, reframe, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
    )
    .run(req.session.userId, situation || null, String(thought).trim(), emotion || null, intensityNum, evidenceFor || null, evidenceAgainst || null, reframe || null, now);
  res.json({ id: result.lastInsertRowid, ok: true });
});

router.delete('/thought-records/:id', requireAuth, (req, res) => {
  const db = getDb();
  db.prepare('DELETE FROM mood_thought_records WHERE id = ? AND user_id = ?').run(req.params.id, req.session.userId);
  res.json({ ok: true });
});

router.post('/thought-records/reframe-suggest', requireAuth, async (req, res) => {
  const { situation, thought, evidenceFor, evidenceAgainst } = req.body || {};
  if (!thought || !String(thought).trim()) {
    return res.status(400).json({ error: '請先填寫「腦中出現的念頭」' });
  }
  try {
    const result = await mood.suggestReframe({ situation, thought, evidenceFor, evidenceAgainst });
    res.json(result);
  } catch (e) {
    logger.error('reframe 建議產生失敗', { error: e.message });
    res.status(502).json({ error: '建議暫時無法產生，請稍後再試，或直接自己寫下你的想法', detail: e.message });
  }
});

// ---------- 跨模塊深層模式識別 ----------
// 不是每次開頁面就重算 (需要一定資料量才有意義、也比較省 AI 成本)，而是存快取，
// 由使用者手動點「重新分析」或前端在快取太舊時才觸發重算。

router.get('/patterns', requireAuth, (req, res) => {
  const db = getDb();
  const row = db
    .prepare('SELECT signals_json, insights, generated_at FROM mood_patterns WHERE user_id = ? ORDER BY id DESC LIMIT 1')
    .get(req.session.userId);
  if (!row) {
    return res.json({ available: false, generated: false, message: '還沒有分析過，點「重新分析」讓 AI 幫你看看資料裡有沒有規律。' });
  }
  res.json({ available: true, generated: true, insights: row.insights, signals: JSON.parse(row.signals_json), generatedAt: row.generated_at });
});

router.post('/patterns/refresh', requireAuth, async (req, res) => {
  const db = getDb();
  const since = new Date();
  since.setDate(since.getDate() - 90);
  const sinceStr = since.toISOString().slice(0, 10);

  const totalCount = db
    .prepare('SELECT COUNT(*) as c FROM mood_entries WHERE user_id = ? AND entry_date >= ?')
    .get(req.session.userId, sinceStr).c;

  if (totalCount < patterns.MIN_MOOD_ENTRIES) {
    return res.json({ available: false, generated: false, message: `心情紀錄還太少 (目前 ${totalCount} 筆，建議累積到至少 ${patterns.MIN_MOOD_ENTRIES} 筆)，再多記錄一陣子，這裡會幫你找出屬於你自己的模式。` });
  }

  try {
    const features = patterns.buildDailyFeatures(db, req.session.userId, sinceStr);
    const signals = patterns.computeSignals(features);
    const result = await patterns.generatePatternInsights(signals);
    const now = new Date().toISOString();
    db.prepare('INSERT INTO mood_patterns (user_id, signals_json, insights, generated_at) VALUES (?, ?, ?, ?)').run(
      req.session.userId,
      JSON.stringify(signals),
      result.reply,
      now
    );
    res.json({ available: true, generated: true, insights: result.reply, signals, generatedAt: now });
  } catch (e) {
    logger.error('跨模塊模式分析失敗', { error: e.message });
    res.status(502).json({ error: '分析暫時無法完成，請稍後再試', detail: e.message });
  }
});

// ---------- 安心小卡 (coping notes) ----------

router.get('/coping-notes', requireAuth, (req, res) => {
  const db = getDb();
  const rows = db
    .prepare('SELECT id, content, created_at FROM mood_coping_notes WHERE user_id = ? ORDER BY id DESC')
    .all(req.session.userId);
  res.json(rows);
});

router.post('/coping-notes', requireAuth, (req, res) => {
  const { content } = req.body || {};
  if (!content || !String(content).trim()) {
    return res.status(400).json({ error: '請提供小卡內容' });
  }
  const db = getDb();
  const now = new Date().toISOString();
  const result = db
    .prepare('INSERT INTO mood_coping_notes (user_id, content, created_at) VALUES (?, ?, ?)')
    .run(req.session.userId, String(content).trim(), now);
  res.json({ id: result.lastInsertRowid, content: String(content).trim(), created_at: now });
});

router.delete('/coping-notes/:id', requireAuth, (req, res) => {
  const db = getDb();
  db.prepare('DELETE FROM mood_coping_notes WHERE id = ? AND user_id = ?').run(req.params.id, req.session.userId);
  res.json({ ok: true });
});

// ---------- 情緒陪伴對話 (獨立於一般 AI 助理) ----------

router.get('/chat/history', requireAuth, (req, res) => {
  const db = getDb();
  res.json(fetchRecentChatHistory(db, req.session.userId, MAX_CHAT_HISTORY));
});

// ---------- AI 對話記憶強化 ----------
// 每累積 MEMORY_CHUNK_SIZE 則訊息，就把「還沒摘要過的最舊一批」濃縮成 1-2 句重點存起來，
// 之後聊天時把最近幾筆摘要一起交給 AI，讓它就算看不到很久以前的逐字稿，也還記得重點。
const MEMORY_CHUNK_SIZE = 40;
const MEMORY_RECALL_COUNT = 6;

async function maybeSummarizeMemoryChunk(db, userId) {
  const totalCount = db.prepare('SELECT COUNT(*) as c FROM mood_chat_messages WHERE user_id = ?').get(userId).c;
  if (totalCount === 0 || totalCount % MEMORY_CHUNK_SIZE !== 0) return;

  const lastMemory = db
    .prepare('SELECT chunk_to_id FROM mood_chat_memory WHERE user_id = ? ORDER BY chunk_to_id DESC LIMIT 1')
    .get(userId);
  const afterId = lastMemory ? lastMemory.chunk_to_id : 0;

  const chunk = db
    .prepare('SELECT id, role, content FROM mood_chat_messages WHERE user_id = ? AND id > ? ORDER BY id ASC LIMIT ?')
    .all(userId, afterId, MEMORY_CHUNK_SIZE);
  if (chunk.length < MEMORY_CHUNK_SIZE) return; // 保險：資料量還不夠一整個 chunk 就不摘要

  try {
    const result = await mood.summarizeChatChunk(chunk);
    if (result.isConfigured && result.reply && !result.reply.includes('無重要記憶點')) {
      db.prepare('INSERT INTO mood_chat_memory (user_id, chunk_from_id, chunk_to_id, summary, created_at) VALUES (?, ?, ?, ?, ?)').run(
        userId,
        chunk[0].id,
        chunk[chunk.length - 1].id,
        result.reply,
        new Date().toISOString()
      );
    }
  } catch (e) {
    logger.error('對話記憶摘要產生失敗', { error: e.message });
    // 記憶摘要失敗不影響這次聊天本身，安靜跳過即可
  }
}

function buildMemoryContext(db, userId) {
  const rows = db
    .prepare('SELECT summary FROM mood_chat_memory WHERE user_id = ? ORDER BY id DESC LIMIT ?')
    .all(userId, MEMORY_RECALL_COUNT)
    .reverse();
  if (!rows.length) return null;
  return rows.map((r) => `- ${r.summary}`).join('\n');
}

router.post('/chat', requireAuth, async (req, res) => {
  const { message } = req.body || {};
  if (!message || !String(message).trim()) {
    return res.status(400).json({ error: '請提供 message' });
  }
  const db = getDb();
  const now = new Date().toISOString();
  const crisisNow = mood.detectCrisisSignal(message);
  db.prepare('INSERT INTO mood_chat_messages (user_id, role, content, flagged, created_at) VALUES (?, ?, ?, ?, ?)').run(
    req.session.userId,
    'user',
    message,
    crisisNow ? 1 : 0,
    now
  );

  const history = fetchRecentChatHistory(db, req.session.userId, MAX_CHAT_HISTORY);
  const memoryContext = buildMemoryContext(db, req.session.userId);

  try {
    const result = await mood.chatMoodCompanion(history, memoryContext);
    db.prepare('INSERT INTO mood_chat_messages (user_id, role, content, flagged, created_at) VALUES (?, ?, ?, ?, ?)').run(
      req.session.userId,
      'assistant',
      result.reply,
      result.crisisDetected ? 1 : 0,
      new Date().toISOString()
    );
    res.json(result);
    maybeSummarizeMemoryChunk(db, req.session.userId).catch(() => {});
  } catch (e) {
    logger.error('心情陪伴對話失敗', { error: e.message });
    res.status(502).json({ error: 'AI 陪伴暫時無法回應，請稍後再試', detail: e.message });
  }
});

router.delete('/chat/history', requireAuth, (req, res) => {
  const db = getDb();
  db.prepare('DELETE FROM mood_chat_messages WHERE user_id = ?').run(req.session.userId);
  res.json({ ok: true });
});

module.exports = router;
