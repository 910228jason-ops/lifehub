const { Router } = require('../mini-http');
const assistant = require('../services/assistant');
const { getDb } = require('../services/db');
const { requireAuth } = require('../middleware/auth');
const logger = require('../services/logger');

const router = Router();

// 對話記錄存在資料庫、以使用者為單位，這樣重新整理頁面或換裝置登入都還在，
// 跟日記/記帳/行事曆的持久化方式一致。只保留最近 200 則，避免單一使用者無限長。
const MAX_HISTORY = 200;

router.get('/history', requireAuth, (req, res) => {
  const db = getDb();
  const rows = db
    .prepare('SELECT role, content, created_at FROM assistant_messages WHERE user_id = ? ORDER BY id ASC LIMIT ?')
    .all(req.session.userId, MAX_HISTORY);
  res.json(rows);
});

router.post('/chat', requireAuth, async (req, res) => {
  const { message } = req.body || {};
  if (!message || !String(message).trim()) {
    return res.status(400).json({ error: '請提供 message' });
  }
  const db = getDb();
  const now = new Date().toISOString();
  db.prepare('INSERT INTO assistant_messages (user_id, role, content, created_at) VALUES (?, ?, ?, ?)').run(
    req.session.userId,
    'user',
    message,
    now
  );

  const history = db
    .prepare('SELECT role, content FROM assistant_messages WHERE user_id = ? ORDER BY id ASC LIMIT ?')
    .all(req.session.userId, MAX_HISTORY);

  try {
    const result = await assistant.chat(history);
    db.prepare('INSERT INTO assistant_messages (user_id, role, content, created_at) VALUES (?, ?, ?, ?)').run(
      req.session.userId,
      'assistant',
      result.reply,
      new Date().toISOString()
    );
    res.json(result);
  } catch (e) {
    logger.error('AI 助理對話失敗', { error: e.message });
    res.status(502).json({ error: 'AI 助理暫時無法回應，請稍後再試', detail: e.message });
  }
});

router.delete('/history', requireAuth, (req, res) => {
  const db = getDb();
  db.prepare('DELETE FROM assistant_messages WHERE user_id = ?').run(req.session.userId);
  res.json({ ok: true });
});

module.exports = router;
