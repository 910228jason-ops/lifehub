// AI 助理：把使用者在「AI 助理」頁籤打的訊息，轉發給 AI 供應商取得回覆。
//
// 支援兩種供應商 (擇一設定即可)：
//   1. Google Gemini (推薦，有免費額度、不需要信用卡)：
//      前往 https://aistudio.google.com/app/apikey 用 Google 帳號免費申請一組 API Key，
//      貼到環境變數 GEMINI_API_KEY。
//   2. Anthropic Claude (品質最好，但採用量計費，需要信用卡)：
//      前往 https://console.anthropic.com 申請 API Key，貼到環境變數 ANTHROPIC_API_KEY。
// 兩個都沒設定時，這個功能會回傳清楚的申請教學而不是報錯崩潰；兩個都有設定時，
// 優先使用 Gemini (免費)。
//
// 這裡只做「最簡單的單輪/多輪對話轉發」，把使用者這支 App 的定位 (生活小幫手：
// 股票資訊、交通旅遊、日記、記帳、聊天、翻譯、生活建議等) 放進 system prompt，
// 讓回覆的語氣貼近這個 App 的助理人設；之後可以依需求擴充成「不同模式」
// (面試練習/翻譯/技術說明等)，只要調整 system prompt 或允許前端傳入不同模式參數即可。

const logger = require('./logger');

const SYSTEM_PROMPT = `你是 LifeHub 這款生活整合 App 內建的 AI 助理，個性親切、有效率。
使用者可能會問你：日常聊天、練習面試、幫忙想怎麼回訊息、分析對話、給不同角度建議、
規劃旅遊行程、安排待辦事項、健身飲食規劃、比較商品、推薦餐廳、找食譜、單位換算、
電腦軟體問題、股票法人買賣分析、新聞整理、技術面/基本面解釋、風險分析、多語言翻譯等。
請用繁體中文回答(除非使用者要求翻譯成其他語言)，語氣自然、簡潔，避免不必要的長篇大論。
如果使用者問的是投資建議，提醒你只能提供參考資訊、不是專業投資建議。`;

function getProvider() {
  if (process.env.GEMINI_API_KEY) return 'gemini';
  if (process.env.ANTHROPIC_API_KEY) return 'anthropic';
  return null;
}

function isConfigured() {
  return getProvider() !== null;
}

async function fetchWithTimeout(url, opts = {}, timeoutMs = 30000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, { ...opts, signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}

async function chatWithGemini(history) {
  const contents = history
    .filter((m) => m && m.content && m.content.trim())
    .map((m) => ({ role: m.role === 'assistant' ? 'model' : 'user', parts: [{ text: m.content }] }));

  const model = process.env.GEMINI_MODEL || 'gemini-2.0-flash';
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${process.env.GEMINI_API_KEY}`;
  const res = await fetchWithTimeout(url, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({
      systemInstruction: { parts: [{ text: SYSTEM_PROMPT }] },
      contents,
    }),
  });

  if (!res.ok) {
    const errText = await res.text().catch(() => '');
    logger.error('Gemini API 呼叫失敗', { status: res.status, body: errText.slice(0, 500) });
    throw new Error(`AI 助理呼叫失敗: HTTP ${res.status}`);
  }
  const json = await res.json();
  const parts = (json.candidates && json.candidates[0] && json.candidates[0].content && json.candidates[0].content.parts) || [];
  const reply = parts.map((p) => p.text || '').join('\n').trim();
  return { isConfigured: true, reply: reply || '(沒有取得回覆內容，可能是被安全過濾擋下，換個問法試試看)' };
}

async function chatWithAnthropic(history) {
  const messages = history
    .filter((m) => m && m.content && m.content.trim())
    .map((m) => ({ role: m.role === 'assistant' ? 'assistant' : 'user', content: m.content }));

  const res = await fetchWithTimeout('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      'x-api-key': process.env.ANTHROPIC_API_KEY,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model: process.env.ANTHROPIC_MODEL || 'claude-3-5-haiku-20241022',
      max_tokens: 1024,
      system: SYSTEM_PROMPT,
      messages,
    }),
  });

  if (!res.ok) {
    const errText = await res.text().catch(() => '');
    logger.error('Anthropic API 呼叫失敗', { status: res.status, body: errText.slice(0, 500) });
    throw new Error(`AI 助理呼叫失敗: HTTP ${res.status}`);
  }
  const json = await res.json();
  const reply = (json.content || []).map((b) => b.text || '').join('\n').trim();
  return { isConfigured: true, reply: reply || '(沒有取得回覆內容)' };
}

// history: [{role: 'user'|'assistant', content: string}, ...]，最後一筆是使用者這次的新訊息
async function chat(history) {
  const provider = getProvider();
  if (!provider) {
    return {
      isConfigured: false,
      reply:
        '尚未設定 AI 助理的 API 金鑰。免費方案：前往 https://aistudio.google.com/app/apikey ' +
        '用 Google 帳號登入即可免費申請一組 Gemini API Key (不需要信用卡)，' +
        '貼到環境變數 GEMINI_API_KEY 後重新部署，就可以開始聊天了。',
    };
  }
  return provider === 'gemini' ? chatWithGemini(history) : chatWithAnthropic(history);
}

function healthcheck() {
  const provider = getProvider();
  return provider ? { ok: true, provider } : { ok: false, reason: '未設定 GEMINI_API_KEY 或 ANTHROPIC_API_KEY' };
}

module.exports = { chat, isConfigured, healthcheck };
