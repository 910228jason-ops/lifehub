-- v0.50.0：專案看板。固定三欄 (待辦/進行中/完成)，不像 Trello 可以自訂欄位——先做最常用的
-- 三階段流程就好，需求更複雜的話之後再擴充。sort_order 決定同一欄內卡片的順序 (拖曳/移動
-- 後更新)，用「該欄目前最大值 + 1」的方式接在最後面，不需要整批重新編號。
CREATE TABLE IF NOT EXISTS kanban_boards (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  name TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS kanban_cards (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  board_id INTEGER NOT NULL REFERENCES kanban_boards(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  note TEXT NOT NULL DEFAULT '',
  column_key TEXT NOT NULL DEFAULT 'todo' CHECK (column_key IN ('todo','in_progress','done')),
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_kanban_cards_board ON kanban_cards(board_id, column_key, sort_order);
