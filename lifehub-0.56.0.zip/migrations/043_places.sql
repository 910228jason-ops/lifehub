-- v0.55：地點資料庫 (「臨時揪一波」快速出遊建議的資料底層)。
--
-- 這是 LifeHub 第一份「全體使用者共用」的公開資料，不像日記/待辦是私人的，也不像
-- 願望清單/固定行程模板是限定跟已連結的家人/伴侶共用——任何登入的使用者都看得到全部
-- 地點、都可以新增/評分，這點跟其他功能的權限模型不一樣，是刻意的設計 (公開的地點資料庫
-- 本來就該讓所有人受益，不該被連結關係限制住)。
--
-- source 欄位分三種：
--   'curated' —— 從 src/services/itinerary.js 原本就有的 CURATED_SPOTS 搬過來的兩個城市
--                 (台中/新北)，那份資料本來就是整理自公開部落格文章、刻意不編造星等，
--                 搬進資料庫後這個「不編造分數」的原則延續：這些地點初始沒有任何評分，
--                 星等要靠使用者自己評才會出現。
--   'gov'     —— 之後政府開放資料匯入腳本會用這個標記 (這支 migration 本身不做匯入，
--                 匯入是另外的一次性後台腳本)。
--   'user'    —— 使用者自己新增的地點，這是長期資料成長的主力來源。
--
-- 評分 (place_ratings) 一人一地點只能有一筆 (UNIQUE(place_id, user_id))，重新評分是覆蓋
-- 舊分數，不是疊加灌票。回報 (place_reports) 同樣一人一地點限一筆，累積到門檻由應用層
-- (routes/places.js) 判斷要不要把 status 改成 needs_review，不是資料庫層的邏輯。

CREATE TABLE IF NOT EXISTS places (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  city TEXT NOT NULL,
  district TEXT,
  address TEXT,
  mood_tags TEXT NOT NULL DEFAULT '',
  transport_tags TEXT NOT NULL DEFAULT '',
  hours_text TEXT,
  fee_info TEXT,
  visit_duration_min INTEGER,
  note TEXT,
  source TEXT NOT NULL DEFAULT 'user',
  status TEXT NOT NULL DEFAULT 'active',
  created_by_user_id INTEGER,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_places_city ON places(city);
CREATE INDEX IF NOT EXISTS idx_places_status ON places(status);

CREATE TABLE IF NOT EXISTS place_ratings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  place_id INTEGER NOT NULL REFERENCES places(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL,
  stars INTEGER NOT NULL,
  note TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  UNIQUE(place_id, user_id)
);
CREATE INDEX IF NOT EXISTS idx_place_ratings_place ON place_ratings(place_id);

CREATE TABLE IF NOT EXISTS place_reports (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  place_id INTEGER NOT NULL REFERENCES places(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL,
  reason TEXT,
  created_at TEXT NOT NULL,
  UNIQUE(place_id, user_id)
);
CREATE INDEX IF NOT EXISTS idx_place_reports_place ON place_reports(place_id);

-- 把 itinerary.js 裡原本硬編碼的「台中/新北」精選清單搬進資料庫當初始種子內容，
-- 避免這個功能一上線資料庫是空的。分類對應：景點->outdoor+photo，美食->food，休閒->relax。
INSERT INTO places (name, city, district, address, mood_tags, transport_tags, hours_text, fee_info, visit_duration_min, note, source, status, created_by_user_id, created_at, updated_at) VALUES ('彩虹眷村', '台中', NULL, NULL, ',outdoor,photo,', ',walk,drive,', NULL, NULL, NULL, '五顏六色的牆面地板，IG 打卡熱點', 'curated', 'active', NULL, '2026-08-04T00:00:00.000Z', '2026-08-04T00:00:00.000Z');
INSERT INTO places (name, city, district, address, mood_tags, transport_tags, hours_text, fee_info, visit_duration_min, note, source, status, created_by_user_id, created_at, updated_at) VALUES ('審計368新創聚落', '台中', NULL, NULL, ',outdoor,photo,', ',walk,drive,', NULL, NULL, NULL, '文青風格創意園區，集合特色店家與文創商品', 'curated', 'active', NULL, '2026-08-04T00:00:00.000Z', '2026-08-04T00:00:00.000Z');
INSERT INTO places (name, city, district, address, mood_tags, transport_tags, hours_text, fee_info, visit_duration_min, note, source, status, created_by_user_id, created_at, updated_at) VALUES ('高美濕地', '台中', NULL, NULL, ',outdoor,photo,', ',walk,drive,', NULL, NULL, NULL, '黃昏必追的夕陽美景，木棧道步道', 'curated', 'active', NULL, '2026-08-04T00:00:00.000Z', '2026-08-04T00:00:00.000Z');
INSERT INTO places (name, city, district, address, mood_tags, transport_tags, hours_text, fee_info, visit_duration_min, note, source, status, created_by_user_id, created_at, updated_at) VALUES ('台中科博館', '台中', NULL, NULL, ',outdoor,photo,', ',walk,drive,', NULL, NULL, NULL, '展示恐龍等自然科學展品的大型博物館', 'curated', 'active', NULL, '2026-08-04T00:00:00.000Z', '2026-08-04T00:00:00.000Z');
INSERT INTO places (name, city, district, address, mood_tags, transport_tags, hours_text, fee_info, visit_duration_min, note, source, status, created_by_user_id, created_at, updated_at) VALUES ('薰衣草森林', '台中', NULL, NULL, ',outdoor,photo,', ',walk,drive,', NULL, NULL, NULL, '高海拔山景與四季花卉的休閒園區', 'curated', 'active', NULL, '2026-08-04T00:00:00.000Z', '2026-08-04T00:00:00.000Z');
INSERT INTO places (name, city, district, address, mood_tags, transport_tags, hours_text, fee_info, visit_duration_min, note, source, status, created_by_user_id, created_at, updated_at) VALUES ('梧棲文化出張所', '台中', NULL, NULL, ',outdoor,photo,', ',walk,drive,', NULL, NULL, NULL, '日治時代派出所改建，濃濃日式風格', 'curated', 'active', NULL, '2026-08-04T00:00:00.000Z', '2026-08-04T00:00:00.000Z');
INSERT INTO places (name, city, district, address, mood_tags, transport_tags, hours_text, fee_info, visit_duration_min, note, source, status, created_by_user_id, created_at, updated_at) VALUES ('積木城堡星巴克', '台中', NULL, NULL, ',food,', ',walk,drive,', NULL, NULL, NULL, '純白色旋轉木馬造型的特色門市', 'curated', 'active', NULL, '2026-08-04T00:00:00.000Z', '2026-08-04T00:00:00.000Z');
INSERT INTO places (name, city, district, address, mood_tags, transport_tags, hours_text, fee_info, visit_duration_min, note, source, status, created_by_user_id, created_at, updated_at) VALUES ('自行車文化探索館', '台中', NULL, NULL, ',relax,', ',walk,drive,', NULL, NULL, NULL, '互動式自行車主題館，有 VR 體驗與騎乘挑戰', 'curated', 'active', NULL, '2026-08-04T00:00:00.000Z', '2026-08-04T00:00:00.000Z');
INSERT INTO places (name, city, district, address, mood_tags, transport_tags, hours_text, fee_info, visit_duration_min, note, source, status, created_by_user_id, created_at, updated_at) VALUES ('烏日觀光啤酒廠', '台中', NULL, NULL, ',relax,', ',walk,drive,', NULL, NULL, NULL, '免門票參觀台灣啤酒製程與文物館', 'curated', 'active', NULL, '2026-08-04T00:00:00.000Z', '2026-08-04T00:00:00.000Z');
INSERT INTO places (name, city, district, address, mood_tags, transport_tags, hours_text, fee_info, visit_duration_min, note, source, status, created_by_user_id, created_at, updated_at) VALUES ('泰安落羽松秘境', '台中', NULL, NULL, ',relax,', ',walk,drive,', NULL, NULL, NULL, '季節限定紅葉美景，適合秋冬拍照 (季節限定)', 'curated', 'active', NULL, '2026-08-04T00:00:00.000Z', '2026-08-04T00:00:00.000Z');
INSERT INTO places (name, city, district, address, mood_tags, transport_tags, hours_text, fee_info, visit_duration_min, note, source, status, created_by_user_id, created_at, updated_at) VALUES ('九份老街', '新北', NULL, NULL, ',outdoor,photo,', ',walk,drive,', NULL, NULL, NULL, '山城風情，適合傍晚時段前往看夜景與山海景', 'curated', 'active', NULL, '2026-08-04T00:00:00.000Z', '2026-08-04T00:00:00.000Z');
INSERT INTO places (name, city, district, address, mood_tags, transport_tags, hours_text, fee_info, visit_duration_min, note, source, status, created_by_user_id, created_at, updated_at) VALUES ('淡水老街', '新北', NULL, NULL, ',outdoor,photo,', ',walk,drive,', NULL, NULL, NULL, '河岸夕陽與歷史街區，適合悠閒散步', 'curated', 'active', NULL, '2026-08-04T00:00:00.000Z', '2026-08-04T00:00:00.000Z');
INSERT INTO places (name, city, district, address, mood_tags, transport_tags, hours_text, fee_info, visit_duration_min, note, source, status, created_by_user_id, created_at, updated_at) VALUES ('暇 咖啡 hima cafe (九份)', '新北', NULL, NULL, ',food,', ',walk,drive,', NULL, NULL, NULL, '絕美九份山城下午茶首選，無敵山海景觀', 'curated', 'active', NULL, '2026-08-04T00:00:00.000Z', '2026-08-04T00:00:00.000Z');
INSERT INTO places (name, city, district, address, mood_tags, transport_tags, hours_text, fee_info, visit_duration_min, note, source, status, created_by_user_id, created_at, updated_at) VALUES ('九份老麵店 (九份)', '新北', NULL, NULL, ',food,', ',walk,drive,', NULL, NULL, NULL, '飄香傳承65年，九份老街第一家牛肉麵專門店', 'curated', 'active', NULL, '2026-08-04T00:00:00.000Z', '2026-08-04T00:00:00.000Z');
INSERT INTO places (name, city, district, address, mood_tags, transport_tags, hours_text, fee_info, visit_duration_min, note, source, status, created_by_user_id, created_at, updated_at) VALUES ('彭園 板橋店 (板橋)', '新北', NULL, NULL, ',food,', ',walk,drive,', NULL, NULL, NULL, '融合八大菜系的中式餐廳，傳承一甲子', 'curated', 'active', NULL, '2026-08-04T00:00:00.000Z', '2026-08-04T00:00:00.000Z');
INSERT INTO places (name, city, district, address, mood_tags, transport_tags, hours_text, fee_info, visit_duration_min, note, source, status, created_by_user_id, created_at, updated_at) VALUES ('瑞芳古早味三輪車割包 (瑞芳)', '新北', NULL, NULL, ',food,', ',walk,drive,', NULL, NULL, NULL, '銅板美食在地排隊名店，傳承超過一甲子', 'curated', 'active', NULL, '2026-08-04T00:00:00.000Z', '2026-08-04T00:00:00.000Z');
INSERT INTO places (name, city, district, address, mood_tags, transport_tags, hours_text, fee_info, visit_duration_min, note, source, status, created_by_user_id, created_at, updated_at) VALUES ('永新豆漿 竹林總店 (永和)', '新北', NULL, NULL, ',food,', ',walk,drive,', NULL, NULL, NULL, '營業滿43年老字號早餐，鹹豆漿加蛋必點', 'curated', 'active', NULL, '2026-08-04T00:00:00.000Z', '2026-08-04T00:00:00.000Z');
INSERT INTO places (name, city, district, address, mood_tags, transport_tags, hours_text, fee_info, visit_duration_min, note, source, status, created_by_user_id, created_at, updated_at) VALUES ('沒有特別計畫咖啡 (淡水)', '新北', NULL, NULL, ',food,', ',walk,drive,', NULL, NULL, NULL, '每日限量甜點，文青療癒系咖啡廳', 'curated', 'active', NULL, '2026-08-04T00:00:00.000Z', '2026-08-04T00:00:00.000Z');
INSERT INTO places (name, city, district, address, mood_tags, transport_tags, hours_text, fee_info, visit_duration_min, note, source, status, created_by_user_id, created_at, updated_at) VALUES ('ABV 地中海餐酒館 (林口)', '新北', NULL, NULL, ',relax,', ',walk,drive,', NULL, NULL, NULL, '超過300款精釀啤酒，適合朋友聚會', 'curated', 'active', NULL, '2026-08-04T00:00:00.000Z', '2026-08-04T00:00:00.000Z');
INSERT INTO places (name, city, district, address, mood_tags, transport_tags, hours_text, fee_info, visit_duration_min, note, source, status, created_by_user_id, created_at, updated_at) VALUES ('初殿鍋物 (新莊)', '新北', NULL, NULL, ',relax,', ',walk,drive,', NULL, NULL, NULL, '平日套餐299元起、60種自助吧吃到飽', 'curated', 'active', NULL, '2026-08-04T00:00:00.000Z', '2026-08-04T00:00:00.000Z');
