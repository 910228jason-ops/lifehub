-- v0.53.0：子任務功能升級，可以各自設定優先度跟精準提醒時間 (不再只有「標題+打勾」兩個
-- 欄位)。這是整個 App 共用的子任務功能升級，不是只有固定行程模板專屬——範本套用出來的
-- 子任務、跟使用者自己在待辦事項底下手動加的子任務，用同一套邏輯、看得到也改得到，避免
-- 兩邊功能不一致 (套用範本出來的子任務有進階設定，自己手動加的卻沒有，會很奇怪)。
ALTER TABLE task_subtasks ADD COLUMN priority TEXT NOT NULL DEFAULT 'medium';
ALTER TABLE task_subtasks ADD COLUMN remind_at TEXT; -- ISO 時間戳記，NULL = 這個子任務沒有自己的精準提醒
ALTER TABLE task_subtasks ADD COLUMN remind_sent_at TEXT; -- 避免重複推播，邏輯跟 tasks.remind_sent_at 一樣
CREATE INDEX IF NOT EXISTS idx_task_subtasks_remind_pending ON task_subtasks(remind_at) WHERE remind_at IS NOT NULL AND remind_sent_at IS NULL;

-- 固定行程模板的「大項」加一個獨立的推播時間 (HH:MM，不含日期——日期是套用時才依 day_offset
-- 算出來的)，NULL 代表這個大項不用精準提醒，只是單純的待辦事項到期日。
ALTER TABLE routine_template_items ADD COLUMN remind_time TEXT;

-- 「小項目」掛在大項底下 (例如大項「出門」底下有「帶牙刷」「帶牙膏」)，使用者自己輸入，
-- 各自有自己的優先度跟精準提醒時間 (可以跟大項或其他小項目都不一樣)，套用範本時會變成
-- 那筆待辦事項底下的子任務。
CREATE TABLE IF NOT EXISTS routine_template_subitems (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  item_id INTEGER NOT NULL REFERENCES routine_template_items(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  priority TEXT NOT NULL DEFAULT 'medium',
  remind_time TEXT,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_routine_subitems_item ON routine_template_subitems(item_id, sort_order);
