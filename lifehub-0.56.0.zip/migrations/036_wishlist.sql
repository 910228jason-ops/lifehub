-- v0.47.0：願望清單。每個人自己的清單 (不像家庭公告欄是圈子共用)，priority 用文字
-- (low/medium/high) 存，不用另外查表；price 是 REAL 允許小數 (例如 199.5 元)，可留空。
CREATE TABLE IF NOT EXISTS wishlist_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  title TEXT NOT NULL,
  note TEXT NOT NULL DEFAULT '',
  link TEXT,
  price REAL,
  priority TEXT NOT NULL DEFAULT 'medium',
  completed INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_wishlist_user ON wishlist_items(user_id, completed, priority);
