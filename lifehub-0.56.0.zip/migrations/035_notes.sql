-- v0.46.0：個人筆記 (iPhone 備忘錄風格)。folder 是自由文字 (不是外鍵關聯到獨立資料表)，
-- 使用者輸入什麼字串就是什麼「資料夾」，用文字比對分組即可，不需要另外的資料夾管理介面——
-- 這跟日記的 tags 欄位是同樣的簡化邏輯 (見 diary_entries.tags)。
CREATE TABLE IF NOT EXISTS notes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  title TEXT NOT NULL DEFAULT '',
  content TEXT NOT NULL DEFAULT '',
  folder TEXT,
  pinned INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_notes_user ON notes(user_id, updated_at);
