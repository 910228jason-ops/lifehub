-- v0.52.0：獎勵兌換頁面加入「跟已連結的家人/伴侶共同建立」的選項。重用既有的 partner_links
-- 配對系統——建立獎勵項目時可以選擇要私人自己看，還是掛在某個連結底下讓雙方都看得到、
-- 都能新增/編輯/刪除，方便情侶/家人一起討論「多少點換什麼」，不用各自重複建一份一樣的清單。
-- 兌換仍然各自扣各自的點數 (不是共用點數池)，「共同」只是獎勵項目清單共同維護而已。
ALTER TABLE point_rewards ADD COLUMN link_id INTEGER;
ALTER TABLE point_rewards ADD COLUMN created_by_user_id INTEGER;
UPDATE point_rewards SET created_by_user_id = user_id WHERE created_by_user_id IS NULL;
CREATE INDEX IF NOT EXISTS idx_point_rewards_link ON point_rewards(link_id);
