-- v0.54：跨模組串連。
--
-- 1) 固定行程模板 × 揪團分帳：範本可以選擇性連結一個分帳群組，套用範本時方便直接跳去記帳，
--    不用重新建立一次分帳群組。
ALTER TABLE routine_templates ADD COLUMN split_group_id INTEGER;

-- 2) 願望清單 × 獎勵頁面：獎勵項目可以是從願望清單項目「轉換」來的，記錄來源方便互相對照。
ALTER TABLE point_rewards ADD COLUMN wishlist_item_id INTEGER;

-- 3) 擴大「共同建立」模式：把獎勵頁面 (v0.52) 已經有的 link_id / created_by_user_id 欄位，
--    比照套用到願望清單、固定行程模板，讓這兩個功能也能跟已連結的家人/伴侶共同建立、共用同一份清單。
ALTER TABLE wishlist_items ADD COLUMN link_id INTEGER;
ALTER TABLE wishlist_items ADD COLUMN created_by_user_id INTEGER;
UPDATE wishlist_items SET created_by_user_id = user_id WHERE created_by_user_id IS NULL;
CREATE INDEX IF NOT EXISTS idx_wishlist_link ON wishlist_items(link_id);

ALTER TABLE routine_templates ADD COLUMN link_id INTEGER;
ALTER TABLE routine_templates ADD COLUMN created_by_user_id INTEGER;
UPDATE routine_templates SET created_by_user_id = user_id WHERE created_by_user_id IS NULL;
CREATE INDEX IF NOT EXISTS idx_routine_templates_link ON routine_templates(link_id);
