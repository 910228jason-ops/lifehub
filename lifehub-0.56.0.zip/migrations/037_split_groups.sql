-- v0.49.0：揪團分帳。跟朋友出去玩/聚餐的分帳群組——成員用「名字」存 (不是綁定真的帳號)，
-- 因為一起分帳的人不見得都有註冊這個 App，這樣比較貼近實際使用情境 (跟 Splitwise 類似)。
-- 群組只有建立者 (user_id) 看得到/管理，不是跟家庭公告欄一樣圈子共用。
CREATE TABLE IF NOT EXISTS split_groups (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  name TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS split_members (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  group_id INTEGER NOT NULL REFERENCES split_groups(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS split_expenses (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  group_id INTEGER NOT NULL REFERENCES split_groups(id) ON DELETE CASCADE,
  description TEXT NOT NULL DEFAULT '',
  amount REAL NOT NULL,
  paid_by_member_id INTEGER NOT NULL,
  expense_date TEXT NOT NULL,
  created_at TEXT NOT NULL
);

-- 這筆花費是哪些成員一起分攤 (預設是全部成員均分，但保留彈性讓某些成員不用分攤這筆)。
CREATE TABLE IF NOT EXISTS split_expense_participants (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  expense_id INTEGER NOT NULL REFERENCES split_expenses(id) ON DELETE CASCADE,
  member_id INTEGER NOT NULL,
  UNIQUE(expense_id, member_id)
);

CREATE INDEX IF NOT EXISTS idx_split_groups_user ON split_groups(user_id);
CREATE INDEX IF NOT EXISTS idx_split_members_group ON split_members(group_id);
CREATE INDEX IF NOT EXISTS idx_split_expenses_group ON split_expenses(group_id);
CREATE INDEX IF NOT EXISTS idx_split_participants_expense ON split_expense_participants(expense_id);
