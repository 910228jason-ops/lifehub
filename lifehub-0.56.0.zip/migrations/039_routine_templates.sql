-- v0.51.0：固定行程模板。範本本身只是「一組項目清單」，套用時才會真的產生待辦事項——
-- day_offset 是相對套用日期的天數 (0 = 當天，1 = 隔天...)，這樣同一個範本套用在不同的
-- 起始日期都能自動算出正確的到期日，不用每次手動調整每一項的日期。
CREATE TABLE IF NOT EXISTS routine_templates (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  name TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS routine_template_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  template_id INTEGER NOT NULL REFERENCES routine_templates(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  note TEXT,
  day_offset INTEGER NOT NULL DEFAULT 0,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_routine_items_template ON routine_template_items(template_id, sort_order);
