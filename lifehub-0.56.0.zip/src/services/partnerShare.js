// 共同建立模式共用工具 (v0.54)。
//
// v0.52 在「點數獎勵」頁面第一次做出「私人項目 vs 跟已連結的家人/伴侶共同建立」這個模式：
// 私人項目 (link_id 是 null) 只有建立者看得到/能改；共同項目 (link_id 有值) 則是那個
// partner_links 連結底下的雙方都算數，不限定只有當初建立的那個人，而且雙方看到的是
// 同一份清單、同一份資料 (不是各自複製一份)。
//
// v0.54 把這套邏輯抽成共用模組，讓「願望清單」「固定行程模板」也能套用同一套共同建立模式，
// 不用每個功能都各自複製一份幾乎一樣的 getUserLinks/canAccess 邏輯。
//
// 使用這個模組的資料表，需要有 link_id (nullable, 指向 partner_links.id) 跟
// created_by_user_id 這兩個欄位。

function getUserLinks(db, userId) {
  const rows = db
    .prepare('SELECT id, user_a_id, user_b_id FROM partner_links WHERE user_a_id = ? OR user_b_id = ?')
    .all(userId, userId);
  return rows.map((r) => ({ linkId: r.id, partnerUserId: r.user_a_id === userId ? r.user_b_id : r.user_a_id }));
}

function linkBelongsToUser(db, linkId, userId) {
  const row = db
    .prepare('SELECT id FROM partner_links WHERE id = ? AND (user_a_id = ? OR user_b_id = ?)')
    .get(linkId, userId, userId);
  return !!row;
}

function userLabel(db, userId) {
  const u = db.prepare('SELECT name, email FROM users WHERE id = ?').get(userId);
  return (u && (u.name || u.email)) || '對方';
}

// item 需要有 link_id / user_id 欄位。私人的 (link_id 是 null) 只有建立者本人算數；
// 共同的 (link_id 有值) 則是那個連結底下的雙方都算數。
function canAccessSharedItem(db, item, userId) {
  if (!item.link_id) return item.user_id === userId;
  return linkBelongsToUser(db, item.link_id, userId);
}

// 幫一筆資料算出要回給前端的「共同建立」相關欄位。links 是呼叫端先算好的 getUserLinks(db, userId) 結果，
// 避免每一筆資料都重新查一次 partner_links。
function enrichShared(db, item, userId, links) {
  if (!item.link_id) return { shared: false };
  const link = links.find((l) => l.linkId === item.link_id);
  const partnerLabel = link ? userLabel(db, link.partnerUserId) : '對方';
  const creatorId = item.created_by_user_id || item.user_id;
  return {
    shared: true,
    partnerLabel,
    creatorLabel: creatorId === userId ? '我' : userLabel(db, creatorId),
    createdByMe: creatorId === userId,
  };
}

module.exports = { getUserLinks, linkBelongsToUser, userLabel, canAccessSharedItem, enrichShared };
