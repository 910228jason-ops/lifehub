// 揪團分帳 (v0.49)。群組成員用名字存 (不綁定真的帳號)，這是為了貼近實際使用情境——
// 一起出去玩分帳的人不一定都有註冊。結算邏輯：每個成員的淨額 = 付的錢 - 應分攤的錢，
// 正數代表「別人欠他」，負數代表「他欠別人」；settleUp() 用貪心法把正負配對，
// 算出最少筆數的「誰該付給誰多少錢」。

const { Router } = require('../mini-http');
const { getDb } = require('../services/db');
const { requireAuth } = require('../middleware/auth');

const router = Router();

function round2(n) {
  return Math.round((n + Number.EPSILON) * 100) / 100;
}

// 貪心演算法：把「淨額為正 (該收錢)」跟「淨額為負 (該付錢)」的人兩兩配對，
// 每次抵消掉金額較小的那筆，直到所有人淨額歸零。這樣產生的轉帳筆數是最少的。
function settleUp(balances) {
  const creditors = balances.filter((b) => b.net > 0.005).map((b) => ({ ...b })).sort((a, b) => b.net - a.net);
  const debtors = balances.filter((b) => b.net < -0.005).map((b) => ({ ...b, net: -b.net })).sort((a, b) => b.net - a.net);
  const transactions = [];
  let i = 0;
  let j = 0;
  while (i < debtors.length && j < creditors.length) {
    const pay = Math.min(debtors[i].net, creditors[j].net);
    if (pay > 0.005) {
      transactions.push({ fromMemberId: debtors[i].memberId, fromName: debtors[i].name, toMemberId: creditors[j].memberId, toName: creditors[j].name, amount: round2(pay) });
    }
    debtors[i].net -= pay;
    creditors[j].net -= pay;
    if (debtors[i].net <= 0.005) i += 1;
    if (creditors[j].net <= 0.005) j += 1;
  }
  return transactions;
}

function computeGroupDetail(db, group) {
  const members = db.prepare('SELECT * FROM split_members WHERE group_id = ? ORDER BY id ASC').all(group.id);
  const expenses = db.prepare('SELECT * FROM split_expenses WHERE group_id = ? ORDER BY expense_date DESC, id DESC').all(group.id);

  const paidByMember = new Map(members.map((m) => [m.id, 0]));
  const owedByMember = new Map(members.map((m) => [m.id, 0]));

  const expensesWithParticipants = expenses.map((exp) => {
    const participants = db
      .prepare('SELECT member_id FROM split_expense_participants WHERE expense_id = ?')
      .all(exp.id)
      .map((r) => r.member_id);
    const shareCount = participants.length || members.length;
    const shareAmount = shareCount ? exp.amount / shareCount : 0;
    const actualParticipants = participants.length ? participants : members.map((m) => m.id);

    if (paidByMember.has(exp.paid_by_member_id)) {
      paidByMember.set(exp.paid_by_member_id, paidByMember.get(exp.paid_by_member_id) + exp.amount);
    }
    actualParticipants.forEach((memberId) => {
      if (owedByMember.has(memberId)) {
        owedByMember.set(memberId, owedByMember.get(memberId) + shareAmount);
      }
    });

    return { ...exp, participantMemberIds: actualParticipants, shareAmount: round2(shareAmount) };
  });

  const balances = members.map((m) => ({
    memberId: m.id,
    name: m.name,
    paid: round2(paidByMember.get(m.id) || 0),
    owed: round2(owedByMember.get(m.id) || 0),
    net: round2((paidByMember.get(m.id) || 0) - (owedByMember.get(m.id) || 0)),
  }));

  const totalAmount = round2(expenses.reduce((sum, e) => sum + e.amount, 0));

  return {
    ...group,
    members,
    expenses: expensesWithParticipants,
    balances,
    settlements: settleUp(balances),
    totalAmount,
  };
}

router.get('/split-groups', requireAuth, (req, res) => {
  const db = getDb();
  const groups = db.prepare('SELECT * FROM split_groups WHERE user_id = ? ORDER BY created_at DESC').all(req.session.userId);
  const summarized = groups.map((g) => {
    const memberCount = db.prepare('SELECT COUNT(*) c FROM split_members WHERE group_id = ?').get(g.id).c;
    const totalAmount = db.prepare('SELECT COALESCE(SUM(amount),0) t FROM split_expenses WHERE group_id = ?').get(g.id).t;
    return { ...g, memberCount, totalAmount: round2(totalAmount) };
  });
  res.json(summarized);
});

router.get('/split-groups/:id', requireAuth, (req, res) => {
  const db = getDb();
  const group = db.prepare('SELECT * FROM split_groups WHERE id = ? AND user_id = ?').get(req.params.id, req.session.userId);
  if (!group) return res.status(404).json({ error: '找不到這個分帳群組' });
  res.json(computeGroupDetail(db, group));
});

router.post('/split-groups', requireAuth, (req, res) => {
  const { name, memberNames } = req.body || {};
  const trimmedName = String(name || '').trim();
  if (!trimmedName) return res.status(400).json({ error: '請輸入群組名稱' });
  const names = Array.isArray(memberNames) ? memberNames.map((n) => String(n || '').trim()).filter(Boolean) : [];
  if (names.length < 2) return res.status(400).json({ error: '至少需要 2 位成員才能分帳' });

  const db = getDb();
  const now = new Date().toISOString();
  const result = db.prepare('INSERT INTO split_groups (user_id, name, created_at) VALUES (?, ?, ?)').run(req.session.userId, trimmedName, now);
  const groupId = result.lastInsertRowid;
  const insertMember = db.prepare('INSERT INTO split_members (group_id, name, created_at) VALUES (?, ?, ?)');
  names.forEach((n) => insertMember.run(groupId, n, now));
  res.json({ id: groupId });
});

router.delete('/split-groups/:id', requireAuth, (req, res) => {
  const db = getDb();
  const group = db.prepare('SELECT * FROM split_groups WHERE id = ? AND user_id = ?').get(req.params.id, req.session.userId);
  if (!group) return res.status(404).json({ error: '找不到這個分帳群組' });
  db.prepare('DELETE FROM split_groups WHERE id = ?').run(group.id);
  res.json({ ok: true });
});

router.post('/split-groups/:id/members', requireAuth, (req, res) => {
  const db = getDb();
  const group = db.prepare('SELECT * FROM split_groups WHERE id = ? AND user_id = ?').get(req.params.id, req.session.userId);
  if (!group) return res.status(404).json({ error: '找不到這個分帳群組' });
  const name = String((req.body || {}).name || '').trim();
  if (!name) return res.status(400).json({ error: '請輸入成員名字' });
  const result = db.prepare('INSERT INTO split_members (group_id, name, created_at) VALUES (?, ?, ?)').run(group.id, name, new Date().toISOString());
  res.json({ id: result.lastInsertRowid });
});

router.delete('/split-groups/:id/members/:memberId', requireAuth, (req, res) => {
  const db = getDb();
  const group = db.prepare('SELECT * FROM split_groups WHERE id = ? AND user_id = ?').get(req.params.id, req.session.userId);
  if (!group) return res.status(404).json({ error: '找不到這個分帳群組' });
  const member = db.prepare('SELECT * FROM split_members WHERE id = ? AND group_id = ?').get(req.params.memberId, group.id);
  if (!member) return res.status(404).json({ error: '找不到這個成員' });
  const usedAsPayer = db.prepare('SELECT COUNT(*) c FROM split_expenses WHERE paid_by_member_id = ?').get(member.id).c;
  const usedAsParticipant = db.prepare('SELECT COUNT(*) c FROM split_expense_participants WHERE member_id = ?').get(member.id).c;
  if (usedAsPayer > 0 || usedAsParticipant > 0) {
    return res.status(400).json({ error: '這位成員已經有分帳紀錄，無法刪除 (可以刪除相關花費後再試)' });
  }
  db.prepare('DELETE FROM split_members WHERE id = ?').run(member.id);
  res.json({ ok: true });
});

router.post('/split-groups/:id/expenses', requireAuth, (req, res) => {
  const db = getDb();
  const group = db.prepare('SELECT * FROM split_groups WHERE id = ? AND user_id = ?').get(req.params.id, req.session.userId);
  if (!group) return res.status(404).json({ error: '找不到這個分帳群組' });
  const { description, amount, paidByMemberId, participantMemberIds, expenseDate } = req.body || {};
  const amountNum = Number(amount);
  if (!Number.isFinite(amountNum) || amountNum <= 0) return res.status(400).json({ error: '金額必須是大於 0 的數字' });
  const payer = db.prepare('SELECT * FROM split_members WHERE id = ? AND group_id = ?').get(paidByMemberId, group.id);
  if (!payer) return res.status(400).json({ error: '請選擇有效的付款人' });

  let participants = Array.isArray(participantMemberIds) ? participantMemberIds.map((n) => Number(n)) : [];
  if (participants.length) {
    const validMembers = new Set(db.prepare('SELECT id FROM split_members WHERE group_id = ?').all(group.id).map((m) => m.id));
    participants = participants.filter((id) => validMembers.has(id));
    if (!participants.length) return res.status(400).json({ error: '參與分攤的成員無效' });
  }

  const db2 = db;
  const now = new Date().toISOString();
  const result = db2
    .prepare('INSERT INTO split_expenses (group_id, description, amount, paid_by_member_id, expense_date, created_at) VALUES (?, ?, ?, ?, ?, ?)')
    .run(group.id, String(description || '').trim(), amountNum, payer.id, expenseDate || now.slice(0, 10), now);
  const expenseId = result.lastInsertRowid;
  const insertParticipant = db2.prepare('INSERT OR IGNORE INTO split_expense_participants (expense_id, member_id) VALUES (?, ?)');
  participants.forEach((memberId) => insertParticipant.run(expenseId, memberId));
  res.json({ id: expenseId });
});

router.delete('/split-groups/:id/expenses/:expenseId', requireAuth, (req, res) => {
  const db = getDb();
  const group = db.prepare('SELECT * FROM split_groups WHERE id = ? AND user_id = ?').get(req.params.id, req.session.userId);
  if (!group) return res.status(404).json({ error: '找不到這個分帳群組' });
  const expense = db.prepare('SELECT * FROM split_expenses WHERE id = ? AND group_id = ?').get(req.params.expenseId, group.id);
  if (!expense) return res.status(404).json({ error: '找不到這筆花費' });
  db.prepare('DELETE FROM split_expenses WHERE id = ?').run(expense.id);
  res.json({ ok: true });
});

module.exports = router;
