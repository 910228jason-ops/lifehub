// 專案看板 (v0.50)。固定三欄：待辦 (todo) / 進行中 (in_progress) / 完成 (done)。
// sort_order 是「該欄位目前最大值 + 1」往後接，移動到別欄時一樣接在目標欄最後面——
// 簡化版排序，不支援「插入到卡片之間」，先滿足最常見的「把卡片挪到下一欄」需求。

const { Router } = require('../mini-http');
const { getDb } = require('../services/db');
const { requireAuth } = require('../middleware/auth');

const router = Router();

const COLUMNS = ['todo', 'in_progress', 'done'];

function nextSortOrder(db, boardId, columnKey) {
  const row = db.prepare('SELECT MAX(sort_order) m FROM kanban_cards WHERE board_id = ? AND column_key = ?').get(boardId, columnKey);
  return (row.m || 0) + 1;
}

router.get('/kanban-boards', requireAuth, (req, res) => {
  const db = getDb();
  const boards = db.prepare('SELECT * FROM kanban_boards WHERE user_id = ? ORDER BY created_at DESC').all(req.session.userId);
  const summarized = boards.map((b) => {
    const cardCount = db.prepare('SELECT COUNT(*) c FROM kanban_cards WHERE board_id = ?').get(b.id).c;
    const doneCount = db.prepare("SELECT COUNT(*) c FROM kanban_cards WHERE board_id = ? AND column_key = 'done'").get(b.id).c;
    return { ...b, cardCount, doneCount };
  });
  res.json(summarized);
});

router.post('/kanban-boards', requireAuth, (req, res) => {
  const name = String((req.body || {}).name || '').trim();
  if (!name) return res.status(400).json({ error: '請輸入看板名稱' });
  const db = getDb();
  const result = db.prepare('INSERT INTO kanban_boards (user_id, name, created_at) VALUES (?, ?, ?)').run(req.session.userId, name, new Date().toISOString());
  res.json({ id: result.lastInsertRowid });
});

router.delete('/kanban-boards/:id', requireAuth, (req, res) => {
  const db = getDb();
  const board = db.prepare('SELECT * FROM kanban_boards WHERE id = ? AND user_id = ?').get(req.params.id, req.session.userId);
  if (!board) return res.status(404).json({ error: '找不到這個看板' });
  db.prepare('DELETE FROM kanban_boards WHERE id = ?').run(board.id);
  res.json({ ok: true });
});

router.get('/kanban-boards/:id', requireAuth, (req, res) => {
  const db = getDb();
  const board = db.prepare('SELECT * FROM kanban_boards WHERE id = ? AND user_id = ?').get(req.params.id, req.session.userId);
  if (!board) return res.status(404).json({ error: '找不到這個看板' });
  const cards = db.prepare('SELECT * FROM kanban_cards WHERE board_id = ? ORDER BY column_key, sort_order ASC').all(board.id);
  const columns = {};
  COLUMNS.forEach((k) => { columns[k] = cards.filter((c) => c.column_key === k); });
  res.json({ ...board, columns });
});

router.post('/kanban-boards/:id/cards', requireAuth, (req, res) => {
  const db = getDb();
  const board = db.prepare('SELECT * FROM kanban_boards WHERE id = ? AND user_id = ?').get(req.params.id, req.session.userId);
  if (!board) return res.status(404).json({ error: '找不到這個看板' });
  const { title, note, column } = req.body || {};
  const trimmedTitle = String(title || '').trim();
  if (!trimmedTitle) return res.status(400).json({ error: '請輸入卡片標題' });
  const columnKey = COLUMNS.includes(column) ? column : 'todo';
  const now = new Date().toISOString();
  const sortOrder = nextSortOrder(db, board.id, columnKey);
  const result = db
    .prepare('INSERT INTO kanban_cards (board_id, title, note, column_key, sort_order, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)')
    .run(board.id, trimmedTitle, note || '', columnKey, sortOrder, now, now);
  res.json({ id: result.lastInsertRowid });
});

router.put('/kanban-boards/:id/cards/:cardId', requireAuth, (req, res) => {
  const db = getDb();
  const board = db.prepare('SELECT * FROM kanban_boards WHERE id = ? AND user_id = ?').get(req.params.id, req.session.userId);
  if (!board) return res.status(404).json({ error: '找不到這個看板' });
  const card = db.prepare('SELECT * FROM kanban_cards WHERE id = ? AND board_id = ?').get(req.params.cardId, board.id);
  if (!card) return res.status(404).json({ error: '找不到這張卡片' });
  const { title, note } = req.body || {};
  const trimmedTitle = title != null ? String(title).trim() : card.title;
  if (!trimmedTitle) return res.status(400).json({ error: '請輸入卡片標題' });
  db.prepare('UPDATE kanban_cards SET title = ?, note = ?, updated_at = ? WHERE id = ?').run(
    trimmedTitle, note != null ? note : card.note, new Date().toISOString(), card.id
  );
  res.json({ ok: true });
});

router.post('/kanban-boards/:id/cards/:cardId/move', requireAuth, (req, res) => {
  const db = getDb();
  const board = db.prepare('SELECT * FROM kanban_boards WHERE id = ? AND user_id = ?').get(req.params.id, req.session.userId);
  if (!board) return res.status(404).json({ error: '找不到這個看板' });
  const card = db.prepare('SELECT * FROM kanban_cards WHERE id = ? AND board_id = ?').get(req.params.cardId, board.id);
  if (!card) return res.status(404).json({ error: '找不到這張卡片' });
  const { column } = req.body || {};
  if (!COLUMNS.includes(column)) return res.status(400).json({ error: '欄位名稱不正確' });
  const sortOrder = nextSortOrder(db, board.id, column);
  db.prepare('UPDATE kanban_cards SET column_key = ?, sort_order = ?, updated_at = ? WHERE id = ?').run(
    column, sortOrder, new Date().toISOString(), card.id
  );
  res.json({ ok: true });
});

router.delete('/kanban-boards/:id/cards/:cardId', requireAuth, (req, res) => {
  const db = getDb();
  const board = db.prepare('SELECT * FROM kanban_boards WHERE id = ? AND user_id = ?').get(req.params.id, req.session.userId);
  if (!board) return res.status(404).json({ error: '找不到這個看板' });
  db.prepare('DELETE FROM kanban_cards WHERE id = ? AND board_id = ?').run(req.params.cardId, board.id);
  res.json({ ok: true });
});

module.exports = router;
