// 個人筆記 (iPhone 備忘錄風格，v0.46)。folder 是自由文字分組，不是獨立資料表——
// 使用者輸入什麼就顯示什麼，跟日記的 tags 欄位同樣的簡化邏輯，不需要另外的資料夾管理介面。

const { Router } = require('../mini-http');
const { getDb } = require('../services/db');
const { requireAuth } = require('../middleware/auth');

const router = Router();

router.get('/notes', requireAuth, (req, res) => {
  const db = getDb();
  const { folder } = req.query;
  const clauses = ['user_id = ?'];
  const params = [req.session.userId];
  if (folder && folder.trim()) { clauses.push('folder = ?'); params.push(folder.trim()); }
  const rows = db
    .prepare(`SELECT * FROM notes WHERE ${clauses.join(' AND ')} ORDER BY pinned DESC, updated_at DESC`)
    .all(...params);
  res.json(rows);
});

router.get('/notes/:id', requireAuth, (req, res) => {
  const db = getDb();
  const note = db.prepare('SELECT * FROM notes WHERE id = ? AND user_id = ?').get(req.params.id, req.session.userId);
  if (!note) return res.status(404).json({ error: '找不到這篇筆記' });
  res.json(note);
});

router.post('/notes', requireAuth, (req, res) => {
  const { title, content, folder } = req.body || {};
  const trimmedContent = String(content || '').trim();
  const trimmedTitle = String(title || '').trim();
  if (!trimmedContent && !trimmedTitle) return res.status(400).json({ error: '標題跟內容不能都是空白' });
  const db = getDb();
  const now = new Date().toISOString();
  const result = db
    .prepare('INSERT INTO notes (user_id, title, content, folder, pinned, created_at, updated_at) VALUES (?, ?, ?, ?, 0, ?, ?)')
    .run(req.session.userId, trimmedTitle, content || '', (folder || '').trim() || null, now, now);
  res.json({ id: result.lastInsertRowid });
});

router.put('/notes/:id', requireAuth, (req, res) => {
  const db = getDb();
  const note = db.prepare('SELECT * FROM notes WHERE id = ? AND user_id = ?').get(req.params.id, req.session.userId);
  if (!note) return res.status(404).json({ error: '找不到這篇筆記' });
  const { title, content, folder } = req.body || {};
  const trimmedContent = content != null ? content : note.content;
  const trimmedTitle = title != null ? String(title).trim() : note.title;
  if (!String(trimmedContent).trim() && !trimmedTitle) return res.status(400).json({ error: '標題跟內容不能都是空白' });
  db.prepare('UPDATE notes SET title = ?, content = ?, folder = ?, updated_at = ? WHERE id = ?').run(
    trimmedTitle, trimmedContent, folder != null ? ((folder || '').trim() || null) : note.folder, new Date().toISOString(), note.id
  );
  res.json({ ok: true });
});

router.delete('/notes/:id', requireAuth, (req, res) => {
  const db = getDb();
  db.prepare('DELETE FROM notes WHERE id = ? AND user_id = ?').run(req.params.id, req.session.userId);
  res.json({ ok: true });
});

router.post('/notes/:id/pin', requireAuth, (req, res) => {
  const db = getDb();
  const note = db.prepare('SELECT * FROM notes WHERE id = ? AND user_id = ?').get(req.params.id, req.session.userId);
  if (!note) return res.status(404).json({ error: '找不到這篇筆記' });
  const nextPinned = note.pinned ? 0 : 1;
  db.prepare('UPDATE notes SET pinned = ?, updated_at = ? WHERE id = ?').run(nextPinned, new Date().toISOString(), note.id);
  res.json({ ok: true, pinned: !!nextPinned });
});

module.exports = router;
