// 固定行程模板 (v0.51，v0.53 加上「大項/小項目」兩層結構 + 優先度 + 精準提醒)。
//
// 範本只是存一份「項目清單」，套用時才依起始日期 + day_offset 算出每一項的到期日，直接寫進
// tasks 表——套用後的待辦事項就是普通的待辦事項，可以照常在「待辦事項」分頁編輯/完成，
// 範本本身不會因為待辦被改動而跟著變，可以重複套用很多次。
//
// v0.53：每個「大項」(例如「出門」) 底下可以掛「小項目」(例如「帶牙刷」「帶牙膏」)，大項跟
// 小項目都可以各自設定要不要精準提醒 (幾點)；小項目還能各自設定自己的優先度，跟大項分開。
// 套用範本時，大項變成一筆待辦事項，小項目變成那筆待辦事項底下的子任務，各自帶著自己的
// 優先度/提醒時間——這些設定套用之後一樣能在「待辦事項」分頁繼續看到、繼續改，不會因為
// 套用完就鎖死。
//
// v0.54：
//   - 比照獎勵頁面/願望清單的「共同建立」模式，範本也可以跟已連結的家人/伴侶共同建立、
//     共用同一份範本 (link_id 有值)——例如「出差打包清單」兩人都能編輯/套用，不用各自建
//     一份。套用範本產生的待辦事項一律算在「實際按下套用的那個人」自己的待辦事項底下，
//     不會影響到對方。
//   - 範本可以選擇性連結一個「揪團分帳」群組 (split_group_id)：如果這個範本本身就牽涉到
//     花費 (例如出差、旅行類範本)，套用之後可以直接跳去那個分帳群組記帳，不用重新建立一次
//     群組跟成員。分帳群組沒有共同建立機制 (splitGroups.js 本身就是私人的)，所以這裡只認
//     「連結範本的那個人自己名下」的分帳群組。

const { Router } = require('../mini-http');
const { getDb } = require('../services/db');
const { requireAuth } = require('../middleware/auth');
const { getUserLinks, linkBelongsToUser, canAccessSharedItem, enrichShared } = require('../services/partnerShare');

const router = Router();

const PRIORITY_OPTIONS = ['low', 'medium', 'high'];

function addDays(dateStr, days) {
  const d = new Date(dateStr + 'T00:00:00Z');
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}

function validRemindTime(t) {
  return t == null || t === '' || /^\d{2}:\d{2}$/.test(String(t));
}

// 把「日期字串」跟「HH:MM」合併成完整的 ISO 時間戳記。這個 App 目前沒有做多時區支援，
// 其他地方 (待辦事項到期日、每日提醒等等) 也都隱含假設使用者在台北時區，這裡延續同樣的
// 假設，直接用 +08:00 組出正確的時間戳記，不用使用者自己換算成 UTC。
function combineDateAndTime(dateStr, timeStr) {
  if (!timeStr) return null;
  const d = new Date(`${dateStr}T${timeStr}:00+08:00`);
  return Number.isNaN(d.getTime()) ? null : d.toISOString();
}

function cleanSubItems(rawSubItems) {
  const list = Array.isArray(rawSubItems) ? rawSubItems : [];
  return list
    .map((s) => ({
      title: String((s && s.title) || '').trim(),
      priority: PRIORITY_OPTIONS.includes(s && s.priority) ? s.priority : 'medium',
      remindTime: validRemindTime(s && s.remindTime) ? ((s && s.remindTime) || null) : undefined,
    }))
    .filter((s) => s.title);
}

// 「連結範本的那個人自己名下」的分帳群組摘要，找不到 (不屬於這個人/已刪除) 就回傳 null，
// 不會洩漏其他人的分帳群組內容。
function splitGroupSummary(db, splitGroupId, userId) {
  if (!splitGroupId) return null;
  const group = db.prepare('SELECT * FROM split_groups WHERE id = ? AND user_id = ?').get(splitGroupId, userId);
  if (!group) return null;
  const memberCount = db.prepare('SELECT COUNT(*) c FROM split_members WHERE group_id = ?').get(group.id).c;
  const totalAmount = db.prepare('SELECT COALESCE(SUM(amount),0) t FROM split_expenses WHERE group_id = ?').get(group.id).t;
  return { id: group.id, name: group.name, memberCount, totalAmount: Math.round(totalAmount * 100) / 100 };
}

function resolveSplitGroupId(db, splitGroupId, userId) {
  if (splitGroupId === undefined) return undefined; // 呼叫端沒帶這個欄位，維持原值不變
  if (splitGroupId === null || splitGroupId === '') return null;
  const group = db.prepare('SELECT id FROM split_groups WHERE id = ? AND user_id = ?').get(splitGroupId, userId);
  if (!group) return false; // 用 false 代表「驗證失敗」，跟「合法但要清空 (null)」區分開
  return group.id;
}

router.get('/routine-templates', requireAuth, (req, res) => {
  const db = getDb();
  const userId = req.session.userId;
  const links = getUserLinks(db, userId);
  const linkIds = links.map((l) => l.linkId);
  let templates;
  if (linkIds.length) {
    const placeholders = linkIds.map(() => '?').join(',');
    templates = db
      .prepare(`SELECT * FROM routine_templates WHERE (link_id IS NULL AND user_id = ?) OR link_id IN (${placeholders}) ORDER BY created_at DESC`)
      .all(userId, ...linkIds);
  } else {
    templates = db.prepare('SELECT * FROM routine_templates WHERE user_id = ? AND link_id IS NULL ORDER BY created_at DESC').all(userId);
  }
  const summarized = templates.map((t) => {
    const itemCount = db.prepare('SELECT COUNT(*) c FROM routine_template_items WHERE template_id = ?').get(t.id).c;
    return { ...t, itemCount, ...enrichShared(db, t, userId, links), hasSplitGroup: !!t.split_group_id };
  });
  res.json(summarized);
});

router.get('/routine-templates/:id', requireAuth, (req, res) => {
  const db = getDb();
  const userId = req.session.userId;
  const template = db.prepare('SELECT * FROM routine_templates WHERE id = ?').get(req.params.id);
  if (!template || !canAccessSharedItem(db, template, userId)) return res.status(404).json({ error: '找不到這個範本' });
  const items = db.prepare('SELECT * FROM routine_template_items WHERE template_id = ? ORDER BY sort_order ASC, id ASC').all(template.id);
  const itemsWithSub = items.map((item) => {
    const subItems = db
      .prepare('SELECT * FROM routine_template_subitems WHERE item_id = ? ORDER BY sort_order ASC, id ASC')
      .all(item.id);
    return { ...item, subItems };
  });
  const links = getUserLinks(db, userId);
  res.json({
    ...template,
    items: itemsWithSub,
    ...enrichShared(db, template, userId, links),
    splitGroup: splitGroupSummary(db, template.split_group_id, userId),
  });
});

router.post('/routine-templates', requireAuth, (req, res) => {
  const { name, items, linkId, splitGroupId } = req.body || {};
  const trimmedName = String(name || '').trim();
  if (!trimmedName) return res.status(400).json({ error: '請輸入範本名稱' });
  const itemList = Array.isArray(items) ? items : [];

  for (const it of itemList) {
    if (it && it.remindTime != null && it.remindTime !== '' && !validRemindTime(it.remindTime)) {
      return res.status(400).json({ error: '提醒時間格式要是 HH:MM' });
    }
    const subs = Array.isArray(it && it.subItems) ? it.subItems : [];
    for (const s of subs) {
      if (s && s.remindTime != null && s.remindTime !== '' && !validRemindTime(s.remindTime)) {
        return res.status(400).json({ error: '小項目的提醒時間格式要是 HH:MM' });
      }
    }
  }

  const cleanedItems = itemList
    .map((it) => ({
      title: String((it && it.title) || '').trim(),
      note: (it && it.note) || '',
      dayOffset: Number.isFinite(Number(it && it.dayOffset)) ? Math.trunc(Number(it.dayOffset)) : 0,
      remindTime: (it && it.remindTime) || null,
      subItems: cleanSubItems(it && it.subItems),
    }))
    .filter((it) => it.title);
  if (!cleanedItems.length) return res.status(400).json({ error: '範本至少需要一個項目' });

  const db = getDb();
  const userId = req.session.userId;

  let resolvedLinkId = null;
  if (linkId !== undefined && linkId !== null && linkId !== '') {
    if (!linkBelongsToUser(db, linkId, userId)) return res.status(400).json({ error: '找不到這個共同連結' });
    resolvedLinkId = linkId;
  }
  let resolvedSplitGroupId = resolveSplitGroupId(db, splitGroupId, userId);
  if (resolvedSplitGroupId === false) return res.status(400).json({ error: '找不到這個分帳群組' });
  if (resolvedSplitGroupId === undefined) resolvedSplitGroupId = null;

  const now = new Date().toISOString();
  const result = db
    .prepare('INSERT INTO routine_templates (user_id, name, created_at, link_id, created_by_user_id, split_group_id) VALUES (?, ?, ?, ?, ?, ?)')
    .run(userId, trimmedName, now, resolvedLinkId, userId, resolvedSplitGroupId);
  const templateId = result.lastInsertRowid;
  const insertItem = db.prepare(
    'INSERT INTO routine_template_items (template_id, title, note, day_offset, remind_time, sort_order, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)'
  );
  const insertSubItem = db.prepare(
    'INSERT INTO routine_template_subitems (item_id, title, priority, remind_time, sort_order, created_at) VALUES (?, ?, ?, ?, ?, ?)'
  );
  cleanedItems.forEach((it, idx) => {
    const itemResult = insertItem.run(templateId, it.title, it.note, it.dayOffset, it.remindTime, idx, now);
    const itemId = itemResult.lastInsertRowid;
    it.subItems.forEach((s, sIdx) => insertSubItem.run(itemId, s.title, s.priority, s.remindTime || null, sIdx, now));
  });
  res.json({ id: templateId });
});

router.delete('/routine-templates/:id', requireAuth, (req, res) => {
  const db = getDb();
  const template = db.prepare('SELECT * FROM routine_templates WHERE id = ?').get(req.params.id);
  if (!template || !canAccessSharedItem(db, template, req.session.userId)) return res.status(404).json({ error: '找不到這個範本' });
  db.prepare('DELETE FROM routine_templates WHERE id = ?').run(template.id);
  res.json({ ok: true });
});

// v0.54：套用範本之後才想到要連結分帳群組 (或想換一個/清空)，不用整個範本刪掉重建。
// 只認「操作的這個人自己名下」的分帳群組——就算範本是共同建立的，也不能連去對方的分帳群組。
router.put('/routine-templates/:id/split-group', requireAuth, (req, res) => {
  const db = getDb();
  const userId = req.session.userId;
  const template = db.prepare('SELECT * FROM routine_templates WHERE id = ?').get(req.params.id);
  if (!template || !canAccessSharedItem(db, template, userId)) return res.status(404).json({ error: '找不到這個範本' });
  const resolved = resolveSplitGroupId(db, (req.body || {}).splitGroupId, userId);
  if (resolved === false) return res.status(400).json({ error: '找不到這個分帳群組' });
  db.prepare('UPDATE routine_templates SET split_group_id = ? WHERE id = ?').run(resolved === undefined ? null : resolved, template.id);
  res.json({ ok: true });
});

// 套用範本：以 startDate 為基準，依每個大項的 day_offset 算出到期日，各自建立一筆待辦事項；
// 大項底下的小項目變成那筆待辦事項底下的子任務，各自帶著自己的優先度/提醒時間 (跟大項共用
// 同一個到期日，因為小項目沒有自己的 day_offset，就是「大項那天要做的其中一件事」)。
router.post('/routine-templates/:id/apply', requireAuth, (req, res) => {
  const db = getDb();
  const template = db.prepare('SELECT * FROM routine_templates WHERE id = ?').get(req.params.id);
  if (!template || !canAccessSharedItem(db, template, req.session.userId)) return res.status(404).json({ error: '找不到這個範本' });
  const startDate = (req.body && req.body.startDate) || new Date().toISOString().slice(0, 10);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(startDate)) return res.status(400).json({ error: '起始日期格式不正確' });

  const items = db.prepare('SELECT * FROM routine_template_items WHERE template_id = ? ORDER BY sort_order ASC, id ASC').all(template.id);
  const now = new Date().toISOString();
  const insertTask = db.prepare(
    'INSERT INTO tasks (user_id, title, note, due_date, priority, completed, created_at, remind_at, remind_sent_at) VALUES (?, ?, ?, ?, ?, 0, ?, ?, NULL)'
  );
  const insertSubtask = db.prepare(
    'INSERT INTO task_subtasks (task_id, user_id, title, completed, priority, remind_at, remind_sent_at, sort_order, created_at) VALUES (?, ?, ?, 0, ?, ?, NULL, ?, ?)'
  );

  const createdTaskIds = items.map((item) => {
    const dueDate = addDays(startDate, item.day_offset);
    const itemRemindAt = combineDateAndTime(dueDate, item.remind_time);
    const result = insertTask.run(req.session.userId, item.title, item.note || null, dueDate, 'medium', now, itemRemindAt);
    const taskId = result.lastInsertRowid;

    const subItems = db
      .prepare('SELECT * FROM routine_template_subitems WHERE item_id = ? ORDER BY sort_order ASC, id ASC')
      .all(item.id);
    subItems.forEach((s, idx) => {
      const subRemindAt = combineDateAndTime(dueDate, s.remind_time);
      insertSubtask.run(taskId, req.session.userId, s.title, s.priority, subRemindAt, idx, now);
    });
    return taskId;
  });
  res.json({ ok: true, createdCount: createdTaskIds.length, taskIds: createdTaskIds });
});

module.exports = router;
