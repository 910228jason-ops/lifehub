// 年度回顧 (v0.48)。純粹讀取彙整既有資料表 (日記/心情/記帳/待辦/習慣/讀書)，不需要
// 新增資料表——年度回顧本質上是「把散在各分頁的資料，依年份做一次總結」。
// 年份用 YYYY-01-01 ~ YYYY-12-31 的字串範圍比對日期欄位 (所有日期欄位都是 YYYY-MM-DD
// 或 ISO 字串開頭 YYYY-MM-DD，字串比較跟數字比較結果一致)。

const { Router } = require('../mini-http');
const { getDb } = require('../services/db');
const { requireAuth } = require('../middleware/auth');

const router = Router();

function yearRange(year) {
  return [`${year}-01-01`, `${year}-12-31`];
}

router.get('/annual-review', requireAuth, (req, res) => {
  const db = getDb();
  const userId = req.session.userId;
  const yearParam = parseInt(req.query.year, 10);
  const year = Number.isInteger(yearParam) && yearParam >= 2000 && yearParam <= 9999 ? yearParam : new Date().getUTCFullYear();
  const [from, to] = yearRange(year);

  const diary = db
    .prepare('SELECT COUNT(*) c FROM diary_entries WHERE user_id = ? AND entry_date BETWEEN ? AND ?')
    .get(userId, from, to);

  const mood = db
    .prepare('SELECT COUNT(*) c, AVG(score) avg FROM mood_entries WHERE user_id = ? AND entry_date BETWEEN ? AND ?')
    .get(userId, from, to);

  const financeTotals = db
    .prepare(
      `SELECT type, SUM(amount) total FROM finance_transactions
       WHERE user_id = ? AND tx_date BETWEEN ? AND ? GROUP BY type`
    )
    .all(userId, from, to);
  let income = 0;
  let expense = 0;
  financeTotals.forEach((row) => {
    if (row.type === 'income') income = row.total || 0;
    if (row.type === 'expense') expense = row.total || 0;
  });

  const topExpenseCategories = db
    .prepare(
      `SELECT category, SUM(amount) total FROM finance_transactions
       WHERE user_id = ? AND type = 'expense' AND tx_date BETWEEN ? AND ?
       GROUP BY category ORDER BY total DESC LIMIT 5`
    )
    .all(userId, from, to);

  const tasks = db
    .prepare(
      `SELECT COUNT(*) c FROM tasks
       WHERE user_id = ? AND completed = 1 AND completed_at BETWEEN ? AND ?`
    )
    .get(userId, from, `${to}T23:59:59.999Z`);

  const habits = db
    .prepare('SELECT COUNT(*) c FROM habit_logs WHERE user_id = ? AND log_date BETWEEN ? AND ?')
    .get(userId, from, to);

  const reading = db
    .prepare(
      `SELECT COUNT(*) c FROM reading_items
       WHERE user_id = ? AND status = 'done' AND updated_at BETWEEN ? AND ?`
    )
    .get(userId, from, `${to}T23:59:59.999Z`);

  res.json({
    year,
    diary: { entryCount: diary.c },
    mood: { entryCount: mood.c, avgScore: mood.avg != null ? Math.round(mood.avg * 10) / 10 : null },
    finance: {
      income,
      expense,
      net: income - expense,
      topExpenseCategories: topExpenseCategories.map((r) => ({ category: r.category, total: r.total })),
    },
    tasks: { completedCount: tasks.c },
    habits: { checkinCount: habits.c },
    reading: { doneCount: reading.c },
  });
});

module.exports = router;
