// 政府開放資料 (data.gov.tw 觀光資訊資料庫「景點」，dataset id 7777) 匯入腳本。
//
// 使用時機：等交通部觀光署的 JSON 檔案 (V1.0 格式，scenic_spot_C_f.json) 拿到手之後執行：
//   node scripts/import_gov_places.js --file /path/to/scenic_spot_C_f.json
//   node scripts/import_gov_places.js --file /path/to/scenic_spot_C_f.json --inspect   (先看欄位長相，不寫入)
//   node scripts/import_gov_places.js --file /path/to/scenic_spot_C_f.json --limit 20  (只試跑前 20 筆)
//
// 這支腳本目前是「照文件寫的」，還沒拿到真實檔案跑過一次 —— 因為這個環境連不到
// media.taiwan.net.tw (WebFetch 跟瀏覽器都試過，見對話紀錄)，所以欄位對應是根據
// data.gov.tw 上公開的欄位說明表寫的，不保證跟實際檔案 100%一致。第一次拿到真實檔案時，
// 務必先跑 --inspect 看第一筆資料實際長怎樣，欄位對不上的話這支腳本會印出警告，
// 依警告訊息調整下面 FIELD MAPPING 那段即可，不需要重寫整支腳本。
//
// 匯入策略：
//   - source 一律標記為 'gov'，用 external_id (= AttractionID) 當去重鍵 (見 migrations/044_more_places.sql)。
//     重複執行 (例如排程每天跑一次) 只會新增沒看過的、更新已存在的，不會一直長出重複地點。
//   - 城市名稱正規化：政府資料習慣用「臺」，app 內既有資料 (含使用者輸入) 習慣用「台」，
//     這裡統一轉成「台」，避免「臺中」「台中」被當成兩個不同城市查不到彼此。
//   - 沒有 AttractionName 或無法判斷城市的資料直接跳過 (不猜測、不硬塞髒資料)。
//   - 不寫入任何評分／星等 —— 這份資料本來就沒有這欄，維持「沒有就是沒有，不編造」的原則。

const fs = require('fs');
const path = require('path');
const { loadEnv } = require('../src/services/env');
loadEnv(); // 跟 server.js 一樣先載入 .env，這樣本機測試時 DB_PATH 才會跟伺服器指到同一個檔案
const { getDb } = require('../src/services/db');

function parseArgs(argv) {
  const args = { limit: null, inspect: false, file: null };
  for (let i = 0; i < argv.length; i++) {
    if (argv[i] === '--file') args.file = argv[++i];
    else if (argv[i] === '--limit') args.limit = Number(argv[++i]);
    else if (argv[i] === '--inspect') args.inspect = true;
  }
  return args;
}

function normalizeCity(raw) {
  if (!raw) return null;
  let s = String(raw).trim();
  s = s.replace(/^臺/, '台').replace(/臺/g, '台'); // 政府資料慣用「臺」，app 內統一用「台」
  s = s.replace(/(市|縣)$/, ''); // 「台中市」→「台中」，跟既有資料的城市欄位格式一致
  return s || null;
}

// 政府開放資料常常把地址塞在 PostalAddress，城市要從裡面抓前幾個字；LocatedCities 有時候
// 是縣市代碼而不是中文名稱，所以優先看 PostalAddress，抓不到才退回 LocatedCities。
function extractCity(record) {
  const addr = record.PostalAddress || record.Add || '';
  const m = String(addr).match(/^(台|臺)?(北|中|南|東|高雄|新北|桃園|新竹|苗栗|彰化|南投|雲林|嘉義|屏東|宜蘭|花蓮|台東|臺東|基隆|澎湖|金門|連江)(市|縣)?/);
  if (m) return normalizeCity(m[0]);
  if (record.LocatedCities) {
    const first = Array.isArray(record.LocatedCities) ? record.LocatedCities[0] : record.LocatedCities;
    if (first && /[一-鿿]/.test(String(first))) return normalizeCity(first);
  }
  return null;
}

// 政府資料的心情/交通標籤是我們這邊自己不存在的概念，這裡先全部留空 (使用者/社群評分之後
// 可以照樣運作，只是「臨時揪一波」的 mood/transport 篩選在這批資料生效前會先篩不到)。
// 之後如果想做得更細，可以從 AttractionClasses (景點分類代碼) 對應到 mood_tags，但代碼表
// 內容目前手上沒有實際樣本可以核對，先不亂猜。
function mapRecord(record) {
  const name = (record.AttractionName || record.Name || '').trim();
  if (!name) return null;
  const city = extractCity(record);
  if (!city) return null;

  let duration = null;
  if (record.VisitDuration != null) {
    const n = Number(String(record.VisitDuration).replace(/[^0-9.]/g, ''));
    if (Number.isFinite(n) && n > 0) duration = Math.round(n);
  }

  return {
    external_id: String(record.AttractionID || record.Id || '').trim() || null,
    name,
    city,
    district: null, // PostalAddress 有更細的區資訊，但沒有樣本可以驗證切法，先留空避免切錯
    address: (record.PostalAddress || record.Add || '').trim() || null,
    hours_text: (record.ServiceTimeInfo || record.Opentime || '').trim() || null,
    fee_info: (record.FeeInfo || record.Ticketinfo || '').trim() || null,
    visit_duration_min: duration,
    note: (record.Description || record.Toursim || '').trim().slice(0, 500) || null,
  };
}

function loadRecords(filePath) {
  const raw = fs.readFileSync(filePath, 'utf8');
  const data = JSON.parse(raw);
  // V1.0 格式印象中最外層可能是陣列，也可能包一層 { XML_Head, Infos: { Info: [...] } } 之類的
  // 結構 (政府 XML 轉 JSON 常見包法)。這裡多嘗試幾種常見形狀，都不對的話印出最外層的 key
  // 讓使用者/我自己知道要往哪裡改。
  if (Array.isArray(data)) return data;
  if (data.Infos && Array.isArray(data.Infos.Info)) return data.Infos.Info;
  if (data.XML_Head && data.Infos) return data.Infos.Info || [];
  const keys = Object.keys(data);
  throw new Error(`無法辨識的 JSON 結構，最外層的 key 是: ${keys.join(', ')}。請打開檔案確認資料實際包在哪個欄位下，再調整 loadRecords()。`);
}

function main() {
  const args = parseArgs(process.argv.slice(2));
  if (!args.file) {
    console.error('用法: node scripts/import_gov_places.js --file <path> [--inspect] [--limit N]');
    process.exit(1);
  }
  const filePath = path.resolve(args.file);
  if (!fs.existsSync(filePath)) {
    console.error(`找不到檔案: ${filePath}`);
    process.exit(1);
  }

  const records = loadRecords(filePath);
  console.log(`讀到 ${records.length} 筆原始資料`);

  if (args.inspect) {
    console.log('第一筆資料的所有欄位:');
    console.log(JSON.stringify(records[0], null, 2));
    console.log('\n如果上面欄位名稱跟腳本裡 mapRecord()/extractCity() 假設的不一樣，先改那兩個函式，再拿掉 --inspect 正式跑。');
    return;
  }

  const limited = args.limit ? records.slice(0, args.limit) : records;
  const mapped = limited.map(mapRecord).filter(Boolean);
  const skipped = limited.length - mapped.length;
  console.log(`成功解析 ${mapped.length} 筆，略過 ${skipped} 筆 (缺名稱或判斷不出城市)`);

  const db = getDb();
  const now = new Date().toISOString();
  const findByExternalId = db.prepare(`SELECT id FROM places WHERE source = 'gov' AND external_id = ?`);
  const findByNameCity = db.prepare(`SELECT id FROM places WHERE source = 'gov' AND name = ? AND city = ?`);
  const insert = db.prepare(
    `INSERT INTO places (name, city, district, address, mood_tags, transport_tags, hours_text, fee_info, visit_duration_min, note, source, status, created_by_user_id, external_id, created_at, updated_at)
     VALUES (?, ?, ?, ?, '', '', ?, ?, ?, ?, 'gov', 'active', NULL, ?, ?, ?)`
  );
  const update = db.prepare(
    `UPDATE places SET name = ?, city = ?, address = ?, hours_text = ?, fee_info = ?, visit_duration_min = ?, note = ?, updated_at = ? WHERE id = ?`
  );

  let inserted = 0, updated = 0;
  for (const r of mapped) {
    const existing = r.external_id ? findByExternalId.get(r.external_id) : findByNameCity.get(r.name, r.city);
    if (existing) {
      update.run(r.name, r.city, r.address, r.hours_text, r.fee_info, r.visit_duration_min, r.note, now, existing.id);
      updated++;
    } else {
      insert.run(r.name, r.city, r.district, r.address, r.hours_text, r.fee_info, r.visit_duration_min, r.note, r.external_id, now, now);
      inserted++;
    }
  }
  console.log(`完成：新增 ${inserted} 筆、更新 ${updated} 筆。`);
}

main();
