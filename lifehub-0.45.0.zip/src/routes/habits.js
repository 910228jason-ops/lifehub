// 習慣養成 (v0.45)：iPhone 風格的每日打卡——一個習慣就是一張卡片，today 打勾/取消打勾，
// 顯示連續天數 (streak) 跟最近 7 天的打卡點點陣列，不做複雜的頻率設定 (每週幾次之類)，
// 保持「每天打勾」這個最直覺的心智模型。

const { Router } = require('../mini-http');
const { getDb } = require('../services/db');
const { requireAuth } = require('../middleware/auth');

const router = Router();

function dateStr(d) {
  return d.toISOString().slice(0, 10);
}

// 連續天數的算法：如果「今天」已經打卡，從今天開始往回數連續有打卡的天數；
// 如果「今天」還沒打卡，不代表連續天數歸零 (使用者可能只是還沒打卡而已，這是常見的
// 習慣類 App 慣例)，改成從「昨天」開始往回數，讓使用者今天打卡前還看得到自己原本累積的
// 連續天數，藉此鼓勵他今天也打卡延續下去。
function computeStreak(logDatesSet, todayStr) {
  let streak = 0;
  const cursor = new Date(todayStr + 'T00:00:00Z');
  if (!logDatesSet.has(dateStr(cursor))) {
    cursor.setUTCDate(cursor.getUTCDate() - 1);
  }
  while (logDatesSet.has(dateStr(cursor))) {
    streak++;
    cursor.setUTCDate(cursor.getUTCDate() - 1);
  }
  return streak;
}

function last7Days(logDatesSet, todayStr) {
  const days = [];
  const cursor = new Date(todayStr + 'T00:00:00Z');
  cursor.setUTCDate(cursor.getUTCDate() - 6);
  for (let i = 0; i < 7; i++) {
    const ds = dateStr(cursor);
    days.push({ date: ds, done: logDatesSet.has(ds) });
    cursor.setUTCDate(cursor.getUTCDate() + 1);
  }
  return days;
}

router.get('/habits', requireAuth, (req, res) => {
  const db = getDb();
  const today = new Date().toISOString().slice(0, 10);
  const habits = db.prepare('SELECT * FROM habits WHERE user_id = ? ORDER BY sort_order ASC, id ASC').all(req.session.userId);
  const result = habits.map((h) => {
    const since = new Date(today + 'T00:00:00Z');
    since.setUTCDate(since.getUTCDate() - 60); // 只抓最近 60 天算連續天數就夠了，避免無限往回查資料庫
    const logs = db
      .prepare('SELECT log_date FROM habit_logs WHERE habit_id = ? AND log_date >= ? ORDER BY log_date ASC')
      .all(h.id, dateStr(since));
    const logDatesSet = new Set(logs.map((l) => l.log_date));
    return {
      id: h.id,
      title: h.title,
      icon: h.icon,
      doneToday: logDatesSet.has(today),
      streak: computeStreak(logDatesSet, today),
      last7: last7Days(logDatesSet, today),
    };
  });
  res.json(result);
});

router.post('/habits', requireAuth, (req, res) => {
  const { title, icon } = req.body || {};
  const trimmed = String(title || '').trim();
  if (!trimmed) return res.status(400).json({ error: '請輸入習慣名稱' });
  const db = getDb();
  const maxOrder = db.prepare('SELECT MAX(sort_order) as m FROM habits WHERE user_id = ?').get(req.session.userId);
  const result = db
    .prepare('INSERT INTO habits (user_id, title, icon, sort_order, created_at) VALUES (?, ?, ?, ?, ?)')
    .run(req.session.userId, trimmed, icon || '✅', (maxOrder.m || 0) + 1, new Date().toISOString());
  res.json({ id: result.lastInsertRowid });
});

router.put('/habits/:id', requireAuth, (req, res) => {
  const db = getDb();
  const habit = db.prepare('SELECT * FROM habits WHERE id = ? AND user_id = ?').get(req.params.id, req.session.userId);
  if (!habit) return res.status(404).json({ error: '找不到這個習慣' });
  const { title, icon } = req.body || {};
  const trimmed = title != null ? String(title).trim() : habit.title;
  if (!trimmed) return res.status(400).json({ error: '習慣名稱不能空白' });
  db.prepare('UPDATE habits SET title = ?, icon = ? WHERE id = ?').run(trimmed, icon || habit.icon, habit.id);
  res.json({ ok: true });
});

router.delete('/habits/:id', requireAuth, (req, res) => {
  const db = getDb();
  db.prepare('DELETE FROM habit_logs WHERE habit_id = ? AND user_id = ?').run(req.params.id, req.session.userId);
  db.prepare('DELETE FROM habits WHERE id = ? AND user_id = ?').run(req.params.id, req.session.userId);
  res.json({ ok: true });
});

// 打勾/取消打勾「今天」：不是新增一筆固定加點的紀錄，而是有就刪、沒有就加，
// 符合「打勾框」這種一按就切換狀態的直覺操作。
router.post('/habits/:id/toggle', requireAuth, (req, res) => {
  const db = getDb();
  const habit = db.prepare('SELECT * FROM habits WHERE id = ? AND user_id = ?').get(req.params.id, req.session.userId);
  if (!habit) return res.status(404).json({ error: '找不到這個習慣' });
  const today = new Date().toISOString().slice(0, 10);
  const existing = db.prepare('SELECT id FROM habit_logs WHERE habit_id = ? AND log_date = ?').get(habit.id, today);
  if (existing) {
    db.prepare('DELETE FROM habit_logs WHERE id = ?').run(existing.id);
    res.json({ ok: true, doneToday: false });
  } else {
    db.prepare('INSERT INTO habit_logs (habit_id, user_id, log_date, created_at) VALUES (?, ?, ?, ?)').run(
      habit.id, req.session.userId, today, new Date().toISOString()
    );
    // 遊戲化點數：reason 帶上 habit.id (而不是統一用 'habit')，讓「每個習慣今天各自最多加一次」，
    // 而不是「今天不管打了幾個習慣的勾都只算一次」——否則使用者靠「打勾→取消→再打勾」同一個
    // 習慣還是能重複刷點數 (awardOncePerDay 是用 reason+日期 節流，同一天同一個 reason 只會
    // 成功一次，之後這個習慣今天再怎麼切換都不會再加點)。
    require('../services/points').awardOncePerDay(db, req.session.userId, 1, `habit:${habit.id}`);
    res.json({ ok: true, doneToday: true });
  }
});

module.exports = router;
