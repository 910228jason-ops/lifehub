const { Router } = require('../mini-http');
const { getDb } = require('../services/db');
const { requireAuth } = require('../middleware/auth');
const mood = require('../services/mood');
const logger = require('../services/logger');

const router = Router();

// 對話記錄一樣要用「最近 N 則」的邏輯，跟 assistant.js 同一套修法：
// 先用 id DESC 撈最新的 N 筆，再用 JS reverse() 還原時間順序，
// 避免對話一旦超過上限，AI 就卡在很久以前的內容 (先前版本的 bug)。
const MAX_CHAT_HISTORY = 300;

function fetchRecentChatHistory(db, userId, limit) {
  const rows = db
    .prepare('SELECT role, content, created_at FROM mood_chat_messages WHERE user_id = ? ORDER BY id DESC LIMIT ?')
    .all(userId, limit);
  return rows.reverse();
}

function todayStr() {
  return new Date().toISOString().slice(0, 10);
}

// ---------- 每日心情紀錄 ----------

router.get('/entries', requireAuth, (req, res) => {
  const db = getDb();
  const { from, to } = req.query;
  let rows;
  if (from && to) {
    rows = db
      .prepare('SELECT * FROM mood_entries WHERE user_id = ? AND entry_date BETWEEN ? AND ? ORDER BY entry_date ASC')
      .all(req.session.userId, from, to);
  } else {
    rows = db
      .prepare('SELECT * FROM mood_entries WHERE user_id = ? ORDER BY entry_date DESC LIMIT 60')
      .all(req.session.userId);
  }
  res.json(rows);
});

// 用日期當 key 做 upsert：同一天重複記錄會直接更新，而不是新增多筆。
router.put('/entries/:date', requireAuth, (req, res) => {
  const { date } = req.params;
  const { score, tags, note } = req.body || {};
  const scoreNum = Number(score);
  if (!date || !Number.isInteger(scoreNum) || scoreNum < 1 || scoreNum > 10) {
    return res.status(400).json({ error: '請提供有效的日期與 1-10 的心情分數' });
  }
  const db = getDb();
  const now = new Date().toISOString();
  const tagsStr = Array.isArray(tags) ? tags.join(',') : (tags || null);
  db.prepare(
    `INSERT INTO mood_entries (user_id, entry_date, score, tags, note, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?)
     ON CONFLICT(user_id, entry_date) DO UPDATE SET score = excluded.score, tags = excluded.tags, note = excluded.note, updated_at = excluded.updated_at`
  ).run(req.session.userId, date, scoreNum, tagsStr, note || null, now, now);
  res.json({ ok: true });
});

router.get('/summary', requireAuth, (req, res) => {
  const db = getDb();
  const { days } = req.query;
  const n = Math.min(Math.max(Number(days) || 30, 1), 180);
  const since = new Date();
  since.setDate(since.getDate() - n);
  const sinceStr = since.toISOString().slice(0, 10);

  const rows = db
    .prepare('SELECT entry_date, score, tags FROM mood_entries WHERE user_id = ? AND entry_date >= ? ORDER BY entry_date ASC')
    .all(req.session.userId, sinceStr);

  const avg = rows.length ? rows.reduce((s, r) => s + r.score, 0) / rows.length : null;
  const tagCounts = {};
  rows.forEach((r) => {
    (r.tags || '').split(',').filter(Boolean).forEach((t) => { tagCounts[t] = (tagCounts[t] || 0) + 1; });
  });
  const topTags = Object.entries(tagCounts).sort((a, b) => b[1] - a[1]).slice(0, 5).map(([tag, count]) => ({ tag, count }));

  // ---- 主動關心訊號 ----
  // 1) gapDays：距離「上一次」有紀錄的日子過了幾天，太久沒紀錄就溫和提醒一下 (不是責備)。
  // 2) needsCare：最近連續幾筆分數偏低時，主動給一句關心的話，而不是等使用者自己來找 AI。
  const lastEntry = db
    .prepare('SELECT entry_date FROM mood_entries WHERE user_id = ? ORDER BY entry_date DESC LIMIT 1')
    .get(req.session.userId);
  let gapDays = null;
  if (lastEntry) {
    const last = new Date(lastEntry.entry_date + 'T00:00:00Z');
    const now = new Date(todayStr() + 'T00:00:00Z');
    gapDays = Math.round((now - last) / (1000 * 60 * 60 * 24));
  }

  const recentScores = rows.slice(-3).map((r) => r.score);
  const recentAvg = recentScores.length ? recentScores.reduce((s, v) => s + v, 0) / recentScores.length : null;
  let needsCare = false;
  let careMessage = null;
  if (recentScores.length >= 2 && recentAvg != null && recentAvg <= 4) {
    needsCare = true;
    careMessage = '這幾天感覺你過得比較辛苦，要不要來這裡聊聊？不用勉強，我在這裡。';
  } else if (gapDays != null && gapDays >= 5) {
    careMessage = `已經 ${gapDays} 天沒有記錄心情了，最近還好嗎？有空的話回來寫一筆吧。`;
  }

  res.json({
    series: rows,
    average: avg != null ? Math.round(avg * 10) / 10 : null,
    topTags,
    count: rows.length,
    gapDays,
    needsCare,
    careMessage,
  });
});

// ---------- 心情 × 行事曆 洞察 ----------
// 粗略比對「當天行事曆事項數量」跟「當天心情分數」的關係，
// 給一句自然語言的觀察 (不是嚴謹統計，只是給使用者一個參考角度)。
router.get('/insights', requireAuth, (req, res) => {
  const db = getDb();
  const since = new Date();
  since.setDate(since.getDate() - 30);
  const sinceStr = since.toISOString().slice(0, 10);

  const moodRows = db
    .prepare('SELECT entry_date, score FROM mood_entries WHERE user_id = ? AND entry_date >= ?')
    .all(req.session.userId, sinceStr);

  if (moodRows.length < 5) {
    return res.json({ available: false, message: '心情紀錄還太少，再多記幾天，這裡會幫你看看跟行程的關聯。' });
  }

  const eventRows = db
    .prepare('SELECT event_date, COUNT(*) as cnt FROM calendar_events WHERE user_id = ? AND event_date >= ? GROUP BY event_date')
    .all(req.session.userId, sinceStr);
  const eventCountByDate = {};
  eventRows.forEach((r) => { eventCountByDate[r.event_date] = r.cnt; });

  const BUSY_THRESHOLD = 3;
  const busyScores = [];
  const calmScores = [];
  moodRows.forEach((r) => {
    const cnt = eventCountByDate[r.entry_date] || 0;
    if (cnt >= BUSY_THRESHOLD) busyScores.push(r.score);
    else calmScores.push(r.score);
  });

  if (!busyScores.length || !calmScores.length) {
    return res.json({ available: false, message: '再累積一些不同忙碌程度的日子，這裡會幫你看看跟行程的關聯。' });
  }

  const avgBusy = Math.round((busyScores.reduce((s, v) => s + v, 0) / busyScores.length) * 10) / 10;
  const avgCalm = Math.round((calmScores.reduce((s, v) => s + v, 0) / calmScores.length) * 10) / 10;
  const diff = Math.round((avgCalm - avgBusy) * 10) / 10;

  let message;
  if (diff >= 1) {
    message = `行程比較滿的日子 (當天 ${BUSY_THRESHOLD} 件事以上)，平均心情分數是 ${avgBusy} 分；行程比較鬆的日子平均是 ${avgCalm} 分。忙碌的日子心情容易比較低，排行程時可以留一點喘息空間給自己。`;
  } else if (diff <= -1) {
    message = `有趣的是，行程比較滿的日子平均心情反而是 ${avgBusy} 分，比較鬆的日子是 ${avgCalm} 分——對你來說，充實地忙可能反而是件好事。`;
  } else {
    message = `行程忙碌程度 (忙碌日平均 ${avgBusy} 分／較鬆日平均 ${avgCalm} 分) 跟你的心情分數目前看起來沒有明顯關聯，心情可能更多受其他事情影響。`;
  }

  res.json({ available: true, avgBusy, avgCalm, busyDays: busyScores.length, calmDays: calmScores.length, message });
});

// ---------- 這週 AI 回顧 ----------

router.post('/weekly-review', requireAuth, async (req, res) => {
  const db = getDb();
  const since = new Date();
  since.setDate(since.getDate() - 7);
  const sinceStr = since.toISOString().slice(0, 10);
  const entries = db
    .prepare('SELECT entry_date, score, tags, note FROM mood_entries WHERE user_id = ? AND entry_date >= ? ORDER BY entry_date ASC')
    .all(req.session.userId, sinceStr);

  try {
    const result = await mood.generateWeeklyReview(entries);
    res.json(result);
  } catch (e) {
    logger.error('心情週回顧產生失敗', { error: e.message });
    res.status(502).json({ error: '這週回顧暫時無法產生，請稍後再試', detail: e.message });
  }
});

// ---------- 安心小卡 (coping notes) ----------

router.get('/coping-notes', requireAuth, (req, res) => {
  const db = getDb();
  const rows = db
    .prepare('SELECT id, content, created_at FROM mood_coping_notes WHERE user_id = ? ORDER BY id DESC')
    .all(req.session.userId);
  res.json(rows);
});

router.post('/coping-notes', requireAuth, (req, res) => {
  const { content } = req.body || {};
  if (!content || !String(content).trim()) {
    return res.status(400).json({ error: '請提供小卡內容' });
  }
  const db = getDb();
  const now = new Date().toISOString();
  const result = db
    .prepare('INSERT INTO mood_coping_notes (user_id, content, created_at) VALUES (?, ?, ?)')
    .run(req.session.userId, String(content).trim(), now);
  res.json({ id: result.lastInsertRowid, content: String(content).trim(), created_at: now });
});

router.delete('/coping-notes/:id', requireAuth, (req, res) => {
  const db = getDb();
  db.prepare('DELETE FROM mood_coping_notes WHERE id = ? AND user_id = ?').run(req.params.id, req.session.userId);
  res.json({ ok: true });
});

// ---------- 情緒陪伴對話 (獨立於一般 AI 助理) ----------

router.get('/chat/history', requireAuth, (req, res) => {
  const db = getDb();
  res.json(fetchRecentChatHistory(db, req.session.userId, MAX_CHAT_HISTORY));
});

router.post('/chat', requireAuth, async (req, res) => {
  const { message } = req.body || {};
  if (!message || !String(message).trim()) {
    return res.status(400).json({ error: '請提供 message' });
  }
  const db = getDb();
  const now = new Date().toISOString();
  const crisisNow = mood.detectCrisisSignal(message);
  db.prepare('INSERT INTO mood_chat_messages (user_id, role, content, flagged, created_at) VALUES (?, ?, ?, ?, ?)').run(
    req.session.userId,
    'user',
    message,
    crisisNow ? 1 : 0,
    now
  );

  const history = fetchRecentChatHistory(db, req.session.userId, MAX_CHAT_HISTORY);

  try {
    const result = await mood.chatMoodCompanion(history);
    db.prepare('INSERT INTO mood_chat_messages (user_id, role, content, flagged, created_at) VALUES (?, ?, ?, ?, ?)').run(
      req.session.userId,
      'assistant',
      result.reply,
      result.crisisDetected ? 1 : 0,
      new Date().toISOString()
    );
    res.json(result);
  } catch (e) {
    logger.error('心情陪伴對話失敗', { error: e.message });
    res.status(502).json({ error: 'AI 陪伴暫時無法回應，請稍後再試', detail: e.message });
  }
});

router.delete('/chat/history', requireAuth, (req, res) => {
  const db = getDb();
  db.prepare('DELETE FROM mood_chat_messages WHERE user_id = ?').run(req.session.userId);
  res.json({ ok: true });
});

module.exports = router;
