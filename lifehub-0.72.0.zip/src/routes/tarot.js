// 塔羅占卜 (v0.70)。牌卡資料是純靜態的 (見 src/data/tarotDeck.js)，抽牌只是伺服器端
// 用 crypto 亂數從 78 張牌裡挑，完全不接任何外部占卜/AI API——先把「有牌可以抽、抽完
// 看得懂牌義」這個最基本的版本做完整，之後如果要做「AI 幫你把牌義結合最近日記/心情
// 寫成客製化解讀」，會是另一支獨立的功能，不影響這裡的基礎資料。
//
// 這支檔案沒有用 app.mount() 單獨掛載，而是比照 feedback.js/wishlist.js 等的做法，
// 被 debug.js 合併進已經掛在 /api 的共用 router，所以每個路由都要自己帶 /tarot 前綴。

const crypto = require('crypto');
const { Router } = require('../mini-http');
const { getDb } = require('../services/db');
const { requireAuth } = require('../middleware/auth');
const { TAROT_DECK, getCardByKey } = require('../data/tarotDeck');
const assistant = require('../services/assistant');

const router = Router();

const SPREADS = {
  single: { count: 1, label: '單張牌：今日/此刻的指引' },
  three: { count: 3, label: '三張牌：過去 / 現在 / 未來' },
};

// 用 crypto.randomInt 而不是 Math.random，抽牌這種「求一個公平的隨機結果」的場景，
// 用密碼學等級的亂數來源比較讓人放心 (雖然這裡不是安全性敏感的用途，但反正 Node
// 內建就有，不需要額外依賴，就直接用比較嚴謹的版本)。
function drawRandomCards(count) {
  const pool = TAROT_DECK.slice();
  const drawn = [];
  for (let i = 0; i < count && pool.length > 0; i++) {
    const idx = crypto.randomInt(0, pool.length);
    const card = pool.splice(idx, 1)[0];
    const reversed = crypto.randomInt(0, 2) === 1;
    drawn.push({ key: card.key, reversed });
  }
  return drawn;
}

function hydrateCard(entry) {
  const card = getCardByKey(entry.key);
  if (!card) return null;
  const side = entry.reversed ? card.reversed : card.upright;
  return {
    key: card.key,
    name: card.name,
    arcana: card.arcana,
    reversed: !!entry.reversed,
    keyword: side.keyword,
    meaning: side.meaning,
  };
}

router.get('/tarot/spreads', requireAuth, (req, res) => {
  res.json({
    spreads: Object.keys(SPREADS).map((key) => ({ key, ...SPREADS[key] })),
  });
});

router.post('/tarot/draw', requireAuth, (req, res) => {
  const { spreadType, question } = req.body || {};
  const spread = SPREADS[spreadType] ? spreadType : 'single';
  const drawnEntries = drawRandomCards(SPREADS[spread].count);
  const cards = drawnEntries.map(hydrateCard).filter(Boolean);

  const db = getDb();
  const now = new Date().toISOString();
  const result = db
    .prepare('INSERT INTO tarot_draws (user_id, spread_type, cards_json, question, created_at) VALUES (?, ?, ?, ?, ?)')
    .run(req.session.userId, spread, JSON.stringify(drawnEntries), (question && String(question).trim().slice(0, 300)) || null, now);

  res.json({
    id: result.lastInsertRowid,
    spreadType: spread,
    spreadLabel: SPREADS[spread].label,
    question: (question && String(question).trim().slice(0, 300)) || null,
    cards,
    aiReading: null,
    createdAt: now,
  });
});

// 補記一句自己的心得/備註到某一次抽牌紀錄 (抽完當下可能還沒想好要寫什麼，之後回來補)。
router.put('/tarot/draws/:id/note', requireAuth, (req, res) => {
  const db = getDb();
  const draw = db.prepare('SELECT * FROM tarot_draws WHERE id = ? AND user_id = ?').get(req.params.id, req.session.userId);
  if (!draw) return res.status(404).json({ error: '找不到這筆占卜紀錄' });
  const note = req.body && req.body.note != null ? String(req.body.note).trim().slice(0, 1000) : null;
  db.prepare('UPDATE tarot_draws SET note = ? WHERE id = ?').run(note || null, draw.id);
  res.json({ ok: true });
});

// 塔羅 AI 解讀的人設：明確定位成「幫你把牌義跟你問題連起來想的小幫手」，不裝真的通靈，
// 語氣上不要太玄虛/宿命論，避免使用者真的把建議當成不能改變的命運來解讀。
const TAROT_READING_SYSTEM_PROMPT = `你是 LifeHub 這款生活整合 App 裡「塔羅占卜」小功能的解讀小幫手。
使用者剛剛抽了牌，你的工作是：把使用者問的問題，結合他抽到的牌 (含正逆位、關鍵字、牌義)，
寫一段大約 150-250 字的繁體中文解讀，語氣溫暖、務實、像朋友給建議，不要裝作是真的通靈占卜師、
不要用「命中註定」「一定會」這種絕對用語，重點放在「這張牌的意涵可以怎麼幫你思考這個問題」，
可以在最後提出一個小小的、可行動的建議或反思方向。如果使用者沒有填問題，就針對抽到的牌本身，
給一段適合「今日指引」或「近期提醒」的解讀就好。請直接輸出解讀內容，不要加開場白或「以下是解讀」之類的話。`;

function buildTarotReadingPrompt(question, cards) {
  const cardLines = cards
    .map((c, i) => `第${i + 1}張：${c.name}${c.reversed ? '（逆位）' : '（正位）'} — 關鍵字：${c.keyword}；牌義：${c.meaning}`)
    .join('\n');
  const questionLine = question ? `使用者想問的問題：${question}` : '使用者這次沒有特別填問題，請針對抽到的牌給一般性的指引。';
  return `${questionLine}\n\n抽到的牌：\n${cardLines}\n\n請根據以上資訊寫一段解讀。`;
}

// 幫某一次抽牌紀錄產生 AI 客製化解讀 (結合當初填的問題 + 抽到的牌)，存回這筆紀錄，
// 之後在占卜紀錄列表也看得到，不用每次重新產生。
router.post('/tarot/draws/:id/ai-reading', requireAuth, async (req, res) => {
  const db = getDb();
  const draw = db.prepare('SELECT * FROM tarot_draws WHERE id = ? AND user_id = ?').get(req.params.id, req.session.userId);
  if (!draw) return res.status(404).json({ error: '找不到這筆占卜紀錄' });

  let entries = [];
  try { entries = JSON.parse(draw.cards_json); } catch (e) { entries = []; }
  const cards = entries.map(hydrateCard).filter(Boolean);
  if (!cards.length) return res.status(400).json({ error: '這筆紀錄沒有牌卡資料' });

  const prompt = buildTarotReadingPrompt(draw.question, cards);
  try {
    const result = await assistant.chat([{ role: 'user', content: prompt }], { systemPrompt: TAROT_READING_SYSTEM_PROMPT });
    if (!result.isConfigured) {
      return res.json({ isConfigured: false, aiReading: null, reply: result.reply });
    }
    db.prepare('UPDATE tarot_draws SET ai_reading = ? WHERE id = ?').run(result.reply, draw.id);
    res.json({ isConfigured: true, aiReading: result.reply });
  } catch (e) {
    res.status(502).json({ error: 'AI 解讀產生失敗', detail: e.message });
  }
});

router.get('/tarot/history', requireAuth, (req, res) => {
  const db = getDb();
  const limit = Math.min(Math.max(Number(req.query.limit) || 20, 1), 100);
  const rows = db
    .prepare('SELECT * FROM tarot_draws WHERE user_id = ? ORDER BY id DESC LIMIT ?')
    .all(req.session.userId, limit);
  const items = rows.map((r) => {
    let entries = [];
    try { entries = JSON.parse(r.cards_json); } catch (e) { entries = []; }
    return {
      id: r.id,
      spreadType: r.spread_type,
      spreadLabel: (SPREADS[r.spread_type] || {}).label || r.spread_type,
      question: r.question,
      note: r.note,
      cards: entries.map(hydrateCard).filter(Boolean),
      aiReading: r.ai_reading || null,
      createdAt: r.created_at,
    };
  });
  res.json({ items });
});

module.exports = router;
