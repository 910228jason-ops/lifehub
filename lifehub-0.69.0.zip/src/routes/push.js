// 背景推播通知 (Web Push) 的 HTTP 端點 + 背景排程。
//
// 端點有四支：
//   GET  /push/vapid-public-key —— 前端訂閱時要帶的公鑰 (公開資訊，不需要登入也能拿)
//   POST /push/subscribe        —— 前端把瀏覽器 PushManager.subscribe() 拿到的訂閱資訊存起來
//   POST /push/unsubscribe      —— 使用者關閉通知時，刪掉這筆訂閱
//   POST /push/test             —— 立刻送一則測試通知給自己，不用等背景排程 (最長 30 分鐘)
//                                   才能確認手機/電腦真的收得到，方便剛開通時馬上驗證
//
// 背景排程 (每 30 分鐘跑一次)：對每個「至少有一筆有效訂閱」的使用者，重複使用
// insights.js 的 computeReminders() 算出目前有哪些提醒，跟上次送過的內容比對
// (push_notify_log)，內容有變化、或超過 24 小時沒送過，才真的推播一次，
// 避免同樣的事情反覆打擾使用者。
//
// 靜音時段 + 合併通知：三支排程 (一般提醒/精準待辦提醒/服藥提醒) 送出通知前都會先經過
// services/notifyQueue.js 的 queueNotification()。被動的一般提醒 (urgent: false) 晚上
// 11 點到早上 10 點不推播，而且同一個使用者短時間 (90 秒) 內累積到的多筆這種提醒會合併成
// 一則送出，不會連續跳出好幾則造成轟炸感。使用者自己設定精準時間要求的提醒 (待辦精準提醒/
// 服藥提醒，urgent: true) 則完全相反：不受靜音時段限制、也「不」跟其他通知合併，一律各自
// 立刻送出——這是使用者主動指定要在那個時間點看到的內容，不能被埋進合併通知裡。詳細規則見
// notifyQueue.js 的說明。
//
// 跟 feedback.js / insights.js 一樣，這裡不另外掛 app.mount()，而是被 debug.js
// 合併進已經掛在 /api 的 router，所以路徑實際上是 /api/push/*。
// 排程本身則放在這個檔案的最外層 (module 第一次被 require 時就啟動)，這樣完全
// 不用碰 server.js，跟這個專案「刻意不去動 server.js」的部署方式一致。

const { Router } = require('../mini-http');
const { getDb } = require('../services/db');
const { requireAuth } = require('../middleware/auth');
const { getOrCreateVapidKeys, sendNotification } = require('../services/webpush');
const { queueNotification } = require('../services/notifyQueue');
const insights = require('./insights');
const logger = require('../services/logger');

const router = Router();

// v0.68：#10 通知有效性回饋迴圈——每種提醒類型 (type) 送出後，使用者有沒有在合理時間內
// 真的採取對應的行動 (完成任務/繳帳單/記心情/記互動...)。用 24 小時當「有效」的判斷窗口，
// 不是所有類型都有明確對應的行動可以比對 (例如 partner-cycle 沒有一個「對應動作」)，
// 沒有比對函式的類型就不列入統計，不亂猜。
function moodActionCheck(db, userId, fromIso, toIso) {
  return !!db.prepare('SELECT 1 FROM mood_entries WHERE user_id = ? AND updated_at BETWEEN ? AND ? LIMIT 1').get(userId, fromIso, toIso);
}
const NOTIFICATION_ACTION_CHECKS = {
  'bill-amount-anomaly': (db, userId, fromIso, toIso) =>
    !!db.prepare('SELECT 1 FROM bill_payments WHERE user_id = ? AND created_at BETWEEN ? AND ? LIMIT 1').get(userId, fromIso, toIso),
  'task-procrastination': (db, userId, fromIso, toIso) =>
    !!db.prepare('SELECT 1 FROM tasks WHERE user_id = ? AND completed = 1 AND completed_at BETWEEN ? AND ? LIMIT 1').get(userId, fromIso, toIso),
  'mood-trend-mild': moodActionCheck,
  'mood-trend-concern': moodActionCheck,
  'mood-social-checkin': moodActionCheck,
  'relationship-checkin': (db, userId, fromIso, toIso) =>
    !!db.prepare('SELECT 1 FROM relationship_interactions WHERE user_id = ? AND created_at BETWEEN ? AND ? LIMIT 1').get(userId, fromIso, toIso),
  'emotional-spending-pattern': (db, userId, fromIso, toIso) =>
    !!db.prepare('SELECT 1 FROM finance_transactions WHERE user_id = ? AND created_at BETWEEN ? AND ? LIMIT 1').get(userId, fromIso, toIso),
};
const EFFECTIVENESS_WINDOW_MS = 24 * 60 * 60 * 1000;

function logNotificationSend(db, userId, items) {
  try {
    const sentAt = new Date().toISOString();
    const insertLog = db.prepare('INSERT INTO notification_send_log (user_id, type, sent_at) VALUES (?, ?, ?)');
    items.forEach((i) => insertLog.run(userId, i.type || 'other', sentAt));
  } catch (e) { /* migration 還沒套用時忽略，不影響推播本身 */ }
}

// 依歷史有效率排序提醒項目——有明確比對函式、而且過去有累積足夠送出次數的類型，
// 有效率高的排前面 (被塞進合併通知的前 3 則摘要時比較有機會被真的看到)；沒有歷史資料
// 或沒有比對函式的類型維持原本順序 (不亂猜、不因為資料不足就排到最後面)。
function sortItemsByEffectiveness(db, userId, items) {
  if (items.length <= 1) return items;
  let rateByType;
  try {
    const since = new Date(Date.now() - 30 * EFFECTIVENESS_WINDOW_MS).toISOString();
    const logs = db.prepare('SELECT type, sent_at FROM notification_send_log WHERE user_id = ? AND sent_at >= ?').all(userId, since);
    rateByType = {};
    const byType = {};
    logs.forEach((l) => { (byType[l.type] = byType[l.type] || []).push(l.sent_at); });
    Object.keys(byType).forEach((type) => {
      const checkFn = NOTIFICATION_ACTION_CHECKS[type];
      if (!checkFn || byType[type].length < 3) return; // 樣本太少不列入排序依據
      const sends = byType[type];
      const acted = sends.filter((sentAt) => checkFn(db, userId, sentAt, new Date(new Date(sentAt).getTime() + EFFECTIVENESS_WINDOW_MS).toISOString())).length;
      rateByType[type] = acted / sends.length;
    });
  } catch (e) { return items; } // migration 還沒套用時直接維持原順序
  const scoreOf = (i) => (rateByType[i.type] != null ? rateByType[i.type] : 0.5); // 沒有資料的當中性值，不影響排序太多
  return [...items].sort((a, b) => scoreOf(b) - scoreOf(a));
}

// ---- 推播通知圖示：依「收到通知的這個人」自己最近 7 天的心情平均分數，挑一個色調 ----
// 跟 App 主畫面圖示不同——主畫面圖示是手機快取的固定圖片，沒辦法動態換；
// 但推播通知是每次伺服器現送的，圖示網址可以每次都不一樣，所以做得到「因人而異、因時而異」。
// 三個檔案是同一個屋型輪廓圖案，只有色調不同 (public/icons/icon-192-care.png 等)，
// 分數沒有紀錄時 (avg === null) 一律用預設色，不猜測、不亂套用溫暖色。
function moodIconPath(db, userId) {
  try {
    const rows = db
      .prepare("SELECT score FROM mood_entries WHERE user_id = ? AND entry_date >= date('now','-7 day')")
      .all(userId);
    if (!rows.length) return '/icons/icon-192.png';
    const avg = rows.reduce((s, r) => s + r.score, 0) / rows.length;
    if (avg <= 4) return '/icons/icon-192-care.png';
    if (avg >= 8) return '/icons/icon-192-bright.png';
    return '/icons/icon-192.png';
  } catch (e) {
    return '/icons/icon-192.png'; // migration 還沒套用等異常狀況，一律退回預設圖示，不讓推播因此失敗
  }
}

router.get('/push/vapid-public-key', (req, res) => {
  const db = getDb();
  const { publicKeyB64 } = getOrCreateVapidKeys(db);
  res.json({ publicKey: publicKeyB64 });
});

router.post('/push/subscribe', requireAuth, (req, res) => {
  const { endpoint, keys } = req.body || {};
  if (!endpoint || !keys || !keys.p256dh || !keys.auth) {
    return res.status(400).json({ error: '缺少訂閱資訊 (endpoint/keys)' });
  }
  const db = getDb();
  const now = new Date().toISOString();
  db.prepare(
    `INSERT INTO push_subscriptions (user_id, endpoint, p256dh, auth, created_at)
     VALUES (?, ?, ?, ?, ?)
     ON CONFLICT(endpoint) DO UPDATE SET user_id = excluded.user_id, p256dh = excluded.p256dh, auth = excluded.auth`
  ).run(req.session.userId, endpoint, keys.p256dh, keys.auth, now);
  res.json({ ok: true });
});

router.post('/push/unsubscribe', requireAuth, (req, res) => {
  const { endpoint } = req.body || {};
  const db = getDb();
  if (endpoint) {
    db.prepare('DELETE FROM push_subscriptions WHERE user_id = ? AND endpoint = ?').run(req.session.userId, endpoint);
  } else {
    db.prepare('DELETE FROM push_subscriptions WHERE user_id = ?').run(req.session.userId);
  }
  res.json({ ok: true });
});

router.post('/push/test', requireAuth, async (req, res) => {
  const db = getDb();
  const subs = db.prepare('SELECT * FROM push_subscriptions WHERE user_id = ?').all(req.session.userId);
  if (!subs.length) {
    return res.status(400).json({ error: '目前沒有已訂閱的裝置，請先按「開啟背景推播通知」' });
  }
  const results = [];
  for (const sub of subs) {
    try {
      const r = await sendNotification(db, sub, {
        title: '推播測試成功',
        body: '收到這則通知，代表背景推播已經設定好了，之後不會漏接任何提醒。',
        icon: moodIconPath(db, req.session.userId),
      });
      results.push({ ok: r.ok, status: r.status });
      if (!r.ok && (r.status === 404 || r.status === 410)) {
        db.prepare('DELETE FROM push_subscriptions WHERE id = ?').run(sub.id);
      }
    } catch (e) {
      logger.error('[push] 測試推播失敗', { userId: req.session.userId, message: e.message });
      results.push({ ok: false, error: e.message });
    }
  }
  const anyOk = results.some((r) => r.ok);
  res.json({ ok: anyOk, results });
});

// v0.68：#10 通知有效性回饋——回傳過去 30 天內，每種有比對函式的提醒類型送出後，
// 24 小時內使用者有沒有真的採取對應行動的比例，給使用者/自己參考「哪種提醒真的有用」。
router.get('/push/effectiveness', requireAuth, (req, res) => {
  const db = getDb();
  const userId = req.session.userId;
  let logs = [];
  try {
    const since = new Date(Date.now() - 30 * EFFECTIVENESS_WINDOW_MS).toISOString();
    logs = db.prepare('SELECT type, sent_at FROM notification_send_log WHERE user_id = ? AND sent_at >= ?').all(userId, since);
  } catch (e) {
    return res.json({ hasEnoughData: false, note: '資料表尚未就緒，請稍後再試。' });
  }
  if (!logs.length) return res.json({ hasEnoughData: false, note: '目前還沒有推播紀錄可以分析。' });

  const byType = {};
  logs.forEach((l) => { (byType[l.type] = byType[l.type] || []).push(l.sent_at); });

  const results = Object.entries(byType)
    .map(([type, sends]) => {
      const checkFn = NOTIFICATION_ACTION_CHECKS[type];
      if (!checkFn) return null; // 沒有明確對應動作可以比對的類型，不列入 (例如 partner-cycle)
      const acted = sends.filter((sentAt) => checkFn(db, userId, sentAt, new Date(new Date(sentAt).getTime() + EFFECTIVENESS_WINDOW_MS).toISOString())).length;
      return { type, sendCount: sends.length, actedCount: acted, effectivenessRate: Math.round((acted / sends.length) * 1000) / 10 };
    })
    .filter(Boolean)
    .sort((a, b) => b.sendCount - a.sendCount);

  res.json({ hasEnoughData: results.length > 0, results, disclaimer: '「有效」定義為送出後 24 小時內做了對應的動作 (例如任務提醒後完成任務)，只是粗略的行為觀察，不是精確的因果分析。' });
});

// ---- 背景排程：每 30 分鐘算一次每個使用者的提醒，內容有變或超過 24hr 才推播 ----
const CHECK_INTERVAL_MS = 30 * 60 * 1000;
const HEARTBEAT_MS = 24 * 60 * 60 * 1000;

async function runNotifyCycle() {
  const db = getDb();
  let userIds = [];
  try {
    userIds = db.prepare('SELECT DISTINCT user_id FROM push_subscriptions').all().map((r) => r.user_id);
  } catch (e) {
    return; // migration 還沒套用/資料表不存在時直接跳過，等下一輪
  }

  for (const userId of userIds) {
    try {
      let items = insights.computeReminders(db, userId);
      if (!items.length) continue;

      // 生日提醒、另一半生理週期提醒，預設都只出現在首頁 (computeReminders 算出來的原始
      // 清單一定包含)，要不要「推播」出去由使用者在設定頁自己決定，這裡用來過濾要推播的
      // 內容；首頁的 /insights/reminders 走另一支路徑、沒有經過這個過濾，所以首頁永遠看得到。
      let pushBirthday = false, pushPartnerCycle = false, pushMoodSocial = false;
      try {
        const prefsRow = db.prepare('SELECT push_birthday_reminders, push_partner_cycle_reminders, push_mood_social_reminders FROM user_prefs WHERE user_id = ?').get(userId);
        pushBirthday = !!(prefsRow && prefsRow.push_birthday_reminders);
        pushPartnerCycle = !!(prefsRow && prefsRow.push_partner_cycle_reminders);
        // push_mood_social_reminders 是 v0.63 才加的欄位——「心情持續偏低+該聯絡的人」這則
        // 提醒的推播內容會直接寫出「你最近心情比較低落」，顯示在鎖定畫面上比較敏感，比照生日/
        // 另一半週期提醒同一套「預設關閉、使用者自己決定」的做法。
        pushMoodSocial = !!(prefsRow && prefsRow.push_mood_social_reminders);
      } catch (e) { /* 欄位還不存在時當作沒開啟 */ }
      // v0.65：mood-social-checkin 分級之後多了 mood-trend-mild / mood-trend-concern 兩種
      // 新的心情提醒類型 (見 insights.js)，內容一樣會提到心情狀態，鎖定畫面顯示同樣敏感，
      // 沿用同一個 push_mood_social_reminders 開關 (不需要另外多加一個設定選項)。
      const MOOD_SENSITIVE_TYPES = new Set(['mood-social-checkin', 'mood-trend-mild', 'mood-trend-concern']);
      items = items.filter((i) => (i.type !== 'birthday' || pushBirthday) && (i.type !== 'partner-cycle' || pushPartnerCycle) && (!MOOD_SENSITIVE_TYPES.has(i.type) || pushMoodSocial));
      if (!items.length) continue;

      const signature = JSON.stringify(items.map((i) => `${i.severity}:${i.text}`));
      const logRow = db.prepare('SELECT * FROM push_notify_log WHERE user_id = ?').get(userId);
      const now = Date.now();
      const lastSentAt = logRow && logRow.last_sent_at ? new Date(logRow.last_sent_at).getTime() : 0;
      const sameAsLast = logRow && logRow.last_signature === signature;
      if (sameAsLast && now - lastSentAt < HEARTBEAT_MS) continue; // 內容沒變、還沒到 24hr，不重複打擾

      const sortedItems = sortItemsByEffectiveness(db, userId, items);
      const top = sortedItems.slice(0, 3);
      const title = items.length > 1 ? `${items.length} 件事需要留意` : (top[0].text || '提醒');
      const body = items.length > 1
        ? top.map((i) => `${i.icon || ''} ${i.text}`).join('\n')
        : '點開看看詳細內容';

      const icon = moodIconPath(db, userId);
      // 帳單快到期/待辦逾期/好幾天沒記心情/生日/另一半生理週期，都是「被動提醒」，使用者
      // 沒有指定要在哪個精準時間收到，屬於非緊急——晚上 11 點到早上 10 點的靜音時段內不推播
      // (交給 queueNotification 判斷)，而且會跟同一時段內的其他提醒合併成一則，不個別轟炸。
      const queued = queueNotification(db, userId, { title, body, icon, urgent: false });
      // 靜音時段被跳過時 (queued === false) 不寫入 push_notify_log：如果無條件標記成「送過
      // 了」，靜音時段一結束，同樣內容的提醒會被誤判成「24小時內推播過」而永遠不會真的送出。
      // 不寫 log 的代價只是接下來每 30 分鐘會重算一次同樣的內容，沒有其他副作用。
      if (!queued) continue;
      logNotificationSend(db, userId, items);

      const nowIso = new Date().toISOString();
      db.prepare(
        `INSERT INTO push_notify_log (user_id, last_signature, last_sent_at) VALUES (?, ?, ?)
         ON CONFLICT(user_id) DO UPDATE SET last_signature = excluded.last_signature, last_sent_at = excluded.last_sent_at`
      ).run(userId, signature, nowIso);
    } catch (e) {
      logger.error('[push] 計算提醒失敗', { userId, message: e.message });
    }
  }
}

// ---- 精準時間提醒 (待辦事項的 remind_at)：例如跟 AI 助理說「2分鐘後提醒我裝水」----
// 跟上面「每 30 分鐘、內容有變才推播」的日常提醒邏輯不同，這裡要「準時」——每 15 秒掃一次
// 全部使用者裡「到期但還沒推播過」的任務 (remind_at <= 現在 AND remind_sent_at IS NULL)，
// 時間一到就立刻推播，不受內容比對/24小時節流限制 (使用者明確要求的一次性提醒，本來就該準時)。
const REMINDER_CHECK_INTERVAL_MS = 15 * 1000;

async function runTaskReminderCycle() {
  const db = getDb();
  let dueTasks = [];
  try {
    const nowIso = new Date().toISOString();
    dueTasks = db
      .prepare('SELECT * FROM tasks WHERE remind_at IS NOT NULL AND remind_sent_at IS NULL AND remind_at <= ? AND completed = 0')
      .all(nowIso);
  } catch (e) {
    return; // migration 還沒套用/資料表欄位不存在時直接跳過，等下一輪
  }
  if (!dueTasks.length) return;

  for (const task of dueTasks) {
    try {
      // 使用者自己明確設定要在這個精準時間被提醒 (例如跟 AI 助理說「2分鐘後提醒我」)，
      // 算是「緊急」——不受靜音時段限制，該幾點提醒就幾點提醒；而且是使用者自己特別要求的
      // 提醒，不會跟其他通知合併，一律獨立、立刻送出。
      queueNotification(db, task.user_id, {
        title: task.title,
        body: '提醒時間到了，別忘記這件事。',
        icon: moodIconPath(db, task.user_id),
        urgent: true,
      });
      // 就算使用者目前沒有任何有效訂閱 (例如還沒開啟背景推播)，還是要蓋上 remind_sent_at，
      // 不然這筆任務會被每 15 秒重複掃到、無限空跑；待辦事項本身仍然會照常留在清單上。
      db.prepare('UPDATE tasks SET remind_sent_at = ? WHERE id = ?').run(new Date().toISOString(), task.id);
    } catch (e) {
      logger.error('[push] 精準提醒處理失敗', { taskId: task.id, message: e.message });
    }
  }
}

// v0.53：小任務 (task_subtasks) 現在也能各自設定精準提醒時間，邏輯完全比照上面的
// runTaskReminderCycle，只是多 JOIN 一下母任務的標題，讓推播內容看得出「這是哪個大任務底下
// 的哪個小項目」(例如「出門 > 帶護照」)，不然只顯示「帶護照」使用者可能想不起來是哪件事。
async function runSubtaskReminderCycle() {
  const db = getDb();
  let dueSubtasks = [];
  try {
    const nowIso = new Date().toISOString();
    dueSubtasks = db
      .prepare(
        `SELECT s.id, s.title as sub_title, s.user_id, t.title as task_title
         FROM task_subtasks s JOIN tasks t ON t.id = s.task_id
         WHERE s.remind_at IS NOT NULL AND s.remind_sent_at IS NULL AND s.remind_at <= ? AND s.completed = 0 AND t.completed = 0`
      )
      .all(nowIso);
  } catch (e) {
    return; // migration 還沒套用/資料表欄位不存在時直接跳過，等下一輪
  }
  if (!dueSubtasks.length) return;

  for (const sub of dueSubtasks) {
    try {
      queueNotification(db, sub.user_id, {
        title: `${sub.task_title} > ${sub.sub_title}`,
        body: '提醒時間到了，別忘記這件事。',
        icon: moodIconPath(db, sub.user_id),
        urgent: true,
      });
      db.prepare('UPDATE task_subtasks SET remind_sent_at = ? WHERE id = ?').run(new Date().toISOString(), sub.id);
    } catch (e) {
      logger.error('[push] 小任務精準提醒處理失敗', { subtaskId: sub.id, message: e.message });
    }
  }
}

// ---- 服藥提醒：health_meds.schedule_time 一直存在資料庫裡但沒有真的接上推播，這裡補上 ----
// 每分鐘掃一次「有設定服用時間、還在使用中」的藥，時間對上現在的 HH:MM 就推播，
// 用 health_med_reminder_log 記錄「這顆藥今天推播過了沒」避免同一天重複打擾。
// 如果當天已經打勾吃過了 (health_med_logs)，就不用再推播提醒，但一樣要標記成「今天處理過」，
// 不然接下來每分鐘都會重新判斷一次「已服用不用推播」，白白浪費查詢。
const MED_REMINDER_CHECK_INTERVAL_MS = 60 * 1000;

function normalizeTimeHHMM(t) {
  if (!t) return null;
  const m = String(t).trim().match(/^(\d{1,2}):(\d{2})/);
  if (!m) return null;
  return `${m[1].padStart(2, '0')}:${m[2]}`;
}

async function runMedReminderCycle() {
  const db = getDb();
  let meds = [];
  try {
    meds = db.prepare("SELECT * FROM health_meds WHERE active = 1 AND schedule_time IS NOT NULL AND schedule_time != ''").all();
  } catch (e) {
    return; // migration 還沒套用/資料表不存在時直接跳過，等下一輪
  }
  if (!meds.length) return;

  const now = new Date();
  const hhmm = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
  const today = now.toISOString().slice(0, 10);
  const nowIso = now.toISOString();

  for (const med of meds) {
    try {
      if (normalizeTimeHHMM(med.schedule_time) !== hhmm) continue;
      const already = db.prepare('SELECT 1 FROM health_med_reminder_log WHERE med_id = ? AND sent_date = ?').get(med.id, today);
      if (already) continue;

      const takenLog = db.prepare('SELECT taken FROM health_med_logs WHERE med_id = ? AND log_date = ?').get(med.id, today);
      if (!(takenLog && takenLog.taken)) {
        // 服藥時間是使用者自己設定的精準時間點 (可能就是設在半夜)，算「緊急」不受靜音時段
        // 限制；也是使用者自己特別要求的提醒，不跟其他通知合併，兩顆藥同一分鐘該吃就各自
        // 獨立送出兩則，不會被合併成籠統的一則讓人搞不清楚是哪顆藥。
        queueNotification(db, med.user_id, {
          title: med.name,
          body: `服藥時間到了${med.dose ? '（' + med.dose + '）' : ''}，記得吃藥。`,
          icon: moodIconPath(db, med.user_id),
          urgent: true,
        });
      }
      db.prepare(
        `INSERT INTO health_med_reminder_log (med_id, sent_date, created_at) VALUES (?, ?, ?)
         ON CONFLICT(med_id, sent_date) DO NOTHING`
      ).run(med.id, today, nowIso);
    } catch (e) {
      logger.error('[push] 服藥提醒處理失敗', { medId: med.id, message: e.message });
    }
  }
}

const medReminderTimer = setInterval(() => {
  runMedReminderCycle().catch((e) => logger.error('[push] 服藥提醒排程執行失敗', { message: e.message }));
}, MED_REMINDER_CHECK_INTERVAL_MS);
medReminderTimer.unref();

// 開機後過一段時間才跑第一次 (避免跟 DB migration/伺服器啟動搶資源)，之後固定間隔重複。
// unref() 讓這個計時器不會阻止 process 正常結束 (例如測試腳本開機後又主動關閉)。
const initialTimer = setTimeout(() => {
  runNotifyCycle().catch((e) => logger.error('[push] 排程執行失敗', { message: e.message }));
  const interval = setInterval(() => {
    runNotifyCycle().catch((e) => logger.error('[push] 排程執行失敗', { message: e.message }));
  }, CHECK_INTERVAL_MS);
  interval.unref();
}, 60 * 1000);
initialTimer.unref();

const reminderTimer = setInterval(() => {
  runTaskReminderCycle().catch((e) => logger.error('[push] 精準提醒排程執行失敗', { message: e.message }));
  runSubtaskReminderCycle().catch((e) => logger.error('[push] 小任務精準提醒排程執行失敗', { message: e.message }));
}, REMINDER_CHECK_INTERVAL_MS);
reminderTimer.unref();

module.exports = router;
