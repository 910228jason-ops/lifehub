const { Router } = require('../mini-http');
const { getDb } = require('../services/db');
const { requireAuth } = require('../middleware/auth');

const router = Router();

const TASK_WIDGET_STYLES = ['grouped', 'progress', 'focus'];
const HHMM_RE = /^([01]\d|2[0-3]):([0-5]\d)$/;

router.get('/', requireAuth, (req, res) => {
  const db = getDb();
  const row = db.prepare('SELECT * FROM user_prefs WHERE user_id = ?').get(req.session.userId);
  if (!row) return res.json({ moduleOrder: ['travel', 'diary', 'finance'], enabledModules: {}, taskWidgetStyle: 'progress', moreNavOrder: [], pushBirthdayReminders: false, bottomNavPinned: [], pushPartnerCycleReminders: false, shareMoodWithPartner: false, shareCalendarWithPartner: true, shareTasksWithPartner: true, shareCycleWithPartner: true, quietHoursStart: '23:00', quietHoursEnd: '10:00', pushMoodSocialReminders: false });
  res.json({
    moduleOrder: JSON.parse(row.module_order_json),
    enabledModules: JSON.parse(row.enabled_modules_json),
    theme: row.theme,
    taskWidgetStyle: row.task_widget_style || 'progress',
    // more_nav_order_json 是 v0.29.0 才加的欄位，舊資料列 (024 migration 套用前建立的帳號)
    // 這欄一律有 DEFAULT '[]'，所以這裡不需要额外防呆，但保留 try/catch 以防萬一資料異常。
    moreNavOrder: (() => { try { return JSON.parse(row.more_nav_order_json || '[]'); } catch (e) { return []; } })(),
    pushBirthdayReminders: !!row.push_birthday_reminders,
    // bottom_nav_pinned_json 是 v0.32.0 才加的欄位，同樣有 DEFAULT '[]'；空陣列時前端會
    // 自己退回預設的「記帳/待辦/行事曆」三項 (見 app.js 的 bottomNavPinnedTabs())。
    bottomNavPinned: (() => { try { return JSON.parse(row.bottom_nav_pinned_json || '[]'); } catch (e) { return []; } })(),
    // push_partner_cycle_reminders 是 v0.35.0 才加的欄位，比照生日提醒同一套「預設關閉、
    // 使用者自己決定要不要推播」的做法。
    pushPartnerCycleReminders: !!row.push_partner_cycle_reminders,
    // share_mood_with_partner 是 v0.36.0 才加的欄位：單方面自己決定要不要分享「心情跟生理
    // 週期關聯」的統計數字給已連結的對象，不需要對方同意、也不影響對方要不要分享給我。
    shareMoodWithPartner: !!row.share_mood_with_partner,
    // share_calendar_with_partner / share_tasks_with_partner / share_cycle_with_partner 是
    // v0.39.0 才加的欄位：把原本「連結了就自動分享」的行事曆/待辦/生理週期，也比照心情統計
    // 做成使用者自己單方面能關掉的開關。DEFAULT 1 (true)，維持舊帳號原本看得到的行為不變，
    // 使用者要收回權限的話自己去設定關掉即可。
    shareCalendarWithPartner: row.share_calendar_with_partner === null || row.share_calendar_with_partner === undefined ? true : !!row.share_calendar_with_partner,
    shareTasksWithPartner: row.share_tasks_with_partner === null || row.share_tasks_with_partner === undefined ? true : !!row.share_tasks_with_partner,
    shareCycleWithPartner: row.share_cycle_with_partner === null || row.share_cycle_with_partner === undefined ? true : !!row.share_cycle_with_partner,
    // quiet_hours_start/end 是 v0.58.0 才加的欄位 (046 migration)，DEFAULT '23:00'/'10:00'，
    // 舊帳號沒特別設定過的話會直接吃到這個預設值，行為跟改版前的寫死時段完全一樣。
    quietHoursStart: row.quiet_hours_start || '23:00',
    quietHoursEnd: row.quiet_hours_end || '10:00',
    // push_mood_social_reminders 是 v0.63 才加的欄位，同樣比照生日/另一半週期提醒「預設關閉、
    // 使用者自己決定要不要推播」的做法 (見 migrations/051 的說明)。
    pushMoodSocialReminders: !!row.push_mood_social_reminders,
  });
});

router.put('/', requireAuth, (req, res) => {
  const {
    moduleOrder, enabledModules, theme, taskWidgetStyle, moreNavOrder, pushBirthdayReminders,
    bottomNavPinned, pushPartnerCycleReminders, shareMoodWithPartner,
    shareCalendarWithPartner, shareTasksWithPartner, shareCycleWithPartner,
    quietHoursStart, quietHoursEnd, pushMoodSocialReminders,
  } = req.body || {};
  // 時間格式驗證：不是合法的 "HH:MM" (例如前端還沒更新、或直接打 API 亂傳) 就退回預設值，
  // 不讓壞資料存進資料庫害之後 isQuietHoursNow() 判斷出錯。
  const safeQuietStart = HHMM_RE.test(quietHoursStart) ? quietHoursStart : '23:00';
  const safeQuietEnd = HHMM_RE.test(quietHoursEnd) ? quietHoursEnd : '10:00';
  const db = getDb();
  db.prepare(
    `UPDATE user_prefs SET module_order_json = ?, enabled_modules_json = ?, theme = ?, task_widget_style = ?, more_nav_order_json = ?, push_birthday_reminders = ?, bottom_nav_pinned_json = ?, push_partner_cycle_reminders = ?, share_mood_with_partner = ?, share_calendar_with_partner = ?, share_tasks_with_partner = ?, share_cycle_with_partner = ?, quiet_hours_start = ?, quiet_hours_end = ?, push_mood_social_reminders = ? WHERE user_id = ?`
  ).run(
    JSON.stringify(moduleOrder || []),
    JSON.stringify(enabledModules || {}),
    theme || 'light',
    TASK_WIDGET_STYLES.includes(taskWidgetStyle) ? taskWidgetStyle : 'progress',
    JSON.stringify(Array.isArray(moreNavOrder) ? moreNavOrder : []),
    pushBirthdayReminders ? 1 : 0,
    JSON.stringify(Array.isArray(bottomNavPinned) ? bottomNavPinned : []),
    pushPartnerCycleReminders ? 1 : 0,
    shareMoodWithPartner ? 1 : 0,
    shareCalendarWithPartner === false ? 0 : 1,
    shareTasksWithPartner === false ? 0 : 1,
    shareCycleWithPartner === false ? 0 : 1,
    safeQuietStart,
    safeQuietEnd,
    pushMoodSocialReminders ? 1 : 0,
    req.session.userId
  );
  res.json({ ok: true });
});

module.exports = router;
