// 跨模組洞察 / 主動式提醒。
//
// 這裡刻意不做「跨模塊深層模式識別」那種需要大量資料、AI 幫忙寫成一段話的深度分析
// (那個已經在心情頁做過了，見 src/services/moodPatterns.js)。這裡要做的是更輕量、
// 首頁就看得到的東西：
//   1. 主動式提醒——把「帳單快到期」「這個月某分類超支」「待辦拖很久」「好幾天沒記心情」
//      這幾件本來都要自己點進去每個分頁才會發現的事，集中成一份列表主動列在首頁。
//   2. 本週動態——單純用程式把心情/記帳/待辦/行事曆/日記這幾個模組本週的數字撈出來，
//      拼成幾句話，不叫 AI (不需要、也不用等待/花費)，資料就是資料，看得懂就好。
//
// 這個檔案沒有另外掛載新的 app.mount()，而是比照 feedback.js 的作法，把 routes 直接
// push 進已經掛在 /api 的 debug.js router，實際路徑就是 /api/insights/*。

const { Router } = require('../mini-http');
const { getDb } = require('../services/db');
const { requireAuth } = require('../middleware/auth');

const router = Router();

function todayStr() { return new Date().toISOString().slice(0, 10); }
function daysAgoStr(n) { return new Date(Date.now() - n * 24 * 3600 * 1000).toISOString().slice(0, 10); }

// 抽出成獨立函式：/api/insights/reminders 這支 API 用，背景推播排程 (src/routes/push.js)
// 也用同一份邏輯算出「這個使用者現在有哪些提醒」，兩邊不會算出不一樣的結果。
function computeReminders(db, userId) {
  const items = [];

  // ---- 帳單快到期還沒繳 (7 天內到期、這個月還沒標記已繳) ----
  try {
    const period = todayStr().slice(0, 7);
    const bills = db.prepare('SELECT * FROM bills WHERE user_id = ? AND active = 1').all(userId);
    const paidRows = db.prepare('SELECT bill_id FROM bill_payments WHERE user_id = ? AND paid_period = ?').all(userId, period);
    const paidSet = new Set(paidRows.map((r) => r.bill_id));
    const dayOfMonth = new Date().getDate();
    bills.forEach((b) => {
      if (paidSet.has(b.id)) return;
      const daysLeft = b.due_day - dayOfMonth;
      if (daysLeft <= 7) {
        items.push({
          severity: daysLeft < 0 ? 'critical' : 'warning',
          icon: '🧾',
          text: daysLeft < 0
            ? `「${b.name}」帳單已經過了繳款日 (每月 ${b.due_day} 號)，還沒標記已繳`
            : daysLeft === 0
              ? `「${b.name}」帳單今天到期 (NT$${Number(b.amount).toLocaleString()})`
              : `「${b.name}」帳單還有 ${daysLeft} 天到期 (NT$${Number(b.amount).toLocaleString()})`,
          tab: 'bills',
        });
      }
    });
  } catch (e) { /* bills 模組資料不存在時忽略，不影響其他提醒 */ }

  // ---- 這個月分類預算超支 ----
  try {
    const period = todayStr().slice(0, 7);
    const budgets = db.prepare('SELECT * FROM finance_budgets WHERE user_id = ?').all(userId);
    if (budgets.length) {
      const spent = db
        .prepare(
          `SELECT category, SUM(amount) as total FROM finance_transactions
           WHERE user_id = ? AND type = 'expense' AND tx_date LIKE ? GROUP BY category`
        )
        .all(userId, `${period}%`);
      const spentByCat = {};
      spent.forEach((s) => { spentByCat[s.category] = s.total; });
      budgets.forEach((b) => {
        const used = spentByCat[b.category] || 0;
        if (used > b.monthly_limit) {
          const overPct = Math.round(((used - b.monthly_limit) / b.monthly_limit) * 100);
          items.push({
            severity: 'warning',
            icon: '💰',
            text: `本月「${b.category}」已經花了 NT$${Math.round(used).toLocaleString()}，超出預算 NT$${Math.round(b.monthly_limit).toLocaleString()} 約 ${overPct}%`,
            tab: 'finance',
          });
        }
      });
    }
  } catch (e) { /* ignore */ }

  // ---- 待辦事項拖延 (逾期超過 3 天還沒完成) ----
  try {
    const overdueThreshold = daysAgoStr(3);
    const overdue = db
      .prepare("SELECT COUNT(*) as c FROM tasks WHERE user_id = ? AND completed = 0 AND due_date IS NOT NULL AND due_date < ?")
      .get(userId, overdueThreshold).c;
    if (overdue > 0) {
      items.push({
        severity: 'warning',
        icon: '✅',
        text: `有 ${overdue} 件待辦事項已經逾期超過 3 天還沒完成`,
        tab: 'tasks',
      });
    }
  } catch (e) { /* ignore */ }

  // ---- 好幾天沒記心情 (最近一次紀錄距今 >= 3 天，或完全沒記過) ----
  try {
    const last = db.prepare('SELECT MAX(entry_date) as d FROM mood_entries WHERE user_id = ?').get(userId).d;
    if (last) {
      const gap = Math.floor((new Date(todayStr()) - new Date(last)) / (24 * 3600 * 1000));
      if (gap >= 3) {
        items.push({ severity: 'info', icon: '💗', text: `已經 ${gap} 天沒有記錄心情了，要不要花點時間打個分數？`, tab: 'mood' });
      }
    }
  } catch (e) { /* ignore */ }

  // ---- 人際關係：該聯絡的人 (設定了「每隔幾天提醒我聯絡」但已經超過那個天數沒有互動紀錄) ----
  // 「上次聯絡」以 relationship_interactions 裡最新一筆互動日期為準；如果從來沒記過互動，
  // 就用這個人被加進來的日期當基準 (代表「加進來之後從來沒聯絡過」，一樣算數)。
  // dueContacts 額外留一份陣列 (不只是塞進 items)，是給下面「心情持續偏低 + 剛好有該聯絡的
  // 人」那個組合訊號用的——兩個地方都要用到「誰該聯絡了」這份名單，只算一次。
  const dueContacts = [];
  try {
    const rels = db.prepare('SELECT * FROM relationships WHERE user_id = ? AND reminder_interval_days IS NOT NULL').all(userId);
    rels.forEach((r) => {
      const lastInteraction = db
        .prepare('SELECT MAX(interaction_date) as d FROM relationship_interactions WHERE relationship_id = ? AND user_id = ?')
        .get(r.id, userId).d;
      const baseline = lastInteraction || r.created_at.slice(0, 10);
      const daysSince = Math.floor((new Date(todayStr()) - new Date(baseline.slice(0, 10))) / (24 * 3600 * 1000));
      if (daysSince >= r.reminder_interval_days) {
        dueContacts.push({ id: r.id, name: r.name, daysSince });
        items.push({
          severity: 'info',
          icon: '🤝',
          text: `已經 ${daysSince} 天沒有跟「${r.name}」互動了 (設定的提醒間隔是 ${r.reminder_interval_days} 天)，要不要找個時間聯絡一下？`,
          tab: 'relationships',
          type: 'relationship-checkin',
        });
      }
    });
  } catch (e) { /* ignore */ }

  // ---- 心情持續偏低 + 剛好有該聯絡的人：兩個訊號同時出現時，合併成一則更具體的提醒 ----
  // 單一一天心情低分很可能只是普通的壞日子，不代表需要特別介入；真正比較值得留意的是
  // 「最近一段時間持續偏低」。判斷方式：近 7 天至少要有 3 筆紀錄才夠判斷 (避免資料太少誤判)，
  // 符合以下任一條件就算「心情持續偏低」：
  //   (a) 近 7 天平均分數本身就偏低 (<=4，滿分 10 分)——不管平常基準線在哪，這種絕對低分
  //       持續好幾天本來就值得留意。
  //   (b) 近 7 天平均比過去的基準線低了 1.5 分以上 (基準線至少要有 10 筆紀錄才夠穩定)——
  //       跟 src/services/moodPatterns.js 判斷「有意義的差距」用的 0.8 分門檻同一個精神，
  //       但這裡故意抓更嚴格一點 (1.5 分)，因為這則提醒會主動跳出來、比較打擾，門檻要抓高一點
  //       避免太常誤觸發。
  // 兩個訊號都成立時，挑「拖最久沒聯絡」的那個人具體點名建議聯絡，比起分開顯示兩則不相關的
  // 提醒，更貼近「使用者最近可能需要有人陪」這個實際情境；同時把這個人原本在上面
  // relationship-checkin 產生的個別提醒拿掉，避免同一個人被提到兩次。
  // v0.65：原本是二元判斷 (觸發/不觸發)，但「心情差一天」跟「已經連續兩週都差」該給的
  // 關注程度完全不一樣，二元判斷會把這兩種情況用同一種強度的提醒帶過。這裡改成三級：
  //   mild (輕微)：近 7 天平均偏低，但還沒到「持續偏低」的門檻，只在首頁顯示一則溫和提醒，
  //     不點名聯絡人 (避免資料還不夠就催促使用者去找人聊)。
  //   persistent (持續偏低)：近 7 天平均夠低、或明顯低於個人基準線 (跟 v0.63 的邏輯相同)，
  //     搭配該聯絡的人一起提醒。
  //   severe (惡化中)：不只這週低，上一週 (8~14 天前) 也已經偏低——代表不是單週的壞狀態，
  //     而是持續惡化超過兩週，用更明確的用字、且優先層級最高。
  try {
    const recentRows = db.prepare('SELECT score FROM mood_entries WHERE user_id = ? AND entry_date >= ?').all(userId, daysAgoStr(7));
    if (recentRows.length >= 3) {
      const recentAvg = recentRows.reduce((s, r) => s + r.score, 0) / recentRows.length;
      let baselineAvg = null;
      const baselineRows = db.prepare('SELECT score FROM mood_entries WHERE user_id = ? AND entry_date < ?').all(userId, daysAgoStr(7));
      if (baselineRows.length >= 10) baselineAvg = baselineRows.reduce((s, r) => s + r.score, 0) / baselineRows.length;
      const baselineDiff = baselineAvg !== null ? baselineAvg - recentAvg : 0;

      const persistent = recentAvg <= 4 || baselineDiff >= 1.5;
      const mild = !persistent && (recentAvg <= 5.5 || baselineDiff >= 1.0);

      let tier = null;
      if (persistent) {
        // 檢查上一週 (8~14 天前) 是不是也偏低，判斷是「這週剛開始差」還是「已經連續兩週差」。
        const prevWeekRows = db
          .prepare('SELECT score FROM mood_entries WHERE user_id = ? AND entry_date >= ? AND entry_date < ?')
          .all(userId, daysAgoStr(14), daysAgoStr(7));
        if (prevWeekRows.length >= 3) {
          const prevWeekAvg = prevWeekRows.reduce((s, r) => s + r.score, 0) / prevWeekRows.length;
          if (prevWeekAvg <= 5) tier = 'severe';
        }
        if (!tier) tier = 'persistent';
      } else if (mild) {
        tier = 'mild';
      }

      if (tier === 'mild') {
        items.push({
          severity: 'info',
          icon: '💗',
          text: `這幾天的心情分數看起來比平常低一點 (過去 7 天平均 ${Math.round(recentAvg * 10) / 10} 分)，還不到需要特別留意的程度，但如果願意的話可以寫幾句記錄一下最近發生什麼事。`,
          tab: 'mood',
          type: 'mood-trend-mild',
        });
      } else if ((tier === 'persistent' || tier === 'severe') && dueContacts.length) {
        const target = [...dueContacts].sort((a, b) => b.daysSince - a.daysSince)[0];
        const text = tier === 'severe'
          ? `你的心情已經連續兩週左右都偏低了 (過去 7 天平均 ${Math.round(recentAvg * 10) / 10} 分，上一週也差不多)，這不像是單純某幾天的壞心情。而且已經有 ${target.daysSince} 天沒跟「${target.name}」聯絡了——要不要找他聊聊，或考慮找專業的人談談？`
          : `你最近幾天心情比較低落 (過去 7 天平均 ${Math.round(recentAvg * 10) / 10} 分)，而且已經有 ${target.daysSince} 天沒跟「${target.name}」聯絡了——要不要找他聊聊？`;
        items.push({
          severity: tier === 'severe' ? 'critical' : 'warning',
          icon: '🫂',
          text,
          tab: 'relationships',
          type: 'mood-social-checkin',
          tier,
        });
        const dupIdx = items.findIndex((it) => it.type === 'relationship-checkin' && it.text.includes(`「${target.name}」`));
        if (dupIdx !== -1) items.splice(dupIdx, 1);
      } else if (tier === 'persistent' || tier === 'severe') {
        // 心情持續偏低成立，但沒有剛好符合「該聯絡的人」條件——還是要提醒，只是不點名聯絡人。
        items.push({
          severity: tier === 'severe' ? 'critical' : 'warning',
          icon: '🫂',
          text: tier === 'severe'
            ? `你的心情已經連續兩週左右都偏低了 (過去 7 天平均 ${Math.round(recentAvg * 10) / 10} 分)，這不像是單純某幾天的壞心情，要不要找信任的人聊聊，或考慮找專業的人談談？`
            : `你最近幾天心情比較低落 (過去 7 天平均 ${Math.round(recentAvg * 10) / 10} 分)，要不要找個人聊聊，或做點喜歡的事？`,
          tab: 'mood',
          type: 'mood-trend-concern',
          tier,
        });
      }
    }
  } catch (e) { /* ignore */ }

  // ---- 帳單金額異常偵測 (v0.66) ----
  // bill_payments 從 v0.66 開始才有 amount 欄位 (見 migrations/054)，所以「歷史金額」只能
  // 從這個功能上線之後開始累積，資料不夠 (少於 4 筆已繳紀錄) 就不比對。拿「最新一筆」跟
  // 「再更早之前那幾筆的平均」比，差距要夠大 (15% 以上且超過 NT$50) 才提醒，避免小數點誤差
  // 或抓一位小數位的四捨五入也被當成異常。
  try {
    const bills = db.prepare('SELECT id, name FROM bills WHERE user_id = ? AND active = 1').all(userId);
    bills.forEach((b) => {
      const payments = db
        .prepare('SELECT paid_period, amount FROM bill_payments WHERE bill_id = ? AND user_id = ? AND amount IS NOT NULL ORDER BY paid_period DESC')
        .all(b.id, userId);
      if (payments.length < 4) return;
      const [latest, ...history] = payments;
      const histAvg = history.reduce((s, p) => s + p.amount, 0) / history.length;
      if (histAvg <= 0) return;
      const diff = latest.amount - histAvg;
      const diffPct = (diff / histAvg) * 100;
      if (diff >= 50 && diffPct >= 15) {
        items.push({
          severity: 'info',
          icon: '🧾',
          text: `「${b.name}」這期 (${latest.paid_period}) 實繳 NT$${Math.round(latest.amount).toLocaleString()}，比過去 ${history.length} 期的平均 NT$${Math.round(histAvg).toLocaleString()} 高出約 ${Math.round(diffPct)}%，可能是漲價或用量異常，要不要確認一下？`,
          tab: 'bills',
          type: 'bill-amount-anomaly',
        });
      }
    });
  } catch (e) { /* ignore */ }

  // ---- 任務拖延模式偵測 (v0.66) ----
  // 反覆延期超過門檻 (>=3 次)、還沒完成的任務，代表這件事可能一直被拖著沒真的處理，跟
  // 「逾期超過 3 天」(上面已經有) 不一樣——逾期是「時間到了沒做」，這裡抓的是「一直被延期」，
  // 就算還沒真的逾期 (例如每次都延到下週) 也一樣算數。
  try {
    const procrastinating = db
      .prepare('SELECT id, title, postponed_count FROM tasks WHERE user_id = ? AND completed = 0 AND postponed_count >= 3 ORDER BY postponed_count DESC LIMIT 1')
      .all(userId);
    if (procrastinating.length) {
      const t = procrastinating[0];
      items.push({
        severity: 'info',
        icon: '🔁',
        text: `「${t.title}」已經被延期 ${t.postponed_count} 次了，這件事是不是根本不該存在、該拆成更小的步驟、或該找人幫忙？一直放著延期本身也會累積壓力。`,
        tab: 'tasks',
        type: 'task-procrastination',
      });
    }
  } catch (e) { /* ignore */ }

  // ---- 情緒化消費偵測 (v0.65) ----
  // 「本週動態」(下面 /insights/weekly) 原本就有一句單週、粗略的心情 vs 支出觀察，但只看
  // 這一週、樣本數常常太少，只能算「順帶一提」。這裡改用更長的窗口 (60 天)、更嚴謹的比較
  // 方式：把有記錄心情的日子分成「心情偏低 (<=4分)」跟「心情偏高 (>=7分)」兩組，各自算
  // 當天的支出平均，兩組都要有至少 5 筆樣本才夠可信，差距要夠大 (30% 以上且金額差距
  // NT$100 以上，避免小額波動被誤判) 才會產生提醒，講出具體金額而不是模糊的「好像比較高」。
  try {
    const windowFrom = daysAgoStr(60);
    const moodRows = db.prepare('SELECT entry_date, score FROM mood_entries WHERE user_id = ? AND entry_date >= ?').all(userId, windowFrom);
    const txRows = db
      .prepare("SELECT tx_date, SUM(amount) as total FROM finance_transactions WHERE user_id = ? AND type='expense' AND tx_date >= ? GROUP BY tx_date")
      .all(userId, windowFrom);
    const spendByDate = {};
    txRows.forEach((r) => { spendByDate[r.tx_date] = r.total; });
    const lowDays = moodRows.filter((m) => m.score <= 4 && spendByDate[m.entry_date] !== undefined);
    const highDays = moodRows.filter((m) => m.score >= 7 && spendByDate[m.entry_date] !== undefined);
    if (lowDays.length >= 5 && highDays.length >= 5) {
      const avgLow = lowDays.reduce((s, r) => s + spendByDate[r.entry_date], 0) / lowDays.length;
      const avgHigh = highDays.reduce((s, r) => s + spendByDate[r.entry_date], 0) / highDays.length;
      const diff = avgLow - avgHigh;
      const diffPct = avgHigh > 0 ? (diff / avgHigh) * 100 : 0;
      if (diff >= 100 && diffPct >= 30) {
        items.push({
          severity: 'info',
          icon: '🛍️',
          text: `過去 60 天內，心情分數偏低 (≤4 分) 的那幾天，平均支出 NT$${Math.round(avgLow).toLocaleString()}，比心情偏高 (≥7 分) 的那幾天 (平均 NT$${Math.round(avgHigh).toLocaleString()}) 高出約 ${Math.round(diffPct)}%。這不代表因果關係一定成立，但如果你也覺得心情差的時候容易多花錢，或許可以留意一下。`,
          tab: 'finance',
          type: 'emotional-spending-pattern',
        });
      }
    }
  } catch (e) { /* ignore */ }

  // ---- 人際關係：快到的生日 (7 天內) ----
  // 這類提醒預設只會出現在首頁，不會自動推播——生日這種事有些人希望主動被推播提醒，
  // 有些人覺得每年一堆生日通知太吵，所以是否要推播由 push.js 依使用者的
  // prefs.pushBirthdayReminders 設定另外過濾 (見 push.js runNotifyCycle)，這裡只負責算出來。
  try {
    const rels = db.prepare("SELECT id, name, birthday FROM relationships WHERE user_id = ? AND birthday IS NOT NULL").all(userId);
    const today = new Date();
    rels.forEach((r) => {
      const [mm, dd] = r.birthday.split('-').map(Number);
      if (!mm || !dd) return;
      let next = new Date(today.getFullYear(), mm - 1, dd);
      if (next < new Date(today.getFullYear(), today.getMonth(), today.getDate())) {
        next = new Date(today.getFullYear() + 1, mm - 1, dd);
      }
      const daysUntil = Math.round((next - new Date(today.getFullYear(), today.getMonth(), today.getDate())) / (24 * 3600 * 1000));
      if (daysUntil >= 0 && daysUntil <= 7) {
        items.push({
          severity: 'info',
          icon: '🎂',
          text: daysUntil === 0 ? `今天是「${r.name}」的生日！` : `再過 ${daysUntil} 天是「${r.name}」的生日`,
          tab: 'relationships',
          type: 'birthday',
        });
      }
    });
  } catch (e) { /* ignore */ }

  // ---- 另一半的生理週期：快來月經了 (3 天內) 或正在經前觀察窗 ----
  // 一樣預設只出現在首頁，是否要推播由 prefs.pushPartnerCycleReminders 決定 (見 push.js)，
  // 這裡只負責用 cycle.currentStatus() 算出來 (跟「陪伴另一半」分頁用的是同一份估算邏輯)。
  try {
    const cycle = require('../services/cycle');
    const partnerEntries = db
      .prepare("SELECT period_start_date, period_end_date FROM cycle_entries WHERE user_id = ? AND tracking_for = 'partner' ORDER BY period_start_date ASC")
      .all(userId);
    const status = cycle.currentStatus(partnerEntries, todayStr());
    if (status.hasData) {
      // v0.81：遲到狀態 (預估日期已過但還沒記錄新的開始日) 有自己的提醒，
      // 提醒的重點放在「她可能比你更焦慮」而不是製造緊張。太久沒記錄 (stale) 就不提醒，
      // 比較可能是忘了記，不值得每天跳一條。
      if (status.isLate) {
        items.push({
          severity: 'info',
          icon: '🌷',
          text: `她的月經比預估晚了 ${status.daysLate} 天，這段時間她自己可能會比較在意，多點平常心陪伴就好`,
          tab: 'partnerCare',
          type: 'partner-cycle',
        });
      } else if (status.daysUntilNextPeriod !== undefined && status.daysUntilNextPeriod <= 3) {
        items.push({
          severity: 'info',
          icon: '🌷',
          text: status.daysUntilNextPeriod === 0 ? '估算她今天可能會來月經' : `估算她再過 ${status.daysUntilNextPeriod} 天可能會來月經`,
          tab: 'partnerCare',
          type: 'partner-cycle',
        });
      } else if (status.isPmsWindow) {
        items.push({
          severity: 'info',
          icon: '🌷',
          text: '估算她現在正處於經前觀察窗，這幾天可能比較敏感或容易累',
          tab: 'partnerCare',
          type: 'partner-cycle',
        });
      }
    }
  } catch (e) { /* ignore */ }

  // 排序：critical 在最前面，其次 warning，最後 info
  const rank = { critical: 0, warning: 1, info: 2 };
  items.sort((a, b) => rank[a.severity] - rank[b.severity]);

  return items;
}

router.get('/insights/reminders', requireAuth, (req, res) => {
  const db = getDb();
  const userId = req.session.userId;
  const items = computeReminders(db, userId);
  res.json({ items, count: items.length });
});

// 本週動態：純程式計算，不叫 AI，把幾個模組本週的數字整理成幾句話。
router.get('/insights/weekly', requireAuth, (req, res) => {
  const db = getDb();
  const userId = req.session.userId;
  const from = daysAgoStr(7);
  const to = todayStr();
  const lines = [];
  const stats = {};

  try {
    const moodRows = db.prepare('SELECT score FROM mood_entries WHERE user_id = ? AND entry_date >= ?').all(userId, from);
    if (moodRows.length) {
      const avg = moodRows.reduce((s, r) => s + r.score, 0) / moodRows.length;
      stats.moodAvg = Math.round(avg * 10) / 10;
      stats.moodCount = moodRows.length;
      lines.push(`這週記錄了 ${moodRows.length} 次心情，平均分數 ${stats.moodAvg} 分`);
      // v0.65：原本只有這週的單一數字，看不出「比上週好還是差」。加一句跟上週 (8~14 天前)
      // 的比較，樣本數也要夠 (至少 3 筆) 才顯示，避免拿一兩筆資料硬算出趨勢。
      const prevMoodRows = db.prepare('SELECT score FROM mood_entries WHERE user_id = ? AND entry_date >= ? AND entry_date < ?').all(userId, daysAgoStr(14), from);
      if (prevMoodRows.length >= 3) {
        const prevAvg = prevMoodRows.reduce((s, r) => s + r.score, 0) / prevMoodRows.length;
        const delta = Math.round((stats.moodAvg - prevAvg) * 10) / 10;
        if (Math.abs(delta) >= 0.5) {
          lines.push(delta > 0 ? `比上週平均高了 ${delta} 分` : `比上週平均低了 ${Math.abs(delta)} 分`);
        } else {
          lines.push('跟上週平均差不多');
        }
      }
    } else {
      lines.push('這週還沒有記錄過心情');
    }
  } catch (e) { /* ignore */ }

  try {
    const fin = db
      .prepare(
        `SELECT SUM(CASE WHEN type='expense' THEN amount ELSE 0 END) as expense,
                SUM(CASE WHEN type='income' THEN amount ELSE 0 END) as income
         FROM finance_transactions WHERE user_id = ? AND tx_date >= ?`
      )
      .get(userId, from);
    stats.expense = Math.round(fin.expense || 0);
    stats.income = Math.round(fin.income || 0);
    if (stats.expense || stats.income) {
      lines.push(`這週支出 NT$${stats.expense.toLocaleString()}，收入 NT$${stats.income.toLocaleString()}`);
      // v0.65：跟上週支出比較，金額差距要夠大 (20% 以上且超過 NT$300) 才提，避免小波動也念一句。
      const prevFin = db
        .prepare("SELECT SUM(CASE WHEN type='expense' THEN amount ELSE 0 END) as expense FROM finance_transactions WHERE user_id = ? AND tx_date >= ? AND tx_date < ?")
        .get(userId, daysAgoStr(14), from);
      const prevExpense = Math.round(prevFin.expense || 0);
      if (prevExpense > 0) {
        const diff = stats.expense - prevExpense;
        const diffPct = Math.abs(diff / prevExpense) * 100;
        if (Math.abs(diff) >= 300 && diffPct >= 20) {
          lines.push(diff > 0 ? `支出比上週多了約 NT$${Math.round(diff).toLocaleString()} (+${Math.round(diffPct)}%)` : `支出比上週少了約 NT$${Math.round(Math.abs(diff)).toLocaleString()} (-${Math.round(diffPct)}%)`);
        }
      }
    }
  } catch (e) { /* ignore */ }

  try {
    const completed = db
      .prepare("SELECT COUNT(*) as c FROM tasks WHERE user_id = ? AND completed = 1 AND substr(completed_at,1,10) >= ?")
      .get(userId, from).c;
    const overdue = db
      .prepare("SELECT COUNT(*) as c FROM tasks WHERE user_id = ? AND completed = 0 AND due_date IS NOT NULL AND due_date < ?")
      .get(userId, to).c;
    stats.tasksCompleted = completed;
    stats.tasksOverdue = overdue;
    lines.push(`待辦完成了 ${completed} 件${overdue > 0 ? `，還有 ${overdue} 件已經逾期` : ''}`);
  } catch (e) { /* ignore */ }

  try {
    const events = db.prepare('SELECT COUNT(*) as c FROM calendar_events WHERE user_id = ? AND event_date >= ? AND event_date <= ?').get(userId, from, to).c;
    stats.eventCount = events;
    lines.push(`行事曆這週有 ${events} 筆行程`);
  } catch (e) { /* ignore */ }

  try {
    const diaryCount = db.prepare('SELECT COUNT(*) as c FROM diary_entries WHERE user_id = ? AND entry_date >= ?').get(userId, from).c;
    stats.diaryCount = diaryCount;
    if (diaryCount > 0) lines.push(`這週寫了 ${diaryCount} 篇日記`);
  } catch (e) { /* ignore */ }

  // v0.65：週摘要原本只有心情/記帳/待辦/行事曆/日記，沒有涵蓋到人際關係模組，補上「有幾個
  // 該聯絡但還沒聯絡的人」這一句，讓這份摘要真的涵蓋跨模組的重點，不是只有幾個模組。
  try {
    const rels = db.prepare('SELECT * FROM relationships WHERE user_id = ? AND reminder_interval_days IS NOT NULL').all(userId);
    let dueCount = 0;
    rels.forEach((r) => {
      const lastInteraction = db
        .prepare('SELECT MAX(interaction_date) as d FROM relationship_interactions WHERE relationship_id = ? AND user_id = ?')
        .get(r.id, userId).d;
      const baseline = lastInteraction || r.created_at.slice(0, 10);
      const daysSince = Math.floor((new Date(to) - new Date(baseline.slice(0, 10))) / (24 * 3600 * 1000));
      if (daysSince >= r.reminder_interval_days) dueCount += 1;
    });
    stats.dueContactsCount = dueCount;
    if (dueCount > 0) lines.push(`目前有 ${dueCount} 位設定了聯絡提醒的人已經超過該聯絡的時間`);
  } catch (e) { /* ignore */ }

  // 一句簡單、不做因果斷言的交叉觀察：心情分數較低的那幾天，平均支出是不是比較高
  // (單純算術比較，不是統計推論，資料不夠時就不顯示，避免看起來像下定論)
  try {
    const moodRows = db.prepare('SELECT entry_date, score FROM mood_entries WHERE user_id = ? AND entry_date >= ?').all(userId, from);
    const txRows = db.prepare("SELECT tx_date, SUM(amount) as total FROM finance_transactions WHERE user_id = ? AND type='expense' AND tx_date >= ? GROUP BY tx_date").all(userId, from);
    const spendByDate = {};
    txRows.forEach((r) => { spendByDate[r.tx_date] = r.total; });
    if (moodRows.length >= 4) {
      const withSpend = moodRows.map((m) => ({ score: m.score, spend: spendByDate[m.entry_date] || 0 }));
      const sorted = [...withSpend].sort((a, b) => a.score - b.score);
      const half = Math.floor(sorted.length / 2);
      const lowerHalf = sorted.slice(0, half);
      const upperHalf = sorted.slice(sorted.length - half);
      const avgLow = lowerHalf.reduce((s, r) => s + r.spend, 0) / lowerHalf.length;
      const avgHigh = upperHalf.reduce((s, r) => s + r.spend, 0) / upperHalf.length;
      if (avgLow > 0 && avgHigh > 0 && Math.abs(avgLow - avgHigh) / Math.max(avgLow, avgHigh) > 0.25) {
        if (avgLow > avgHigh) {
          lines.push(`初步觀察（非絕對因果）：這週心情分數比較低的那幾天，支出似乎偏高一些`);
        } else {
          lines.push(`初步觀察（非絕對因果）：這週心情分數比較高的那幾天，支出似乎偏高一些`);
        }
      }
    }
  } catch (e) { /* ignore */ }

  res.json({ rangeFrom: from, rangeTo: to, lines, stats });
});

router.computeReminders = computeReminders;
module.exports = router;
