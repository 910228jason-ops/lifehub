// 「搬家」：把使用者在 LifeHub 裡的資料匯出成一份 JSON，涵蓋全部模塊。
// 用 JSON 而不是 CSV+zip 的原因：這個專案刻意不加任何 npm 套件 (連壓縮都是手寫的 bootstrap-extract)，
// 用單一 JSON 檔可以完整保留巢狀資料、不需要額外的壓縮函式庫，也還是可以直接用文字編輯器打開來看，
// 對「備份/ 搬家」這個需求來說已經足夠完整。

const { Router } = require('../mini-http');
const { getDb } = require('../services/db');
const { requireAuth } = require('../middleware/auth');

const router = Router();

// v0.67：抽成獨立函式，讓 GET /all (使用者自己按「匯出全部資料」) 跟背景自動備份排程
// (見下面 src/services/monthlyBackup.js) 共用同一份「這個使用者的完整資料長什麼樣子」的
// 邏輯，不用維護兩份幾乎一樣、但容易慢慢長歪成不一致的程式碼。
function buildExportData(db, uid) {
  const data = {
    exportedAt: new Date().toISOString(),
    lifehubVersion: require('../../package.json').version,
    user: db.prepare('SELECT id, email, name, created_at FROM users WHERE id = ?').get(uid),
    prefs: db.prepare('SELECT * FROM user_prefs WHERE user_id = ?').get(uid),
    diaryEntries: db.prepare('SELECT entry_date, content, mood, created_at, updated_at FROM diary_entries WHERE user_id = ? ORDER BY entry_date ASC').all(uid),
    financeTransactions: db.prepare('SELECT tx_date, type, category, amount, note, created_at FROM finance_transactions WHERE user_id = ? ORDER BY tx_date ASC').all(uid),
    financeBudgets: db.prepare('SELECT category, monthly_limit FROM finance_budgets WHERE user_id = ?').all(uid),
    calendarEvents: db.prepare('SELECT event_date, start_time, title, note, category, created_at, updated_at FROM calendar_events WHERE user_id = ? ORDER BY event_date ASC').all(uid),
    favoriteTrains: db.prepare('SELECT * FROM favorite_trains WHERE user_id = ?').all(uid),
    assistantMessages: db.prepare('SELECT role, content, created_at FROM assistant_messages WHERE user_id = ? ORDER BY id ASC').all(uid),
    mood: {
      entries: db.prepare('SELECT entry_date, score, tags, note, created_at, updated_at FROM mood_entries WHERE user_id = ? ORDER BY entry_date ASC').all(uid),
      chatMessages: db.prepare('SELECT role, content, flagged, created_at FROM mood_chat_messages WHERE user_id = ? ORDER BY id ASC').all(uid),
      chatMemorySummaries: db.prepare('SELECT summary, created_at FROM mood_chat_memory WHERE user_id = ? ORDER BY id ASC').all(uid),
      copingNotes: db.prepare('SELECT content, created_at FROM mood_coping_notes WHERE user_id = ? ORDER BY id ASC').all(uid),
      thoughtRecords: db.prepare('SELECT situation, thought, emotion, intensity, evidence_for, evidence_against, reframe, created_at FROM mood_thought_records WHERE user_id = ? ORDER BY id ASC').all(uid),
      techniqueFeedback: db.prepare('SELECT tag, technique_key, helped, created_at FROM mood_technique_feedback WHERE user_id = ? ORDER BY id ASC').all(uid),
      patterns: db.prepare('SELECT insights, generated_at FROM mood_patterns WHERE user_id = ? ORDER BY id DESC LIMIT 5').all(uid),
      cycleEntries: db.prepare('SELECT period_start_date, period_end_date, symptoms, tracking_for, created_at FROM cycle_entries WHERE user_id = ? ORDER BY period_start_date ASC').all(uid),
    },
    health: {
      sleepEntries: db.prepare('SELECT entry_date, hours, note, created_at FROM health_sleep_entries WHERE user_id = ? ORDER BY entry_date ASC').all(uid),
      meds: db.prepare('SELECT name, dose, schedule_time, active, created_at FROM health_meds WHERE user_id = ?').all(uid),
      medLogs: db.prepare('SELECT med_id, log_date, taken, created_at FROM health_med_logs WHERE user_id = ? ORDER BY log_date ASC').all(uid),
    },
    bills: db.prepare('SELECT name, amount, due_day, category, note, active, created_at FROM bills WHERE user_id = ?').all(uid),
    billPayments: db.prepare('SELECT bill_id, paid_period, paid_at FROM bill_payments WHERE user_id = ?').all(uid),
    relationships: db.prepare('SELECT id, name, relation_type, birthday, note, created_at FROM relationships WHERE user_id = ?').all(uid),
    relationshipInteractions: db.prepare('SELECT relationship_id, interaction_date, note, created_at FROM relationship_interactions WHERE user_id = ?').all(uid),
    tasks: db.prepare('SELECT title, note, due_date, priority, energy_level, recurrence, recurrence_interval, completed, completed_at, created_at FROM tasks WHERE user_id = ?').all(uid),
    financeGoals: db.prepare('SELECT name, target_amount, target_date, start_date, archived, created_at FROM finance_goals WHERE user_id = ?').all(uid),
    importantDates: db.prepare('SELECT relationship_id, label, month_day, note, created_at FROM important_dates WHERE user_id = ?').all(uid),
    packingItems: db.prepare('SELECT trip_id, item, category, checked, created_at FROM packing_items WHERE user_id = ?').all(uid),
    trips: (() => {
      const trips = db.prepare('SELECT * FROM trips WHERE user_id = ?').all(uid);
      return trips.map((t) => ({
        name: t.name, baseCurrency: t.base_currency, startDate: t.start_date, endDate: t.end_date, settled: !!t.settled, createdAt: t.created_at,
        participants: db.prepare('SELECT name, is_me FROM trip_participants WHERE trip_id = ?').all(t.id),
        expenses: db.prepare('SELECT payer_id, description, amount, currency, exchange_rate, expense_date, created_at FROM trip_expenses WHERE trip_id = ?').all(t.id),
      }));
    })(),
  };
  return data;
}

router.get('/all', requireAuth, (req, res) => {
  const db = getDb();
  const uid = req.session.userId;
  const data = buildExportData(db, uid);
  const filename = `lifehub-backup-${new Date().toISOString().slice(0, 10)}.json`;
  res.setHeader('content-disposition', `attachment; filename="${filename}"`);
  res.json(data);
});

// v0.67：自動備份排程 (見 src/services/monthlyBackup.js) 每個月會把每個使用者的完整資料
// 存一份到伺服器磁碟上，這裡讓使用者自己查看/下載「之前自動存過哪幾份」，不用等到真的需要
// 復原資料才發現「原來只有手動匯出過的那一次，其他時間都沒有備份」。
router.get('/backups', requireAuth, (req, res) => {
  const list = monthlyBackup.listBackupsForUser(req.session.userId);
  res.json({ items: list });
});

router.get('/backups/:period', requireAuth, (req, res) => {
  const content = monthlyBackup.readBackupForUser(req.session.userId, req.params.period);
  if (!content) return res.status(404).json({ error: '找不到這份備份' });
  const filename = `lifehub-backup-${req.params.period}.json`;
  res.setHeader('content-disposition', `attachment; filename="${filename}"`);
  res.setHeader('content-type', 'application/json');
  res.end(content);
});

module.exports = router;
module.exports.buildExportData = buildExportData;

// v0.67：放在檔案最下面才 require，且用到的地方 (上面兩個 /backups 路由) 都是透過閉包引用
// 這個變數、實際執行時機是「使用者呼叫這兩支 API 時」，那時候整個模組早就載入完成，不會有
// 「buildExportData 還沒定義」的問題。monthlyBackup.js 內部才是真的需要 buildExportData
// 的地方 (背景排程用)，它是用函式內延遲 require 的方式拿，同樣避開這裡的循環引用時機問題。
const monthlyBackup = require('../services/monthlyBackup');
