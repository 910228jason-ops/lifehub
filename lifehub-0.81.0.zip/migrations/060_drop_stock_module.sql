-- v0.79.0：股票模組整個移除（使用者反映不太實用，外面專業看盤軟體做得更好）。
-- 導覽/首頁卡片/分頁在前端已經拿掉，這裡把後端資料表也一併清掉，不留殘留資料表。
-- 注意：這會永久刪除使用者已經記錄過的股票交易/股利/到價提醒資料，無法復原。

DROP TABLE IF EXISTS stock_transactions;
DROP TABLE IF EXISTS stock_dividends;
DROP TABLE IF EXISTS stock_price_alerts;
