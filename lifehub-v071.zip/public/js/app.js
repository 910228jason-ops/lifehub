// ===================== 共用工具 =====================
const state = { user: null, prefs: null, watchlist: ['2330', '2317', '0050'] };

// ===================== 側欄收合 =====================
function toggleSidebar() {
  const sb = $('#sidebar');
  const collapsed = sb.classList.toggle('collapsed');
  $('#sidebarToggle').textContent = collapsed ? '▸' : '◂';
  try { localStorage.setItem('lifehub_sidebar_collapsed', collapsed ? '1' : '0'); } catch (e) {}
}
function restoreSidebarState() {
  try {
    if (localStorage.getItem('lifehub_sidebar_collapsed') === '1') {
      $('#sidebar').classList.add('collapsed');
      $('#sidebarToggle').textContent = '▸';
    }
  } catch (e) {}
}

// ===================== 星空背景 =====================
function initStarfield() {
  const canvas = $('#starfield');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  let stars = [];
  function resize() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    const count = Math.round((canvas.width * canvas.height) / 9000);
    stars = Array.from({ length: count }, () => ({
      x: Math.random() * canvas.width,
      y: Math.random() * canvas.height,
      r: Math.random() * 1.3 + 0.3,
      base: Math.random() * 0.5 + 0.25,
      speed: Math.random() * 0.015 + 0.004,
      phase: Math.random() * Math.PI * 2,
    }));
  }
  function draw(t) {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = '#eaf0fb';
    stars.forEach((s) => {
      const twinkle = reduceMotion ? s.base : s.base + Math.sin(t * s.speed + s.phase) * 0.35;
      ctx.globalAlpha = Math.max(0.08, Math.min(1, twinkle));
      ctx.beginPath();
      ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
      ctx.fill();
    });
    ctx.globalAlpha = 1;
    if (!reduceMotion) requestAnimationFrame(draw);
  }
  window.addEventListener('resize', resize);
  resize();
  draw(0);
}

function $(sel) { return document.querySelector(sel); }
function el(tag, attrs = {}, children = []) {
  const e = document.createElement(tag);
  Object.entries(attrs).forEach(([k, v]) => {
    if (k === 'html') e.innerHTML = v;
    else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else e.setAttribute(k, v);
  });
  (Array.isArray(children) ? children : [children]).forEach((c) => {
    if (c == null) return;
    e.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
  });
  return e;
}
function showToast(msg) {
  const t = $('#toast');
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 2200);
}
async function api(path, opts = {}) {
  const res = await fetch('/api' + path, {
    headers: { 'content-type': 'application/json' },
    ...opts,
    body: opts.body ? JSON.stringify(opts.body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
  return data;
}
function fmtNum(n) { return Number(n || 0).toLocaleString('zh-Hant-TW'); }
function fmtMoney(n) { return 'NT$ ' + Number(n || 0).toLocaleString('zh-Hant-TW'); }

// ===================== Auth =====================
function toggleAuth(showRegister) {
  $('#loginForm').style.display = showRegister ? 'none' : 'block';
  $('#registerForm').style.display = showRegister ? 'block' : 'none';
}

async function doLogin() {
  try {
    const user = await api('/auth/login', {
      method: 'POST',
      body: { email: $('#loginEmail').value.trim(), password: $('#loginPassword').value },
    });
    onAuthed(user);
  } catch (e) { $('#loginError').textContent = e.message; }
}
async function doRegister() {
  try {
    const user = await api('/auth/register', {
      method: 'POST',
      body: { name: $('#regName').value.trim(), email: $('#regEmail').value.trim(), password: $('#regPassword').value },
    });
    onAuthed(user);
  } catch (e) { $('#regError').textContent = e.message; }
}
async function doLogout() {
  await api('/auth/logout', { method: 'POST' });
  state.user = null;
  $('#shell').style.display = 'none';
  $('#authScreen').style.display = 'flex';
}
function onAuthed(user) {
  state.user = user;
  $('#authScreen').style.display = 'none';
  $('#shell').style.display = 'flex';
  $('#userName').textContent = user.name;
  $('#userAvatar').textContent = (user.name || '?').slice(0, 1).toUpperCase();
  restoreSidebarState();
  loadPrefsAndBoot();
}
initStarfield();

async function loadPrefsAndBoot() {
  try {
    state.prefs = await api('/prefs');
    if (state.prefs.watchlist && state.prefs.watchlist.length) state.watchlist = state.prefs.watchlist;
  } catch (e) { /* 忽略，用預設值 */ }
  renderDashboard();
  switchTab('dashboard');
  try {
    const health = await api('/health');
    $('#appVersion').textContent = health.version;
  } catch (e) {}
}

// ===================== Tab 切換 =====================
const TAB_TITLES = { dashboard: '我的首頁', stocks: '股票', travel: '交通與旅遊', diary: '日記', mood: '心情陪伴', finance: '記帳', calendar: '行事曆', assistant: 'AI 助理', settings: '個人化設定' };
function switchTab(tab) {
  document.querySelectorAll('.nav-item').forEach((n) => n.classList.toggle('active', n.dataset.tab === tab));
  document.querySelectorAll('.tab-panel').forEach((p) => (p.style.display = 'none'));
  $(`#tab-${tab}`).style.display = 'block';
  $('#pageTitle').textContent = TAB_TITLES[tab];
  if (tab === 'stocks') renderStocks();
  if (tab === 'travel') renderTravel();
  if (tab === 'diary') renderDiary();
  if (tab === 'mood') renderMood();
  if (tab === 'finance') renderFinance();
  if (tab === 'calendar') renderCalendar();
  if (tab === 'assistant') renderAssistant();
  if (tab === 'settings') renderSettings();
}

// ===================== SVG 圖表小工具 =====================
// 依 dataviz 規範：細線條、圓角端點、2px 間距、淺色 gridline、tooltip 互動
function svgEl(tag, attrs) {
  const e = document.createElementNS('http://www.w3.org/2000/svg', tag);
  Object.entries(attrs).forEach(([k, v]) => e.setAttribute(k, v));
  return e;
}

// 水平長條圖 (用於記帳分類金額) — 類別色依固定順序指派
const CATEGORICAL = ['--series-blue', '--series-orange', '--series-aqua', '--series-yellow', '--series-magenta', '--series-green', '--series-violet', '--series-red'];
function cssVar(name) { return getComputedStyle(document.documentElement).getPropertyValue(name).trim(); }

function renderBarChart(container, data, opts = {}) {
  // data: [{label, value}]
  container.innerHTML = '';
  if (!data.length) { container.appendChild(el('div', { class: 'empty-state' }, opts.emptyText || '目前沒有資料')); return; }
  const width = container.clientWidth || 400;
  const rowH = 30;
  const height = data.length * rowH + 10;
  const max = Math.max(...data.map((d) => d.value), 1);
  const svg = svgEl('svg', { width: '100%', height, viewBox: `0 0 ${width} ${height}` });

  data.forEach((d, i) => {
    const y = i * rowH + 6;
    // 預留右側 90px 給數值標籤，避免最大值那一列的長條把標籤擠出容器外
    const barW = Math.max(4, (d.value / max) * (width - 140 - 90));
    const color = cssVar(CATEGORICAL[i % CATEGORICAL.length]);
    svg.appendChild(svgEl('rect', { x: 110, y, width: barW, height: 14, rx: 4, fill: color }));
    const label = svgEl('text', { x: 0, y: y + 11, 'font-size': 12, fill: cssVar('--text-secondary') });
    label.textContent = d.label.length > 10 ? d.label.slice(0, 10) + '…' : d.label;
    svg.appendChild(label);
    const val = svgEl('text', { x: 110 + barW + 8, y: y + 11, 'font-size': 12, fill: cssVar('--text-primary') });
    val.textContent = opts.money ? fmtMoney(d.value) : fmtNum(d.value);
    svg.appendChild(val);

    const hit = svgEl('rect', { x: 110, y, width: Math.max(barW, 4), height: 14, fill: 'transparent' });
    hit.addEventListener('mousemove', (ev) => showTooltip(ev, `${d.label}: ${opts.money ? fmtMoney(d.value) : fmtNum(d.value)}`));
    hit.addEventListener('mouseleave', hideTooltip);
    svg.appendChild(hit);
  });
  container.appendChild(svg);
}

// 發散長條圖 (法人買賣超: 正值買超=blue, 負值賣超=red, 0軸=灰色基準線)
function renderDivergingChart(container, data) {
  container.innerHTML = '';
  if (!data.length) { container.appendChild(el('div', { class: 'empty-state' }, '目前沒有可用的法人買賣超資料')); return; }
  const width = container.clientWidth || 500;
  const height = 180;
  const padL = 10, padR = 10, padTop = 10, padBottom = 24;
  const plotW = width - padL - padR;
  const plotH = height - padTop - padBottom;
  const max = Math.max(...data.map((d) => Math.abs(d.netBuySell)), 1);
  const barW = Math.max(6, plotW / data.length - 6);
  const midY = padTop + plotH / 2;

  const svg = svgEl('svg', { width: '100%', height, viewBox: `0 0 ${width} ${height}` });
  svg.appendChild(svgEl('line', { x1: padL, x2: width - padR, y1: midY, y2: midY, stroke: cssVar('--baseline'), 'stroke-width': 1 }));

  data.forEach((d, i) => {
    const x = padL + i * (plotW / data.length) + (plotW / data.length - barW) / 2;
    const h = (Math.abs(d.netBuySell) / max) * (plotH / 2 - 4);
    const isBuy = d.netBuySell >= 0;
    const y = isBuy ? midY - h : midY;
    const color = isBuy ? cssVar('--series-blue') : cssVar('--series-red');
    svg.appendChild(svgEl('rect', { x, y, width: barW, height: Math.max(h, 1), rx: 3, fill: color }));

    const hit = svgEl('rect', { x, y: padTop, width: barW, height: plotH, fill: 'transparent' });
    hit.addEventListener('mousemove', (ev) => showTooltip(ev, `${d.date}: ${isBuy ? '買超' : '賣超'} ${fmtNum(Math.abs(d.netBuySell))} 股`));
    hit.addEventListener('mouseleave', hideTooltip);
    svg.appendChild(hit);

    if (i % Math.ceil(data.length / 6 || 1) === 0) {
      const lbl = svgEl('text', { x: x + barW / 2, y: height - 6, 'font-size': 10, 'text-anchor': 'middle', fill: cssVar('--text-muted') });
      lbl.textContent = (d.date || '').slice(4);
      svg.appendChild(lbl);
    }
  });
  container.appendChild(svg);
  container.appendChild(el('div', { class: 'legend' }, [
    el('div', { class: 'legend-item' }, [el('div', { class: 'legend-dot', style: `background:${cssVar('--series-blue')}` }), '買超 (法人淨買進)']),
    el('div', { class: 'legend-item' }, [el('div', { class: 'legend-dot', style: `background:${cssVar('--series-red')}` }), '賣超 (法人淨賣出)']),
  ]));
}

// 折線圖 (記帳月趨勢: 收入 vs 支出 兩條線)
function renderLineChart(container, series) {
  // series: [{name, color, points:[{x,y}]}]
  container.innerHTML = '';
  const allPoints = series.flatMap((s) => s.points);
  if (!allPoints.length) { container.appendChild(el('div', { class: 'empty-state' }, '目前沒有可用的趨勢資料')); return; }
  const width = container.clientWidth || 500;
  const height = 200;
  const padL = 40, padR = 16, padTop = 16, padBottom = 26;
  const plotW = width - padL - padR;
  const plotH = height - padTop - padBottom;
  const xs = [...new Set(allPoints.map((p) => p.x))];
  const maxY = Math.max(...allPoints.map((p) => p.y), 1);

  const svg = svgEl('svg', { width: '100%', height, viewBox: `0 0 ${width} ${height}` });
  for (let g = 0; g <= 4; g++) {
    const y = padTop + (plotH / 4) * g;
    svg.appendChild(svgEl('line', { x1: padL, x2: width - padR, y1: y, y2: y, stroke: cssVar('--grid-line'), 'stroke-width': 1 }));
    const val = svgEl('text', { x: 4, y: y + 4, 'font-size': 10, fill: cssVar('--text-muted') });
    val.textContent = fmtNum(Math.round(maxY - (maxY / 4) * g));
    svg.appendChild(val);
  }

  series.forEach((s) => {
    const pts = xs.map((x) => {
      const p = s.points.find((pt) => pt.x === x);
      return { x, y: p ? p.y : 0 };
    });
    const path = pts.map((p, i) => {
      const px = padL + (xs.indexOf(p.x) / Math.max(xs.length - 1, 1)) * plotW;
      const py = padTop + plotH - (p.y / maxY) * plotH;
      return `${i === 0 ? 'M' : 'L'}${px},${py}`;
    }).join(' ');
    svg.appendChild(svgEl('path', { d: path, fill: 'none', stroke: s.color, 'stroke-width': 2, 'stroke-linecap': 'round' }));

    pts.forEach((p) => {
      const px = padL + (xs.indexOf(p.x) / Math.max(xs.length - 1, 1)) * plotW;
      const py = padTop + plotH - (p.y / maxY) * plotH;
      const dot = svgEl('circle', { cx: px, cy: py, r: 4, fill: s.color });
      dot.addEventListener('mousemove', (ev) => showTooltip(ev, `${s.name} ${p.x}: ${fmtMoney(p.y)}`));
      dot.addEventListener('mouseleave', hideTooltip);
      svg.appendChild(dot);
    });
  });

  xs.forEach((x, i) => {
    const px = padL + (i / Math.max(xs.length - 1, 1)) * plotW;
    const lbl = svgEl('text', { x: px, y: height - 6, 'font-size': 10, 'text-anchor': 'middle', fill: cssVar('--text-muted') });
    lbl.textContent = x;
    svg.appendChild(lbl);
  });

  container.appendChild(svg);
  container.appendChild(el('div', { class: 'legend' }, series.map((s) =>
    el('div', { class: 'legend-item' }, [el('div', { class: 'legend-dot', style: `background:${s.color}` }), s.name])
  )));
}

// 股價走勢圖 (收盤價 + MA5 + MA20)：y 軸依價格範圍縮放 (不從 0 開始，股價圖慣例)
function renderPriceChart(container, points) {
  container.innerHTML = '';
  if (!points || points.length < 2) { container.appendChild(el('div', { class: 'empty-state' }, '歷史資料不足，無法繪製走勢圖')); return; }
  const width = container.clientWidth || 600;
  const height = 220;
  const padL = 48, padR = 14, padTop = 12, padBottom = 26;
  const plotW = width - padL - padR, plotH = height - padTop - padBottom;
  const vals = points.flatMap((p) => [p.close, p.ma5, p.ma20]).filter((v) => v != null);
  const vMin = Math.min(...vals), vMax = Math.max(...vals);
  const span = vMax - vMin || vMax * 0.02 || 1;
  const lo = vMin - span * 0.08, hi = vMax + span * 0.08;
  const xAt = (i) => padL + (i / Math.max(points.length - 1, 1)) * plotW;
  const yAt = (v) => padTop + plotH - ((v - lo) / (hi - lo)) * plotH;

  const svg = svgEl('svg', { width: '100%', height, viewBox: `0 0 ${width} ${height}` });
  for (let g = 0; g <= 4; g++) {
    const y = padTop + (plotH / 4) * g;
    const v = hi - ((hi - lo) / 4) * g;
    svg.appendChild(svgEl('line', { x1: padL, x2: width - padR, y1: y, y2: y, stroke: cssVar('--grid-line'), 'stroke-width': 1 }));
    const lbl = svgEl('text', { x: 4, y: y + 4, 'font-size': 10, fill: cssVar('--text-muted') });
    lbl.textContent = v >= 1000 ? Math.round(v).toLocaleString() : v.toFixed(1);
    svg.appendChild(lbl);
  }

  const series = [
    { key: 'close', name: '收盤價', color: cssVar('--series-blue'), w: 2 },
    { key: 'ma5', name: 'MA5', color: cssVar('--series-orange'), w: 1.5 },
    { key: 'ma20', name: 'MA20', color: cssVar('--series-aqua'), w: 1.5 },
  ];
  series.forEach((s) => {
    let d = '';
    points.forEach((p, i) => {
      const v = p[s.key];
      if (v == null) return;
      d += `${d ? 'L' : 'M'}${xAt(i).toFixed(1)},${yAt(v).toFixed(1)} `;
    });
    if (d) svg.appendChild(svgEl('path', { d: d.trim(), fill: 'none', stroke: s.color, 'stroke-width': s.w, 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }));
  });

  const colW = plotW / points.length;
  points.forEach((p, i) => {
    const hit = svgEl('rect', { x: xAt(i) - colW / 2, y: padTop, width: colW, height: plotH, fill: 'transparent' });
    hit.addEventListener('mousemove', (ev) => showTooltip(ev,
      `${p.date} 收盤 ${p.close}${p.ma5 != null ? ' · MA5 ' + p.ma5 : ''}${p.ma20 != null ? ' · MA20 ' + p.ma20 : ''}`));
    hit.addEventListener('mouseleave', hideTooltip);
    svg.appendChild(hit);
  });

  const step = Math.max(1, Math.ceil(points.length / 5));
  points.forEach((p, i) => {
    if (i % step !== 0 && i !== points.length - 1) return;
    const lbl = svgEl('text', { x: xAt(i), y: height - 6, 'font-size': 10, 'text-anchor': 'middle', fill: cssVar('--text-muted') });
    lbl.textContent = String(p.date || '').slice(-5);
    svg.appendChild(lbl);
  });

  container.appendChild(svg);
  container.appendChild(el('div', { class: 'legend' }, series.map((s) =>
    el('div', { class: 'legend-item' }, [el('div', { class: 'legend-dot', style: `background:${s.color}` }), s.name])
  )));
}

function showTooltip(ev, text) {
  const tip = $('#tooltip');
  tip.textContent = text;
  tip.style.left = ev.pageX + 12 + 'px';
  tip.style.top = ev.pageY + 12 + 'px';
  tip.style.opacity = '1';
}
function hideTooltip() { $('#tooltip').style.opacity = '0'; }

// ===================== Dashboard =====================
const DASH_GREETINGS = [
  '今天也辛苦了，記得喝口水休息一下 🌿',
  '不管今天過得如何，你都做得很好 ✨',
  '慢慢來也沒關係，你的步調就是最好的步調 🌙',
  '有你在乎的事情，本身就是一件很棒的事 💫',
  '今天想做的事，先做一件小小的就好 🌤️',
  '累的時候，休息也是一種前進 🍃',
];

function renderDashboard() {
  const c = $('#tab-dashboard');
  c.innerHTML = '';
  const greeting = DASH_GREETINGS[Math.floor(Math.random() * DASH_GREETINGS.length)];

  const orbCard = el('div', { class: 'dash-orb-card' }, [
    el('div', { class: 'dash-orb-visual' }, [
      el('div', { class: 'dash-orb-ring' }),
      el('div', { class: 'dash-orb-core' }),
    ]),
    el('div', { class: 'hello' }, `哈囉，${state.user ? state.user.name : ''} 👋`),
    el('div', { class: 'sub' }, greeting),
    el('div', { class: 'dash-orb-input' }, [
      el('input', { id: 'dashAskInput', placeholder: '想問 AI 什麼呢？', onkeydown: (ev) => { if (ev.key === 'Enter') dashAskAI(); } }),
      el('button', { class: 'btn btn-primary', onclick: () => dashAskAI() }, '送出'),
    ]),
    el('div', { class: 'dash-orb-hint' }, '按 Enter 直接與 AI 助理對話，資料與對話記錄都會同步保存'),
  ]);

  const leftCol = el('div', { class: 'dash-col' }, [
    dashCard('📈', '股市摘要', 'stocksSummaryBody', () => switchTab('stocks')),
    dashCard('📅', '行事曆行程', 'calendarSummaryBody', () => switchTab('calendar')),
    dashCard('🚄', '交通與旅遊', null, () => switchTab('travel'), '台鐵/高鐵時刻、機票訂房連結、智慧行程規劃，點卡片前往'),
  ]);
  const rightCol = el('div', { class: 'dash-col' }, [
    dashCard('💗', '心情陪伴', 'moodSummaryBody', () => switchTab('mood')),
    dashCard('💰', '記帳流水', 'financeSummaryBody', () => switchTab('finance')),
    dashCard('📔', '日記隨筆', 'diarySummaryBody', () => switchTab('diary')),
  ]);

  c.appendChild(el('div', { class: 'dash-grid' }, [
    leftCol,
    el('div', { class: 'dash-orb-col' }, [orbCard]),
    rightCol,
  ]));

  loadDashStockSummary();
  loadDashCalendarSummary();
  loadDashFinanceSummary();
  loadDashDiarySummary();
  loadDashMoodSummary();
}

function dashCard(icon, title, bodyId, onClick, staticHint) {
  const children = [el('h3', {}, [el('div', { class: 'hex-badge' }, icon), title])];
  if (staticHint) {
    children.push(el('p', { class: 'hint', style: 'margin-bottom:0' }, staticHint));
  } else if (bodyId) {
    children.push(el('div', { id: bodyId }, el('p', { class: 'hint', style: 'margin-bottom:0' }, '載入中...')));
  }
  return el('div', { class: `card dash-card${onClick ? ' clickable' : ''}`, onclick: onClick || undefined }, children);
}

async function loadDashMoodSummary() {
  const body = $('#moodSummaryBody');
  if (!body) return;
  try {
    const today = todayStr();
    const [todayRows, summary] = await Promise.all([
      api(`/mood/entries?from=${today}&to=${today}`),
      api('/mood/summary?days=7'),
    ]);
    body.innerHTML = '';
    if (todayRows.length) {
      body.appendChild(el('div', { class: 'stat-big' }, `${todayRows[0].score} 分`));
      body.appendChild(el('p', { class: 'hint', style: 'margin:4px 0 0' }, `今天已記錄 · 近 7 天平均 ${summary.average != null ? summary.average : '--'} 分，點卡片查看趨勢與陪伴對話`));
    } else {
      body.appendChild(el('p', { class: 'hint', style: 'margin-bottom:0' }, '今天還沒記錄心情，點卡片花 10 秒記一下'));
    }
  } catch (e) {
    body.innerHTML = '';
    body.appendChild(el('p', { class: 'hint', style: 'margin-bottom:0' }, '心情資料暫時無法取得'));
  }
}

async function loadDashStockSummary() {
  const body = $('#stocksSummaryBody');
  if (!body) return;
  try {
    const t = await api('/stocks/index/taiex');
    body.innerHTML = '';
    const changeColor = t.change > 0 ? 'delta-up' : t.change < 0 ? 'delta-down' : '';
    body.appendChild(el('div', { class: 'stat-big' }, [
      t.index != null ? Number(t.index).toLocaleString('zh-Hant-TW', { maximumFractionDigits: 2 }) : '--',
      el('span', { class: changeColor, style: 'font-size:13px;margin-left:8px' }, t.change != null ? `${t.change > 0 ? '▲+' : t.change < 0 ? '▼' : ''}${t.change}` : ''),
    ]));
    body.appendChild(el('p', { class: 'hint', style: 'margin:6px 0 0' }, `加權指數 · 自選股 ${state.watchlist.length} 檔，點卡片查看詳情`));
  } catch (e) {
    body.innerHTML = '';
    body.appendChild(el('p', { class: 'hint', style: 'margin-bottom:0' }, '股市資料暫時無法取得'));
  }
}

async function loadDashCalendarSummary() {
  const body = $('#calendarSummaryBody');
  if (!body) return;
  try {
    const today = new Date();
    const from = today.toISOString().slice(0, 10);
    const toDate = new Date(today); toDate.setDate(toDate.getDate() + 14);
    const to = toDate.toISOString().slice(0, 10);
    const events = await api(`/calendar?from=${from}&to=${to}`);
    body.innerHTML = '';
    if (!events.length) {
      body.appendChild(el('p', { class: 'hint', style: 'margin-bottom:0' }, '接下來兩週沒有安排的行程'));
    } else {
      const list = el('ul', { style: 'list-style:none;padding:0;margin:0;display:flex;flex-direction:column;gap:6px' });
      events.slice(0, 3).forEach((ev) => {
        list.appendChild(el('li', { style: 'font-size:12.5px;color:var(--text-secondary)' }, `${ev.event_date}${ev.start_time ? ' ' + ev.start_time : ''} · ${ev.title}`));
      });
      body.appendChild(list);
      if (events.length > 3) body.appendChild(el('p', { class: 'hint', style: 'margin:6px 0 0' }, `還有 ${events.length - 3} 項行程，點卡片查看完整行事曆`));
    }
  } catch (e) {
    body.innerHTML = '';
    body.appendChild(el('p', { class: 'hint', style: 'margin-bottom:0' }, '行事曆資料暫時無法取得'));
  }
}

async function loadDashFinanceSummary() {
  const body = $('#financeSummaryBody');
  if (!body) return;
  try {
    const summary = await api('/finance/summary');
    const income = (summary.totals || []).find((t) => t.type === 'income')?.total || 0;
    const expense = (summary.totals || []).find((t) => t.type === 'expense')?.total || 0;
    body.innerHTML = '';
    body.appendChild(el('div', { class: 'stat-big' }, fmtMoney(expense)));
    body.appendChild(el('p', { class: 'hint', style: 'margin:4px 0 0' }, `本月支出 · 收入 ${fmtMoney(income)}，點卡片看完整分析`));
  } catch (e) {
    body.innerHTML = '';
    body.appendChild(el('p', { class: 'hint', style: 'margin-bottom:0' }, '記帳資料暫時無法取得'));
  }
}

async function loadDashDiarySummary() {
  const body = $('#diarySummaryBody');
  if (!body) return;
  try {
    const entries = await api('/diary?from=0001-01-01&to=9999-12-31');
    body.innerHTML = '';
    if (!entries.length) {
      body.appendChild(el('p', { class: 'hint', style: 'margin-bottom:0' }, '還沒有日記，點卡片開始寫下今天'));
    } else {
      const latest = entries[0];
      const snippet = (latest.content || '').slice(0, 40);
      body.appendChild(el('p', { style: 'font-size:12.5px;color:var(--text-secondary);margin:0 0 4px' }, `${latest.entry_date}`));
      body.appendChild(el('p', { class: 'hint', style: 'margin-bottom:0' }, snippet + (latest.content && latest.content.length > 40 ? '…' : '')));
    }
  } catch (e) {
    body.innerHTML = '';
    body.appendChild(el('p', { class: 'hint', style: 'margin-bottom:0' }, '日記資料暫時無法取得'));
  }
}

function dashAskAI() {
  const input = $('#dashAskInput');
  const text = input ? input.value.trim() : '';
  if (!text) { switchTab('assistant'); return; }
  switchTab('assistant');
  state.assistantHistory = state.assistantHistory || [];
  const target = $('#assistantInput');
  if (target) { target.value = text; sendAssistantMessage(); }
}

// ===================== 股票 =====================
async function renderStocks() {
  const c = $('#tab-stocks');
  c.innerHTML = '';
  c.appendChild(el('div', { class: 'disclaimer' }, '股票資訊來自台灣證券交易所公開資料 (每日盤後更新)，均線指標僅為統計描述、SOX 指數為非官方資料源，皆僅供參考整理，不構成任何投資建議，買賣決策請自行判斷並留意風險。'));

  c.appendChild(el('div', { class: 'grid-2', style: 'margin-bottom:16px' }, [
    el('div', { class: 'card', id: 'taiexCard', style: 'margin-bottom:0' }, [el('div', {}, '台股加權指數載入中...')]),
    el('div', { class: 'card', id: 'soxCard', style: 'margin-bottom:0' }, [el('div', {}, '費半指數 (SOX) 載入中...')]),
  ]));
  loadTaiexCard();
  loadSoxCard();

  const watchCard = el('div', { class: 'card' }, [
    el('h3', {}, '自選股'),
    el('div', { class: 'form-row' }, [
      el('input', { id: 'newStockCode', placeholder: '輸入股票代號或公司名稱，如 2330 或 台積電' }),
      el('button', { class: 'btn btn-primary', onclick: addWatchStock }, '加入自選'),
    ]),
    el('div', { id: 'watchlistArea' }),
  ]);
  c.appendChild(watchCard);
  await renderWatchlist();
}

function indexCardContent(name, value, change, badgeText, extraLabel) {
  const changeColor = change > 0 ? 'delta-up' : change < 0 ? 'delta-down' : '';
  return el('div', { class: 'index-card' }, [
    el('div', {}, [
      el('div', { class: 'idx-name' }, name),
      el('div', { class: 'stat-tile' }, [
        el('span', { class: 'value' }, value != null ? Number(value).toLocaleString('zh-Hant-TW', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : '--'),
        el('span', { class: changeColor, style: 'margin-left:8px' }, change != null ? `${change > 0 ? '▲+' : change < 0 ? '▼' : ''}${change}` : ''),
      ]),
      extraLabel ? el('div', { class: 'label' }, extraLabel) : null,
    ]),
    el('span', { class: 'badge badge-neutral' }, badgeText),
  ]);
}

async function loadTaiexCard() {
  const card = $('#taiexCard');
  try {
    const t = await api('/stocks/index/taiex');
    card.innerHTML = '';
    card.appendChild(indexCardContent(t.symbol, t.index, t.change, '證交所官方資料',
      t.tradeValue != null ? `資料日期 ${t.date || '--'} · 成交金額 ${fmtNum(Math.round(t.tradeValue / 100000000))} 億` : `資料日期 ${t.date || '--'}`));
  } catch (e) {
    card.innerHTML = '';
    card.appendChild(el('div', { style: 'font-size:12px;color:var(--text-muted)' }, `加權指數暫時無法取得 (${e.message})`));
  }
}

async function loadSoxCard() {
  const card = $('#soxCard');
  try {
    const sox = await api('/stocks/index/sox');
    card.innerHTML = '';
    card.appendChild(indexCardContent(sox.symbol, sox.price, sox.change, '非官方資料源', null));
  } catch (e) {
    card.innerHTML = '';
    card.appendChild(el('div', { style: 'font-size:12px;color:var(--text-muted)' }, `費半指數暫時無法取得 (${e.message})`));
  }
}

async function addWatchStock() {
  const raw = $('#newStockCode').value.trim();
  if (!raw) return;
  try {
    const resolved = await api(`/stocks/resolve/${encodeURIComponent(raw)}`);
    if (!state.watchlist.includes(resolved.code)) state.watchlist.push(resolved.code);
    $('#newStockCode').value = '';
    await savePrefsWatchlist();
    expandedStocks.add(resolved.code); // 剛加入的直接展開，讓使用者立刻看到資訊
    renderWatchlist();
    showToast(`已加入 ${resolved.name} (${resolved.code})`);
  } catch (e) {
    showToast(`加入失敗：${e.message}`);
  }
}
async function removeWatchStock(code) {
  state.watchlist = state.watchlist.filter((c) => c !== code);
  await savePrefsWatchlist();
  renderWatchlist();
}
async function savePrefsWatchlist() {
  try {
    await api('/prefs', { method: 'PUT', body: { ...state.prefs, watchlist: state.watchlist } });
  } catch (e) {}
}

const expandedStocks = new Set();
function toggleStockExpand(code) {
  if (expandedStocks.has(code)) expandedStocks.delete(code);
  else expandedStocks.add(code);
  renderWatchlist();
}

async function renderWatchlist() {
  const area = $('#watchlistArea');
  area.innerHTML = '';
  if (!state.watchlist.length) { area.appendChild(el('div', { class: 'empty-state' }, '尚未加入自選股')); return; }

  for (const code of state.watchlist) {
    const box = el('div', { class: 'card stock-card', style: 'margin-bottom:12px' }, [el('div', {}, `載入 ${code} 中...`)]);
    area.appendChild(box);
    loadStockCard(code, box);
  }
}

function sectionTitle(text) {
  return el('div', { style: 'font-size:12.5px;font-weight:700;color:var(--text-secondary);margin-bottom:8px' }, text);
}

function miniStat(label, value) {
  return el('span', { class: 'mini-stat' }, [label + ' ', el('b', {}, value)]);
}
function miniBadge(tone, text) {
  const cls = tone === 'positive' ? 'badge-positive' : tone === 'negative' ? 'badge-negative' : 'badge-neutral';
  return el('span', { class: `badge ${cls}`, style: 'font-size:11px;padding:2px 8px' }, text);
}

async function loadStockCard(code, box) {
  try {
    const [quote, inst, indicatorRes, newsRes, valuation, historyRes] = await Promise.all([
      api(`/stocks/quote/${code}`).catch((e) => ({ error: e.message })),
      api(`/stocks/institutional/${code}?days=15`).catch((e) => ({ error: e.message })),
      api(`/stocks/indicator/${code}`).catch((e) => ({ error: e.message })),
      api(`/stocks/news/${code}`).catch((e) => ({ error: e.message })),
      api(`/stocks/valuation/${code}`).catch((e) => ({ error: e.message })),
      api(`/stocks/history/${code}`).catch((e) => ({ error: e.message })),
    ]);
    box.innerHTML = '';
    if (quote.error) {
      box.appendChild(el('div', { style: 'display:flex;justify-content:space-between;align-items:center' }, [
        el('div', {}, [el('b', {}, code), ` — ${quote.error}`]),
        el('button', { class: 'btn btn-ghost', onclick: () => removeWatchStock(code) }, '移除'),
      ]));
      return;
    }
    const isOpen = expandedStocks.has(code);
    const changeColor = quote.change > 0 ? 'delta-up' : quote.change < 0 ? 'delta-down' : '';
    const prevClose = quote.closingPrice != null ? quote.closingPrice - quote.change : null;
    const changePct = prevClose ? (quote.change / prevClose) * 100 : null;

    // ---- 精簡摘要列：永遠顯示，收合時只看這排數字就好，不用整張攤開 ----
    const summaryChips = [];
    if (!valuation.error && valuation && valuation.peRatio != null) summaryChips.push(miniStat('本益比', valuation.peRatio.toFixed(2)));
    if (!valuation.error && valuation && valuation.dividendYield != null) summaryChips.push(miniStat('殖利率', valuation.dividendYield.toFixed(2) + '%'));
    if (!indicatorRes.error && indicatorRes.indicator && indicatorRes.indicator.available) {
      summaryChips.push(miniBadge(indicatorRes.indicator.tone, `均線 ${indicatorRes.indicator.label}`));
    }
    if (!inst.error && inst.signal) summaryChips.push(miniBadge(inst.signal.tone, `法人 ${inst.signal.label}`));

    const header = el('div', { class: 'stock-summary-row', onclick: () => toggleStockExpand(code) }, [
      el('div', { class: 'stock-summary-left' }, [
        el('div', { style: 'font-weight:800;font-size:15px;display:flex;align-items:center;gap:6px' }, [
          el('span', { class: 'chevron' }, isOpen ? '▾' : '▸'),
          `${quote.name || code} (${code})`,
        ]),
        summaryChips.length ? el('div', { class: 'stock-summary-chips' }, summaryChips) : el('div', { class: 'label', style: 'margin-top:4px' }, `收盤日期 ${quote.date || '--'}`),
      ]),
      el('div', { class: 'stock-summary-right' }, [
        el('div', { class: 'stat-tile' }, [
          el('span', { class: 'value', style: 'font-size:18px' }, quote.closingPrice != null ? quote.closingPrice.toFixed(2) : '--'),
          el('span', { class: changeColor, style: 'margin-left:6px;font-size:12.5px' },
            `${quote.change > 0 ? '▲+' : quote.change < 0 ? '▼' : ''}${quote.change}${changePct != null ? ` (${changePct > 0 ? '+' : ''}${changePct.toFixed(2)}%)` : ''}`),
        ]),
        el('button', {
          class: 'btn btn-ghost',
          style: 'padding:5px 10px;font-size:12px',
          onclick: (ev) => { ev.stopPropagation(); removeWatchStock(code); },
        }, '移除'),
      ]),
    ]);
    box.appendChild(header);

    if (!isOpen) return; // 收合狀態：只顯示上面那排摘要，不載入圖表/新聞等細節 DOM，畫面更乾淨

    const detail = el('div', { class: 'stock-detail' });
    box.appendChild(detail);

    detail.appendChild(el('div', { class: 'label', style: 'margin-bottom:10px' }, `收盤日期 ${quote.date || '--'} (每日盤後更新)`));

    // ---- 詳細數據格 (開高低量 + 估值) ----
    const kv = (k, v) => el('div', { class: 'kv' }, [el('div', { class: 'k' }, k), el('div', { class: 'v' }, v)]);
    const kvs = [
      kv('開盤', quote.openingPrice != null ? quote.openingPrice.toFixed(2) : '--'),
      kv('最高', quote.highestPrice != null ? quote.highestPrice.toFixed(2) : '--'),
      kv('最低', quote.lowestPrice != null ? quote.lowestPrice.toFixed(2) : '--'),
      kv('成交量', fmtNum(quote.tradeVolume) + ' 股'),
    ];
    if (!valuation.error && valuation && (valuation.peRatio != null || valuation.dividendYield != null || valuation.pbRatio != null)) {
      kvs.push(kv('本益比', valuation.peRatio != null ? valuation.peRatio.toFixed(2) : '--'));
      kvs.push(kv('殖利率', valuation.dividendYield != null ? valuation.dividendYield.toFixed(2) + '%' : '--'));
      kvs.push(kv('股價淨值比', valuation.pbRatio != null ? valuation.pbRatio.toFixed(2) : '--'));
      kvs.push(kv('振幅',
        quote.highestPrice != null && quote.lowestPrice != null && prevClose
          ? (((quote.highestPrice - quote.lowestPrice) / prevClose) * 100).toFixed(2) + '%' : '--'));
    }
    detail.appendChild(el('div', { class: 'kv-grid' }, kvs));

    // ---- 股價走勢 + 均線圖 ----
    if (!historyRes.error && historyRes.points && historyRes.points.length >= 5) {
      const sec = el('div', { style: 'margin-top:14px;padding-top:12px;border-top:1px solid var(--grid-line)' }, [
        sectionTitle(`近 ${historyRes.points.length} 個交易日收盤走勢與均線`),
      ]);
      const chartDiv = el('div');
      sec.appendChild(chartDiv);
      detail.appendChild(sec);
      renderPriceChart(chartDiv, historyRes.points);
    }

    // ---- 均線位置描述 (非預測) ----
    if (!indicatorRes.error && indicatorRes.indicator && indicatorRes.indicator.available) {
      const ind = indicatorRes.indicator;
      const badgeClass = ind.tone === 'positive' ? 'badge-positive' : ind.tone === 'negative' ? 'badge-negative' : 'badge-neutral';
      detail.appendChild(el('div', { style: 'margin-top:10px' }, [
        el('span', { class: `badge ${badgeClass}` }, `均線位置：${ind.label}`),
        el('span', { style: 'margin-left:8px;font-size:12px;color:var(--text-muted)' }, `MA5 ${ind.ma5} / MA20 ${ind.ma20} (${ind.diffPct > 0 ? '+' : ''}${ind.diffPct}%)`),
        el('div', { style: 'font-size:11px;color:var(--text-muted);margin-top:4px' }, ind.disclaimer),
      ]));
    } else if (indicatorRes.indicator) {
      detail.appendChild(el('div', { style: 'margin-top:10px;font-size:12px;color:var(--text-muted)' }, indicatorRes.indicator.reason || ''));
    }

    // ---- 法人動向 (合計圖 + 外資/投信/自營商 分項) ----
    if (!inst.error) {
      const badgeClass = inst.signal.tone === 'positive' ? 'badge-positive' : inst.signal.tone === 'negative' ? 'badge-negative' : 'badge-neutral';
      detail.appendChild(el('div', { style: 'margin-top:14px;padding-top:12px;border-top:1px solid var(--grid-line)' }, [
        sectionTitle('三大法人買賣超 (近15個交易日)'),
        el('div', {}, [
          el('span', { class: `badge ${badgeClass}` }, inst.signal.label),
          el('span', { style: 'margin-left:8px;font-size:12px;color:var(--text-muted)' }, inst.signal.detail),
        ]),
      ]));
      const chartDiv = el('div', { style: 'margin-top:10px' });
      detail.appendChild(chartDiv);
      renderDivergingChart(chartDiv, inst.trend);

      const last = inst.trend[inst.trend.length - 1];
      if (last && last.foreign != null) {
        const sum = (k) => inst.trend.reduce((s, t) => s + (t[k] || 0), 0);
        const chip = (label, today, cum) => el('div', { class: 'inst-chip' }, [
          el('div', { class: 'k' }, `${label} (最新交易日)`),
          el('div', { class: 'v', style: today >= 0 ? 'color:var(--series-blue)' : 'color:var(--series-red)' },
            `${today >= 0 ? '買超 +' : '賣超 '}${fmtNum(today)} 股`),
          el('div', { class: 'k' }, `近${inst.trend.length}日累計 ${cum >= 0 ? '+' : ''}${fmtNum(cum)}`),
        ]);
        detail.appendChild(el('div', { class: 'inst-chips' }, [
          chip('外資', last.foreign, sum('foreign')),
          chip('投信', last.trust, sum('trust')),
          chip('自營商', last.dealer, sum('dealer')),
        ]));
      }
    }

    // ---- 相關新聞 ----
    if (!newsRes.error && newsRes.items && newsRes.items.length) {
      const newsBox = el('div', { style: 'margin-top:14px;padding-top:12px;border-top:1px solid var(--grid-line)' }, [
        sectionTitle('相關新聞 (來源: Yahoo奇摩股市)'),
      ]);
      newsRes.items.slice(0, 5).forEach((n) => {
        newsBox.appendChild(el('a', { href: n.link, target: '_blank', rel: 'noopener', style: 'display:block;font-size:12.5px;color:var(--series-blue);margin-bottom:5px;text-decoration:none' }, '· ' + n.title));
      });
      detail.appendChild(newsBox);
    }
  } catch (e) {
    box.innerHTML = '';
    box.appendChild(el('div', {}, `${code} 載入失敗: ${e.message}`));
  }
}

// ===================== 交通與旅遊 =====================
const TRAVEL_SUB_TABS = [
  { key: 'train', label: '🚄 台鐵 / 高鐵' },
  { key: 'flight', label: '✈️ 機票' },
  { key: 'hotel', label: '🏨 住宿' },
  { key: 'itinerary', label: '🗺️ 行程規劃' },
];
let travelSubTab = 'train';

function switchTravelSub(key) {
  travelSubTab = key;
  renderTravel();
}

function renderTravel() {
  const c = $('#tab-travel');
  c.innerHTML = '';

  // 次分頁：把「火車 / 機票 / 住宿 / 行程規劃」分開，一次只看一個，不要全部塞在同一畫面
  c.appendChild(el('div', { class: 'subnav' }, TRAVEL_SUB_TABS.map((t) =>
    el('div', {
      class: `subnav-item${travelSubTab === t.key ? ' active' : ''}`,
      onclick: () => switchTravelSub(t.key),
    }, t.label)
  )));

  const panel = (key, children) => el('div', { class: `subpanel${travelSubTab === key ? ' active' : ''}` }, children);

  c.appendChild(panel('train', [
    el('div', { class: 'card' }, [
      el('h3', {}, '台鐵 / 高鐵 時刻搜尋'),
      el('p', { class: 'hint' }, '資料來源：交通部 TDX 運輸資料流通服務。僅提供時刻/誤點/票價區間查詢，實際訂票請至官方售票網站。'),
      el('div', { class: 'form-row' }, [
        el('select', { id: 'trainMode' }, [el('option', { value: 'tra' }, '台鐵 TRA'), el('option', { value: 'thsr' }, '高鐵 THSR')]),
        el('input', { id: 'stationName', placeholder: '出發站，如 台北' }),
        el('input', { id: 'stationTo', placeholder: '目的站，如 台中' }),
        el('input', { id: 'trainDate', type: 'date', value: todayStr() }),
      ]),
      el('div', { class: 'form-row' }, [
        el('input', { id: 'timeFrom', type: 'time', value: '06:00' }),
        el('span', { style: 'align-self:center;color:var(--text-muted)' }, '～'),
        el('input', { id: 'timeTo', type: 'time', value: '22:00' }),
        el('input', { id: 'trainNoSearch', placeholder: '搜尋車次號碼 (選填)' }),
        el('button', { class: 'btn btn-primary', onclick: searchTrain }, '查詢'),
      ]),
      el('div', { id: 'trainResult' }),
    ]),
    el('div', { class: 'card' }, [
      el('h3', {}, '⭐ 我的收藏車次'),
      el('p', { class: 'hint' }, '收藏常搭的車次，下次不用重新查詢。'),
      el('div', { id: 'favoriteTrainsArea' }),
    ]),
  ]));

  c.appendChild(panel('flight', [
    el('div', { class: 'card' }, [
      el('h3', {}, '機票 — 各家航空公司/比價網站'),
      el('p', { class: 'hint' }, '目前沒有免費即時比價 API，這裡改用「深連結」方式：點下去會直接跳到該網站，並幫你帶入出發地/目的地/日期。真正一頁比全部價格需要另外申請商業合作 API。'),
      el('div', { class: 'form-row' }, [
        el('input', { id: 'flyFrom', placeholder: '出發地，如 台北' }),
        el('input', { id: 'flyTo', placeholder: '目的地，如 大阪' }),
        el('input', { id: 'flyDate', type: 'date' }),
        el('button', { class: 'btn btn-primary', onclick: searchFlightProviders }, '列出各家連結' ),
      ]),
      el('div', { id: 'flightResult' }),
    ]),
  ]));

  c.appendChild(panel('hotel', [
    el('div', { class: 'card' }, [
      el('h3', {}, '住宿 — 各家訂房網站'),
      el('div', { class: 'form-row' }, [
        el('input', { id: 'hotelCity', placeholder: '城市，如 大阪' }),
        el('input', { id: 'hotelCheckin', type: 'date' }),
        el('input', { id: 'hotelCheckout', type: 'date' }),
        el('button', { class: 'btn btn-primary', onclick: searchHotelProviders }, '列出各家連結'),
      ]),
      el('div', { id: 'hotelResult' }),
    ]),
  ]));

  c.appendChild(panel('itinerary', [
    el('div', { class: 'card' }, [
      el('h3', {}, '智慧行程規劃'),
      el('p', { class: 'hint' }, '輸入出發地、目的地與天數，產生行程草案；若目的地或出發地是已收錄城市 (目前：台中、新北)，會額外附上精選景點/美食/休閒推薦。'),
      el('div', { class: 'form-row' }, [
        el('input', { id: 'tripFrom', placeholder: '出發地' }),
        el('input', { id: 'tripTo', placeholder: '目的地' }),
        el('input', { id: 'tripDays', type: 'number', value: 3, min: 1, max: 14 }),
        el('button', { class: 'btn btn-primary', onclick: generateItinerary }, '產生行程'),
      ]),
      el('div', { id: 'itineraryResult' }),
    ]),
  ]));

  if (travelSubTab === 'train') loadFavoriteTrains();
}

const PROVIDER_COLORS = ['--series-blue', '--series-orange', '--series-aqua', '--series-violet', '--series-magenta', '--series-yellow'];
function providerList(providers) {
  return el('div', {}, providers.map((p, i) => el('a', { href: p.url, target: '_blank', rel: 'noopener', class: 'provider-item' }, [
    el('div', { class: 'p-left' }, [
      el('div', { class: 'p-avatar', style: `background:${cssVar(PROVIDER_COLORS[i % PROVIDER_COLORS.length])}` }, p.name.replace(/^[^一-龥A-Za-z]*/, '').slice(0, 1).toUpperCase()),
      el('div', {}, [
        el('div', { class: 'p-name' }, [
          p.name,
          el('span', { class: p.prefill ? 'tag tag-fill' : 'tag tag-manual' }, p.prefill ? '已帶入條件' : '需自行輸入'),
        ]),
        el('div', { class: 'p-note' }, p.note),
      ]),
    ]),
    el('span', { class: 'p-go' }, '前往 →'),
  ])));
}

async function searchTrain() {
  const mode = $('#trainMode').value;
  const station = $('#stationName').value.trim();
  const to = $('#stationTo').value.trim();
  const date = $('#trainDate').value;
  const timeFrom = $('#timeFrom').value;
  const timeTo = $('#timeTo').value;
  const trainNo = $('#trainNoSearch').value.trim();
  const resultBox = $('#trainResult');
  if (!station) return;
  resultBox.innerHTML = '查詢中...';
  try {
    const qs = new URLSearchParams({ station, to, date, timeFrom, timeTo, trainNo }).toString();
    const data = await api(`/travel/train/${mode}/board?${qs}`);
    resultBox.innerHTML = '';
    if (data.isDemo) resultBox.appendChild(el('div', { class: 'disclaimer' }, data.notice));
    if (data.trains) {
      if (!data.trains.length) { resultBox.appendChild(el('div', { class: 'empty-state' }, '這個時間範圍沒有符合的車次')); return; }
      const rows = data.trains.map((t) => el('tr', {}, [
        el('td', {}, t.trainNo),
        el('td', {}, t.departure),
        el('td', {}, t.arrival || '--'),
        el('td', {}, t.fare != null ? fmtMoney(t.fare) : '--'),
        el('td', {}, t.status),
        el('td', {}, el('button', { class: 'btn btn-ghost', onclick: () => favoriteTrain(mode, t, station, to) }, '⭐ 收藏')),
      ]));
      resultBox.appendChild(el('table', {}, [
        el('thead', {}, el('tr', {}, [el('th', {}, '車次'), el('th', {}, '出發'), el('th', {}, '到達'), el('th', {}, '票價(估)'), el('th', {}, '狀態'), el('th', {}, '')])),
        el('tbody', {}, rows),
      ]));
    } else if (data.raw) {
      resultBox.appendChild(el('pre', { style: 'font-size:11px;white-space:pre-wrap' }, JSON.stringify(data.raw, null, 2).slice(0, 3000)));
    }
  } catch (e) { resultBox.innerHTML = `查詢失敗: ${e.message}`; }
}

async function favoriteTrain(mode, train, fromStation, toStation) {
  try {
    await api('/travel/train/favorites', {
      method: 'POST',
      body: { mode, trainNo: train.trainNo, fromStation, toStation, departureTime: train.departure },
    });
    showToast('已收藏車次');
    loadFavoriteTrains();
  } catch (e) { showToast('收藏失敗: ' + e.message); }
}

async function loadFavoriteTrains() {
  const area = $('#favoriteTrainsArea');
  if (!area) return;
  try {
    const rows = await api('/travel/train/favorites');
    area.innerHTML = '';
    if (!rows.length) { area.appendChild(el('div', { class: 'empty-state' }, '還沒有收藏的車次')); return; }
    rows.forEach((r) => {
      const dateInputId = `favTrainDate-${r.id}`;
      area.appendChild(el('div', { style: 'display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid var(--grid-line);flex-wrap:wrap;gap:8px' }, [
        el('div', { style: 'font-size:13px' }, `${r.mode === 'THSR' ? '高鐵' : '台鐵'} ${r.train_no} · ${r.from_station}${r.to_station ? ' → ' + r.to_station : ''} · ${r.departure_time || ''}`),
        el('div', { style: 'display:flex;gap:6px;align-items:center' }, [
          el('input', { id: dateInputId, type: 'date', style: 'width:132px;padding:6px 8px;font-size:12px' }),
          el('button', { class: 'btn btn-ghost', style: 'font-size:12px', onclick: () => addFavoriteTrainToCalendar(r, dateInputId) }, '📅 加入行事曆'),
          el('button', { class: 'btn btn-ghost', onclick: () => deleteFavoriteTrain(r.id) }, '移除'),
        ]),
      ]));
    });
  } catch (e) { area.innerHTML = ''; }
}
async function deleteFavoriteTrain(id) {
  await api(`/travel/train/favorites/${id}`, { method: 'DELETE' });
  loadFavoriteTrains();
}
async function addFavoriteTrainToCalendar(r, dateInputId) {
  const date = $(`#${dateInputId}`).value;
  if (!date) { showToast('請先選擇日期'); return; }
  try {
    await api('/calendar', {
      method: 'POST',
      body: {
        event_date: date,
        start_time: r.departure_time || null,
        title: `🚄 ${r.mode === 'THSR' ? '高鐵' : '台鐵'} ${r.train_no} ${r.from_station}${r.to_station ? '→' + r.to_station : ''}`,
        category: 'travel',
      },
    });
    showToast('已加入行事曆');
  } catch (e) { showToast('加入失敗: ' + e.message); }
}

async function searchFlightProviders() {
  const from = $('#flyFrom').value.trim(), to = $('#flyTo').value.trim(), date = $('#flyDate').value;
  const box = $('#flightResult');
  if (!from || !to) return;
  box.innerHTML = '載入中...';
  try {
    const data = await api(`/travel/flights/providers?from=${encodeURIComponent(from)}&to=${encodeURIComponent(to)}&date=${date || ''}`);
    box.innerHTML = '';
    box.appendChild(providerList(data.providers));
  } catch (e) { box.innerHTML = `載入失敗: ${e.message}`; }
}

async function searchHotelProviders() {
  const city = $('#hotelCity').value.trim();
  const checkin = $('#hotelCheckin').value, checkout = $('#hotelCheckout').value;
  const box = $('#hotelResult');
  if (!city) return;
  box.innerHTML = '載入中...';
  try {
    const data = await api(`/travel/hotels/providers?city=${encodeURIComponent(city)}&checkin=${checkin || ''}&checkout=${checkout || ''}`);
    box.innerHTML = '';
    box.appendChild(providerList(data.providers));
  } catch (e) { box.innerHTML = `載入失敗: ${e.message}`; }
}

async function generateItinerary() {
  const from = $('#tripFrom').value.trim(), to = $('#tripTo').value.trim(), days = $('#tripDays').value;
  const box = $('#itineraryResult');
  if (!from || !to) return;
  box.innerHTML = '規劃中...';
  try {
    const data = await api('/travel/itinerary', { method: 'POST', body: { from, to, days } });
    box.innerHTML = '';
    box.appendChild(el('p', { class: 'hint' }, data.disclaimer));
    data.plan.forEach((d) => {
      box.appendChild(el('div', { style: 'margin-bottom:10px' }, [el('b', {}, d.title), el('div', { style: 'font-size:13px;color:var(--text-secondary)' }, d.suggestion)]));
    });
    if (data.curated) {
      box.appendChild(el('div', { style: 'margin-top:14px;padding-top:14px;border-top:1px solid var(--grid-line)' }, [
        el('div', { style: 'font-weight:700;margin-bottom:4px' }, `📍 ${data.curated.city} 精選推薦`),
        el('p', { class: 'hint' }, data.curated.sourceNote),
      ]));
      Object.entries(data.curated.categories).forEach(([cat, items]) => {
        const wrap = el('div', { style: 'margin-bottom:10px' }, [el('div', { style: 'font-size:13px;font-weight:600;margin-bottom:4px' }, cat)]);
        items.forEach((it) => {
          wrap.appendChild(el('div', { style: 'font-size:13px;margin-bottom:4px' }, [
            el('b', {}, it.name), el('span', { style: 'color:var(--text-muted)' }, ` — ${it.note}`),
          ]));
        });
        box.appendChild(wrap);
      });
    }
  } catch (e) { box.innerHTML = `規劃失敗: ${e.message}`; }
}

// ===================== 日期/月曆共用工具 =====================
// 用本地時區組字串，不要用 toISOString()（那是 UTC，半夜時段會跟「今天」差一天）
function fmtYMD(date) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}
function todayStr() { return fmtYMD(new Date()); }
// 產生月曆格子 (含前後補空白，湊滿整週)，month 是 0-11
function monthGridDates(year, month) {
  const first = new Date(year, month, 1);
  const startWeekday = first.getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const cells = [];
  for (let i = 0; i < startWeekday; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(new Date(year, month, d));
  while (cells.length % 7 !== 0) cells.push(null);
  return cells;
}

// ===================== 日記 =====================
let diaryCalCursor = null;

function renderDiary() {
  const c = $('#tab-diary');
  c.innerHTML = '';
  const now = new Date();
  if (!diaryCalCursor) diaryCalCursor = { year: now.getFullYear(), month: now.getMonth() };

  c.appendChild(el('div', { class: 'grid-2' }, [
    el('div', { class: 'card', style: 'margin-bottom:0' }, [
      el('h3', {}, '寫日記'),
      el('div', { class: 'form-row' }, [
        el('input', { id: 'diaryDate', type: 'date', value: todayStr(), onchange: loadDiaryForDate }),
        el('label', { class: 'btn btn-ghost', style: 'cursor:pointer' }, [
          '📂 匯入文字',
          el('input', { type: 'file', accept: '.txt,.md', style: 'display:none', onchange: importDiaryFile }),
        ]),
      ]),
      el('textarea', { id: 'diaryContent', rows: 10, placeholder: '今天發生了什麼事...' }),
      el('div', { style: 'margin-top:10px' }, el('button', { class: 'btn btn-primary', onclick: saveDiary }, '儲存')),
    ]),
    el('div', { class: 'card', style: 'margin-bottom:0' }, [
      el('h3', {}, '月曆瀏覽'),
      el('p', { class: 'hint' }, '藍色圓點代表當天有寫日記，點日期直接跳過去看/編輯。'),
      el('div', { id: 'diaryCalendar' }),
    ]),
  ]));

  c.appendChild(el('div', { class: 'card' }, [
    el('h3', {}, '搜尋日記'),
    el('div', { class: 'form-row' }, [
      el('input', { id: 'diarySearchInput', placeholder: '輸入關鍵字搜尋內容...', onkeydown: (ev) => { if (ev.key === 'Enter') searchDiary(); } }),
      el('button', { class: 'btn btn-primary', onclick: searchDiary }, '搜尋'),
      el('button', { class: 'btn btn-ghost', onclick: clearDiarySearch }, '清除'),
    ]),
  ]));

  c.appendChild(el('div', { class: 'card' }, [el('h3', {}, '日記列表'), el('div', { id: 'diaryList' })]));

  loadDiaryForDate();
  loadDiaryList();
  renderDiaryCalendar();
}

async function renderDiaryCalendar() {
  const box = $('#diaryCalendar');
  if (!box) return;
  const { year, month } = diaryCalCursor;
  const from = fmtYMD(new Date(year, month, 1));
  const to = fmtYMD(new Date(year, month + 1, 0));
  let marked = new Set();
  try {
    const rows = await api(`/diary?from=${from}&to=${to}`);
    marked = new Set(rows.map((r) => r.entry_date));
  } catch (e) { /* 忽略，當作沒有標記 */ }

  const cells = monthGridDates(year, month);
  const weekdayLabels = ['日', '一', '二', '三', '四', '五', '六'];
  box.innerHTML = '';
  box.appendChild(el('div', { style: 'display:flex;justify-content:space-between;align-items:center;margin-bottom:8px' }, [
    el('button', { class: 'btn btn-ghost', style: 'padding:4px 10px', onclick: () => shiftDiaryMonth(-1) }, '‹'),
    el('div', { style: 'font-weight:700;font-size:13.5px' }, `${year} 年 ${month + 1} 月`),
    el('button', { class: 'btn btn-ghost', style: 'padding:4px 10px', onclick: () => shiftDiaryMonth(1) }, '›'),
  ]));
  const grid = el('div', { class: 'mini-cal-grid' });
  weekdayLabels.forEach((w) => grid.appendChild(el('div', { class: 'mini-cal-weekday' }, w)));
  cells.forEach((d) => {
    if (!d) { grid.appendChild(el('div', { class: 'mini-cal-cell empty' })); return; }
    const dateStr = fmtYMD(d);
    const isToday = dateStr === todayStr();
    const hasEntry = marked.has(dateStr);
    grid.appendChild(el('div', {
      class: `mini-cal-cell${isToday ? ' today' : ''}${hasEntry ? ' has-mark' : ''}`,
      onclick: () => { $('#diaryDate').value = dateStr; loadDiaryForDate(); },
    }, [String(d.getDate()), hasEntry ? el('span', { class: 'mini-cal-dot' }) : null]));
  });
  box.appendChild(grid);
}
function shiftDiaryMonth(delta) {
  let { year, month } = diaryCalCursor;
  month += delta;
  if (month < 0) { month = 11; year -= 1; }
  if (month > 11) { month = 0; year += 1; }
  diaryCalCursor = { year, month };
  renderDiaryCalendar();
}

async function loadDiaryForDate() {
  const date = $('#diaryDate').value;
  try {
    const row = await api(`/diary/${date}`);
    $('#diaryContent').value = row ? row.content : '';
  } catch (e) { $('#diaryContent').value = ''; }
}
async function saveDiary() {
  const date = $('#diaryDate').value;
  const content = $('#diaryContent').value;
  try {
    await api(`/diary/${date}`, { method: 'PUT', body: { content } });
    showToast('已儲存');
    loadDiaryList();
    renderDiaryCalendar();
  } catch (e) { showToast('儲存失敗: ' + e.message); }
}
function importDiaryFile(ev) {
  const file = ev.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => { $('#diaryContent').value = reader.result; };
  reader.readAsText(file, 'utf-8');
}
function searchDiary() {
  loadDiaryList($('#diarySearchInput').value.trim());
}
function clearDiarySearch() {
  $('#diarySearchInput').value = '';
  loadDiaryList();
}
async function loadDiaryList(q) {
  const list = $('#diaryList');
  list.innerHTML = '載入中...';
  try {
    const rows = await api(q ? `/diary?q=${encodeURIComponent(q)}` : '/diary');
    list.innerHTML = '';
    if (!rows.length) { list.appendChild(el('div', { class: 'empty-state' }, q ? '沒有符合的日記' : '還沒有日記')); return; }
    rows.slice(0, 30).forEach((r) => {
      list.appendChild(el('div', {
        style: 'padding:8px 0;border-bottom:1px solid var(--grid-line);cursor:pointer',
        onclick: () => { $('#diaryDate').value = r.entry_date; loadDiaryForDate(); },
      }, [
        el('b', {}, r.entry_date), el('div', { style: 'font-size:13px;color:var(--text-secondary)' }, (r.content || '').slice(0, 80)),
      ]));
    });
  } catch (e) { list.innerHTML = '載入失敗'; }
}

// ===================== 記帳 =====================
const FINANCE_CATEGORIES = ['餐飲', '交通', '娛樂', '購物', '居家', '醫療', '教育', '其他'];
let financeBudgets = [];
let financeSummaryCache = null;

function renderFinance() {
  const c = $('#tab-finance');
  c.innerHTML = '';
  c.appendChild(el('div', { class: 'card' }, [
    el('h3', {}, '新增一筆記帳'),
    el('p', { class: 'hint' }, '目前為手動輸入金額；即時銀行帳戶餘額串接屬於台灣「Open Banking」範疇，需金融機構/金管會核准的第三方資格，暫未開放，詳見規劃書說明。'),
    el('div', { class: 'form-row' }, [
      el('input', { id: 'txDate', type: 'date', value: todayStr() }),
      el('select', { id: 'txType' }, [el('option', { value: 'expense' }, '支出'), el('option', { value: 'income' }, '收入')]),
      el('select', { id: 'txCategory', onchange: onTxCategoryChange }, [
        ...FINANCE_CATEGORIES.map((cat) => el('option', { value: cat }, cat)),
        el('option', { value: '__custom__' }, '✏️ 自訂分類...'),
      ]),
      el('input', { id: 'txAmount', type: 'number', placeholder: '金額' }),
    ]),
    el('div', { class: 'form-row' }, [
      el('input', { id: 'txCategoryCustom', placeholder: '輸入自訂分類名稱', style: 'display:none' }),
    ]),
    el('label', { style: 'display:block;font-size:13px;color:var(--text-secondary,#666);margin:10px 0 4px' }, '📝 這筆消費原因/備註 (選填，自己打字寫也可以)'),
    el('input', { id: 'txNote', placeholder: '例如：跟朋友聚餐、幫家人買日用品、加油...', style: 'width:100%' }),
    el('button', { class: 'btn btn-primary', onclick: addTransaction, style: 'margin-top:10px' }, '新增'),
  ]));

  c.appendChild(el('div', { class: 'grid-2' }, [
    el('div', { class: 'card' }, [el('h3', {}, '本月支出分類'), el('div', { id: 'financeBarChart' })]),
    el('div', { class: 'card' }, [el('h3', {}, '近12個月收支趨勢'), el('div', { id: 'financeLineChart' })]),
  ]));

  c.appendChild(el('div', { class: 'card' }, [
    el('h3', {}, '📊 預算設定'),
    el('p', { class: 'hint' }, '設定每個分類的每月預算上限，超支會用顏色提醒 (不會擋你記帳，只是提醒)。'),
    el('div', { id: 'budgetArea' }),
  ]));

  c.appendChild(el('div', { class: 'card' }, [el('h3', {}, '本月明細'), el('div', { id: 'txTable' })]));

  loadFinance();
  loadBudgets();
}

function onTxCategoryChange() {
  $('#txCategoryCustom').style.display = $('#txCategory').value === '__custom__' ? 'block' : 'none';
}

async function addTransaction() {
  const sel = $('#txCategory').value;
  const category = sel === '__custom__' ? ($('#txCategoryCustom').value.trim() || '未分類') : sel;
  const body = {
    tx_date: $('#txDate').value,
    type: $('#txType').value,
    category,
    amount: Number($('#txAmount').value),
    note: $('#txNote').value.trim(),
  };
  if (!body.amount) { showToast('請輸入金額'); return; }
  try {
    await api('/finance/transactions', { method: 'POST', body });
    $('#txCategoryCustom').value = ''; $('#txAmount').value = ''; $('#txNote').value = '';
    showToast('已新增');
    loadFinance();
  } catch (e) { showToast('新增失敗: ' + e.message); }
}
async function deleteTransaction(id) {
  await api(`/finance/transactions/${id}`, { method: 'DELETE' });
  loadFinance();
}

async function loadFinance() {
  try {
    const summary = await api('/finance/summary');
    financeSummaryCache = summary;
    const expenseByCat = summary.byCategory.filter((r) => r.type === 'expense').map((r) => ({ label: r.category, value: r.total }));
    renderBarChart($('#financeBarChart'), expenseByCat, { money: true, emptyText: '本月尚無支出紀錄' });

    const months = [...new Set(summary.monthlyTrend.map((r) => r.ym))];
    const income = months.map((m) => ({ x: m, y: (summary.monthlyTrend.find((r) => r.ym === m && r.type === 'income') || {}).total || 0 }));
    const expense = months.map((m) => ({ x: m, y: (summary.monthlyTrend.find((r) => r.ym === m && r.type === 'expense') || {}).total || 0 }));
    renderLineChart($('#financeLineChart'), [
      { name: '收入', color: cssVar('--series-blue'), points: income },
      { name: '支出', color: cssVar('--series-red'), points: expense },
    ]);

    const rows = await api('/finance/transactions?month=' + todayStr().slice(0, 7));
    const table = $('#txTable');
    table.innerHTML = '';
    renderBudgetArea();
    if (!rows.length) { table.appendChild(el('div', { class: 'empty-state' }, '本月尚無紀錄')); return; }
    const trs = rows.map((r) => el('tr', {}, [
      el('td', {}, r.tx_date), el('td', {}, r.type === 'income' ? '收入' : '支出'), el('td', {}, r.category),
      el('td', { style: r.type === 'income' ? 'color:var(--good)' : 'color:var(--critical)' }, fmtMoney(r.amount)),
      el('td', {}, r.note || ''),
      el('td', {}, el('button', { class: 'btn btn-ghost', onclick: () => deleteTransaction(r.id) }, '刪除')),
    ]));
    table.appendChild(el('table', {}, [
      el('thead', {}, el('tr', {}, [el('th', {}, '日期'), el('th', {}, '類型'), el('th', {}, '分類'), el('th', {}, '金額'), el('th', {}, '備註'), el('th', {}, '')])),
      el('tbody', {}, trs),
    ]));
  } catch (e) { showToast('載入記帳資料失敗: ' + e.message); }
}

async function loadBudgets() {
  try { financeBudgets = await api('/finance/budgets'); } catch (e) { financeBudgets = []; }
  renderBudgetArea();
}

function renderBudgetArea() {
  const area = $('#budgetArea');
  if (!area) return;
  area.innerHTML = '';

  const spentByCategory = {};
  if (financeSummaryCache) {
    financeSummaryCache.byCategory.filter((r) => r.type === 'expense').forEach((r) => { spentByCategory[r.category] = r.total; });
  }
  const allCats = new Set(FINANCE_CATEGORIES);
  financeBudgets.forEach((b) => allCats.add(b.category));
  Object.keys(spentByCategory).forEach((cat) => allCats.add(cat));

  [...allCats].forEach((cat) => {
    const budget = financeBudgets.find((b) => b.category === cat);
    const limit = budget ? budget.monthly_limit : null;
    const spent = spentByCategory[cat] || 0;
    const pct = limit ? Math.round((spent / limit) * 100) : null;
    const barColor = pct == null ? 'var(--series-blue)' : pct >= 100 ? 'var(--critical)' : pct >= 70 ? 'var(--warning)' : 'var(--good)';
    const inputId = `budgetInput-${cat}`;

    area.appendChild(el('div', { style: 'padding:10px 0;border-bottom:1px solid var(--grid-line)' }, [
      el('div', { style: 'display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;margin-bottom:6px' }, [
        el('div', { style: 'font-weight:600;font-size:13.5px' }, cat),
        el('div', { style: 'display:flex;gap:8px;align-items:center' }, [
          el('span', { style: 'font-size:12px;color:var(--text-muted)' }, limit != null ? `${fmtMoney(spent)} / ${fmtMoney(limit)}` : `已花 ${fmtMoney(spent)}`),
          el('input', { id: inputId, type: 'number', placeholder: '預算上限', value: limit != null ? limit : '', style: 'width:100px;padding:5px 8px;font-size:12px' }),
          el('button', { class: 'btn btn-ghost', style: 'padding:5px 10px;font-size:12px', onclick: () => saveBudget(cat, inputId) }, '儲存'),
        ]),
      ]),
      limit != null ? el('div', { style: 'height:6px;background:var(--gray-mid);border-radius:999px;overflow:hidden' }, [
        el('div', { style: `height:100%;width:${Math.min(100, pct)}%;background:${barColor}` }),
      ]) : null,
    ]));
  });
}

async function saveBudget(cat, inputId) {
  const val = Number($(`#${inputId}`).value);
  if (!val || val <= 0) { showToast('請輸入有效的預算金額'); return; }
  try {
    await api(`/finance/budgets/${encodeURIComponent(cat)}`, { method: 'PUT', body: { monthly_limit: val } });
    showToast('已儲存預算');
    loadBudgets();
  } catch (e) { showToast('儲存失敗: ' + e.message); }
}

// ===================== 行事曆 =====================
const CALENDAR_CATEGORIES = [
  { key: 'meal', label: '🍜 飲食', colorVar: '--series-orange' },
  { key: 'movie', label: '🎬 電影', colorVar: '--series-violet' },
  { key: 'sport', label: '🏃 運動', colorVar: '--series-aqua' },
  { key: 'work', label: '💼 工作', colorVar: '--series-blue' },
  { key: 'date', label: '💗 約會', colorVar: '--series-magenta' },
  { key: 'travel', label: '🚄 交通旅遊', colorVar: '--series-green' },
  { key: 'other', label: '📌 其他', colorVar: '--series-yellow' },
];
function calCategoryInfo(key) {
  return CALENDAR_CATEGORIES.find((c) => c.key === key) || CALENDAR_CATEGORIES[CALENDAR_CATEGORIES.length - 1];
}

let calCursor = null;
let calEventsCache = [];
let selectedCalDate = null;

function renderCalendar() {
  const c = $('#tab-calendar');
  c.innerHTML = '';
  const now = new Date();
  if (!calCursor) calCursor = { year: now.getFullYear(), month: now.getMonth() };
  if (!selectedCalDate) selectedCalDate = todayStr();

  // 月曆放左邊 (畫面主體)，新增行程表單 + 選定日期行程放右邊直向排一起，
  // 桌面/大螢幕上這樣一畫面就能看到全部功能，不用再往下滑；手機螢幕窄的話會自動改成上下排列。
  c.appendChild(el('div', { class: 'grid-cal' }, [
    el('div', { class: 'card' }, [
      el('div', { id: 'calMonthNav' }),
      el('div', { id: 'calMonthGrid' }),
      el('div', { class: 'legend', style: 'margin-top:12px' }, CALENDAR_CATEGORIES.map((cat) => el('div', { class: 'legend-item' }, [
        el('span', { class: 'legend-dot', style: `background:${cssVar(cat.colorVar)}` }), cat.label,
      ]))),
    ]),
    el('div', { class: 'cal-side' }, [
      el('div', { class: 'card' }, [
        el('h3', {}, '新增行程'),
        el('div', { class: 'form-row' }, [
          el('input', { id: 'calDate', type: 'date', value: todayStr() }),
          el('input', { id: 'calTime', type: 'time' }),
        ]),
        el('input', { id: 'calTitle', placeholder: '要做什麼事？', style: 'width:100%;margin-top:8px' }),
        el('div', { class: 'form-row', style: 'margin-top:8px' }, [
          el('select', { id: 'calCategory' }, CALENDAR_CATEGORIES.map((cat) => el('option', { value: cat.key }, cat.label))),
        ]),
        el('input', { id: 'calNote', placeholder: '備註 (選填)', style: 'width:100%;margin-top:8px' }),
        el('button', { class: 'btn btn-primary', onclick: addCalendarEvent, style: 'margin-top:10px' }, '新增'),
      ]),
      el('div', { class: 'card' }, [el('h3', { id: 'calDayTitle' }, '選定日期的行程'), el('div', { id: 'calDayDetail' })]),
    ]),
  ]));

  loadCalendarMonth();
}

async function loadCalendarMonth() {
  const { year, month } = calCursor;
  const from = fmtYMD(new Date(year, month, 1));
  const to = fmtYMD(new Date(year, month + 1, 0));
  try {
    calEventsCache = await api(`/calendar?from=${from}&to=${to}`);
  } catch (e) { calEventsCache = []; }
  renderCalMonthNav();
  renderCalMonthGrid();
  renderCalDayDetail(selectedCalDate);
}

function renderCalMonthNav() {
  const nav = $('#calMonthNav');
  if (!nav) return;
  const { year, month } = calCursor;
  nav.innerHTML = '';
  nav.appendChild(el('div', { style: 'display:flex;justify-content:space-between;align-items:center;margin-bottom:12px' }, [
    el('button', { class: 'btn btn-ghost', onclick: () => shiftCalMonth(-1) }, '‹ 上個月'),
    el('div', { style: 'font-weight:800;font-size:16px' }, `${year} 年 ${month + 1} 月`),
    el('button', { class: 'btn btn-ghost', onclick: () => shiftCalMonth(1) }, '下個月 ›'),
  ]));
}
function shiftCalMonth(delta) {
  let { year, month } = calCursor;
  month += delta;
  if (month < 0) { month = 11; year -= 1; }
  if (month > 11) { month = 0; year += 1; }
  calCursor = { year, month };
  loadCalendarMonth();
}

function renderCalMonthGrid() {
  const grid = $('#calMonthGrid');
  if (!grid) return;
  grid.innerHTML = '';
  const { year, month } = calCursor;
  const cells = monthGridDates(year, month);
  const weekdayLabels = ['日', '一', '二', '三', '四', '五', '六'];
  const wrap = el('div', { class: 'cal-grid' });
  weekdayLabels.forEach((w) => wrap.appendChild(el('div', { class: 'cal-weekday' }, w)));

  const byDate = {};
  calEventsCache.forEach((ev) => { (byDate[ev.event_date] = byDate[ev.event_date] || []).push(ev); });

  cells.forEach((d) => {
    if (!d) { wrap.appendChild(el('div', { class: 'cal-cell empty' })); return; }
    const dateStr = fmtYMD(d);
    const isToday = dateStr === todayStr();
    const isSelected = dateStr === selectedCalDate;
    const dayEvents = byDate[dateStr] || [];
    // 桌面版：完整文字小方塊。手機螢幕較窄，改用色點表示「這天有幾件事」，
    // 點下去照樣會在下方「選定日期的行程」卡片看到完整內容，畫面不用一直橫向擠字。
    const chips = dayEvents.slice(0, 3).map((ev) => {
      const info = calCategoryInfo(ev.category);
      return el('div', { class: 'cal-chip', style: `background:color-mix(in srgb, ${cssVar(info.colorVar)} 18%, transparent);color:${cssVar(info.colorVar)}` }, ev.title.slice(0, 8));
    });
    const dots = dayEvents.slice(0, 4).map((ev) => {
      const info = calCategoryInfo(ev.category);
      return el('div', { class: 'cal-dot', style: `background:${cssVar(info.colorVar)}` });
    });
    wrap.appendChild(el('div', {
      class: `cal-cell${isToday ? ' today' : ''}${isSelected ? ' selected' : ''}`,
      onclick: () => { selectedCalDate = dateStr; renderCalMonthGrid(); renderCalDayDetail(dateStr); },
    }, [
      el('div', { class: 'cal-daynum' }, String(d.getDate())),
      el('div', { class: 'cal-chips-desktop' }, [
        ...chips,
        dayEvents.length > 3 ? el('div', { class: 'cal-more' }, `+${dayEvents.length - 3}`) : null,
      ]),
      dots.length ? el('div', { class: 'cal-dots-mobile' }, dots) : null,
    ]));
  });
  grid.appendChild(wrap);
}

function renderCalDayDetail(dateStr) {
  selectedCalDate = dateStr;
  const title = $('#calDayTitle');
  if (title) title.textContent = `${dateStr} 的行程`;
  const box = $('#calDayDetail');
  if (!box) return;
  box.innerHTML = '';
  const events = calEventsCache
    .filter((ev) => ev.event_date === dateStr)
    .sort((a, b) => (a.start_time || '').localeCompare(b.start_time || ''));
  if (!events.length) { box.appendChild(el('div', { class: 'empty-state' }, '這天還沒有安排行程')); return; }
  events.forEach((r) => {
    const info = calCategoryInfo(r.category);
    box.appendChild(el('div', { style: 'display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid var(--grid-line)' }, [
      el('div', {}, [
        el('span', { class: 'badge', style: `background:color-mix(in srgb, ${cssVar(info.colorVar)} 16%, transparent);color:${cssVar(info.colorVar)};margin-right:8px` }, info.label),
        el('span', { style: 'color:var(--series-blue);font-weight:600;margin-right:8px' }, r.start_time || '全天'),
        el('span', {}, r.title),
        r.note ? el('div', { style: 'font-size:12px;color:var(--text-muted);margin-top:2px' }, r.note) : null,
      ]),
      el('button', { class: 'btn btn-ghost', onclick: () => deleteCalendarEvent(r.id) }, '刪除'),
    ]));
  });
}

async function addCalendarEvent() {
  const body = {
    event_date: $('#calDate').value,
    start_time: $('#calTime').value,
    title: $('#calTitle').value.trim(),
    note: $('#calNote').value.trim(),
    category: $('#calCategory').value,
  };
  if (!body.event_date || !body.title) { showToast('請至少填日期與事項'); return; }
  try {
    await api('/calendar', { method: 'POST', body });
    $('#calTitle').value = ''; $('#calNote').value = ''; $('#calTime').value = '';
    showToast('已新增行程');
    if (body.event_date.slice(0, 7) === fmtYMD(new Date(calCursor.year, calCursor.month, 1)).slice(0, 7)) {
      selectedCalDate = body.event_date;
    }
    loadCalendarMonth();
  } catch (e) { showToast('新增失敗: ' + e.message); }
}
async function deleteCalendarEvent(id) {
  await api(`/calendar/${id}`, { method: 'DELETE' });
  loadCalendarMonth();
}

// ===================== AI 助理 =====================
// 對話記錄改存資料庫 (見 /api/assistant/history)，重新整理頁面或換裝置登入都還在，
// 不再只是瀏覽器記憶體裡的暫時變數。
if (!state.assistantHistory) state.assistantHistory = [];
function renderAssistant() {
  const c = $('#tab-assistant');
  c.innerHTML = '';
  c.appendChild(el('div', { class: 'card' }, [
    el('div', { style: 'display:flex;justify-content:space-between;align-items:center' }, [
      el('h3', { style: 'margin-bottom:0' }, '💬 AI 助理'),
      el('button', { class: 'btn btn-ghost', style: 'font-size:12px', onclick: clearAssistantHistory }, '🗑️ 清除對話'),
    ]),
    el('p', { class: 'hint', style: 'margin-top:6px' }, '可以問生活規劃、旅遊行程、記帳建議、股票資訊解讀、翻譯、食譜、單位換算等任何問題。對話記錄會保存在你的帳號裡，換裝置登入也看得到。'),
    el('div', { id: 'assistantMessages', class: 'chat-box' }, el('div', { class: 'empty-state' }, '載入中...')),
    el('div', { class: 'form-row' }, [
      el('input', { id: 'assistantInput', placeholder: '輸入訊息，按 Enter 送出', onkeydown: (ev) => { if (ev.key === 'Enter') sendAssistantMessage(); } }),
      el('button', { class: 'btn btn-primary', onclick: sendAssistantMessage }, '送出'),
    ]),
  ]));
  loadAssistantHistory();
}
async function loadAssistantHistory() {
  try {
    state.assistantHistory = await api('/assistant/history');
  } catch (e) {
    state.assistantHistory = [];
  }
  renderAssistantMessages();
}
async function clearAssistantHistory() {
  try {
    await api('/assistant/history', { method: 'DELETE' });
    state.assistantHistory = [];
    renderAssistantMessages();
    showToast('已清除對話記錄');
  } catch (e) { showToast('清除失敗: ' + e.message); }
}
function renderAssistantMessages() {
  const box = $('#assistantMessages');
  if (!box) return;
  box.innerHTML = '';
  if (!state.assistantHistory.length) {
    box.appendChild(el('div', { class: 'empty-state' }, '還沒有對話，輸入訊息開始聊天吧'));
    return;
  }
  state.assistantHistory.forEach((m) => {
    box.appendChild(el('div', { class: 'chat-msg ' + (m.role === 'user' ? 'chat-user' : 'chat-ai') }, m.content));
  });
  box.scrollTop = box.scrollHeight;
}
async function sendAssistantMessage() {
  const input = $('#assistantInput');
  const text = input.value.trim();
  if (!text) return;
  state.assistantHistory.push({ role: 'user', content: text });
  input.value = '';
  renderAssistantMessages();
  try {
    const res = await api('/assistant/chat', { method: 'POST', body: { message: text } });
    state.assistantHistory.push({ role: 'assistant', content: res.reply });
    renderAssistantMessages();
  } catch (e) {
    state.assistantHistory.push({ role: 'assistant', content: '發生錯誤: ' + e.message });
    renderAssistantMessages();
  }
}

// ===================== 心情陪伴 =====================
const MOOD_TAGS = ['焦慮', '疲憊', '開心', '平靜', '煩躁', '難過', '有動力', '孤單'];
const moodState = { selectedScore: null, selectedTags: new Set(), chatHistory: null };

function todayStr() { return new Date().toISOString().slice(0, 10); }

function renderMood() {
  const c = $('#tab-mood');
  c.innerHTML = '';
  moodState.selectedScore = moodState.selectedScore || 5;
  moodState.selectedTags = new Set();

  const checkinCard = el('div', { class: 'card' }, [
    el('h3', {}, [el('div', { class: 'hex-badge' }, '💗'), '今天的你感覺怎麼樣？']),
    el('p', { class: 'hint' }, '拖曳滑桿選一個最貼近現在的分數，標籤跟備註都是選填。'),
    el('div', { class: 'mood-score-slider-wrap' }, [
      el('input', { id: 'moodScoreSlider', type: 'range', min: '1', max: '10', step: '1', value: String(moodState.selectedScore), oninput: (ev) => selectMoodScore(Number(ev.target.value)) }),
      el('div', { id: 'moodScoreDisplay', class: 'mood-score-display' }, String(moodState.selectedScore)),
    ]),
    el('div', { class: 'mood-tag-row', id: 'moodTagRow' }),
    el('input', { id: 'moodNote', placeholder: '想多寫一點也可以，這裡沒有人會評論你 (選填)' }),
    el('div', { style: 'margin-top:12px' }, [
      el('button', { class: 'btn btn-primary', onclick: saveMoodEntry }, '儲存今天的紀錄'),
    ]),
  ]);

  const trendCard = el('div', { class: 'card', style: 'margin-bottom:0' }, [
    el('h3', {}, '📈 心情趨勢 (近 30 天)'),
    el('div', { id: 'moodTrendChart' }, el('div', { class: 'empty-state' }, '載入中...')),
  ]);

  const chatCard = el('div', { class: 'card mood-chat-card mood-chat-companion' }, [
    el('div', { class: 'mood-chat-avatar' }, '🌱'),
    el('div', { style: 'text-align:center;margin-bottom:4px' }, [
      el('h3', { style: 'justify-content:center;margin-bottom:2px' }, 'AI 心靈對話室'),
      el('p', { class: 'hint', style: 'margin-bottom:0' }, '隨時可以聊聊，這裡是陪伴傾聽，不是正式的心理治療'),
    ]),
    el('div', { id: 'moodChatMessages', class: 'chat-box', style: 'margin-top:10px' }, el('div', { class: 'empty-state' }, '載入中...')),
    el('div', { class: 'form-row' }, [
      el('input', { id: 'moodChatInput', placeholder: '想說什麼都可以，按 Enter 送出', onkeydown: (ev) => { if (ev.key === 'Enter') sendMoodChatMessage(); } }),
      el('button', { class: 'btn btn-primary', onclick: sendMoodChatMessage }, '送出'),
    ]),
    el('div', { style: 'text-align:center;margin-top:8px' }, [
      el('button', { class: 'btn btn-ghost', style: 'font-size:12px', onclick: clearMoodChatHistory }, '🗑️ 清除對話'),
    ]),
  ]);

  const statsCard = el('div', { class: 'card', style: 'margin-bottom:0' }, [
    el('h3', {}, '📊 情緒健康報告'),
    el('div', { id: 'moodStatsGrid', class: 'mood-stat-grid' }, el('div', { class: 'empty-state' }, '載入中...')),
  ]);
  const diaryCard = el('div', { class: 'card', style: 'margin-bottom:0' }, [
    el('h3', {}, '📔 今天的日記'),
    el('div', { id: 'moodDiaryLink' }, el('div', { class: 'empty-state' }, '載入中...')),
  ]);

  c.appendChild(el('div', { class: 'mood-grid' }, [
    el('div', { class: 'dash-col' }, [checkinCard, trendCard]),
    chatCard,
    el('div', { class: 'dash-col' }, [statsCard, diaryCard]),
  ]));

  c.appendChild(el('div', { class: 'card mood-resource-card', style: 'margin-top:16px' }, [
    el('h3', {}, '🌿 需要立即協助？'),
    el('p', { class: 'hint', style: 'margin-bottom:0' }, '不管幾點、不管是什麼原因，這幾個台灣的免費專線隨時都可以打，會有人願意聽你說：'),
    el('div', { class: 'mood-hotline-row' }, [
      el('div', { class: 'mood-hotline' }, '安心專線 1925 (24小時)'),
      el('div', { class: 'mood-hotline' }, '生命線 1995 (24小時)'),
      el('div', { class: 'mood-hotline' }, '張老師專線 1980 (日間)'),
    ]),
  ]));

  const tagRow = $('#moodTagRow');
  MOOD_TAGS.forEach((tag) => {
    tagRow.appendChild(el('button', { class: 'mood-tag-chip', 'data-tag': tag, onclick: () => toggleMoodTag(tag) }, tag));
  });

  loadMoodToday();
  loadMoodTrend();
  loadMoodDiaryLink();
  loadMoodChatHistory();
}

function selectMoodScore(score) {
  moodState.selectedScore = score;
  const slider = $('#moodScoreSlider');
  if (slider) slider.value = String(score);
  const display = $('#moodScoreDisplay');
  if (display) display.textContent = String(score);
}
function toggleMoodTag(tag) {
  if (moodState.selectedTags.has(tag)) moodState.selectedTags.delete(tag);
  else moodState.selectedTags.add(tag);
  document.querySelectorAll('.mood-tag-chip').forEach((b) => b.classList.toggle('selected', moodState.selectedTags.has(b.dataset.tag)));
}

async function loadMoodToday() {
  try {
    const today = todayStr();
    const rows = await api(`/mood/entries?from=${today}&to=${today}`);
    if (rows.length) {
      const entry = rows[0];
      selectMoodScore(entry.score);
      (entry.tags || '').split(',').filter(Boolean).forEach((t) => { moodState.selectedTags.add(t); });
      document.querySelectorAll('.mood-tag-chip').forEach((b) => b.classList.toggle('selected', moodState.selectedTags.has(b.dataset.tag)));
      if (entry.note) $('#moodNote').value = entry.note;
    }
  } catch (e) { /* 忽略，當作今天還沒記錄 */ }
}

async function saveMoodEntry() {
  if (!moodState.selectedScore) { showToast('先選一個 1-10 的分數'); return; }
  try {
    await api(`/mood/entries/${todayStr()}`, {
      method: 'PUT',
      body: { score: moodState.selectedScore, tags: [...moodState.selectedTags], note: $('#moodNote').value.trim() },
    });
    showToast('已記錄今天的心情 💗');
    loadMoodTrend();
  } catch (e) { showToast('儲存失敗：' + e.message); }
}

async function loadMoodTrend() {
  const chartArea = $('#moodTrendChart');
  const statsGrid = $('#moodStatsGrid');
  if (!chartArea) return;
  try {
    const summary = await api('/mood/summary?days=30');
    if (!summary.series.length) {
      chartArea.innerHTML = '';
      chartArea.appendChild(el('div', { class: 'empty-state' }, '還沒有心情紀錄，記錄第一筆之後這裡就會出現趨勢圖'));
    } else {
      renderMoodChart(chartArea, summary.series);
    }
    if (statsGrid) renderMoodStats(statsGrid, summary);
  } catch (e) {
    chartArea.innerHTML = '';
    chartArea.appendChild(el('div', { class: 'empty-state' }, '心情資料暫時無法取得'));
    if (statsGrid) { statsGrid.innerHTML = ''; statsGrid.appendChild(el('div', { class: 'empty-state' }, '心情資料暫時無法取得')); }
  }
}

function moodStatTile(value, label) {
  return el('div', { class: 'mood-stat-tile' }, [
    el('div', { class: 'mood-stat-value' }, value),
    el('div', { class: 'mood-stat-label' }, label),
  ]);
}

function renderMoodStats(container, summary) {
  container.innerHTML = '';
  const series = summary.series || [];
  if (!series.length) {
    container.appendChild(el('div', { class: 'empty-state' }, '還沒有資料'));
    return;
  }
  const thisMonth = todayStr().slice(0, 7);
  const monthCount = series.filter((r) => r.entry_date.startsWith(thisMonth)).length;

  // 連續記錄天數：從今天往回算，只要中間斷一天就停止
  const dateSet = new Set(series.map((r) => r.entry_date));
  let streak = 0;
  let cursor = new Date();
  while (true) {
    const ds = cursor.toISOString().slice(0, 10);
    if (!dateSet.has(ds)) break;
    streak++;
    cursor.setDate(cursor.getDate() - 1);
  }

  // 情緒穩定度：分數波動愈小，數值愈高 (僅供參考，不是精確的醫學指標)
  let stability = null;
  if (series.length >= 2 && summary.average != null) {
    const variance = series.reduce((s, r) => s + Math.pow(r.score - summary.average, 2), 0) / series.length;
    const stdev = Math.sqrt(variance);
    stability = Math.max(0, Math.round(100 - (stdev / 4.5) * 100));
  }

  container.appendChild(moodStatTile(summary.average != null ? `${summary.average} 分` : '--', '近 30 天平均分數'));
  container.appendChild(moodStatTile(String(monthCount), '本月已記錄天數'));
  container.appendChild(moodStatTile(`${streak} 天`, '連續記錄天數'));
  container.appendChild(moodStatTile(stability != null ? `${stability}%` : '--', '情緒穩定度 (僅供參考)'));
  if (summary.topTags && summary.topTags.length) {
    const tagsBox = el('div', { style: 'grid-column:1/-1;margin-top:4px' }, [
      el('div', { class: 'mood-stat-label', style: 'margin-bottom:6px' }, '常見標籤'),
      el('div', { class: 'mood-tag-row', style: 'margin:0' }, summary.topTags.map((t) => el('span', { class: 'mood-tag-chip selected' }, `${t.tag} ×${t.count}`))),
    ]);
    container.appendChild(tagsBox);
  }
}

function renderMoodChart(container, series) {
  container.innerHTML = '';
  const width = container.clientWidth || 460;
  const height = 180;
  const padL = 28, padR = 12, padTop = 14, padBottom = 26;
  const plotW = width - padL - padR;
  const plotH = height - padTop - padBottom;
  const svg = svgEl('svg', { width: '100%', height, viewBox: `0 0 ${width} ${height}` });

  for (const gv of [1, 4, 7, 10]) {
    const y = padTop + plotH - ((gv - 1) / 9) * plotH;
    svg.appendChild(svgEl('line', { x1: padL, x2: width - padR, y1: y, y2: y, stroke: cssVar('--grid-line'), 'stroke-width': 1 }));
    const lbl = svgEl('text', { x: 2, y: y + 4, 'font-size': 10, fill: cssVar('--text-muted') });
    lbl.textContent = String(gv);
    svg.appendChild(lbl);
  }

  const n = series.length;
  const coords = series.map((p, i) => ({
    px: padL + (n > 1 ? (i / (n - 1)) * plotW : plotW / 2),
    py: padTop + plotH - ((p.score - 1) / 9) * plotH,
  }));
  const pathD = coords.map((p, i) => `${i === 0 ? 'M' : 'L'}${p.px},${p.py}`).join(' ');

  const gradId = 'moodAreaGrad';
  const defs = svgEl('defs', {});
  const grad = svgEl('linearGradient', { id: gradId, x1: '0', y1: '0', x2: '0', y2: '1' });
  const stop1 = svgEl('stop', { offset: '0%', 'stop-color': cssVar('--series-magenta'), 'stop-opacity': '0.35' });
  const stop2 = svgEl('stop', { offset: '100%', 'stop-color': cssVar('--series-magenta'), 'stop-opacity': '0' });
  grad.appendChild(stop1); grad.appendChild(stop2); defs.appendChild(grad); svg.appendChild(defs);

  const areaD = `${pathD} L${coords[coords.length - 1].px},${padTop + plotH} L${coords[0].px},${padTop + plotH} Z`;
  svg.appendChild(svgEl('path', { d: areaD, fill: `url(#${gradId})`, stroke: 'none' }));
  svg.appendChild(svgEl('path', { d: pathD, fill: 'none', stroke: cssVar('--series-magenta'), 'stroke-width': 2, 'stroke-linecap': 'round' }));

  series.forEach((p, i) => {
    const px = padL + (n > 1 ? (i / (n - 1)) * plotW : plotW / 2);
    const py = padTop + plotH - ((p.score - 1) / 9) * plotH;
    const dot = svgEl('circle', { cx: px, cy: py, r: 3.5, fill: cssVar('--series-magenta') });
    dot.addEventListener('mousemove', (ev) => showTooltip(ev, `${p.entry_date}：${p.score} 分`));
    dot.addEventListener('mouseleave', hideTooltip);
    svg.appendChild(dot);
    if (n <= 10 || i === 0 || i === n - 1 || i % Math.ceil(n / 6) === 0) {
      const lbl = svgEl('text', { x: px, y: height - 6, 'font-size': 9, 'text-anchor': 'middle', fill: cssVar('--text-muted') });
      lbl.textContent = p.entry_date.slice(5);
      svg.appendChild(lbl);
    }
  });

  container.appendChild(svg);
}

async function loadMoodDiaryLink() {
  const area = $('#moodDiaryLink');
  if (!area) return;
  try {
    const today = todayStr();
    const entries = await api(`/diary?from=${today}&to=${today}`);
    area.innerHTML = '';
    if (!entries.length) {
      area.appendChild(el('div', { class: 'empty-state' }, '今天還沒寫日記'));
      area.appendChild(el('button', { class: 'btn btn-ghost', style: 'margin-top:8px', onclick: () => switchTab('diary') }, '前往寫日記'));
    } else {
      const snippet = (entries[0].content || '').slice(0, 80);
      area.appendChild(el('p', { style: 'font-size:13px;color:var(--text-secondary)' }, snippet + (entries[0].content.length > 80 ? '…' : '')));
      area.appendChild(el('button', { class: 'btn btn-ghost', style: 'margin-top:4px', onclick: () => switchTab('diary') }, '查看完整日記'));
    }
  } catch (e) {
    area.innerHTML = '';
    area.appendChild(el('div', { class: 'empty-state' }, '日記資料暫時無法取得'));
  }
}

async function loadMoodChatHistory() {
  try {
    moodState.chatHistory = await api('/mood/chat/history');
  } catch (e) {
    moodState.chatHistory = [];
  }
  renderMoodChatMessages();
}
async function clearMoodChatHistory() {
  try {
    await api('/mood/chat/history', { method: 'DELETE' });
    moodState.chatHistory = [];
    renderMoodChatMessages();
    showToast('已清除陪伴對話記錄');
  } catch (e) { showToast('清除失敗: ' + e.message); }
}
function renderMoodChatMessages() {
  const box = $('#moodChatMessages');
  if (!box) return;
  box.innerHTML = '';
  if (!moodState.chatHistory || !moodState.chatHistory.length) {
    box.appendChild(el('div', { class: 'empty-state' }, '還沒有對話，想聊聊嗎？隨時都可以開始'));
    return;
  }
  moodState.chatHistory.forEach((m) => {
    box.appendChild(el('div', { class: 'chat-msg ' + (m.role === 'user' ? 'chat-user' : 'chat-ai') }, m.content));
  });
  box.scrollTop = box.scrollHeight;
}
async function sendMoodChatMessage() {
  const input = $('#moodChatInput');
  const text = input.value.trim();
  if (!text) return;
  moodState.chatHistory = moodState.chatHistory || [];
  moodState.chatHistory.push({ role: 'user', content: text });
  input.value = '';
  renderMoodChatMessages();
  try {
    const res = await api('/mood/chat', { method: 'POST', body: { message: text } });
    moodState.chatHistory.push({ role: 'assistant', content: res.reply });
    renderMoodChatMessages();
  } catch (e) {
    moodState.chatHistory.push({ role: 'assistant', content: '發生錯誤: ' + e.message });
    renderMoodChatMessages();
  }
}

// ===================== 個人化設定 =====================
function renderSettings() {
  const c = $('#tab-settings');
  c.innerHTML = '';
  const modules = ['stocks', 'travel', 'diary', 'finance'];
  const labels = { stocks: '股票', travel: '交通與旅遊', diary: '日記', finance: '記帳' };
  const enabled = (state.prefs && state.prefs.enabledModules) || {};

  const rows = modules.map((m) => el('div', { class: 'module-toggle-row' }, [
    el('span', {}, labels[m]),
    el('label', { class: 'switch' }, [
      el('input', { type: 'checkbox', checked: enabled[m] !== false, onchange: (ev) => toggleModule(m, ev.target.checked) }),
      el('span', { class: 'slider' }),
    ]),
  ]));
  c.appendChild(el('div', { class: 'card' }, [el('h3', {}, '首頁模組顯示設定'), el('p', { class: 'hint' }, '關閉的模組仍可從左側選單進入，只是不會出現在首頁摘要。'), ...rows]));
}
async function toggleModule(name, val) {
  state.prefs.enabledModules = { ...(state.prefs.enabledModules || {}), [name]: val };
  await api('/prefs', { method: 'PUT', body: state.prefs });
  showToast('已更新設定');
}

// ===================== Debug 面板 =====================
async function showDebug() {
  const token = prompt('輸入 Debug Token (見伺服器 .env 的 DEBUG_TOKEN)：');
  if (token == null) return;
  try {
    const res = await fetch('/api/debug', { headers: { 'X-Debug-Token': token } });
    const data = await res.json();
    if (!res.ok) { showToast(data.error || '驗證失敗'); return; }
    alert(JSON.stringify(data, null, 2).slice(0, 4000));
  } catch (e) { showToast('取得系統狀態失敗'); }
}

// ===================== 啟動 =====================
(async function boot() {
  try {
    const { user } = await api('/auth/me');
    if (user) onAuthed(user);
    else {
      const health = await api('/health');
      $('#appVersion').textContent = health.version;
    }
  } catch (e) {}
})();
