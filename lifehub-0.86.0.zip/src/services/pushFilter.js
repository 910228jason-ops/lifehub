// v0.84.2：「依提醒類型檢查推播開關」的共用過濾邏輯。
//
// 背景推播排程 (routes/push.js 的 runNotifyCycle) 跟前景瀏覽器通知 (app.js 的
// checkGeneralReminders / checkMoodReminder) 過去各自判斷要不要跳通知，前景那條路完全沒有
// 檢查設定頁的開關——使用者關掉「自我照顧提醒」之類的開關，只要 App 開著，前景通知照樣會跳。
// 現在兩邊都呼叫這裡，同一份規則只維護一次。
//
// 注意：這只決定「要不要主動通知」。首頁/各分頁上看得到的提醒清單不經過這個過濾，一律照常顯示。

// 會在通知內容裡直接提到心情狀態的類型，鎖定畫面上比較敏感，共用 push_mood_social_reminders 開關。
const MOOD_SENSITIVE_TYPES = new Set(['mood-social-checkin', 'mood-trend-mild', 'mood-trend-concern']);

function getPushToggles(db, userId) {
  const toggles = { birthday: false, partnerCycle: false, moodSocial: false, selfCare: false, familyBoard: false };
  try {
    const row = db
      .prepare('SELECT push_birthday_reminders, push_partner_cycle_reminders, push_mood_social_reminders, push_self_care_reminders, push_family_board_reminders FROM user_prefs WHERE user_id = ?')
      .get(userId);
    if (row) {
      toggles.birthday = !!row.push_birthday_reminders;
      toggles.partnerCycle = !!row.push_partner_cycle_reminders;
      toggles.moodSocial = !!row.push_mood_social_reminders;
      toggles.selfCare = !!row.push_self_care_reminders;
      toggles.familyBoard = !!row.push_family_board_reminders;
    }
  } catch (e) { /* 欄位還不存在時當作全部沒開啟 */ }
  return toggles;
}

function isTypeAllowed(type, toggles) {
  if (type === 'birthday') return toggles.birthday;
  if (type === 'partner-cycle') return toggles.partnerCycle;
  if (type === 'self-care') return toggles.selfCare;
  if (type === 'family-board') return toggles.familyBoard;
  if (MOOD_SENSITIVE_TYPES.has(type)) return toggles.moodSocial;
  return true; // 帳單/待辦/預算等一般提醒沒有個別開關
}

function filterNotifiableItems(db, userId, items) {
  const toggles = getPushToggles(db, userId);
  return (items || []).filter((i) => isTypeAllowed(i.type, toggles));
}

module.exports = { MOOD_SENSITIVE_TYPES, getPushToggles, isTypeAllowed, filterNotifiableItems };
