// v0.86：異地備份——每天把整個 SQLite 資料庫加密後上傳到 Google Cloud Storage (GCS)。
//
// 為什麼需要：v0.67 的每月備份 (monthlyBackup.js) 存在同一台 VM 的磁碟上，VM 壞掉、被重建
// 或硬碟出問題時，備份會跟資料庫一起消失。這裡把備份放到 VM 以外的地方。
//
// 設計：
// - 零 npm 依賴：用 Node 內建的 crypto/zlib/fetch，透過 GCE 的 metadata server 拿 VM 服務
//   帳戶的存取權杖 (不需要任何金鑰檔)，直接呼叫 GCS JSON API。
//   前提：VM 的「Cloud API 存取權範圍 → 儲存空間」要是「讀寫」或「完整」(預設是唯讀)。
// - 加密：AES-256-GCM。金鑰優先用環境變數 BACKUP_KEY (base64 的 32 bytes)；沒設定的話第一次
//   執行時自動產生一把存在資料庫同目錄的 backup.key (權限 600)。管理者可以在「個人化設定 →
//   異地備份」看到這把金鑰並自己另外保存——VM 整台不見時，要靠這把金鑰才能解開雲端上的備份。
//   (心情、生理週期等資料都很私人，上傳前一定先加密，就算 bucket 權限設錯也看不到內容。)
// - 檔案格式 (.lhbk)：'LHBK1' (5 bytes) + IV (12) + GCM tag (16) + 密文；密文解開是 gzip 過的
//   SQLite 檔。還原工具：scripts/decrypt-backup.js。
// - 排程：每 30 分鐘檢查一次，台北時間每天 04:00 之後、當天還沒成功過就備份一次；每月 1 日
//   另外多存一份到 monthly/。daily/ 只保留最近 30 天 (程式自己清)，monthly/ 保留 12 個月。
// - Bucket：環境變數 BACKUP_GCS_BUCKET；沒設定就用「<GCP 專案 ID>-lifehub-backups」，不存在時
//   自動建立 (位置 us-east1、禁止公開存取、統一存取權)。
// - 不在 GCE 上 (本機開發、Railway) 時，拿不到 metadata，安靜跳過，只在狀態裡註明。
//
// 跟其他背景排程一樣，這個檔案由 src/routes/offsiteBackup.js 被 require 時啟動，不動 server.js。

const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const zlib = require('zlib');
const { getDb, DB_PATH } = require('./db');
const logger = require('./logger');

const DATA_DIR = path.dirname(DB_PATH);
const KEY_FILE = path.join(DATA_DIR, 'backup.key');
const STATUS_FILE = path.join(DATA_DIR, 'offsite-backup-status.json');
const MAGIC = Buffer.from('LHBK1');
// 兩個 URL 可以用環境變數覆寫，只是為了在本機用假的 metadata/GCS 伺服器測試；正式環境不用設。
const META = process.env.LIFEHUB_GCE_METADATA_URL || 'http://metadata.google.internal/computeMetadata/v1';
const GCS = process.env.LIFEHUB_GCS_BASE || 'https://storage.googleapis.com';
const CHECK_INTERVAL_MS = 30 * 60 * 1000;
const RUN_AFTER_HOUR_TAIPEI = 4;
const KEEP_DAILY_DAYS = 30;
const KEEP_MONTHLY = 12;

let running = false;

function taipeiDate(d = new Date()) {
  const t = new Date(d.getTime() + 8 * 60 * 60 * 1000);
  return { ymd: t.toISOString().slice(0, 10), ym: t.toISOString().slice(0, 7), hour: t.getUTCHours(), day: t.getUTCDate() };
}

function readStatus() {
  try { return JSON.parse(fs.readFileSync(STATUS_FILE, 'utf8')); } catch (e) { return {}; }
}
function writeStatus(patch) {
  const next = { ...readStatus(), ...patch };
  try { fs.writeFileSync(STATUS_FILE, JSON.stringify(next, null, 2)); } catch (e) { /* 狀態寫不進去不影響備份本身 */ }
  return next;
}

function getKey() {
  if (process.env.BACKUP_KEY && process.env.BACKUP_KEY.trim()) {
    const k = Buffer.from(process.env.BACKUP_KEY.trim(), 'base64');
    if (k.length !== 32) throw new Error('BACKUP_KEY 必須是 base64 編碼的 32 bytes');
    return { key: k, source: 'env' };
  }
  if (!fs.existsSync(KEY_FILE)) {
    fs.writeFileSync(KEY_FILE, crypto.randomBytes(32).toString('base64') + '\n', { mode: 0o600 });
    logger.info('[offsiteBackup] 已產生新的備份加密金鑰 (backup.key)，請到「個人化設定 → 異地備份」另外保存', {});
  }
  const k = Buffer.from(fs.readFileSync(KEY_FILE, 'utf8').trim(), 'base64');
  if (k.length !== 32) throw new Error('backup.key 格式不正確');
  return { key: k, source: 'file' };
}

function encrypt(plain, key) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const enc = Buffer.concat([cipher.update(plain), cipher.final()]);
  return Buffer.concat([MAGIC, iv, cipher.getAuthTag(), enc]);
}

function decrypt(buf, key) {
  if (!buf.subarray(0, 5).equals(MAGIC)) throw new Error('不是 LifeHub 備份檔 (.lhbk)');
  const iv = buf.subarray(5, 17), tag = buf.subarray(17, 33), data = buf.subarray(33);
  const d = crypto.createDecipheriv('aes-256-gcm', key, iv);
  d.setAuthTag(tag);
  return Buffer.concat([d.update(data), d.final()]);
}

async function meta(p) {
  const r = await fetch(META + p, { headers: { 'Metadata-Flavor': 'Google' }, signal: AbortSignal.timeout(2000) });
  if (!r.ok) throw new Error(`metadata ${p} -> ${r.status}`);
  return r.text();
}

async function gcsContext() {
  let token, project;
  try {
    token = JSON.parse(await meta('/instance/service-accounts/default/token')).access_token;
    project = (await meta('/project/project-id')).trim();
  } catch (e) {
    const err = new Error('不在 Google Cloud VM 上 (拿不到 metadata)，跳過異地備份');
    err.code = 'NOT_GCE';
    throw err;
  }
  let scopes = '';
  try { scopes = await meta('/instance/service-accounts/default/scopes'); } catch (e) { /* 拿不到就不判斷 */ }
  const bucket = (process.env.BACKUP_GCS_BUCKET || `${project}-lifehub-backups`).trim();
  return { token, project, bucket, scopes };
}

function scopeHint(scopes) {
  if (!scopes) return '';
  const ok = /devstorage\.read_write|devstorage\.full_control|cloud-platform/.test(scopes);
  return ok ? '' : 'VM 的「Cloud API 存取權範圍 → 儲存空間」目前是唯讀，需要改成「讀寫」(要先停止 VM 才能修改)。';
}

async function gcs(ctx, method, url, body, headers = {}) {
  const r = await fetch(url, { method, body, headers: { Authorization: `Bearer ${ctx.token}`, ...headers } });
  const text = await r.text();
  if (!r.ok) {
    const err = new Error(`GCS ${method} ${r.status}: ${text.slice(0, 200)}`);
    err.status = r.status;
    throw err;
  }
  return text ? JSON.parse(text) : {};
}

async function ensureBucket(ctx) {
  try {
    await gcs(ctx, 'GET', `${GCS}/storage/v1/b/${encodeURIComponent(ctx.bucket)}`);
    return false;
  } catch (e) {
    if (e.status !== 404) throw e;
  }
  await gcs(ctx, 'POST', `${GCS}/storage/v1/b?project=${encodeURIComponent(ctx.project)}`, JSON.stringify({
    name: ctx.bucket,
    location: 'US-EAST1',
    storageClass: 'STANDARD',
    iamConfiguration: { uniformBucketLevelAccess: { enabled: true }, publicAccessPrevention: 'enforced' },
  }), { 'Content-Type': 'application/json' });
  logger.info(`[offsiteBackup] 已建立 bucket ${ctx.bucket}`, {});
  return true;
}

async function upload(ctx, name, data) {
  const url = `${GCS}/upload/storage/v1/b/${encodeURIComponent(ctx.bucket)}/o?uploadType=media&name=${encodeURIComponent(name)}`;
  return gcs(ctx, 'POST', url, data, { 'Content-Type': 'application/octet-stream' });
}

async function listObjects(ctx, prefix) {
  const out = [];
  let pageToken = '';
  do {
    const res = await gcs(ctx, 'GET', `${GCS}/storage/v1/b/${encodeURIComponent(ctx.bucket)}/o?prefix=${encodeURIComponent(prefix)}${pageToken ? `&pageToken=${encodeURIComponent(pageToken)}` : ''}`);
    (res.items || []).forEach((i) => out.push(i.name));
    pageToken = res.nextPageToken || '';
  } while (pageToken);
  return out;
}

async function prune(ctx) {
  const today = taipeiDate();
  const cutoff = new Date(Date.parse(today.ymd + 'T00:00:00Z') - KEEP_DAILY_DAYS * 86400000).toISOString().slice(0, 10);
  const daily = await listObjects(ctx, 'daily/');
  const monthly = (await listObjects(ctx, 'monthly/')).sort();
  const toDelete = daily.filter((n) => (n.match(/daily\/(\d{4}-\d{2}-\d{2})/) || [])[1] < cutoff);
  if (monthly.length > KEEP_MONTHLY) toDelete.push(...monthly.slice(0, monthly.length - KEEP_MONTHLY));
  for (const n of toDelete) {
    try { await gcs(ctx, 'DELETE', `${GCS}/storage/v1/b/${encodeURIComponent(ctx.bucket)}/o/${encodeURIComponent(n)}`); } catch (e) { /* 下次再清 */ }
  }
  return toDelete.length;
}

function snapshotDb() {
  const tmp = path.join(os.tmpdir(), `lifehub-backup-${process.pid}-${Date.now()}.db`);
  getDb().exec(`VACUUM INTO '${tmp.replace(/'/g, "''")}'`);
  try { return fs.readFileSync(tmp); } finally { try { fs.unlinkSync(tmp); } catch (e) { /* ignore */ } }
}

async function runBackup({ reason = 'schedule' } = {}) {
  if (running) return { ok: false, error: '備份正在進行中' };
  running = true;
  const startedAt = new Date().toISOString();
  writeStatus({ lastAttemptAt: startedAt, lastReason: reason });
  let ctx = null;
  try {
    ctx = await gcsContext();
    const { key } = getKey();
    const dbBuf = snapshotDb();
    const payload = encrypt(zlib.gzipSync(dbBuf, { level: 9 }), key);
    await ensureBucket(ctx);
    const t = taipeiDate();
    const dailyName = `daily/${t.ymd}.lhbk`;
    await upload(ctx, dailyName, payload);
    const uploaded = [dailyName];
    if (t.day === 1 || reason === 'monthly') {
      const monthlyName = `monthly/${t.ym}.lhbk`;
      await upload(ctx, monthlyName, payload);
      uploaded.push(monthlyName);
    }
    const pruned = await prune(ctx).catch(() => 0);
    const st = writeStatus({
      lastSuccessAt: new Date().toISOString(), lastSuccessDate: t.ymd, lastError: null, lastErrorHint: null,
      bucket: ctx.bucket, lastObjects: uploaded, lastSizeBytes: payload.length, dbSizeBytes: dbBuf.length, pruned,
    });
    logger.info(`[offsiteBackup] 備份完成 gs://${ctx.bucket}/${dailyName} (${payload.length} bytes)`, {});
    return { ok: true, status: st };
  } catch (e) {
    const hint = e.code === 'NOT_GCE' ? null : ((e.status === 403 || e.status === 401) ? (scopeHint(ctx && ctx.scopes) || '服務帳戶沒有寫入這個 bucket 的權限。') : null);
    const st = writeStatus({ lastError: e.message, lastErrorAt: new Date().toISOString(), lastErrorHint: hint, notOnGce: e.code === 'NOT_GCE', bucket: ctx ? ctx.bucket : readStatus().bucket });
    if (e.code !== 'NOT_GCE') logger.error('[offsiteBackup] 備份失敗', { message: e.message });
    return { ok: false, error: e.message, hint, status: st };
  } finally {
    running = false;
  }
}

async function scheduledCheck() {
  const t = taipeiDate();
  const st = readStatus();
  if (st.notOnGce && st.lastAttemptAt && Date.now() - Date.parse(st.lastAttemptAt) < 24 * 3600 * 1000) return;
  if (t.hour < RUN_AFTER_HOUR_TAIPEI || st.lastSuccessDate === t.ymd) return;
  // 失敗後不要每 30 分鐘狂試：同一天失敗過的話，隔 3 小時再試一次
  if (st.lastErrorAt && st.lastErrorAt > (st.lastSuccessAt || '') && Date.now() - Date.parse(st.lastErrorAt) < 3 * 3600 * 1000) return;
  await runBackup({ reason: 'schedule' });
}

function getStatus() {
  const st = readStatus();
  let keySource = null;
  try { keySource = process.env.BACKUP_KEY ? 'env' : (fs.existsSync(KEY_FILE) ? 'file' : null); } catch (e) { /* ignore */ }
  return { ...st, running, keySource, scheduleHourTaipei: RUN_AFTER_HOUR_TAIPEI, keepDailyDays: KEEP_DAILY_DAYS, keepMonthly: KEEP_MONTHLY };
}

function revealKey() { return getKey().key.toString('base64'); }

if (!process.env.LIFEHUB_DISABLE_OFFSITE_BACKUP) {
  const first = setTimeout(() => scheduledCheck().catch(() => {}), 2 * 60 * 1000);
  first.unref();
  const timer = setInterval(() => scheduledCheck().catch(() => {}), CHECK_INTERVAL_MS);
  timer.unref();
}

module.exports = { runBackup, getStatus, revealKey, encrypt, decrypt, MAGIC };
