// v0.86：異地備份 (見 src/services/offsiteBackup.js) 的管理介面。只有管理者帳號能用——
// 這份備份包含「所有使用者」的資料，金鑰也能解開所有人的備份。
// 比照 feedback/insights 的做法，路由由 src/routes/debug.js 併進 /api，不動 server.js；
// 這個檔案被 require 時也會順便啟動每日備份排程。
const { Router } = require('../mini-http');
const { getDb } = require('../services/db');
const { requireAuth } = require('../middleware/auth');
const { isAdminEmail } = require('../services/admin');
const offsite = require('../services/offsiteBackup');

const router = Router();

function requireAdmin(req, res) {
  const me = getDb().prepare('SELECT email FROM users WHERE id = ?').get(req.session.userId);
  if (!isAdminEmail(me && me.email)) { res.status(403).json({ error: '只有管理者可以使用異地備份設定' }); return false; }
  return true;
}

router.get('/backup/offsite/status', requireAuth, (req, res) => {
  if (!requireAdmin(req, res)) return;
  res.json(offsite.getStatus());
});

router.post('/backup/offsite/run', requireAuth, async (req, res) => {
  if (!requireAdmin(req, res)) return;
  const result = await offsite.runBackup({ reason: 'manual' });
  res.json(result);
});

// 顯示加密金鑰，讓管理者自己另外保存 (VM 整台不見時要靠它解開雲端備份)。
router.post('/backup/offsite/key', requireAuth, (req, res) => {
  if (!requireAdmin(req, res)) return;
  try { res.json({ key: offsite.revealKey() }); } catch (e) { res.status(500).json({ error: e.message }); }
});

module.exports = router;
