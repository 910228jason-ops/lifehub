#!/usr/bin/env node
// v0.86：把異地備份 (.lhbk) 解回 SQLite 資料庫檔。
// 用法：node scripts/decrypt-backup.js <備份檔.lhbk> <輸出.db> [金鑰]
//   金鑰 (base64) 沒給的話，依序讀環境變數 BACKUP_KEY、data/backup.key。
// 從 GCS 下載備份：在 GCP 主控台 → Cloud Storage → bucket → daily/ 點檔案下載，
// 或 `gcloud storage cp gs://<bucket>/daily/2026-10-29.lhbk .`
// 還原：停掉服務 → 把輸出的 .db 換成 DB_PATH 指的檔案 (預設 data/app.db) → 重啟。
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const crypto = require('crypto');

const [, , input, output, keyArg] = process.argv;
if (!input || !output) { console.error('用法：node scripts/decrypt-backup.js <備份檔.lhbk> <輸出.db> [金鑰]'); process.exit(1); }
let keyB64 = keyArg || process.env.BACKUP_KEY;
if (!keyB64) {
  const f = path.join(__dirname, '..', 'data', 'backup.key');
  if (fs.existsSync(f)) keyB64 = fs.readFileSync(f, 'utf8').trim();
}
if (!keyB64) { console.error('找不到金鑰：請把金鑰當第三個參數，或設定 BACKUP_KEY'); process.exit(1); }
const key = Buffer.from(keyB64.trim(), 'base64');
const buf = fs.readFileSync(input);
if (!buf.subarray(0, 5).equals(Buffer.from('LHBK1'))) { console.error('不是 LifeHub 備份檔 (.lhbk)'); process.exit(1); }
const d = crypto.createDecipheriv('aes-256-gcm', key, buf.subarray(5, 17));
d.setAuthTag(buf.subarray(17, 33));
let plain;
try { plain = Buffer.concat([d.update(buf.subarray(33)), d.final()]); } catch (e) { console.error('解密失敗：金鑰不對或檔案損毀'); process.exit(1); }
fs.writeFileSync(output, zlib.gunzipSync(plain));
console.log(`已還原到 ${output}`);
