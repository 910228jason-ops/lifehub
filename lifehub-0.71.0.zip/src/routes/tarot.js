// 塔羅占卜 (v0.70)。牌卡資料是純靜態的 (見 src/data/tarotDeck.js)，抽牌只是伺服器端
// 用 crypto 亂數從 78 張牌裡挑，完全不接任何外部占卜/AI API——先把「有牌可以抽、抽完
// 看得懂牌義」這個最基本的版本做完整，之後如果要做「AI 幫你把牌義結合最近日記/心情
// 寫成客製化解讀」，會是另一支獨立的功能，不影響這裡的基礎資料。
//
// 這支檔案沒有用 app.mount() 單獨掛載，而是比照 feedback.js/wishlist.js 等的做法，
// 被 debug.js 合併進已經掛在 /api 的共用 router，所以每個路由都要自己帶 /tarot 前綴。

const crypto = require('crypto');
const { Router } = require('../mini-http');
const { getDb } = require('../services/db');
const { requireAuth } = require('../middleware/auth');
const { TAROT_DECK, getCardByKey } = require('../data/tarotDeck');

const router = Router();

const SPREADS = {
  single: { count: 1, label: '單張牌：今日/此刻的指引' },
  three: { count: 3, label: '三張牌：過去 / 現在 / 未來' },
};

// 用 crypto.randomInt 而不是 Math.random，抽牌這種「求一個公平的隨機結果」的場景，
// 用密碼學等級的亂數來源比較讓人放心 (雖然這裡不是安全性敏感的用途，但反正 Node
// 內建就有，不需要額外依賴，就直接用比較嚴謹的版本)。
function drawRandomCards(count) {
  const pool = TAROT_DECK.slice();
  const drawn = [];
  for (let i = 0; i < count && pool.length > 0; i++) {
    const idx = crypto.randomInt(0, pool.length);
    const card = pool.splice(idx, 1)[0];
    const reversed = crypto.randomInt(0, 2) === 1;
    drawn.push({ key: card.key, reversed });
  }
  return drawn;
}

function hydrateCard(entry) {
  const card = getCardByKey(entry.key);
  if (!card) return null;
  const side = entry.reversed ? card.reversed : card.upright;
  return {
    key: card.key,
    name: card.name,
    arcana: card.arcana,
    reversed: !!entry.reversed,
    keyword: side.keyword,
    meaning: side.meaning,
  };
}

router.get('/tarot/spreads', requireAuth, (req, res) => {
  res.json({
    spreads: Object.keys(SPREADS).map((key) => ({ key, ...SPREADS[key] })),
  });
});

router.post('/tarot/draw', requireAuth, (req, res) => {
  const { spreadType, question } = req.body || {};
  const spread = SPREADS[spreadType] ? spreadType : 'single';
  const drawnEntries = drawRandomCards(SPREADS[spread].count);
  const cards = drawnEntries.map(hydrateCard).filter(Boolean);

  const db = getDb();
  const now = new Date().toISOString();
  const result = db
    .prepare('INSERT INTO tarot_draws (user_id, spread_type, cards_json, question, created_at) VALUES (?, ?, ?, ?, ?)')
    .run(req.session.userId, spread, JSON.stringify(drawnEntries), (question && String(question).trim().slice(0, 300)) || null, now);

  res.json({
    id: result.lastInsertRowid,
    spreadType: spread,
    spreadLabel: SPREADS[spread].label,
    question: (question && String(question).trim().slice(0, 300)) || null,
    cards,
    createdAt: now,
  });
});

// 補記一句自己的心得/備註到某一次抽牌紀錄 (抽完當下可能還沒想好要寫什麼，之後回來補)。
router.put('/tarot/draws/:id/note', requireAuth, (req, res) => {
  const db = getDb();
  const draw = db.prepare('SELECT * FROM tarot_draws WHERE id = ? AND user_id = ?').get(req.params.id, req.session.userId);
  if (!draw) return res.status(404).json({ error: '找不到這筆占卜紀錄' });
  const note = req.body && req.body.note != null ? String(req.body.note).trim().slice(0, 1000) : null;
  db.prepare('UPDATE tarot_draws SET note = ? WHERE id = ?').run(note || null, draw.id);
  res.json({ ok: true });
});

router.get('/tarot/history', requireAuth, (req, res) => {
  const db = getDb();
  const limit = Math.min(Math.max(Number(req.query.limit) || 20, 1), 100);
  const rows = db
    .prepare('SELECT * FROM tarot_draws WHERE user_id = ? ORDER BY id DESC LIMIT ?')
    .all(req.session.userId, limit);
  const items = rows.map((r) => {
    let entries = [];
    try { entries = JSON.parse(r.cards_json); } catch (e) { entries = []; }
    return {
      id: r.id,
      spreadType: r.spread_type,
      spreadLabel: (SPREADS[r.spread_type] || {}).label || r.spread_type,
      question: r.question,
      note: r.note,
      cards: entries.map(hydrateCard).filter(Boolean),
      createdAt: r.created_at,
    };
  });
  res.json({ items });
});

module.exports = router;
