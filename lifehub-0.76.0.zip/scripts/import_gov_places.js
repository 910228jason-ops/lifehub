// 政府開放資料 (data.gov.tw 觀光資訊資料庫「景點」，dataset id 7777) 匯入腳本。
//
// v2 改版說明：原本的 V1.0 JSON (scenic_spot_C_f.json) 已經在 2026-06-30 被交通部觀光署
// 下架，現在只剩 V2.1 格式 (zip 壓縮檔，解壓縮後是三支檔案：AttractionList.json 景點基本
// 資料、AttractionServiceTimeList.json 營運時間、AttractionFeeList.json 收費資訊，manifest.csv
// 記錄檔名對照)。這支腳本已經改成照 V2.1 的真實結構寫、且用真實檔案 (2026-08-04 下載，
// 6102 筆景點) 實際跑過驗證，不是之前那版「照文件猜」的版本。
//
// 使用方式：
//   node scripts/import_gov_places.js --dir /path/to/解壓縮後的資料夾 --inspect   (先看資料長怎樣，不寫入)
//   node scripts/import_gov_places.js --dir /path/to/解壓縮後的資料夾            (寫入目前 DB_PATH 指到的資料庫)
//   node scripts/import_gov_places.js --dir ... --sql-out migrations/045_xxx.sql (改成輸出成一支 SQL migration 檔，
//                                                                                  不直接寫資料庫 —— Railway 正式環境
//                                                                                  沒有辦法直接連進去跑腳本，只能
//                                                                                  透過 migrations/*.sql 隨部署套用)
//   都可以加 --limit N 只處理前 N 筆，方便先小量測試。
//
// 資料夾裡至少要有 AttractionList.json；AttractionServiceTimeList.json / AttractionFeeList.json
// 是選用的，有的話會拿來補營業時間/收費資訊 (這兩個輔助檔案涵蓋率不高，大部份景點就是
// 沒有結構化的營業時間/收費資料，維持 NULL，不是漏抓，是政府資料本身沒填)。
//
// 匯入策略：
//   - source 一律標記為 'gov'，用 external_id (= AttractionID) 當去重鍵 (見 migrations/044_more_places.sql
//     的 external_id 欄位)。重複執行只會新增沒看過的、更新已存在的，不會一直長出重複地點。
//   - 只匯入 ServiceStatus === 1 (正常開放) 的景點，跳過歇業/暫停開放/狀態不明的 (0、3)。
//   - 城市名稱正規化：政府資料的 PostalAddress.City 是「臺中市」這種帶「臺」+ 市/縣後綴的
//     寫法，這裡統一轉成跟既有資料一致的「台中」(規則跟 src/routes/places.js 的
//     normalizeCity 完全一樣，兩邊操到同一份資料才會對得上)。
//   - 沒有 AttractionName 或 PostalAddress.City 的資料直接跳過，不猜測、不硬塞髒資料。
//   - 不寫入任何評分／星等 —— 這份資料本來就沒有這欄，維持「沒有就是沒有，不編造」的原則。
//   - mood_tags (v0.59)：政府資料的 AttractionClasses 是分類代碼，沒有對照表可以核對代碼
//     對應的實際分類，所以不是用那個欄位，改成用「名稱 + 描述」關鍵字比對 (見
//     src/services/moodTagClassifier.js) 自動猜幾個合理的心情標籤。比對不到任何關鍵字的
//     地方留空 (不亂猜)，這種地方在心情篩選開啟時還是找不到，但比對得到的 (實測約八成)
//     現在可以被篩選找到了。transport_tags 目前還是留空——交通方式 (步行/開車/騎車)
//     的判斷需要停車場/大眾運輸資訊，政府資料裡的 ParkingInfo/TrafficInfo 涵蓋率太低、
//     格式又不統一，先不猜，之後有更好的訊號來源再處理。

const fs = require('fs');
const path = require('path');
const { classifyMoodTags } = require('../src/services/moodTagClassifier');

function parseArgs(argv) {
  const args = { limit: null, inspect: false, dir: null, sqlOut: null };
  for (let i = 0; i < argv.length; i++) {
    if (argv[i] === '--dir') args.dir = argv[++i];
    else if (argv[i] === '--limit') args.limit = Number(argv[++i]);
    else if (argv[i] === '--inspect') args.inspect = true;
    else if (argv[i] === '--sql-out') args.sqlOut = argv[++i];
  }
  return args;
}

// 跟 src/routes/places.js 的 normalizeCity 保持同一套規則，兩邊資料才會對得上。
function normalizeCity(raw) {
  if (!raw) return '';
  let s = String(raw).trim();
  s = s.replace(/臺/g, '台');
  s = s.replace(/(市|縣)$/, '');
  return s;
}

function readJsonBom(filePath) {
  // V2.1 檔案帶 UTF-8 BOM，Node 的 JSON.parse 對開頭的 BOM 會直接報錯，要先砍掉。
  const raw = fs.readFileSync(filePath, 'utf8');
  const stripped = raw.charCodeAt(0) === 0xfeff ? raw.slice(1) : raw;
  return JSON.parse(stripped);
}

function buildAuxMaps(dir) {
  const serviceTimeMap = new Map(); // AttractionID -> 人類可讀的營業時間字串
  const feeMap = new Map(); // AttractionID -> 人類可讀的收費字串

  const stPath = path.join(dir, 'AttractionServiceTimeList.json');
  if (fs.existsSync(stPath)) {
    const data = readJsonBom(stPath);
    (data.AttractionServiceTimes || []).forEach((rec) => {
      const parts = (rec.ServiceTimes || []).map((s) => {
        const days = (s.ServiceDays || []).join('/');
        const time = s.StartTime && s.EndTime ? `${s.StartTime.slice(0, 5)}-${s.EndTime.slice(0, 5)}` : '';
        return [s.Name, days, time].filter(Boolean).join(' ');
      });
      if (parts.length) serviceTimeMap.set(rec.AttractionID, parts.join('；').slice(0, 300));
    });
  }

  const feePath = path.join(dir, 'AttractionFeeList.json');
  if (fs.existsSync(feePath)) {
    const data = readJsonBom(feePath);
    (data.AttractionFees || []).forEach((rec) => {
      const parts = (rec.Fees || []).map((f) => {
        const price = f.Price != null ? `${f.Price}元` : '';
        return [f.Name, price].filter(Boolean).join(' ');
      });
      if (parts.length) feeMap.set(rec.AttractionID, parts.join('；').slice(0, 300));
    });
  }

  return { serviceTimeMap, feeMap };
}

function mapRecord(record, auxMaps) {
  if (record.ServiceStatus !== 1) return null; // 只收正常開放的，跳過歇業/暫停/狀態不明

  const name = (record.AttractionName || '').trim();
  if (!name) return null;

  const pa = record.PostalAddress || {};
  const city = normalizeCity(pa.City);
  if (!city) return null;

  const district = (pa.Town || '').trim() || null;
  const address = [pa.City, pa.Town, pa.StreetAddress].filter(Boolean).join('').trim() || null;

  let duration = null;
  if (record.VisitDuration != null) {
    const n = Number(String(record.VisitDuration).replace(/[^0-9.]/g, ''));
    if (Number.isFinite(n) && n > 0) duration = Math.round(n);
  }

  const hoursText = auxMaps.serviceTimeMap.get(record.AttractionID) || (record.ServiceTimeInfo || '').trim() || null;
  const feeInfo = auxMaps.feeMap.get(record.AttractionID) || (record.FeeInfo || '').trim() || null;
  const description = (record.Description || '').trim();

  // v0.59：從名稱 + 完整描述關鍵字比對，自動猜幾個心情標籤 (見 moodTagClassifier.js 的
  // 說明)。用完整描述 (不是被截到 500 字的 note) 判斷，資訊比較完整、比對得更準；比對不到
  // 任何關鍵字就回傳空陣列，不會硬塞不準確的標籤。
  const moodTags = classifyMoodTags(`${name} ${description}`);

  return {
    external_id: String(record.AttractionID || '').trim() || null,
    name,
    city,
    district,
    address,
    hours_text: hoursText,
    fee_info: feeInfo,
    visit_duration_min: duration,
    note: description.slice(0, 500) || null,
    mood_tags: moodTags,
  };
}

function sqlStr(s) {
  if (s === null || s === undefined) return 'NULL';
  return "'" + String(s).replace(/'/g, "''") + "'";
}

// 跟 src/routes/places.js 的 cleanTagList() 存的格式完全一樣：`,tag1,tag2,` (前後都有逗號，
// 方便用 SQL 的 `LIKE '%,tag,%'` 查詢)，空陣列存成空字串。兩邊格式要一致，篩選才會對得上。
function tagsToStoredString(tags) {
  return tags && tags.length ? `,${tags.join(',')},` : '';
}

function writeSqlMigration(outPath, mapped, now) {
  const seenExternalIds = new Set(); // 原始資料理論上 AttractionID 不重複，這裡防呆一下
  const lines = [
    '-- 政府開放資料 (交通部觀光署「景點 - 觀光資訊資料庫」dataset id 7777, V2.1 JSON) 匯入。',
    `-- 來源檔案下載/處理時間：${now}，共匯入 ${mapped.length} 筆 (原始 ServiceStatus=1 正常開放的景點)。`,
    '-- 由 scripts/import_gov_places.js --sql-out 產生，欄位對應邏輯見該檔案開頭的說明註解。',
    '-- 這是一次性 migration，套用過後 schema_migrations 會記錄下來，重新部署不會重複匯入；',
    '-- 之後要更新這批資料需要重新下載檔案、重新產生一支新的 migration (用新的 external_id',
    '-- 去重規則，UPDATE 已存在的、INSERT 新出現的，不會炸出重複地點)。',
    '',
  ];
  for (const r of mapped) {
    if (r.external_id) {
      if (seenExternalIds.has(r.external_id)) continue;
      seenExternalIds.add(r.external_id);
    }
    lines.push(
      `INSERT INTO places (name, city, district, address, mood_tags, transport_tags, hours_text, fee_info, visit_duration_min, note, source, status, created_by_user_id, external_id, created_at, updated_at) VALUES (${sqlStr(r.name)}, ${sqlStr(r.city)}, ${sqlStr(r.district)}, ${sqlStr(r.address)}, ${sqlStr(tagsToStoredString(r.mood_tags))}, '', ${sqlStr(r.hours_text)}, ${sqlStr(r.fee_info)}, ${r.visit_duration_min === null ? 'NULL' : r.visit_duration_min}, ${sqlStr(r.note)}, 'gov', 'active', NULL, ${sqlStr(r.external_id)}, ${sqlStr(now)}, ${sqlStr(now)});`
    );
  }
  fs.writeFileSync(outPath, lines.join('\n') + '\n');
  return seenExternalIds.size;
}

function main() {
  const args = parseArgs(process.argv.slice(2));
  if (!args.dir) {
    console.error('用法: node scripts/import_gov_places.js --dir <解壓縮後的資料夾路徑> [--inspect] [--limit N] [--sql-out <輸出路徑>]');
    process.exit(1);
  }
  const dir = path.resolve(args.dir);
  const listPath = path.join(dir, 'AttractionList.json');
  if (!fs.existsSync(listPath)) {
    console.error(`找不到 ${listPath}，請確認 --dir 指向的是解壓縮後、包含 AttractionList.json 的資料夾`);
    process.exit(1);
  }

  const data = readJsonBom(listPath);
  const records = data.Attractions || [];
  console.log(`讀到 ${records.length} 筆原始資料 (更新時間: ${data.UpdateTime})`);

  if (args.inspect) {
    console.log('第一筆資料的所有欄位:');
    console.log(JSON.stringify(records[0], null, 2));
    console.log('\n如果上面欄位名稱跟腳本裡 mapRecord() 假設的不一樣，先改那個函式，再拿掉 --inspect 正式跑。');
    return;
  }

  const auxMaps = buildAuxMaps(dir);
  const limited = args.limit ? records.slice(0, args.limit) : records;
  const mapped = limited.map((r) => mapRecord(r, auxMaps)).filter(Boolean);
  const skipped = limited.length - mapped.length;
  console.log(`成功解析 ${mapped.length} 筆，略過 ${skipped} 筆 (非正常開放狀態、缺名稱、或判斷不出城市)`);

  const now = new Date().toISOString();

  if (args.sqlOut) {
    const outPath = path.resolve(args.sqlOut);
    const count = writeSqlMigration(outPath, mapped, now);
    console.log(`已寫入 SQL migration: ${outPath} (${count} 筆去重後的 INSERT)`);
    return;
  }

  const { loadEnv } = require('../src/services/env');
  loadEnv();
  const { getDb } = require('../src/services/db');
  const db = getDb();
  const findByExternalId = db.prepare(`SELECT id FROM places WHERE source = 'gov' AND external_id = ?`);
  const insert = db.prepare(
    `INSERT INTO places (name, city, district, address, mood_tags, transport_tags, hours_text, fee_info, visit_duration_min, note, source, status, created_by_user_id, external_id, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, '', ?, ?, ?, ?, 'gov', 'active', NULL, ?, ?, ?)`
  );
  const update = db.prepare(
    `UPDATE places SET name = ?, city = ?, district = ?, address = ?, mood_tags = ?, hours_text = ?, fee_info = ?, visit_duration_min = ?, note = ?, updated_at = ? WHERE id = ?`
  );

  let inserted = 0, updated = 0;
  for (const r of mapped) {
    const existing = r.external_id ? findByExternalId.get(r.external_id) : null;
    const moodTagsStr = tagsToStoredString(r.mood_tags);
    if (existing) {
      update.run(r.name, r.city, r.district, r.address, moodTagsStr, r.hours_text, r.fee_info, r.visit_duration_min, r.note, now, existing.id);
      updated++;
    } else {
      insert.run(r.name, r.city, r.district, r.address, moodTagsStr, r.hours_text, r.fee_info, r.visit_duration_min, r.note, r.external_id, now, now);
      inserted++;
    }
  }
  console.log(`完成：新增 ${inserted} 筆、更新 ${updated} 筆。`);
}

main();
