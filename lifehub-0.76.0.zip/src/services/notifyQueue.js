// 推播的「靜音時段」+「短時間內合併成一則」共用邏輯。
//
// 背景：三支獨立的排程 (一般提醒/精準待辦提醒/服藥提醒，見 routes/push.js) 原本各自算好
// 內容就直接對每個訂閱裝置送出，彼此互不知道對方的存在。使用者實際使用時的抱怨是「連續跳出
// 好幾則通知，很有轟炸感」——例如同一分鐘內剛好待辦提醒跟服藥提醒都到期，就會连續跳兩則。
// 這支檔案提供一個所有推播來源都要經過的共用出口 queueNotification()，依「urgent」分兩條
// 完全不同的路徑處理：
//
//   1. 非緊急 (urgent: false)——使用者自己沒有指定精準時間的被動提醒 (帳單快到期/待辦逾期/
//      好幾天沒記心情/生日/另一半生理週期)：
//      - 靜音時段 (晚上 11 點到早上 10 點) 直接跳過，等隔天早上再看，不用半夜跳出來吵醒人。
//      - 沒被靜音時段擋下的話，會先進 90 秒的收集佇列，等收集窗結束後把同一個使用者這段
//        時間內累積的多筆非緊急通知「合併成一則」送出 (多筆時標題變成「X 則新提醒」)，
//        避免同一時段內好幾個被動提醒各自跳出來轟炸。
//   2. 緊急 (urgent: true)——使用者自己明確設定精準時間的待辦提醒、服藥提醒：這是使用者
//      主動要求「在這個時間點通知我」的內容，所以：
//      - 不受靜音時段限制 (吃藥時間就是設在半夜也照樣準時提醒)。
//      - 也「不」跟其他通知合併——使用者是特別為了這件事設定提醒，應該獨立、完整地顯示
//        (標題就是這件事本身)，不能被埋進「3 則新提醒」這種合併通知裡讓人抓不到重點，
//        所以緊急通知一律立刻各自送出，即使剛好跟別的緊急通知同一分鐘觸發也一樣。
//
// 三支排程只需要把「直接迴圈訂閱裝置送出」改成呼叫 queueNotification()，其餘 (加密、簽章、
// 失效訂閱清除) 都還是 webpush.js 負責，這裡只管「什麼時候送、送幾則」。

const logger = require('./logger');
const { sendNotification } = require('./webpush');

const BUNDLE_WINDOW_MS = 90 * 1000; // 90 秒內的「非緊急」通知合併成一則，短到不會讓使用者等太久才看到，長到足夠吸收同一批排程觸發的多筆提醒
const DEFAULT_QUIET_HOURS_START = '23:00'; // 晚上 11 點 (舊版寫死的預設值，現在使用者可以在「個人化設定」自己調整)
const DEFAULT_QUIET_HOURS_END = '10:00'; // 早上 10 點 (不含，10:00 開始正常推播)
// v0.67：推播疲勞控管——靜音時段/合併通知解決的是「同一時段內轟炸」，沒解決「一整天下來
// 累積送了很多次」(例如帳單/待辦/心情提醒剛好在不同時段各自觸發變化，每次都各自通過合併
// 窗口送出)。這裡加一天最多幾次非緊急推播的上限，超過當天就不再推播 (首頁還是看得到)。
// 緊急/使用者自訂精準提醒 (urgent: true，見下面的說明) 不受這個上限限制。
const DAILY_NONURGENT_PUSH_CAP = 6;

function todayDateStr() { return new Date().toISOString().slice(0, 10); }

function getTodaySendCount(db, userId) {
  try {
    const row = db.prepare('SELECT count FROM push_send_counts WHERE user_id = ? AND send_date = ?').get(userId, todayDateStr());
    return row ? row.count : 0;
  } catch (e) { return 0; } // migration 還沒套用時當作沒送過，不讓推播因此掛掉
}

function incrementTodaySendCount(db, userId) {
  try {
    db.prepare(
      `INSERT INTO push_send_counts (user_id, send_date, count) VALUES (?, ?, 1)
       ON CONFLICT(user_id, send_date) DO UPDATE SET count = count + 1`
    ).run(userId, todayDateStr());
  } catch (e) { /* 欄位還不存在時忽略，不影響推播本身 */ }
}

const pending = new Map(); // userId -> { items: [{title, body, icon}], timer }  ——只用來裝「非緊急」通知

// "HH:MM" 轉成當天累計分鐘數，方便比較；格式不合法 (使用者資料異常/欄位還沒套用 migration
// 時的 NULL) 一律退回對應的預設值，不讓整個靜音時段判斷因此掛掉。
function toMinutes(hhmm, fallback) {
  const m = typeof hhmm === 'string' && hhmm.match(/^(\d{1,2}):(\d{2})$/);
  if (!m) return toMinutes(fallback, null);
  const h = Number(m[1]), min = Number(m[2]);
  if (h > 23 || min > 59) return toMinutes(fallback, null);
  return h * 60 + min;
}

// v0.58：靜音時段區間現在是「每個使用者自己在設定頁調整」，不再是全站寫死的 23:00-10:00，
// 所以這裡改成吃 start/end 兩個參數 (預設值維持跟舊版一樣的 23:00-10:00，沒傳參數時行為
// 完全不變)。支援跨午夜的區間 (start > end，例如 23:00-10:00) 也支援不跨午夜的區間
// (start < end，例如 01:00-06:00)；start === end 視為「沒有設定靜音時段」，一律不跳過，
// 避免使用者不小心設成同一個時間，導致全天都被誤判成靜音、完全收不到非緊急通知。
function isQuietHoursNow(date = new Date(), startHHMM = DEFAULT_QUIET_HOURS_START, endHHMM = DEFAULT_QUIET_HOURS_END) {
  const start = toMinutes(startHHMM, DEFAULT_QUIET_HOURS_START);
  const end = toMinutes(endHHMM, DEFAULT_QUIET_HOURS_END);
  if (start === end) return false;
  const cur = date.getHours() * 60 + date.getMinutes();
  if (start < end) return cur >= start && cur < end; // 不跨午夜的區間
  return cur >= start || cur < end; // 跨午夜的區間 (例如 23:00-10:00)
}

// 把一則通知內容實際送給某個使用者的每一台訂閱裝置——緊急的單筆立即送、非緊急的合併後
// 一起走這裡，行為 (加密送出/失效訂閱清除) 完全一樣，差別只在呼叫時機。
async function deliverToUser(db, userId, { title, body, icon }, logLabel) {
  const subs = db.prepare('SELECT * FROM push_subscriptions WHERE user_id = ?').all(userId);
  for (const sub of subs) {
    try {
      const result = await sendNotification(db, sub, { title, body, icon });
      if (!result.ok && (result.status === 404 || result.status === 410)) {
        db.prepare('DELETE FROM push_subscriptions WHERE id = ?').run(sub.id);
      }
    } catch (e) {
      logger.error(`[push] ${logLabel}送出失敗`, { userId, message: e.message });
    }
  }
}

async function flushUser(db, userId) {
  const entry = pending.get(userId);
  if (!entry) return;
  pending.delete(userId);
  const items = entry.items;
  if (!items.length) return;

  let title, body, icon;
  if (items.length === 1) {
    ({ title, body, icon } = items[0]);
  } else {
    // 合併成一則：標題講清楚「有幾件事」，內文把每一則的標題跟內容各列一行 (最多列 5 則，
    // 避免通知內容過長被系統截斷)，圖示沿用第一則的 (同一個使用者這段時間內圖示通常一樣)。
    title = `${items.length} 則新提醒`;
    body = items.slice(0, 5).map((i) => `${i.title}：${i.body}`).join('\n');
    icon = items[0].icon;
  }

  await deliverToUser(db, userId, { title, body, icon }, '合併推播');
  incrementTodaySendCount(db, userId); // v0.67：每一次真的送出的合併推播算一次，不是每個 item 各算一次
}

// opts.urgent = true：使用者自己明確要求的提醒 (服藥提醒/使用者自訂精準時間的待辦提醒)。
// 這種不受靜音時段限制、也不進合併佇列，直接各自立刻送出，確保使用者看到的就是他自己
// 設定的那則通知，不會被合併成籠統的「X 則新提醒」。
//
// 其餘一律視為「非緊急」，靜音時段內直接跳過、不進佇列 (使用者隔天打開 App 首頁一樣看得到
// 對應的洞察內容，只是不會半夜推播打擾)；沒被擋下的話進 90 秒合併佇列。
//
// 回傳值 (true = 會送出/已排入佇列, false = 靜音時段跳過) 給呼叫端判斷要不要更新自己的
// 「已推播過」紀錄——如果直接無條件標記成「送過了」，靜音時段結束後同樣的提醒內容會被
// 誤判成「24小時內推播過」而永遠不會真的送出，這裡讓呼叫端只在真的會送出時才標記。
function queueNotification(db, userId, { title, body, icon, urgent = false }) {
  if (urgent) {
    deliverToUser(db, userId, { title, body, icon }, '緊急推播').catch((e) =>
      logger.error('[push] 緊急推播失敗', { userId, message: e.message })
    );
    return true;
  }
  // 每個使用者自己在「個人化設定」調整靜音時段的起訖時間 (quiet_hours_start/end)；
  // 欄位還沒套用 migration、或這個使用者還沒存過偏好時，退回舊版的 23:00-10:00 預設值，
  // 行為跟改版前完全一致。
  let quietStart = DEFAULT_QUIET_HOURS_START, quietEnd = DEFAULT_QUIET_HOURS_END;
  try {
    const prefsRow = db.prepare('SELECT quiet_hours_start, quiet_hours_end FROM user_prefs WHERE user_id = ?').get(userId);
    if (prefsRow) {
      quietStart = prefsRow.quiet_hours_start || quietStart;
      quietEnd = prefsRow.quiet_hours_end || quietEnd;
    }
  } catch (e) { /* migration 還沒套用時直接用預設值，不讓推播因此掛掉 */ }
  if (isQuietHoursNow(new Date(), quietStart, quietEnd)) {
    logger.info(`[push] 靜音時段 (${quietStart}-${quietEnd})，跳過非緊急通知`, { userId, title });
    return false;
  }
  // v0.67：每日推播上限——已經進到佇列裡但還沒被合併送出的通知，不會被這個上限擋下 (它們
  // 屬於「這次要送」的量，擋下已經排進去的反而奇怪)，這裡只在「準備排進新的一批」之前檢查
  // 今天已經實際送出過幾次合併通知，超過上限就直接跳過、不進佇列。
  if (getTodaySendCount(db, userId) >= DAILY_NONURGENT_PUSH_CAP) {
    logger.info(`[push] 今天已達每日推播上限 (${DAILY_NONURGENT_PUSH_CAP} 次)，跳過非緊急通知`, { userId, title });
    return false;
  }
  let entry = pending.get(userId);
  if (!entry) {
    entry = { items: [], timer: null };
    pending.set(userId, entry);
  }
  entry.items.push({ title, body, icon });
  if (entry.timer) clearTimeout(entry.timer);
  entry.timer = setTimeout(() => {
    flushUser(db, userId).catch((e) => logger.error('[push] 合併通知 flush 失敗', { userId, message: e.message }));
  }, BUNDLE_WINDOW_MS);
  entry.timer.unref(); // 不阻止 process 正常結束 (跟其他排程 timer 一致)
  return true;
}

module.exports = { queueNotification, isQuietHoursNow, BUNDLE_WINDOW_MS, getTodaySendCount, incrementTodaySendCount, DAILY_NONURGENT_PUSH_CAP };
