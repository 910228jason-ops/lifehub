// v0.67：資料自動備份排程。
//
// 背景：使用者原本只能自己記得去「個人化設定」按「匯出全部資料」，忘記按、或根本不知道
// 有這個功能的話，萬一資料出問題 (例如 Railway 沒接 Volume 導致重新部署清空資料庫，見
// README 的說明) 就完全沒有備份可以復原。這裡加一個完全被動、不需要使用者做任何事的
// 背景排程：每個月自動幫「每一個使用者」各存一份完整資料備份到伺服器磁碟上。
//
// 存放位置：跟資料庫檔案 (DB_PATH)同一個目錄下的 backups/ 資料夾——這樣如果 Railway 有
// 掛 Volume (README 建議的正式部署方式)，備份檔案會跟資料庫一樣掛在 Volume 上、重新部署
// 不會遺失；如果沒掛 Volume，本來資料庫也保不住，備份檔案保不住是同一個已知限制，不是
// 這個功能自己的問題。
//
// 只保留最近 6 個月，避免使用者一多、累積時間一長，備份檔案無限增長占滿磁碟空間。
//
// 這個檔案沒有被 server.js 直接 require——是透過 src/routes/export.js 的
// `require('../services/monthlyBackup')` 間接載入，第一次被 require 時就會啟動下面的
// setInterval 排程，符合這個專案「刻意不去動 server.js」的部署慣例。

const fs = require('fs');
const path = require('path');
const { getDb, DB_PATH } = require('./db');
const logger = require('./logger');

const BACKUP_DIR = path.join(path.dirname(DB_PATH), 'backups');
const KEEP_MONTHS = 6;
const CHECK_INTERVAL_MS = 6 * 60 * 60 * 1000; // 每 6 小時檢查一次「這個月備份過了沒」，不需要更頻繁

function ensureDir(dir) {
  try { fs.mkdirSync(dir, { recursive: true }); } catch (e) { /* 已存在或權限問題時忽略，下面寫檔會再失敗一次並記 log */ }
}

function currentPeriod() { return new Date().toISOString().slice(0, 7); } // YYYY-MM

function userBackupDir(userId) { return path.join(BACKUP_DIR, `user_${userId}`); }

// 列出某個使用者目前存在磁碟上的備份 (最新的在前面)，給 GET /export/backups 用。
function listBackupsForUser(userId) {
  const dir = userBackupDir(userId);
  try {
    return fs.readdirSync(dir)
      .filter((f) => f.endsWith('.json'))
      .map((f) => {
        const full = path.join(dir, f);
        const stat = fs.statSync(full);
        return { period: f.replace(/\.json$/, ''), sizeBytes: stat.size, createdAt: stat.mtime.toISOString() };
      })
      .sort((a, b) => b.period.localeCompare(a.period));
  } catch (e) {
    return []; // 資料夾還不存在 (從來沒備份過) 時回傳空陣列，不是錯誤
  }
}

function readBackupForUser(userId, period) {
  // period 只允許 YYYY-MM 格式，避免路徑穿越
  if (!/^\d{4}-\d{2}$/.test(period)) return null;
  const full = path.join(userBackupDir(userId), `${period}.json`);
  try { return fs.readFileSync(full, 'utf8'); } catch (e) { return null; }
}

function pruneOldBackups(userId) {
  const dir = userBackupDir(userId);
  try {
    const files = fs.readdirSync(dir).filter((f) => f.endsWith('.json')).sort();
    const excess = files.length - KEEP_MONTHS;
    for (let i = 0; i < excess; i++) {
      try { fs.unlinkSync(path.join(dir, files[i])); } catch (e) { /* 刪不掉就算了，下次再試 */ }
    }
  } catch (e) { /* 資料夾不存在時沒有東西要清 */ }
}

function runMonthlyBackupForAllUsers() {
  const db = getDb();
  const period = currentPeriod();
  try {
    const already = db.prepare('SELECT 1 FROM backup_runs WHERE run_period = ?').get(period);
    if (already) return; // 這個月已經備份過了
  } catch (e) {
    return; // migration 還沒套用時直接跳過，等下一輪再檢查
  }

  ensureDir(BACKUP_DIR);
  const { buildExportData } = require('../routes/export');
  const users = db.prepare('SELECT id FROM users').all();
  let successCount = 0;
  users.forEach((u) => {
    try {
      const data = buildExportData(db, u.id);
      const dir = userBackupDir(u.id);
      ensureDir(dir);
      fs.writeFileSync(path.join(dir, `${period}.json`), JSON.stringify(data));
      pruneOldBackups(u.id);
      successCount += 1;
    } catch (e) {
      logger.error('[monthlyBackup] 使用者備份失敗', { userId: u.id, message: e.message });
    }
  });

  try {
    db.prepare('INSERT INTO backup_runs (run_period, ran_at, user_count) VALUES (?, ?, ?)').run(period, new Date().toISOString(), successCount);
  } catch (e) { /* 寫入標記失敗的話，下次檢查會重跑一次，頂多多備份一次，不會漏掉 */ }
  logger.info(`[monthlyBackup] ${period} 自動備份完成，共 ${successCount} 位使用者`, {});
}

// 啟動時先檢查一次 (伺服器可能剛好在月初重啟、或本來就還沒跑過這個月的份)，之後每 6 小時
// 再檢查一次。用 try/catch 包起來，任何一次執行失敗都不該讓整個排程停掉。
function safeRun() {
  try { runMonthlyBackupForAllUsers(); } catch (e) { logger.error('[monthlyBackup] 排程執行失敗', { message: e.message }); }
}
safeRun();
const backupTimer = setInterval(safeRun, CHECK_INTERVAL_MS);
backupTimer.unref(); // 不阻止 process 正常結束，跟其他背景排程一致

module.exports = { listBackupsForUser, readBackupForUser, runMonthlyBackupForAllUsers };
