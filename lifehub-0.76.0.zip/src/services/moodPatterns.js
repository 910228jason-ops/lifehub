// 跨模塊深層模式識別。
//
// 分兩層做 (詳細原因跟使用者討論過)：
//   第一層：純程式計算每天的結構化特徵 + 幾組平均數對比，不靠 AI，數字準確、不會腦補。
//   第二層：只把「算出來的統計訊號」(數字，不是日記原文) 交給 AI，請它組織成一段人話，
//           並提醒這只是初步觀察、不是絕對因果關係，避免使用者被下定論嚇到或誤信。
//
// 因為需要一定的資料量才有意義，這個分析不是每次開頁面就重算，而是由 route 決定何時觸發、
// 存進 mood_patterns 表當快取。

const assistant = require('./assistant');
const cycle = require('./cycle');

const MIN_MOOD_ENTRIES = 20;

function buildDailyFeatures(db, userId, sinceStr) {
  const moodRows = db
    .prepare('SELECT entry_date, score, tags FROM mood_entries WHERE user_id = ? AND entry_date >= ?')
    .all(userId, sinceStr);

  const eventRows = db
    .prepare('SELECT event_date, COUNT(*) as cnt FROM calendar_events WHERE user_id = ? AND event_date >= ? GROUP BY event_date')
    .all(userId, sinceStr);
  const eventsByDate = {};
  eventRows.forEach((r) => { eventsByDate[r.event_date] = r.cnt; });

  const txRows = db
    .prepare("SELECT tx_date, SUM(amount) as total FROM finance_transactions WHERE user_id = ? AND tx_date >= ? AND type = 'expense' GROUP BY tx_date")
    .all(userId, sinceStr);
  const spendByDate = {};
  txRows.forEach((r) => { spendByDate[r.tx_date] = r.total; });

  const diaryRows = db
    .prepare('SELECT entry_date, LENGTH(content) as len FROM diary_entries WHERE user_id = ? AND entry_date >= ?')
    .all(userId, sinceStr);
  const diaryLenByDate = {};
  diaryRows.forEach((r) => { diaryLenByDate[r.entry_date] = r.len; });

  // 生理週期是選填功能，沒有記錄的話這裡就是空陣列，phaseForDate 會回傳 null，
  // 下面的 computeSignals 看到全部都是 null 就不會產生這組訊號，不影響其他分析。
  // 只算使用者自己的經期資料 (tracking_for = 'self')；有些人記錄的是幫另一半代記的經期，
  // 那種不代表使用者自己的生理狀態，不該被拿來跟使用者的心情做關聯分析。
  const cycleEntries = db
    .prepare("SELECT period_start_date, period_end_date FROM cycle_entries WHERE user_id = ? AND tracking_for = 'self' ORDER BY period_start_date ASC")
    .all(userId);

  const sleepRows = db
    .prepare('SELECT entry_date, hours FROM health_sleep_entries WHERE user_id = ? AND entry_date >= ?')
    .all(userId, sinceStr);
  const sleepByDate = {};
  sleepRows.forEach((r) => { sleepByDate[r.entry_date] = r.hours; });

  const interactionRows = db
    .prepare('SELECT DISTINCT interaction_date FROM relationship_interactions WHERE user_id = ? AND interaction_date >= ?')
    .all(userId, sinceStr);
  const interactionDates = new Set(interactionRows.map((r) => r.interaction_date));

  return moodRows.map((r) => {
    const d = new Date(r.entry_date + 'T00:00:00Z');
    const dayOfMonth = d.getUTCDate();
    const dayOfWeek = d.getUTCDay(); // 0=Sun, 6=Sat
    const prevDate = new Date(d.getTime() - 24 * 60 * 60 * 1000).toISOString().slice(0, 10);
    return {
      date: r.entry_date,
      score: r.score,
      tags: (r.tags || '').split(',').filter(Boolean),
      isMonthEnd: dayOfMonth >= 25,
      isWeekend: dayOfWeek === 0 || dayOfWeek === 6,
      eventCount: eventsByDate[r.entry_date] || 0,
      spend: spendByDate[r.entry_date] || 0,
      diaryLen: diaryLenByDate[r.entry_date] || 0,
      cyclePhase: cycle.phaseForDate(cycleEntries, r.entry_date),
      // 前一晚睡眠時數：用來看「睡不夠的隔天心情如何」，不是當天睡眠 (通常還沒發生)
      prevNightSleepHours: sleepByDate[prevDate] != null ? sleepByDate[prevDate] : null,
      hadInteraction: interactionDates.has(r.entry_date),
    };
  });
}

function avg(arr) {
  if (!arr.length) return null;
  return Math.round((arr.reduce((s, v) => s + v, 0) / arr.length) * 10) / 10;
}

// 每一組對比都需要兩邊都至少有幾筆資料，太少沒有代表性就跳過。
const MIN_GROUP_SIZE = 4;

function computeSignals(features) {
  const signals = [];

  function pushComparison(label, groupAName, groupA, groupBName, groupB) {
    if (groupA.length < MIN_GROUP_SIZE || groupB.length < MIN_GROUP_SIZE) return;
    const avgA = avg(groupA.map((f) => f.score));
    const avgB = avg(groupB.map((f) => f.score));
    const diff = Math.round((avgA - avgB) * 10) / 10;
    if (Math.abs(diff) < 0.8) return; // 差異太小，不算是有意義的訊號
    signals.push({ label, groupAName, avgA, countA: groupA.length, groupBName, avgB, countB: groupB.length, diff });
  }

  pushComparison('月底 vs 非月底', '月底 (25 號後)', features.filter((f) => f.isMonthEnd), '非月底', features.filter((f) => !f.isMonthEnd));
  pushComparison('週末 vs 平日', '週末', features.filter((f) => f.isWeekend), '平日', features.filter((f) => !f.isWeekend));

  const spendValues = features.map((f) => f.spend).filter((v) => v > 0);
  if (spendValues.length >= MIN_GROUP_SIZE * 2) {
    const sorted = [...spendValues].sort((a, b) => a - b);
    const median = sorted[Math.floor(sorted.length / 2)];
    pushComparison('高支出日 vs 一般日', '支出偏高的日子', features.filter((f) => f.spend > median), '其他日子', features.filter((f) => f.spend <= median));
  }

  const eventCounts = features.map((f) => f.eventCount);
  if (eventCounts.some((c) => c > 0)) {
    pushComparison('行程滿 vs 行程鬆', '當天 3 件事以上', features.filter((f) => f.eventCount >= 3), '當天少於 3 件事', features.filter((f) => f.eventCount < 3));
  }

  pushComparison('有寫日記 vs 沒寫日記', '當天有寫日記', features.filter((f) => f.diaryLen > 0), '當天沒寫日記', features.filter((f) => f.diaryLen === 0));

  // 只有使用者自己有記錄睡眠，才會有非 null 的前一晚睡眠時數
  const sleepValues = features.filter((f) => f.prevNightSleepHours != null);
  if (sleepValues.length >= MIN_GROUP_SIZE * 2) {
    pushComparison(
      '前一晚睡不到6小時 vs 睡滿6小時以上',
      '前一晚睡不到6小時',
      sleepValues.filter((f) => f.prevNightSleepHours < 6),
      '前一晚睡滿6小時以上',
      sleepValues.filter((f) => f.prevNightSleepHours >= 6)
    );
  }

  // 只是單純的資料對比 (有無社交互動的那幾天心情平均)，純觀察用，不代表「應該」去社交
  pushComparison('有社交互動 vs 沒有社交互動', '當天有記錄社交互動', features.filter((f) => f.hadInteraction), '當天沒有記錄社交互動', features.filter((f) => !f.hadInteraction));

  // v0.59：原本只比較「經前(黃體期後段)」跟其他階段，只看得到單一片段。改成四個生理週期
  // 階段各自跟「其他階段」比一次，才看得出完整的週期心情剖面 (例如經期本身心情如何、排卵期
  // 呢)，不是只知道經前這一段。只有使用者自己記錄過生理週期時 (cyclePhase 有非 null 值)
  // 才會跑這組比較，而且每個階段各自都要有足夠的樣本數 (pushComparison 內建的
  // MIN_GROUP_SIZE 篩選)，資料不夠的階段自然不會產生訊號，不會硬湊出不可靠的結論。
  const CYCLE_PHASE_LABELS = { menstrual: '月經期', follicular: '濾泡期', ovulation: '排卵期', luteal: '經前(黃體期後段)' };
  if (features.some((f) => f.cyclePhase)) {
    Object.keys(CYCLE_PHASE_LABELS).forEach((phase) => {
      pushComparison(
        `${CYCLE_PHASE_LABELS[phase]} vs 其他階段`,
        CYCLE_PHASE_LABELS[phase],
        features.filter((f) => f.cyclePhase === phase),
        '其他階段',
        features.filter((f) => f.cyclePhase !== phase && f.cyclePhase != null)
      );
    });
  }

  // v0.59：長期趨勢——把整個分析區間 (預設 90 天) 對半切成「較早」跟「近期」兩段，比較
  // 平均心情分數有沒有明顯變化，讓使用者看得出「最近是不是比一陣子前更好/更差」，而不是
  // 只看得到零散的單日對比訊號。用「日期範圍中點」而不是「筆數對半」來切，避免記錄疏密不均
  // (例如某段時間很認真記、某段時間漏記) 讓兩組的時間長度失真。
  if (features.length >= MIN_GROUP_SIZE * 2) {
    const sortedDates = features.map((f) => f.date).sort();
    const earliestMs = new Date(sortedDates[0] + 'T00:00:00Z').getTime();
    const latestMs = new Date(sortedDates[sortedDates.length - 1] + 'T00:00:00Z').getTime();
    const midMs = (earliestMs + latestMs) / 2;
    pushComparison(
      '近期 vs 較早的紀錄 (長期趨勢)',
      '較近期',
      features.filter((f) => new Date(f.date + 'T00:00:00Z').getTime() >= midMs),
      '較早之前',
      features.filter((f) => new Date(f.date + 'T00:00:00Z').getTime() < midMs)
    );
  }

  // 標籤相關：每個常見標籤出現的那幾天 vs 沒出現的那幾天
  const tagCounts = {};
  features.forEach((f) => f.tags.forEach((t) => { tagCounts[t] = (tagCounts[t] || 0) + 1; }));
  Object.keys(tagCounts)
    .filter((t) => tagCounts[t] >= MIN_GROUP_SIZE)
    .forEach((tag) => {
      pushComparison(`標籤「${tag}」出現的日子`, `有「${tag}」`, features.filter((f) => f.tags.includes(tag)), `沒有「${tag}」`, features.filter((f) => !f.tags.includes(tag)));
    });

  return signals;
}

const PATTERN_SYSTEM_PROMPT = `你是 LifeHub 的心情陪伴 AI。使用者的系統幫他統計了幾組「心情分數」跟其他生活面向 (行程、記帳、日記、標籤) 的平均數對比資料，
請你把這些數字訊號組織成 2-4 句自然的觀察，語氣溫和、像朋友在跟他分享觀察到的事，不要條列式、不要說教。
非常重要：這些只是平均數的對比，不是嚴謹的統計檢定，更不是因果關係，請在文字中很自然地帶到「這只是初步的觀察，不代表絕對如此」這樣的提醒，
但不要講得太生硬、公式化。如果訊號很少或很平淡，就誠實說目前還看不出明顯的規律，鼓勵使用者繼續累積紀錄。
特別注意：如果訊號跟「社交互動」或「睡眠」有關，只是單純分享數字上的觀察，絕對不要用命令、催促或「應該要」的語氣要求使用者去社交或早睡，
每個人步調不同、也不是每個人都想要或需要頻繁社交，用平等分享觀察的語氣就好，把決定權留給使用者。
請一律用繁體中文回覆。`;

async function generatePatternInsights(signals) {
  if (!signals.length) {
    return { isConfigured: true, reply: '目前資料量還看不出明顯的規律，再累積多一點心情紀錄，這裡會幫你抓出屬於你自己的模式。' };
  }
  const lines = signals.map((s) => `${s.label}：${s.groupAName} 平均 ${s.avgA} 分 (n=${s.countA})，${s.groupBName} 平均 ${s.avgB} 分 (n=${s.countB})，差 ${s.diff} 分`);
  const prompt = `這是系統統計出來的心情關聯訊號：\n${lines.join('\n')}\n請幫我寫成觀察文字。`;
  return assistant.chat([{ role: 'user', content: prompt }], { systemPrompt: PATTERN_SYSTEM_PROMPT });
}

module.exports = { MIN_MOOD_ENTRIES, buildDailyFeatures, computeSignals, generatePatternInsights };
