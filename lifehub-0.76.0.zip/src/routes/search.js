// v0.76.0：全站搜尋 (/api/search)。使用者反應待辦事項/日記/願望清單/讀書清單/筆記各自都有
// 自己的搜尋框，但沒有一個「一次搜全部模組」的入口。這支路由用同一個關鍵字分別對幾個內容
// 型模組（不是設定型模組，例如股票自選、記帳分類這種不算「內容」，不需要被搜到）各自下一次
// LIKE 查詢，每個模組最多回傳 8 筆，前端會依模組分組顯示、點下去就直接切換到對應分頁——
// 不做「跳到那個項目、自動捲動高亮」這麼深，先讓「找得到在哪個分頁」堪用即可，之後有需要
// 再加深。家庭公告欄因為牽涉多人共用圈子的權限判斷 (partnerShare)，這版先不含在全站搜尋
// 範圍內，避免把權限邏輯複製一份出來又不一致；其餘都是「只有自己看得到自己的」單純案例。
const { Router } = require('../mini-http');
const { getDb } = require('../services/db');
const { requireAuth } = require('../middleware/auth');

const router = Router();

const MAX_PER_MODULE = 8;

function snippet(text, q, max = 60) {
  if (!text) return '';
  const idx = text.toLowerCase().indexOf(q.toLowerCase());
  if (idx < 0) return text.slice(0, max);
  const start = Math.max(0, idx - 15);
  const s = text.slice(start, start + max);
  return (start > 0 ? '…' : '') + s + (start + max < text.length ? '…' : '');
}

router.get('/search', requireAuth, (req, res) => {
  const q = String((req.query && req.query.q) || '').trim();
  if (!q || q.length < 1) return res.json({ results: [] });
  const db = getDb();
  const userId = req.session.userId;
  const like = `%${q}%`;
  const results = [];

  const tasks = db
    .prepare('SELECT id, title, note FROM tasks WHERE user_id = ? AND (title LIKE ? OR note LIKE ?) ORDER BY created_at DESC LIMIT ?')
    .all(userId, like, like, MAX_PER_MODULE);
  tasks.forEach((t) => results.push({
    module: 'tasks', moduleLabel: '待辦事項', icon: '✅', tab: 'tasks',
    title: t.title, snippet: snippet(t.note, q),
  }));

  const diary = db
    .prepare('SELECT id, entry_date, content FROM diary_entries WHERE user_id = ? AND content LIKE ? ORDER BY entry_date DESC LIMIT ?')
    .all(userId, like, MAX_PER_MODULE);
  diary.forEach((d) => results.push({
    module: 'diary', moduleLabel: '日記', icon: '📔', tab: 'diary',
    title: d.entry_date, snippet: snippet(d.content, q),
  }));

  const notes = db
    .prepare('SELECT id, title, content FROM notes WHERE user_id = ? AND (title LIKE ? OR content LIKE ?) ORDER BY updated_at DESC LIMIT ?')
    .all(userId, like, like, MAX_PER_MODULE);
  notes.forEach((n) => results.push({
    module: 'notes', moduleLabel: '個人筆記', icon: '📝', tab: 'notes',
    title: n.title || '（無標題）', snippet: snippet(n.content, q),
  }));

  const wishlist = db
    .prepare('SELECT id, title, note FROM wishlist_items WHERE user_id = ? AND (title LIKE ? OR note LIKE ?) ORDER BY created_at DESC LIMIT ?')
    .all(userId, like, like, MAX_PER_MODULE);
  wishlist.forEach((w) => results.push({
    module: 'wishlist', moduleLabel: '願望清單', icon: '🎀', tab: 'wishlist',
    title: w.title, snippet: snippet(w.note, q),
  }));

  const reading = db
    .prepare('SELECT id, title, note FROM reading_items WHERE user_id = ? AND (title LIKE ? OR note LIKE ?) ORDER BY updated_at DESC LIMIT ?')
    .all(userId, like, like, MAX_PER_MODULE);
  reading.forEach((r) => results.push({
    module: 'reading', moduleLabel: '讀書', icon: '📖', tab: 'reading',
    title: r.title, snippet: snippet(r.note, q),
  }));

  res.json({ results });
});

module.exports = router;
