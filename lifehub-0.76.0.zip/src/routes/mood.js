const { Router } = require('../mini-http');
const { getDb } = require('../services/db');
const { requireAuth } = require('../middleware/auth');
const mood = require('../services/mood');
const techniques = require('../services/moodTechniques');
const patterns = require('../services/moodPatterns');
const cycle = require('../services/cycle');
const logger = require('../services/logger');

const router = Router();

// 對話記錄一樣要用「最近 N 則」的邏輯，跟 assistant.js 同一套修法：
// 先用 id DESC 撈最新的 N 筆，再用 JS reverse() 還原時間順序，
// 避免對話一旦超過上限，AI 就卡在很久以前的內容 (先前版本的 bug)。
const MAX_CHAT_HISTORY = 300;

function fetchRecentChatHistory(db, userId, limit) {
  const rows = db
    .prepare('SELECT role, content, created_at FROM mood_chat_messages WHERE user_id = ? ORDER BY id DESC LIMIT ?')
    .all(userId, limit);
  return rows.reverse();
}

function todayStr() {
  return new Date().toISOString().slice(0, 10);
}

// ---------- 每日心情紀錄 ----------

router.get('/entries', requireAuth, (req, res) => {
  const db = getDb();
  const { from, to } = req.query;
  let rows;
  if (from && to) {
    rows = db
      .prepare('SELECT * FROM mood_entries WHERE user_id = ? AND entry_date BETWEEN ? AND ? ORDER BY entry_date ASC')
      .all(req.session.userId, from, to);
  } else {
    rows = db
      .prepare('SELECT * FROM mood_entries WHERE user_id = ? ORDER BY entry_date DESC LIMIT 60')
      .all(req.session.userId);
  }
  res.json(rows);
});

// v0.70：天氣是使用者自己選的 (不接氣象 API，維持這個專案「零外部依賴」的原則)，
// 純粹當作一個可選標籤，之後才能做「心情 x 天氣」的簡單關聯統計 (見 GET /weather-correlation)。
const VALID_WEATHER = new Set(['sunny', 'cloudy', 'rainy', 'cold', 'hot']);

// 用日期當 key 做 upsert：同一天重複記錄會直接更新，而不是新增多筆。
router.put('/entries/:date', requireAuth, (req, res) => {
  const { date } = req.params;
  const { score, tags, note, weather } = req.body || {};
  const scoreNum = Number(score);
  if (!date || !Number.isInteger(scoreNum) || scoreNum < 1 || scoreNum > 10) {
    return res.status(400).json({ error: '請提供有效的日期與 1-10 的心情分數' });
  }
  const weatherVal = VALID_WEATHER.has(weather) ? weather : null;
  const db = getDb();
  const now = new Date().toISOString();
  const tagsStr = Array.isArray(tags) ? tags.join(',') : (tags || null);
  // 遊戲化點數：只在「今天第一次記心情」時加點——這裡用 INSERT ... ON CONFLICT 一次處理
  // 新增/更新，所以要先查一次「今天有沒有紀錄」，不能靠 SQL 本身的 upsert 結果判斷，
  // 不然使用者一直改今天的分數會一直加點。
  const alreadyRecordedToday = db.prepare('SELECT 1 FROM mood_entries WHERE user_id = ? AND entry_date = ?').get(req.session.userId, date);
  db.prepare(
    `INSERT INTO mood_entries (user_id, entry_date, score, tags, note, weather, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)
     ON CONFLICT(user_id, entry_date) DO UPDATE SET score = excluded.score, tags = excluded.tags, note = excluded.note, weather = excluded.weather, updated_at = excluded.updated_at`
  ).run(req.session.userId, date, scoreNum, tagsStr, note || null, weatherVal, now, now);
  if (!alreadyRecordedToday) {
    require('../services/points').awardPoints(db, req.session.userId, 2, 'mood');
  }
  res.json({ ok: true });
});

// v0.70：心情 x 天氣關聯——把有標記天氣的紀錄依天氣分組算平均分數，樣本太少 (少於 3 筆)
// 的天氣類別不列入 (避免只記錄過 1 次「下雨」就說「下雨你心情比較差」這種過度推論)。
router.get('/weather-correlation', requireAuth, (req, res) => {
  const db = getDb();
  const rows = db
    .prepare("SELECT weather, score FROM mood_entries WHERE user_id = ? AND weather IS NOT NULL")
    .all(req.session.userId);
  const byWeather = {};
  rows.forEach((r) => { (byWeather[r.weather] = byWeather[r.weather] || []).push(r.score); });
  const results = Object.entries(byWeather)
    .filter(([, scores]) => scores.length >= 3)
    .map(([weather, scores]) => ({
      weather,
      count: scores.length,
      avgScore: Math.round((scores.reduce((s, v) => s + v, 0) / scores.length) * 10) / 10,
    }))
    .sort((a, b) => b.avgScore - a.avgScore);
  res.json({ hasEnoughData: results.length > 0, results, totalTagged: rows.length });
});

router.get('/summary', requireAuth, (req, res) => {
  const db = getDb();
  const { days } = req.query;
  const n = Math.min(Math.max(Number(days) || 30, 1), 180);
  const since = new Date();
  since.setDate(since.getDate() - n);
  const sinceStr = since.toISOString().slice(0, 10);

  const rows = db
    .prepare('SELECT entry_date, score, tags FROM mood_entries WHERE user_id = ? AND entry_date >= ? ORDER BY entry_date ASC')
    .all(req.session.userId, sinceStr);

  const avg = rows.length ? rows.reduce((s, r) => s + r.score, 0) / rows.length : null;
  const tagCounts = {};
  rows.forEach((r) => {
    (r.tags || '').split(',').filter(Boolean).forEach((t) => { tagCounts[t] = (tagCounts[t] || 0) + 1; });
  });
  const topTags = Object.entries(tagCounts).sort((a, b) => b[1] - a[1]).slice(0, 5).map(([tag, count]) => ({ tag, count }));

  // ---- 主動關心訊號 ----
  // 1) gapDays：距離「上一次」有紀錄的日子過了幾天，太久沒紀錄就溫和提醒一下 (不是責備)。
  // 2) needsCare：最近連續幾筆分數偏低時，主動給一句關心的話，而不是等使用者自己來找 AI。
  const lastEntry = db
    .prepare('SELECT entry_date FROM mood_entries WHERE user_id = ? ORDER BY entry_date DESC LIMIT 1')
    .get(req.session.userId);
  let gapDays = null;
  if (lastEntry) {
    const last = new Date(lastEntry.entry_date + 'T00:00:00Z');
    const now = new Date(todayStr() + 'T00:00:00Z');
    gapDays = Math.round((now - last) / (1000 * 60 * 60 * 24));
  }

  const recentScores = rows.slice(-3).map((r) => r.score);
  const recentAvg = recentScores.length ? recentScores.reduce((s, v) => s + v, 0) / recentScores.length : null;
  let needsCare = false;
  let careMessage = null;
  if (recentScores.length >= 2 && recentAvg != null && recentAvg <= 4) {
    needsCare = true;
    careMessage = '這幾天感覺你過得比較辛苦，要不要來這裡聊聊？不用勉強，我在這裡。';
  } else if (gapDays != null && gapDays >= 5) {
    careMessage = `已經 ${gapDays} 天沒有記錄心情了，最近還好嗎？有空的話回來寫一筆吧。`;
  } else {
    // 3) 經前觀察窗 (選填功能，只有使用者自己有記錄生理週期才會出現)：
    //    優先度低於上面兩個訊號，只在沒有更急迫的關心事項時才顯示。
    const cycleStatus = getCycleStatus(db, req.session.userId);
    if (cycleStatus.hasData && cycleStatus.isPmsWindow) {
      careMessage = '接下來這幾天可能會進入經前階段，如果覺得特別容易累、情緒起伏比較大，那是正常的身體反應，別太苛責自己。';
    }
  }

  res.json({
    series: rows,
    average: avg != null ? Math.round(avg * 10) / 10 : null,
    topTags,
    count: rows.length,
    gapDays,
    needsCare,
    careMessage,
  });
});

// ---------- 生理週期紀錄 (選填功能) ----------
// 只用來讓「主動關心」跟「跨模塊模式分析」能考慮經前階段，不做醫療用途的排卵/生育預測。

// 「主動關心」的經前提醒只看使用者自己的經期資料 (tracking_for = 'self')；
// 如果是幫另一半代記錄的，不該被拿來推測/關心使用者自己的心情狀態。
function getCycleStatus(db, userId) {
  const entries = db
    .prepare("SELECT period_start_date, period_end_date FROM cycle_entries WHERE user_id = ? AND tracking_for = 'self' ORDER BY period_start_date ASC")
    .all(userId);
  return cycle.currentStatus(entries, todayStr());
}

router.get('/cycle', requireAuth, (req, res) => {
  const db = getDb();
  const rows = db.prepare('SELECT id, period_start_date, period_end_date, symptoms, tracking_for, created_at FROM cycle_entries WHERE user_id = ? ORDER BY period_start_date DESC LIMIT 24').all(req.session.userId);
  res.json(rows);
});

router.post('/cycle', requireAuth, (req, res) => {
  const { periodStartDate, periodEndDate, symptoms, trackingFor } = req.body || {};
  if (!periodStartDate) return res.status(400).json({ error: '請提供經期開始日期' });
  const tf = trackingFor === 'partner' ? 'partner' : 'self';
  const db = getDb();
  const now = new Date().toISOString();
  const symptomsStr = Array.isArray(symptoms) ? symptoms.join(',') : (symptoms || null);
  const result = db.prepare('INSERT INTO cycle_entries (user_id, period_start_date, period_end_date, symptoms, tracking_for, created_at) VALUES (?, ?, ?, ?, ?, ?)').run(
    req.session.userId, periodStartDate, periodEndDate || null, symptomsStr, tf, now
  );
  res.json({ id: result.lastInsertRowid, ok: true });
});

router.delete('/cycle/:id', requireAuth, (req, res) => {
  const db = getDb();
  db.prepare('DELETE FROM cycle_entries WHERE id = ? AND user_id = ?').run(req.params.id, req.session.userId);
  res.json({ ok: true });
});

// 另一半的週期狀態估算：跟使用者自己的完全分開算 (只吃 tracking_for = 'partner' 的資料)，
// 給「陪伴另一半」分頁用，純粹是提醒使用者現在大概是哪個階段，方便理解與陪伴，不做醫療用途。
router.get('/cycle/partner-status', requireAuth, (req, res) => {
  const db = getDb();
  const entries = db
    .prepare("SELECT period_start_date, period_end_date FROM cycle_entries WHERE user_id = ? AND tracking_for = 'partner' ORDER BY period_start_date ASC")
    .all(req.session.userId);
  res.json(cycle.currentStatus(entries, todayStr()));
});

router.get('/cycle/status', requireAuth, (req, res) => {
  const db = getDb();
  res.json(getCycleStatus(db, req.session.userId));
});

// ---------- 心情 × 行事曆 洞察 ----------
// 粗略比對「當天行事曆事項數量」跟「當天心情分數」的關係，
// 給一句自然語言的觀察 (不是嚴謹統計，只是給使用者一個參考角度)。
router.get('/insights', requireAuth, (req, res) => {
  const db = getDb();
  const since = new Date();
  since.setDate(since.getDate() - 30);
  const sinceStr = since.toISOString().slice(0, 10);

  const moodRows = db
    .prepare('SELECT entry_date, score FROM mood_entries WHERE user_id = ? AND entry_date >= ?')
    .all(req.session.userId, sinceStr);

  if (moodRows.length < 5) {
    return res.json({ available: false, message: '心情紀錄還太少，再多記幾天，這裡會幫你看看跟行程的關聯。' });
  }

  const eventRows = db
    .prepare('SELECT event_date, COUNT(*) as cnt FROM calendar_events WHERE user_id = ? AND event_date >= ? GROUP BY event_date')
    .all(req.session.userId, sinceStr);
  const eventCountByDate = {};
  eventRows.forEach((r) => { eventCountByDate[r.event_date] = r.cnt; });

  const BUSY_THRESHOLD = 3;
  const busyScores = [];
  const calmScores = [];
  moodRows.forEach((r) => {
    const cnt = eventCountByDate[r.entry_date] || 0;
    if (cnt >= BUSY_THRESHOLD) busyScores.push(r.score);
    else calmScores.push(r.score);
  });

  if (!busyScores.length || !calmScores.length) {
    return res.json({ available: false, message: '再累積一些不同忙碌程度的日子，這裡會幫你看看跟行程的關聯。' });
  }

  const avgBusy = Math.round((busyScores.reduce((s, v) => s + v, 0) / busyScores.length) * 10) / 10;
  const avgCalm = Math.round((calmScores.reduce((s, v) => s + v, 0) / calmScores.length) * 10) / 10;
  const diff = Math.round((avgCalm - avgBusy) * 10) / 10;

  let message;
  if (diff >= 1) {
    message = `行程比較滿的日子 (當天 ${BUSY_THRESHOLD} 件事以上)，平均心情分數是 ${avgBusy} 分；行程比較鬆的日子平均是 ${avgCalm} 分。忙碌的日子心情容易比較低，排行程時可以留一點喘息空間給自己。`;
  } else if (diff <= -1) {
    message = `有趣的是，行程比較滿的日子平均心情反而是 ${avgBusy} 分，比較鬆的日子是 ${avgCalm} 分——對你來說，充實地忙可能反而是件好事。`;
  } else {
    message = `行程忙碌程度 (忙碌日平均 ${avgBusy} 分／較鬆日平均 ${avgCalm} 分) 跟你的心情分數目前看起來沒有明顯關聯，心情可能更多受其他事情影響。`;
  }

  res.json({ available: true, avgBusy, avgCalm, busyDays: busyScores.length, calmDays: calmScores.length, message });
});

// ---------- 這週 AI 回顧 ----------

router.post('/weekly-review', requireAuth, async (req, res) => {
  const db = getDb();
  const since = new Date();
  since.setDate(since.getDate() - 7);
  const sinceStr = since.toISOString().slice(0, 10);
  const entries = db
    .prepare('SELECT entry_date, score, tags, note FROM mood_entries WHERE user_id = ? AND entry_date >= ? ORDER BY entry_date ASC')
    .all(req.session.userId, sinceStr);

  try {
    const result = await mood.generateWeeklyReview(entries);
    res.json(result);
  } catch (e) {
    logger.error('心情週回顧產生失敗', { error: e.message });
    res.status(502).json({ error: '這週回顧暫時無法產生，請稍後再試', detail: e.message });
  }
});

// ---------- 這個月 AI 回顧 ----------

router.post('/monthly-review', requireAuth, async (req, res) => {
  const db = getDb();
  const month = (req.body && req.body.month) || todayStr().slice(0, 7); // YYYY-MM
  const entries = db
    .prepare("SELECT entry_date, score, tags, note FROM mood_entries WHERE user_id = ? AND entry_date LIKE ? ORDER BY entry_date ASC")
    .all(req.session.userId, `${month}%`);

  try {
    const result = await mood.generateMonthlyReview(entries, month);
    res.json({ month, ...result });
  } catch (e) {
    logger.error('心情月回顧產生失敗', { error: e.message });
    res.status(502).json({ error: '這個月的回顧暫時無法產生，請稍後再試', detail: e.message });
  }
});

// ---------- 會學習的因應技巧庫 ----------

router.get('/techniques/suggest', requireAuth, (req, res) => {
  const { tag } = req.query;
  if (!tag) return res.status(400).json({ error: '請提供 tag' });
  const db = getDb();
  const technique = techniques.pickTechnique(db, req.session.userId, tag);
  res.json({ tag, technique });
});

// 技巧成效總覽：把使用者對每個標籤底下每個技巧的回饋整理成「你自己的因應工具箱」，
// 每個標籤只顯示回饋數最多、且有幫助比例最高的技巧 (至少要有 1 筆回饋)，讓使用者能看到
// 系統實際上「學到了什麼」，而不是每次都是黑盒子建議。
router.get('/techniques/stats', requireAuth, (req, res) => {
  const db = getDb();
  const rows = db
    .prepare('SELECT tag, technique_key, helped FROM mood_technique_feedback WHERE user_id = ?')
    .all(req.session.userId);

  const byTag = {};
  rows.forEach((r) => {
    if (!byTag[r.tag]) byTag[r.tag] = {};
    if (!byTag[r.tag][r.technique_key]) byTag[r.tag][r.technique_key] = { helped: 0, total: 0 };
    byTag[r.tag][r.technique_key].total += 1;
    if (r.helped) byTag[r.tag][r.technique_key].helped += 1;
  });

  const result = Object.keys(byTag).map((tag) => {
    const techEntries = Object.entries(byTag[tag]);
    const pool = techniques.getTechniquesForTag(tag);
    let best = null;
    techEntries.forEach(([key, stat]) => {
      const ratio = stat.helped / stat.total;
      if (!best || ratio > best.ratio || (ratio === best.ratio && stat.total > best.total)) {
        const meta = pool.find((t) => t.key === key);
        best = { key, title: meta ? meta.title : key, ratio, helped: stat.helped, total: stat.total };
      }
    });
    return { tag, best };
  });

  res.json(result.filter((r) => r.best));
});

router.post('/techniques/feedback', requireAuth, (req, res) => {
  const { tag, techniqueKey, helped } = req.body || {};
  if (!tag || !techniqueKey || typeof helped !== 'boolean') {
    return res.status(400).json({ error: '請提供 tag、techniqueKey、helped' });
  }
  const db = getDb();
  db.prepare('INSERT INTO mood_technique_feedback (user_id, tag, technique_key, helped, created_at) VALUES (?, ?, ?, ?, ?)').run(
    req.session.userId,
    tag,
    techniqueKey,
    helped ? 1 : 0,
    new Date().toISOString()
  );
  res.json({ ok: true });
});

// ---------- CBT 式思考記錄 ----------
// 定位提醒：這是自助認知練習輔助工具，不是心理治療或診斷；AI 的建議只是「一個可能的角度」，
// 使用者永遠可以不採用、自己寫 reframe。

router.get('/thought-records', requireAuth, (req, res) => {
  const db = getDb();
  const rows = db
    .prepare('SELECT id, situation, thought, emotion, intensity, evidence_for, evidence_against, reframe, created_at FROM mood_thought_records WHERE user_id = ? ORDER BY id DESC')
    .all(req.session.userId);
  res.json(rows);
});

router.post('/thought-records', requireAuth, (req, res) => {
  const { situation, thought, emotion, intensity, evidenceFor, evidenceAgainst, reframe } = req.body || {};
  if (!thought || !String(thought).trim()) {
    return res.status(400).json({ error: '請至少填寫「腦中出現的念頭」' });
  }
  const intensityNum = intensity != null && intensity !== '' ? Number(intensity) : null;
  if (intensityNum != null && (!Number.isInteger(intensityNum) || intensityNum < 1 || intensityNum > 10)) {
    return res.status(400).json({ error: '情緒強度請填 1-10 的整數' });
  }
  const db = getDb();
  const now = new Date().toISOString();
  const result = db
    .prepare(
      `INSERT INTO mood_thought_records (user_id, situation, thought, emotion, intensity, evidence_for, evidence_against, reframe, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
    )
    .run(req.session.userId, situation || null, String(thought).trim(), emotion || null, intensityNum, evidenceFor || null, evidenceAgainst || null, reframe || null, now);
  res.json({ id: result.lastInsertRowid, ok: true });
});

router.delete('/thought-records/:id', requireAuth, (req, res) => {
  const db = getDb();
  db.prepare('DELETE FROM mood_thought_records WHERE id = ? AND user_id = ?').run(req.params.id, req.session.userId);
  res.json({ ok: true });
});

router.post('/thought-records/reframe-suggest', requireAuth, async (req, res) => {
  const { situation, thought, evidenceFor, evidenceAgainst } = req.body || {};
  if (!thought || !String(thought).trim()) {
    return res.status(400).json({ error: '請先填寫「腦中出現的念頭」' });
  }
  try {
    const result = await mood.suggestReframe({ situation, thought, evidenceFor, evidenceAgainst });
    res.json(result);
  } catch (e) {
    logger.error('reframe 建議產生失敗', { error: e.message });
    res.status(502).json({ error: '建議暫時無法產生，請稍後再試，或直接自己寫下你的想法', detail: e.message });
  }
});

// ---------- 跨模塊深層模式識別 ----------
// 不是每次開頁面就重算 (需要一定資料量才有意義、也比較省 AI 成本)，而是存快取，
// 由使用者手動點「重新分析」或前端在快取太舊時才觸發重算。

router.get('/patterns', requireAuth, (req, res) => {
  const db = getDb();
  const row = db
    .prepare('SELECT signals_json, insights, generated_at FROM mood_patterns WHERE user_id = ? ORDER BY id DESC LIMIT 1')
    .get(req.session.userId);
  if (!row) {
    return res.json({ available: false, generated: false, message: '還沒有分析過，點「重新分析」讓 AI 幫你看看資料裡有沒有規律。' });
  }
  res.json({ available: true, generated: true, insights: row.insights, signals: JSON.parse(row.signals_json), generatedAt: row.generated_at });
});

router.post('/patterns/refresh', requireAuth, async (req, res) => {
  const db = getDb();
  const since = new Date();
  since.setDate(since.getDate() - 90);
  const sinceStr = since.toISOString().slice(0, 10);

  const totalCount = db
    .prepare('SELECT COUNT(*) as c FROM mood_entries WHERE user_id = ? AND entry_date >= ?')
    .get(req.session.userId, sinceStr).c;

  if (totalCount < patterns.MIN_MOOD_ENTRIES) {
    return res.json({ available: false, generated: false, message: `心情紀錄還太少 (目前 ${totalCount} 筆，建議累積到至少 ${patterns.MIN_MOOD_ENTRIES} 筆)，再多記錄一陣子，這裡會幫你找出屬於你自己的模式。` });
  }

  try {
    const features = patterns.buildDailyFeatures(db, req.session.userId, sinceStr);
    const signals = patterns.computeSignals(features);
    const result = await patterns.generatePatternInsights(signals);
    const now = new Date().toISOString();
    db.prepare('INSERT INTO mood_patterns (user_id, signals_json, insights, generated_at) VALUES (?, ?, ?, ?)').run(
      req.session.userId,
      JSON.stringify(signals),
      result.reply,
      now
    );
    res.json({ available: true, generated: true, insights: result.reply, signals, generatedAt: now });
  } catch (e) {
    logger.error('跨模塊模式分析失敗', { error: e.message });
    res.status(502).json({ error: '分析暫時無法完成，請稍後再試', detail: e.message });
  }
});

// ---------- 安心小卡 (coping notes) ----------

router.get('/coping-notes', requireAuth, (req, res) => {
  const db = getDb();
  const rows = db
    .prepare('SELECT id, content, created_at FROM mood_coping_notes WHERE user_id = ? ORDER BY id DESC')
    .all(req.session.userId);
  res.json(rows);
});

router.post('/coping-notes', requireAuth, (req, res) => {
  const { content } = req.body || {};
  if (!content || !String(content).trim()) {
    return res.status(400).json({ error: '請提供小卡內容' });
  }
  const db = getDb();
  const now = new Date().toISOString();
  const result = db
    .prepare('INSERT INTO mood_coping_notes (user_id, content, created_at) VALUES (?, ?, ?)')
    .run(req.session.userId, String(content).trim(), now);
  res.json({ id: result.lastInsertRowid, content: String(content).trim(), created_at: now });
});

router.delete('/coping-notes/:id', requireAuth, (req, res) => {
  const db = getDb();
  db.prepare('DELETE FROM mood_coping_notes WHERE id = ? AND user_id = ?').run(req.params.id, req.session.userId);
  res.json({ ok: true });
});

// ---------- 情緒陪伴對話 (獨立於一般 AI 助理) ----------

router.get('/chat/history', requireAuth, (req, res) => {
  const db = getDb();
  res.json(fetchRecentChatHistory(db, req.session.userId, MAX_CHAT_HISTORY));
});

// 對話室的主動開場：只有在「目前沒有對話紀錄，但還留有長期記憶摘要」時才會用到
// (例如使用者之前清過對話畫面，但記憶摘要還在)，其他情況前端不會呼叫這支。
router.get('/chat/opener', requireAuth, async (req, res) => {
  const db = getDb();
  const chatCount = db.prepare('SELECT COUNT(*) as c FROM mood_chat_messages WHERE user_id = ?').get(req.session.userId).c;
  if (chatCount > 0) return res.json({ available: false });
  const memoryContext = buildMemoryContext(db, req.session.userId);
  if (!memoryContext) return res.json({ available: false });
  try {
    const result = await mood.generateChatOpener(memoryContext);
    res.json({ available: result.isConfigured, reply: result.reply });
  } catch (e) {
    res.json({ available: false });
  }
});

// ---------- AI 對話記憶強化 ----------
// 每累積 MEMORY_CHUNK_SIZE 則訊息，就把「還沒摘要過的最舊一批」濃縮成 1-2 句重點存起來，
// 之後聊天時把最近幾筆摘要一起交給 AI，讓它就算看不到很久以前的逐字稿，也還記得重點。
const MEMORY_CHUNK_SIZE = 40;
const MEMORY_RECALL_COUNT = 6;

async function maybeSummarizeMemoryChunk(db, userId) {
  const totalCount = db.prepare('SELECT COUNT(*) as c FROM mood_chat_messages WHERE user_id = ?').get(userId).c;
  if (totalCount === 0 || totalCount % MEMORY_CHUNK_SIZE !== 0) return;

  const lastMemory = db
    .prepare('SELECT chunk_to_id FROM mood_chat_memory WHERE user_id = ? ORDER BY chunk_to_id DESC LIMIT 1')
    .get(userId);
  const afterId = lastMemory ? lastMemory.chunk_to_id : 0;

  const chunk = db
    .prepare('SELECT id, role, content FROM mood_chat_messages WHERE user_id = ? AND id > ? ORDER BY id ASC LIMIT ?')
    .all(userId, afterId, MEMORY_CHUNK_SIZE);
  if (chunk.length < MEMORY_CHUNK_SIZE) return; // 保險：資料量還不夠一整個 chunk 就不摘要

  try {
    const result = await mood.summarizeChatChunk(chunk);
    if (result.isConfigured && result.reply && !result.reply.includes('無重要記憶點')) {
      db.prepare('INSERT INTO mood_chat_memory (user_id, chunk_from_id, chunk_to_id, summary, created_at) VALUES (?, ?, ?, ?, ?)').run(
        userId,
        chunk[0].id,
        chunk[chunk.length - 1].id,
        result.reply,
        new Date().toISOString()
      );
    }
  } catch (e) {
    logger.error('對話記憶摘要產生失敗', { error: e.message });
    // 記憶摘要失敗不影響這次聊天本身，安靜跳過即可
  }
}

function buildMemoryContext(db, userId) {
  const rows = db
    .prepare('SELECT summary FROM mood_chat_memory WHERE user_id = ? ORDER BY id DESC LIMIT ?')
    .all(userId, MEMORY_RECALL_COUNT)
    .reverse();
  if (!rows.length) return null;
  return rows.map((r) => `- ${r.summary}`).join('\n');
}

// 把「人際關係」模塊記錄過的人整理成簡短清單，讓心情陪伴 AI 認得使用者聊天中提到的名字，
// 不用每次都重新解釋這個人是誰。只取姓名/關係/備註，不帶互動時間等跟社交頻率有關的資訊，
// 避免 AI 拿這個去評論使用者多久沒聯絡誰。
function buildRelationshipContext(db, userId) {
  const rows = db
    .prepare('SELECT name, relation_type, note FROM relationships WHERE user_id = ? ORDER BY id DESC LIMIT 40')
    .all(userId);
  if (!rows.length) return null;
  return rows.map((r) => `- ${r.name}${r.relation_type ? `（${r.relation_type}）` : ''}${r.note ? `：${r.note}` : ''}`).join('\n');
}

router.post('/chat', requireAuth, async (req, res) => {
  const { message } = req.body || {};
  if (!message || !String(message).trim()) {
    return res.status(400).json({ error: '請提供 message' });
  }
  const db = getDb();
  const now = new Date().toISOString();
  const crisisNow = mood.detectCrisisSignal(message);
  db.prepare('INSERT INTO mood_chat_messages (user_id, role, content, flagged, created_at) VALUES (?, ?, ?, ?, ?)').run(
    req.session.userId,
    'user',
    message,
    crisisNow ? 1 : 0,
    now
  );

  const history = fetchRecentChatHistory(db, req.session.userId, MAX_CHAT_HISTORY);
  const memoryContext = buildMemoryContext(db, req.session.userId);
  const relationshipContext = buildRelationshipContext(db, req.session.userId);

  try {
    const result = await mood.chatMoodCompanion(history, memoryContext, relationshipContext);
    db.prepare('INSERT INTO mood_chat_messages (user_id, role, content, flagged, created_at) VALUES (?, ?, ?, ?, ?)').run(
      req.session.userId,
      'assistant',
      result.reply,
      result.crisisDetected ? 1 : 0,
      new Date().toISOString()
    );
    res.json(result);
    maybeSummarizeMemoryChunk(db, req.session.userId).catch(() => {});
  } catch (e) {
    logger.error('心情陪伴對話失敗', { error: e.message });
    res.status(502).json({ error: 'AI 陪伴暫時無法回應，請稍後再試', detail: e.message });
  }
});

router.delete('/chat/history', requireAuth, (req, res) => {
  const db = getDb();
  db.prepare('DELETE FROM mood_chat_messages WHERE user_id = ?').run(req.session.userId);
  res.json({ ok: true });
});

module.exports = router;
