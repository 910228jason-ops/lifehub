const { Router } = require('../mini-http');
const { getDb } = require('../services/db');
const { requireAuth } = require('../middleware/auth');

const router = Router();

router.get('/transactions', requireAuth, (req, res) => {
  const db = getDb();
  const { month } = req.query; // YYYY-MM
  let rows;
  if (month) {
    rows = db
      .prepare(`SELECT * FROM finance_transactions WHERE user_id = ? AND tx_date LIKE ? ORDER BY tx_date DESC, id DESC`)
      .all(req.session.userId, `${month}%`);
  } else {
    rows = db
      .prepare(`SELECT * FROM finance_transactions WHERE user_id = ? ORDER BY tx_date DESC, id DESC LIMIT 200`)
      .all(req.session.userId);
  }
  res.json(rows);
});

router.post('/transactions', requireAuth, (req, res) => {
  const { tx_date, type, category, amount, note } = req.body || {};
  if (!tx_date || !type || !category || amount === undefined) {
    return res.status(400).json({ error: '缺少必要欄位 (日期/類型/分類/金額)' });
  }
  if (!['income', 'expense'].includes(type)) return res.status(400).json({ error: 'type 必須是 income 或 expense' });

  const db = getDb();
  const info = db
    .prepare(
      'INSERT INTO finance_transactions (user_id, tx_date, type, category, amount, note, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)'
    )
    .run(req.session.userId, tx_date, type, category, Number(amount), note || null, new Date().toISOString());
  // 遊戲化點數：記帳一天可能記很多筆 (跟日記/心情一天一筆不同)，用「同一天只加一次」節流，
  // 避免使用者狂新增交易紀錄刷點數。
  require('../services/points').awardOncePerDay(db, req.session.userId, 1, 'finance');
  res.json({ id: info.lastInsertRowid });
});

router.delete('/transactions/:id', requireAuth, (req, res) => {
  const db = getDb();
  db.prepare('DELETE FROM finance_transactions WHERE id = ? AND user_id = ?').run(req.params.id, req.session.userId);
  res.json({ ok: true });
});

router.get('/summary', requireAuth, (req, res) => {
  const { month } = req.query;
  const db = getDb();
  const like = month ? `${month}%` : `${new Date().toISOString().slice(0, 7)}%`;

  const byCategory = db
    .prepare(
      `SELECT category, type, SUM(amount) as total FROM finance_transactions
       WHERE user_id = ? AND tx_date LIKE ? GROUP BY category, type ORDER BY total DESC`
    )
    .all(req.session.userId, like);

  const totals = db
    .prepare(
      `SELECT type, SUM(amount) as total FROM finance_transactions WHERE user_id = ? AND tx_date LIKE ? GROUP BY type`
    )
    .all(req.session.userId, like);

  const monthlyTrend = db
    .prepare(
      `SELECT substr(tx_date,1,7) as ym, type, SUM(amount) as total FROM finance_transactions
       WHERE user_id = ? GROUP BY ym, type ORDER BY ym DESC LIMIT 12`
    )
    .all(req.session.userId);

  res.json({ month: like.replace('%', ''), byCategory, totals, monthlyTrend: monthlyTrend.reverse() });
});

// 固定支出/訂閱偵測：找「備註/分類組合」在至少 2 個不同月份都出現、金額差距不大的支出，
// 整理成一份「你可能有的固定支出」清單，讓你確認、不是自動幫你下結論
router.get('/subscriptions', requireAuth, (req, res) => {
  const db = getDb();
  const rows = db
    .prepare(
      `SELECT category, note, amount, tx_date FROM finance_transactions
       WHERE user_id = ? AND type = 'expense' AND note IS NOT NULL AND trim(note) != ''
       ORDER BY tx_date ASC`
    )
    .all(req.session.userId);

  const groups = new Map();
  rows.forEach((r) => {
    const key = `${r.category}::${String(r.note).trim().toLowerCase()}`;
    if (!groups.has(key)) groups.set(key, { category: r.category, note: r.note, entries: [] });
    groups.get(key).entries.push({ amount: r.amount, ym: r.tx_date.slice(0, 7), tx_date: r.tx_date });
  });

  const candidates = [];
  groups.forEach((g) => {
    const distinctMonths = new Set(g.entries.map((e) => e.ym));
    if (distinctMonths.size < 2) return;
    const amounts = g.entries.map((e) => e.amount);
    const avg = amounts.reduce((s, a) => s + a, 0) / amounts.length;
    const maxDiff = Math.max(...amounts.map((a) => Math.abs(a - avg)));
    if (avg > 0 && maxDiff / avg > 0.15) return; // 金額差太多，可能不是同一筆固定支出
    // v0.68：#4 訂閱型帳單殭屍偵測——同一筆固定支出已經持續存在 6 個月以上，累積付出的
    // 總金額也一起算出來，提示使用者「已經付了這麼多，要不要確認一下還有沒有在用」，
    // 只是提醒不是自動判定，是否真的沒用還是要使用者自己確認。
    const monthsSeen = distinctMonths.size;
    candidates.push({
      category: g.category,
      note: g.note,
      monthsSeen,
      avgAmount: Math.round(avg),
      lastDate: g.entries[g.entries.length - 1].tx_date,
      occurrences: g.entries.length,
      totalPaid: Math.round(amounts.reduce((s, a) => s + a, 0)),
      reviewSuggested: monthsSeen >= 6,
    });
  });
  candidates.sort((a, b) => b.monthsSeen - a.monthsSeen || b.avgAmount - a.avgAmount);

  res.json({
    disclaimer: '依「備註+分類」在多個月份出現、金額相近的規則整理，是猜測不是保證，請自行確認是否為真的固定支出。',
    candidates,
    reviewSuggestedCount: candidates.filter((c) => c.reviewSuggested).length,
  });
});

// v0.68：#15 緊急預備金計算機——用最近幾個月的平均月支出估算建議的緊急預備金水位
// (一般建議 3~6 個月生活費)，並拿目前的「累計現金結餘」(跟淨資產趨勢同一份資料來源)
// 概略估算現有存款大概夠撐幾個月，不是精準的可動用現金餘額 (不含投資部位)。
router.get('/emergency-fund', requireAuth, (req, res) => {
  const db = getDb();
  const userId = req.session.userId;
  const monthly = db
    .prepare(
      `SELECT substr(tx_date,1,7) as ym,
              SUM(CASE WHEN type='income' THEN amount ELSE 0 END) as income,
              SUM(CASE WHEN type='expense' THEN amount ELSE 0 END) as expense
       FROM finance_transactions WHERE user_id = ? GROUP BY ym ORDER BY ym DESC LIMIT 6`
    )
    .all(userId);

  if (monthly.length < 2) {
    return res.json({ hasEnoughData: false, note: '記帳資料還不夠多 (至少需要 2 個月)，先多記一些交易再回來看。' });
  }

  const avgMonthlyExpense = Math.round(monthly.reduce((s, m) => s + (m.expense || 0), 0) / monthly.length);
  const suggestedMin = avgMonthlyExpense * 3;
  const suggestedMax = avgMonthlyExpense * 6;

  const allMonthly = db
    .prepare(
      `SELECT SUM(CASE WHEN type='income' THEN amount ELSE 0 END) as income,
              SUM(CASE WHEN type='expense' THEN amount ELSE 0 END) as expense
       FROM finance_transactions WHERE user_id = ?`
    )
    .get(userId);
  const currentCumulativeBalance = Math.round((allMonthly.income || 0) - (allMonthly.expense || 0));
  const monthsCovered = avgMonthlyExpense > 0 ? Math.round((currentCumulativeBalance / avgMonthlyExpense) * 10) / 10 : null;

  let statusLabel = '資料不足';
  if (monthsCovered != null) {
    if (monthsCovered >= 6) statusLabel = '充足';
    else if (monthsCovered >= 3) statusLabel = '尚可，建議再累積';
    else if (monthsCovered >= 0) statusLabel = '偏低，建議優先累積';
    else statusLabel = '目前為負值';
  }

  res.json({
    hasEnoughData: true,
    avgMonthlyExpense,
    suggestedMin,
    suggestedMax,
    currentCumulativeBalance,
    monthsCovered,
    statusLabel,
    disclaimer: '「目前現金結餘」只計算記帳收支的累加 (不含投資部位市值)，建議金額是常見的 3~6 個月生活費法則，僅供參考，實際需要視個人狀況調整。',
  });
});

// 淨資產趨勢：用每月收支計算「累計現金結餘」隨時間的變化 (不含股票等投資部位市值，
// 投資部位市值請看股票頁的庫存損益總覽，避免兩邊資料來源不一致造成混淆)
router.get('/networth-trend', requireAuth, (req, res) => {
  const db = getDb();
  const monthly = db
    .prepare(
      `SELECT substr(tx_date,1,7) as ym,
              SUM(CASE WHEN type='income' THEN amount ELSE 0 END) as income,
              SUM(CASE WHEN type='expense' THEN amount ELSE 0 END) as expense
       FROM finance_transactions WHERE user_id = ? GROUP BY ym ORDER BY ym ASC`
    )
    .all(req.session.userId);

  let cumulative = 0;
  const trend = monthly.map((m) => {
    cumulative += (m.income || 0) - (m.expense || 0);
    return { ym: m.ym, income: m.income || 0, expense: m.expense || 0, netChange: (m.income || 0) - (m.expense || 0), cumulativeBalance: cumulative };
  });

  res.json({
    disclaimer: '這裡的「累計結餘」只計算記帳收支的累加，不包含股票等投資部位的市值。',
    trend,
    currentCumulativeBalance: cumulative,
  });
});

router.get('/budgets', requireAuth, (req, res) => {
  const db = getDb();
  res.json(db.prepare('SELECT * FROM finance_budgets WHERE user_id = ?').all(req.session.userId));
});

router.put('/budgets/:category', requireAuth, (req, res) => {
  const { monthly_limit } = req.body || {};
  if (monthly_limit === undefined || monthly_limit === null || Number.isNaN(Number(monthly_limit)) || Number(monthly_limit) <= 0) {
    return res.status(400).json({ error: '請提供有效的 monthly_limit (需大於 0)' });
  }
  const db = getDb();
  const existing = db
    .prepare('SELECT id FROM finance_budgets WHERE user_id = ? AND category = ?')
    .get(req.session.userId, req.params.category);
  if (existing) {
    db.prepare('UPDATE finance_budgets SET monthly_limit = ? WHERE id = ?').run(Number(monthly_limit), existing.id);
  } else {
    db.prepare('INSERT INTO finance_budgets (user_id, category, monthly_limit) VALUES (?, ?, ?)').run(
      req.session.userId,
      req.params.category,
      Number(monthly_limit)
    );
  }
  res.json({ ok: true });
});

// ---- 財務目標 ----
// 不需要使用者手動記錄「存了多少」，而是用目標設立日之後的實際淨儲蓄 (收入-支出) 自動推算進度，
// 並用過去的平均月淨儲蓄速度，推算大概何時能達成。

function computeGoalProgress(db, userId, goal) {
  const row = db
    .prepare(
      `SELECT
         COALESCE(SUM(CASE WHEN type = 'income' THEN amount ELSE 0 END), 0) as income,
         COALESCE(SUM(CASE WHEN type = 'expense' THEN amount ELSE 0 END), 0) as expense
       FROM finance_transactions WHERE user_id = ? AND tx_date >= ?`
    )
    .get(userId, goal.start_date);
  const netSaved = Math.round((row.income - row.expense) * 100) / 100;
  const progressPct = goal.target_amount > 0 ? Math.max(0, Math.min(100, Math.round((netSaved / goal.target_amount) * 1000) / 10)) : 0;

  // 用「目標設立至今」的月數，算平均每月淨儲蓄速度，藉此推算大約何時能達成
  const start = new Date(goal.start_date + 'T00:00:00Z');
  const now = new Date();
  const monthsElapsed = Math.max(1 / 30, (now - start) / (1000 * 60 * 60 * 24 * 30));
  const monthlyRate = netSaved / monthsElapsed;

  let projectedDate = null;
  let onTrack = null;
  const remaining = goal.target_amount - netSaved;
  if (remaining <= 0) {
    projectedDate = 'reached';
  } else if (monthlyRate > 0.01) {
    const monthsNeeded = remaining / monthlyRate;
    const projected = new Date(now.getTime() + monthsNeeded * 30 * 24 * 60 * 60 * 1000);
    projectedDate = projected.toISOString().slice(0, 10);
    if (goal.target_date) {
      onTrack = projectedDate <= goal.target_date;
    }
  }

  // v0.68：#5 財務目標達成率預測——除了原本「用全期間平均月儲蓄速度」推算的 projectedDate，
  // 再額外算「最近 3 個月的淨儲蓄速度」，兩者一起看可以看出「最近有沒有變快/變慢」，
  // 並給一個簡單的信心標籤 (不是機率模型，只是把兩個速度的落差轉成好懂的文字)。
  const recent3Start = new Date();
  recent3Start.setMonth(recent3Start.getMonth() - 3);
  const recent3StartStr = recent3Start.toISOString().slice(0, 10);
  const recentRow = db
    .prepare(
      `SELECT COALESCE(SUM(CASE WHEN type = 'income' THEN amount ELSE 0 END), 0) as income,
              COALESCE(SUM(CASE WHEN type = 'expense' THEN amount ELSE 0 END), 0) as expense
       FROM finance_transactions WHERE user_id = ? AND tx_date >= ?`
    )
    .get(userId, recent3StartStr > goal.start_date ? recent3StartStr : goal.start_date);
  const recentSpan = Math.max(1 / 30, (now - new Date(Math.max(new Date(recent3StartStr).getTime(), start.getTime()))) / (1000 * 60 * 60 * 24 * 30));
  const recentMonthlyRate = (recentRow.income - recentRow.expense) / recentSpan;

  let confidenceLabel = '資料不足';
  if (remaining <= 0) {
    confidenceLabel = '已達成';
  } else if (monthsElapsed >= 1) {
    if (recentMonthlyRate >= monthlyRate * 1.1) confidenceLabel = '最近存錢速度加快，達成機會提升';
    else if (recentMonthlyRate <= monthlyRate * 0.5) confidenceLabel = '最近存錢速度變慢，可能需要調整';
    else confidenceLabel = '存錢速度大致穩定';
  }
  const requiredMonthlyRateForTargetDate = goal.target_date && remaining > 0
    ? (() => {
        const monthsLeft = Math.max(1 / 30, (new Date(goal.target_date + 'T00:00:00Z') - now) / (1000 * 60 * 60 * 24 * 30));
        return Math.round((remaining / monthsLeft) * 100) / 100;
      })()
    : null;

  return {
    ...goal, netSaved, progressPct, monthlyRate: Math.round(monthlyRate * 100) / 100, projectedDate, onTrack,
    recentMonthlyRate: Math.round(recentMonthlyRate * 100) / 100,
    confidenceLabel,
    requiredMonthlyRateForTargetDate,
  };
}

router.get('/goals', requireAuth, (req, res) => {
  const db = getDb();
  const goals = db
    .prepare('SELECT * FROM finance_goals WHERE user_id = ? AND archived = 0 ORDER BY created_at DESC')
    .all(req.session.userId);
  res.json(goals.map((g) => computeGoalProgress(db, req.session.userId, g)));
});

router.post('/goals', requireAuth, (req, res) => {
  const { name, target_amount, target_date, start_date } = req.body || {};
  if (!name || !target_amount || Number(target_amount) <= 0) {
    return res.status(400).json({ error: '請提供目標名稱與大於 0 的目標金額' });
  }
  const db = getDb();
  const info = db
    .prepare(
      'INSERT INTO finance_goals (user_id, name, target_amount, target_date, start_date, archived, created_at) VALUES (?, ?, ?, ?, ?, 0, ?)'
    )
    .run(
      req.session.userId,
      name,
      Number(target_amount),
      target_date || null,
      start_date || new Date().toISOString().slice(0, 10),
      new Date().toISOString()
    );
  res.json({ id: info.lastInsertRowid });
});

router.delete('/goals/:id', requireAuth, (req, res) => {
  const db = getDb();
  db.prepare('UPDATE finance_goals SET archived = 1 WHERE id = ? AND user_id = ?').run(req.params.id, req.session.userId);
  res.json({ ok: true });
});

// computeGoalProgress 額外匯出給 wishlist.js 用 (#12 願望清單串連財務目標)，
// 不用另外複製一份幾乎一樣的預測邏輯。
module.exports = router;
module.exports.computeGoalProgress = computeGoalProgress;
