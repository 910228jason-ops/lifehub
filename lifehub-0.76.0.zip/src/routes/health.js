const { Router } = require('../mini-http');
const { getDb } = require('../services/db');
const { requireAuth } = require('../middleware/auth');

const router = Router();

function todayStr() { return new Date().toISOString().slice(0, 10); }

// ---------- 睡眠 ----------

router.get('/sleep', requireAuth, (req, res) => {
  const db = getDb();
  const { from, to } = req.query;
  let rows;
  if (from && to) {
    rows = db.prepare('SELECT * FROM health_sleep_entries WHERE user_id = ? AND entry_date BETWEEN ? AND ? ORDER BY entry_date ASC').all(req.session.userId, from, to);
  } else {
    rows = db.prepare('SELECT * FROM health_sleep_entries WHERE user_id = ? ORDER BY entry_date DESC LIMIT 60').all(req.session.userId);
  }
  res.json(rows);
});

router.put('/sleep/:date', requireAuth, (req, res) => {
  const { date } = req.params;
  const { hours, note } = req.body || {};
  const hoursNum = Number(hours);
  if (!date || Number.isNaN(hoursNum) || hoursNum < 0 || hoursNum > 24) {
    return res.status(400).json({ error: '請提供有效的日期與 0-24 之間的睡眠時數' });
  }
  const db = getDb();
  const now = new Date().toISOString();
  db.prepare(
    `INSERT INTO health_sleep_entries (user_id, entry_date, hours, note, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?)
     ON CONFLICT(user_id, entry_date) DO UPDATE SET hours = excluded.hours, note = excluded.note, updated_at = excluded.updated_at`
  ).run(req.session.userId, date, hoursNum, note || null, now, now);
  res.json({ ok: true });
});

router.get('/sleep/summary', requireAuth, (req, res) => {
  const db = getDb();
  const n = Math.min(Math.max(Number(req.query.days) || 30, 1), 180);
  const since = new Date();
  since.setDate(since.getDate() - n);
  const sinceStr = since.toISOString().slice(0, 10);
  const rows = db.prepare('SELECT entry_date, hours FROM health_sleep_entries WHERE user_id = ? AND entry_date >= ? ORDER BY entry_date ASC').all(req.session.userId, sinceStr);
  const avg = rows.length ? Math.round((rows.reduce((s, r) => s + r.hours, 0) / rows.length) * 10) / 10 : null;
  res.json({ series: rows, average: avg, count: rows.length });
});

// v0.68：#1 睡眠與心情關聯分析——把「前一晚的睡眠時數」跟「隔天的心情分數」配對起來看，
// 不是同一天的睡眠跟心情比 (睡眠通常是記錄「昨晚睡了幾小時」，會影響的是「今天」的心情，
// 同一天比對容易誤導)。用簡單分組平均 (睡足 7 小時以上 vs 不足) 呈現，不做正式的統計顯著性
// 檢定 (資料量通常不夠)，只是提供一個「你自己觀察到的傾向」，並附上樣本數方便自行判斷可信度。
router.get('/sleep/mood-correlation', requireAuth, (req, res) => {
  const db = getDb();
  const userId = req.session.userId;
  const n = Math.min(Math.max(Number(req.query.days) || 60, 1), 180);
  const since = new Date();
  since.setDate(since.getDate() - n);
  const sinceStr = since.toISOString().slice(0, 10);

  const sleepRows = db.prepare('SELECT entry_date, hours FROM health_sleep_entries WHERE user_id = ? AND entry_date >= ?').all(userId, sinceStr);
  if (sleepRows.length < 5) {
    return res.json({ hasEnoughData: false, sampleSize: sleepRows.length, note: '睡眠紀錄還不夠多 (至少需要 5 筆)，先多記錄幾天再回來看。' });
  }
  const moodRows = db.prepare('SELECT entry_date, score FROM mood_entries WHERE user_id = ? AND entry_date >= ?').all(userId, sinceStr);
  const moodByDate = new Map(moodRows.map((m) => [m.entry_date, m.score]));

  // 睡眠日期 D 配對「隔天」(D+1) 的心情分數
  const pairs = [];
  sleepRows.forEach((s) => {
    const next = new Date(s.entry_date + 'T00:00:00Z');
    next.setUTCDate(next.getUTCDate() + 1);
    const nextDateStr = next.toISOString().slice(0, 10);
    const mood = moodByDate.get(nextDateStr);
    if (mood != null) pairs.push({ sleepDate: s.entry_date, hours: s.hours, nextMood: mood });
  });

  if (pairs.length < 5) {
    return res.json({ hasEnoughData: false, sampleSize: pairs.length, note: '睡眠跟隔天心情都有記錄的天數還不夠多 (至少需要 5 組)，先多記錄幾天再回來看。' });
  }

  const wellRested = pairs.filter((p) => p.hours >= 7);
  const shortSleep = pairs.filter((p) => p.hours < 7);
  const avg = (arr) => (arr.length ? Math.round((arr.reduce((s, p) => s + p.nextMood, 0) / arr.length) * 10) / 10 : null);
  const wellRestedAvg = avg(wellRested);
  const shortSleepAvg = avg(shortSleep);

  // 簡易皮爾森相關係數 (睡眠時數 vs 隔天心情分數)，四捨五入到小數點兩位，正值代表「睡越多隔天心情傾向越好」
  const meanHours = pairs.reduce((s, p) => s + p.hours, 0) / pairs.length;
  const meanMood = pairs.reduce((s, p) => s + p.nextMood, 0) / pairs.length;
  let cov = 0, varHours = 0, varMood = 0;
  pairs.forEach((p) => {
    cov += (p.hours - meanHours) * (p.nextMood - meanMood);
    varHours += (p.hours - meanHours) ** 2;
    varMood += (p.nextMood - meanMood) ** 2;
  });
  const correlation = varHours > 0 && varMood > 0 ? Math.round((cov / Math.sqrt(varHours * varMood)) * 100) / 100 : null;

  res.json({
    hasEnoughData: true,
    sampleSize: pairs.length,
    wellRestedCount: wellRested.length,
    shortSleepCount: shortSleep.length,
    wellRestedAvgNextMood: wellRestedAvg,
    shortSleepAvgNextMood: shortSleepAvg,
    correlation,
    disclaimer: '依你自己的紀錄做簡單統計整理，是觀察不是醫療診斷，樣本數不多時僅供參考。',
  });
});

// ---------- 服藥 ----------

router.get('/meds', requireAuth, (req, res) => {
  const db = getDb();
  const rows = db.prepare('SELECT * FROM health_meds WHERE user_id = ? AND active = 1 ORDER BY id ASC').all(req.session.userId);
  res.json(rows);
});

router.post('/meds', requireAuth, (req, res) => {
  const { name, dose, scheduleTime } = req.body || {};
  if (!name || !String(name).trim()) return res.status(400).json({ error: '請提供藥品名稱' });
  const db = getDb();
  const now = new Date().toISOString();
  const result = db.prepare('INSERT INTO health_meds (user_id, name, dose, schedule_time, active, created_at) VALUES (?, ?, ?, ?, 1, ?)').run(
    req.session.userId, String(name).trim(), dose || null, scheduleTime || null, now
  );
  res.json({ id: result.lastInsertRowid, ok: true });
});

router.delete('/meds/:id', requireAuth, (req, res) => {
  const db = getDb();
  db.prepare('UPDATE health_meds SET active = 0 WHERE id = ? AND user_id = ?').run(req.params.id, req.session.userId);
  res.json({ ok: true });
});

// 當天服藥打勾：用 (med_id, log_date) 當 key，重複打同一天會直接覆蓋，不會產生多筆
router.put('/meds/:id/log', requireAuth, (req, res) => {
  const db = getDb();
  const med = db.prepare('SELECT id FROM health_meds WHERE id = ? AND user_id = ?').get(req.params.id, req.session.userId);
  if (!med) return res.status(404).json({ error: '找不到這筆藥品' });
  const date = (req.body && req.body.date) || todayStr();
  const taken = req.body && req.body.taken != null ? (req.body.taken ? 1 : 0) : 1;
  const now = new Date().toISOString();
  db.prepare(
    `INSERT INTO health_med_logs (user_id, med_id, log_date, taken, created_at) VALUES (?, ?, ?, ?, ?)
     ON CONFLICT(med_id, log_date) DO UPDATE SET taken = excluded.taken`
  ).run(req.session.userId, req.params.id, date, taken, now);
  res.json({ ok: true });
});

router.get('/meds/today', requireAuth, (req, res) => {
  const db = getDb();
  const date = req.query.date || todayStr();
  const meds = db.prepare('SELECT * FROM health_meds WHERE user_id = ? AND active = 1 ORDER BY id ASC').all(req.session.userId);
  const logs = db.prepare('SELECT med_id, taken FROM health_med_logs WHERE user_id = ? AND log_date = ?').all(req.session.userId, date);
  const takenByMed = {};
  logs.forEach((l) => { takenByMed[l.med_id] = !!l.taken; });
  res.json(meds.map((m) => ({ ...m, takenToday: !!takenByMed[m.id] })));
});

// v0.68：#2 服藥遵從率與漏服模式——統計每顆藥最近 N 天的「有打勾吃過/總天數」遵從率，
// 並找出漏服最常發生在星期幾 (只看藥品啟用之後、且已經過去的每一天，沒打勾就算漏服)。
router.get('/meds/adherence', requireAuth, (req, res) => {
  const db = getDb();
  const userId = req.session.userId;
  const n = Math.min(Math.max(Number(req.query.days) || 30, 1), 180);
  const meds = db.prepare('SELECT * FROM health_meds WHERE user_id = ? AND active = 1 ORDER BY id ASC').all(userId);
  const WEEKDAY_LABEL = ['週日', '週一', '週二', '週三', '週四', '週五', '週六'];

  const result = meds.map((med) => {
    const startDate = new Date(Math.max(new Date(med.created_at).getTime(), Date.now() - n * 86400000));
    const today = new Date();
    const logs = db.prepare('SELECT log_date, taken FROM health_med_logs WHERE med_id = ? AND user_id = ?').all(med.id, userId);
    const takenDates = new Set(logs.filter((l) => l.taken).map((l) => l.log_date));

    const missedByWeekday = [0, 0, 0, 0, 0, 0, 0];
    const totalByWeekday = [0, 0, 0, 0, 0, 0, 0];
    let totalDays = 0, takenDays = 0;
    const cursor = new Date(startDate);
    cursor.setHours(0, 0, 0, 0);
    const todayMid = new Date(today); todayMid.setHours(0, 0, 0, 0);
    let guard = 0;
    while (cursor <= todayMid && guard < 200) {
      guard++;
      const dateStr = cursor.toISOString().slice(0, 10);
      const wd = cursor.getDay();
      totalDays++;
      totalByWeekday[wd]++;
      if (takenDates.has(dateStr)) { takenDays++; } else { missedByWeekday[wd]++; }
      cursor.setDate(cursor.getDate() + 1);
    }

    const adherenceRate = totalDays > 0 ? Math.round((takenDays / totalDays) * 1000) / 10 : null;
    let worstWeekday = null;
    if (totalDays >= 7) {
      let worstIdx = -1, worstRate = 1;
      for (let i = 0; i < 7; i++) {
        if (totalByWeekday[i] < 2) continue; // 樣本太少不列入比較
        const rate = 1 - missedByWeekday[i] / totalByWeekday[i];
        if (rate < worstRate) { worstRate = rate; worstIdx = i; }
      }
      if (worstIdx >= 0 && worstRate < (adherenceRate != null ? adherenceRate / 100 : 1)) {
        worstWeekday = { label: WEEKDAY_LABEL[worstIdx], missRate: Math.round((1 - worstRate) * 1000) / 10 };
      }
    }

    return {
      medId: med.id, name: med.name, dose: med.dose,
      totalDays, takenDays, adherenceRate, worstWeekday,
    };
  });

  res.json({ meds: result, disclaimer: '依你自己勾選的服藥紀錄統計，沒打勾不代表一定沒吃，僅供自我觀察參考。' });
});

module.exports = router;
