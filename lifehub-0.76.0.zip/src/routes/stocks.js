const { Router } = require('../mini-http');
const twse = require('../services/twse');
const marketExtras = require('../services/marketExtras');
const { requireAuth } = require('../middleware/auth');
const { getDb } = require('../services/db');
const logger = require('../services/logger');

const router = Router();

// 讓使用者可以直接輸入公司名稱 (例如「華邦電」) 或代號 (例如「2344」) 來新增自選股，
// 前端會先呼叫這支 API 解析成正確代號，再存進自選股清單。
router.get('/resolve/:query', requireAuth, async (req, res) => {
  try {
    const result = await twse.resolveCode(req.params.query);
    if (!result) return res.status(404).json({ error: '查無此股票代號或名稱 (僅涵蓋上市個股)' });
    res.json(result);
  } catch (e) {
    logger.error('股票代號解析失敗', { error: e.message });
    res.status(502).json({ error: '目前無法查詢，請稍後再試', detail: e.message });
  }
});

router.get('/quote/:code', requireAuth, async (req, res) => {
  try {
    const quote = await twse.getQuote(req.params.code);
    if (!quote) return res.status(404).json({ error: '查無此股票代號 (僅涵蓋上市個股)' });
    res.json(quote);
  } catch (e) {
    logger.error('取得股價失敗', { error: e.message });
    res.status(502).json({ error: '目前無法取得證交所資料，請稍後再試', detail: e.message });
  }
});

router.get('/institutional/:code', requireAuth, async (req, res) => {
  try {
    const days = Math.min(30, Number(req.query.days) || 10);
    const trend = await twse.getInstitutionalTrend(req.params.code, days);
    const signal = twse.computeSignal(trend);
    res.json({ code: req.params.code, trend, signal, disclaimer: '本資訊僅整理公開法人買賣超資料，屬統計參考，不構成投資建議。' });
  } catch (e) {
    logger.error('取得法人買賣超失敗', { error: e.message });
    res.status(502).json({ error: '目前無法取得法人買賣超資料，請稍後再試', detail: e.message });
  }
});

// 均線描述性指標 (非預測) — 見 twse.js 註解說明為什麼不做「未來走勢預測」
router.get('/indicator/:code', requireAuth, async (req, res) => {
  try {
    const history = await twse.getStockHistory(req.params.code);
    const indicator = twse.computeMovingAverageTrend(history);
    res.json({ code: req.params.code, historyPoints: history.length, indicator });
  } catch (e) {
    logger.error('取得均線指標失敗', { error: e.message });
    res.status(502).json({ error: '目前無法取得歷史股價資料，請稍後再試', detail: e.message });
  }
});

// 個股估值 (本益比/殖利率/股價淨值比) — 證交所官方 OpenAPI
router.get('/valuation/:code', requireAuth, async (req, res) => {
  try {
    const v = await twse.getValuation(req.params.code);
    if (!v) return res.status(404).json({ error: '查無此股票的估值資料' });
    res.json(v);
  } catch (e) {
    logger.error('取得估值資料失敗', { error: e.message });
    res.status(502).json({ error: '目前無法取得估值資料，請稍後再試', detail: e.message });
  }
});

// 近 40 個交易日收盤價 + MA5/MA20 (畫走勢圖用)
router.get('/history/:code', requireAuth, async (req, res) => {
  try {
    const points = await twse.getHistoryWithMA(req.params.code);
    res.json({ code: req.params.code, points });
  } catch (e) {
    logger.error('取得歷史股價失敗', { error: e.message });
    res.status(502).json({ error: '目前無法取得歷史股價資料，請稍後再試', detail: e.message });
  }
});

// 台股加權指數 (大盤) — 證交所官方 OpenAPI
router.get('/index/taiex', requireAuth, async (req, res) => {
  try {
    res.json(await twse.getTaiex());
  } catch (e) {
    res.status(502).json({ error: '目前無法取得加權指數資料，請稍後再試', detail: e.message });
  }
});

// 費城半導體指數 (SOX) — 非官方資料源，見 marketExtras.js 註解
router.get('/index/sox', requireAuth, async (req, res) => {
  try {
    res.json(await marketExtras.getSoxIndex());
  } catch (e) {
    res.status(502).json({ error: '目前無法取得 SOX 指數資料 (非官方資料源，可能暫時失效)', detail: e.message });
  }
});

// 更多技術指標 (RSI/KD/MACD/成交量趨勢) 一次打包回傳，畫面上放一起比較不用分開等好幾次。
router.get('/technicals/:code', requireAuth, async (req, res) => {
  try {
    const history = await twse.getStockHistory(req.params.code);
    res.json({
      code: req.params.code,
      historyPoints: history.length,
      rsi: twse.computeRSI(history),
      kd: twse.computeKD(history),
      macd: twse.computeMACD(history),
      volumeTrend: twse.computeVolumeTrend(history),
      disclaimer: '以上皆為描述近期價格/量能相對位置的統計指標，不是價格預測，也不構成投資建議，過去表現不代表未來結果。',
    });
  } catch (e) {
    logger.error('取得技術指標失敗', { error: e.message });
    res.status(502).json({ error: '目前無法取得歷史股價資料，請稍後再試', detail: e.message });
  }
});

// 法人買賣力道是否收斂/放大 (「量有沒有縮」)
router.get('/institutional/:code/volume-trend', requireAuth, async (req, res) => {
  try {
    const trend = await twse.getInstitutionalTrend(req.params.code, 10);
    res.json({ code: req.params.code, ...twse.computeInstitutionalVolumeTrend(trend) });
  } catch (e) {
    res.status(502).json({ error: '目前無法取得法人力道趨勢，請稍後再試', detail: e.message });
  }
});

// ---------- 簡易選股/篩選 ----------
// query: sortBy(dividendYield|peRatio|pbRatio|change|tradeVolume), order(asc|desc), minDividendYield, maxPE, limit
router.get('/screener', requireAuth, async (req, res) => {
  try {
    const { sortBy, order, minDividendYield, maxPE, limit } = req.query;
    const result = await twse.screenStocks({
      sortBy,
      order,
      minDividendYield: minDividendYield !== undefined ? Number(minDividendYield) : undefined,
      maxPE: maxPE !== undefined ? Number(maxPE) : undefined,
      limit: limit !== undefined ? Number(limit) : undefined,
    });
    res.json(result);
  } catch (e) {
    logger.error('簡易選股失敗', { error: e.message });
    res.status(502).json({ error: '目前無法取得全市場估值資料，請稍後再試', detail: e.message });
  }
});

// ---------- 我的持股 (庫存損益追蹤) ----------
// 用「移動加權平均成本法」在這裡計算，不額外存衍生欄位，資料來源永遠是交易紀錄本身。
function computePositionsFromTransactions(transactions) {
  const byCode = {};
  [...transactions]
    .sort((a, b) => (a.trade_date < b.trade_date ? -1 : a.trade_date > b.trade_date ? 1 : a.id - b.id))
    .forEach((t) => {
      if (!byCode[t.code]) byCode[t.code] = { code: t.code, name: t.name, shares: 0, costBasis: 0, realizedPL: 0 };
      const pos = byCode[t.code];
      if (t.side === 'buy') {
        pos.costBasis += t.shares * t.price + t.fee;
        pos.shares += t.shares;
        pos.name = t.name || pos.name;
      } else {
        const avgCost = pos.shares > 0 ? pos.costBasis / pos.shares : 0;
        const sellShares = Math.min(t.shares, pos.shares);
        pos.realizedPL += sellShares * (t.price - avgCost) - t.fee - t.tax;
        pos.costBasis -= sellShares * avgCost;
        pos.shares -= sellShares;
      }
    });
  return Object.values(byCode);
}

router.get('/portfolio', requireAuth, async (req, res) => {
  const db = getDb();
  try {
    const transactions = db.prepare('SELECT * FROM stock_transactions WHERE user_id = ? ORDER BY trade_date ASC, id ASC').all(req.session.userId);
    const positions = computePositionsFromTransactions(transactions);
    const dividendRows = db.prepare('SELECT code, SUM(amount) as total FROM stock_dividends WHERE user_id = ? GROUP BY code').all(req.session.userId);
    const dividendByCode = {};
    dividendRows.forEach((r) => { dividendByCode[r.code] = r.total; });

    const withQuotes = await Promise.all(
      positions.map(async (p) => {
        let currentPrice = null;
        try {
          const q = await twse.getQuote(p.code);
          currentPrice = q ? q.closingPrice : null;
        } catch (e) { /* 個股報價暫時查不到就先跳過，不影響整體列表 */ }
        const avgCost = p.shares > 0 ? Math.round((p.costBasis / p.shares) * 100) / 100 : 0;
        const marketValue = currentPrice != null ? Math.round(currentPrice * p.shares) : null;
        const unrealizedPL = currentPrice != null && p.shares > 0 ? Math.round((currentPrice - avgCost) * p.shares) : null;
        return {
          code: p.code,
          name: p.name,
          shares: p.shares,
          avgCost,
          currentPrice,
          marketValue,
          unrealizedPL,
          realizedPL: Math.round(p.realizedPL),
          dividendIncome: Math.round(dividendByCode[p.code] || 0),
        };
      })
    );

    // 只要有任一檔位查不到即時報價，市值/未實現損益的「總計」就不夠準了，
    // 用 null 明確表示「資料不完整」，前端就不會顯示一個看似精確、其實少算的數字。
    const anyQuoteMissing = withQuotes.some((p) => p.shares > 0 && p.currentPrice == null);
    const totalMarketValue = anyQuoteMissing ? null : withQuotes.reduce((s, p) => s + (p.marketValue || 0), 0);
    const totalUnrealizedPL = anyQuoteMissing ? null : withQuotes.reduce((s, p) => s + (p.unrealizedPL || 0), 0);
    const totalRealizedPL = withQuotes.reduce((s, p) => s + p.realizedPL, 0);
    const totalDividendIncome = withQuotes.reduce((s, p) => s + p.dividendIncome, 0);

    res.json({
      positions: withQuotes.filter((p) => p.shares > 0 || p.realizedPL !== 0 || p.dividendIncome !== 0),
      totals: { totalMarketValue, totalUnrealizedPL, totalRealizedPL, totalDividendIncome },
      disclaimer: '損益採移動加權平均成本法計算，市值以最近一個交易日收盤價估算 (非即時報價)，僅供個人記錄參考，實際課稅/成本計算請以券商對帳單為準。',
    });
  } catch (e) {
    logger.error('取得持股損益失敗', { error: e.message });
    res.status(502).json({ error: '目前無法計算持股損益，請稍後再試', detail: e.message });
  }
});

router.get('/transactions', requireAuth, (req, res) => {
  const db = getDb();
  const { code } = req.query;
  const rows = code
    ? db.prepare('SELECT * FROM stock_transactions WHERE user_id = ? AND code = ? ORDER BY trade_date DESC, id DESC').all(req.session.userId, code)
    : db.prepare('SELECT * FROM stock_transactions WHERE user_id = ? ORDER BY trade_date DESC, id DESC LIMIT 200').all(req.session.userId);
  res.json(rows);
});

router.post('/transactions', requireAuth, (req, res) => {
  const { code, name, tradeDate, side, shares, price, fee, tax, note } = req.body || {};
  if (!code || !tradeDate || !['buy', 'sell'].includes(side) || !shares || Number(shares) <= 0 || price == null || Number(price) < 0) {
    return res.status(400).json({ error: '請提供股票代號、日期、買賣別、股數 (大於0)、價格' });
  }
  const db = getDb();
  const now = new Date().toISOString();
  const info = db
    .prepare('INSERT INTO stock_transactions (user_id, code, name, trade_date, side, shares, price, fee, tax, note, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
    .run(req.session.userId, String(code).trim(), name || null, tradeDate, side, Number(shares), Number(price), Number(fee) || 0, Number(tax) || 0, note || null, now);
  res.json({ id: info.lastInsertRowid, ok: true });
});

router.delete('/transactions/:id', requireAuth, (req, res) => {
  const db = getDb();
  db.prepare('DELETE FROM stock_transactions WHERE id = ? AND user_id = ?').run(req.params.id, req.session.userId);
  res.json({ ok: true });
});

// v0.68：#3 股票交易時機 vs 三大法人動向比對——對每一筆買/賣交易，查當天三大法人買賣超的
// 方向，比對使用者是「跟著法人做同一個方向」還是「跟法人反著做」。只看近 90 天內的交易
// (證交所公開資料/快取通常也只涵蓋近期，太久以前的個別交易日資料查詢意義不大)，最多查
// 最近 30 筆，避免逐筆序列打證交所 API 太慢——每個日期各自有快取，同一天有多筆交易時也
// 只會真的打一次。
router.get('/institutional-alignment', requireAuth, async (req, res) => {
  const db = getDb();
  const since = new Date();
  since.setDate(since.getDate() - 90);
  const sinceStr = since.toISOString().slice(0, 10);
  const txs = db
    .prepare(
      `SELECT id, code, name, trade_date, side, shares FROM stock_transactions
       WHERE user_id = ? AND trade_date >= ? ORDER BY trade_date DESC, id DESC LIMIT 30`
    )
    .all(req.session.userId, sinceStr);

  if (!txs.length) {
    return res.json({ hasEnoughData: false, note: '近 90 天沒有交易紀錄，或還沒有記錄任何股票交易。' });
  }

  const uniqueDates = [...new Set(txs.map((t) => t.trade_date.replace(/-/g, '')))];
  const settled = await Promise.allSettled(uniqueDates.map((d) => twse.getInstitutionalDaily(d)));
  const rowsByDate = new Map();
  settled.forEach((outcome, i) => {
    if (outcome.status === 'fulfilled') rowsByDate.set(uniqueDates[i], outcome.value.rows);
  });

  const results = [];
  txs.forEach((t) => {
    const dateKey = t.trade_date.replace(/-/g, '');
    const dayRows = rowsByDate.get(dateKey);
    if (!dayRows) return; // 該日資料查不到 (非交易日/證交所暫時無資料)，跳過不計入統計
    const instRow = dayRows.find((r) => r.code === t.code);
    if (!instRow || instRow.netBuySell === 0) return; // 法人當天沒有明顯買賣超方向，不列入比對
    const institutionalDirection = instRow.netBuySell > 0 ? 'buy' : 'sell';
    const aligned = institutionalDirection === t.side;
    results.push({
      code: t.code, name: t.name, tradeDate: t.trade_date, side: t.side,
      institutionalDirection, institutionalNetBuySell: instRow.netBuySell, aligned,
    });
  });

  if (!results.length) {
    return res.json({ hasEnoughData: false, note: '近期交易當天的法人買賣超資料還無法比對 (可能是非交易日或資料尚未提供)。' });
  }

  const alignedCount = results.filter((r) => r.aligned).length;
  res.json({
    hasEnoughData: true,
    sampleSize: results.length,
    alignedCount,
    alignedRate: Math.round((alignedCount / results.length) * 1000) / 10,
    details: results,
    disclaimer: '僅比對交易當天三大法人整體買賣超方向與你的交易方向是否一致，屬統計整理，不構成投資建議，過去的一致/不一致不代表未來績效。',
  });
});

// ---------- 股利紀錄 ----------
router.get('/dividends', requireAuth, (req, res) => {
  const db = getDb();
  res.json(db.prepare('SELECT * FROM stock_dividends WHERE user_id = ? ORDER BY pay_date DESC LIMIT 200').all(req.session.userId));
});

router.post('/dividends', requireAuth, (req, res) => {
  const { code, name, payDate, amount, note } = req.body || {};
  if (!code || !payDate || amount == null || Number(amount) < 0) {
    return res.status(400).json({ error: '請提供股票代號、發放日期、金額' });
  }
  const db = getDb();
  const now = new Date().toISOString();
  const info = db
    .prepare('INSERT INTO stock_dividends (user_id, code, name, pay_date, amount, note, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)')
    .run(req.session.userId, String(code).trim(), name || null, payDate, Number(amount), note || null, now);
  res.json({ id: info.lastInsertRowid, ok: true });
});

router.delete('/dividends/:id', requireAuth, (req, res) => {
  const db = getDb();
  db.prepare('DELETE FROM stock_dividends WHERE id = ? AND user_id = ?').run(req.params.id, req.session.userId);
  res.json({ ok: true });
});

// ---------- 到價提醒 ----------
// 沒有背景推播機制，所以是「打開 App / 首頁摘要時檢查一次」的模式，不是即時通知。
router.get('/alerts', requireAuth, (req, res) => {
  const db = getDb();
  res.json(db.prepare('SELECT * FROM stock_price_alerts WHERE user_id = ? ORDER BY created_at DESC').all(req.session.userId));
});

router.post('/alerts', requireAuth, (req, res) => {
  const { code, name, targetPrice, direction } = req.body || {};
  if (!code || targetPrice == null || !['above', 'below'].includes(direction)) {
    return res.status(400).json({ error: '請提供股票代號、目標價、方向 (above/below)' });
  }
  const db = getDb();
  const now = new Date().toISOString();
  const info = db
    .prepare('INSERT INTO stock_price_alerts (user_id, code, name, target_price, direction, active, created_at) VALUES (?, ?, ?, ?, ?, 1, ?)')
    .run(req.session.userId, String(code).trim(), name || null, Number(targetPrice), direction, now);
  res.json({ id: info.lastInsertRowid, ok: true });
});

router.delete('/alerts/:id', requireAuth, (req, res) => {
  const db = getDb();
  db.prepare('DELETE FROM stock_price_alerts WHERE id = ? AND user_id = ?').run(req.params.id, req.session.userId);
  res.json({ ok: true });
});

// 檢查目前所有「還在生效中」的提醒是否已經到價；到價的話標記 triggered_at 並回傳給前端顯示，
// 不會自動關閉 (使用者自己確認後可以刪除或之後再加一個「重設」功能)。
router.get('/alerts/check', requireAuth, async (req, res) => {
  const db = getDb();
  try {
    const alerts = db.prepare('SELECT * FROM stock_price_alerts WHERE user_id = ? AND active = 1').all(req.session.userId);
    const triggered = [];
    for (const a of alerts) {
      let quote;
      try { quote = await twse.getQuote(a.code); } catch (e) { continue; }
      if (!quote || quote.closingPrice == null) continue;
      const hit = a.direction === 'above' ? quote.closingPrice >= a.target_price : quote.closingPrice <= a.target_price;
      if (hit) {
        db.prepare('UPDATE stock_price_alerts SET triggered_at = ? WHERE id = ?').run(new Date().toISOString(), a.id);
        triggered.push({ ...a, currentPrice: quote.closingPrice });
      }
    }
    res.json({ triggered });
  } catch (e) {
    res.status(502).json({ error: '檢查到價提醒時發生問題，請稍後再試', detail: e.message });
  }
});

// 相關新聞 (Yahoo奇摩股市官方 RSS)
router.get('/news/:code', requireAuth, async (req, res) => {
  try {
    const quote = await twse.getQuote(req.params.code).catch(() => null);
    const keyword = quote ? quote.name : null;
    const items = await marketExtras.getMarketNews(keyword);
    res.json({ code: req.params.code, keyword, items });
  } catch (e) {
    res.status(502).json({ error: '目前無法取得新聞資料', detail: e.message });
  }
});

module.exports = router;
