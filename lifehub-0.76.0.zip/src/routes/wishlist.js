// 願望清單 (v0.47)。個人清單：想要的東西、優先度、價格、連結，完成 (買到/實現了) 就打勾，
// 不會被刪除、只是排到清單最後面方便回顧。
//
// v0.54：
//   - 比照獎勵頁面 (v0.52) 的「共同建立」模式，願望清單項目也可以選擇跟已連結的家人/伴侶
//     共同建立、共用同一份清單 (link_id 有值)，不再只能是私人清單。
//   - 新增「轉換成獎勵」：把一個願望項目直接變成點數獎勵目錄裡的一個獎勵項目，用點數兌換，
//     把「想要的東西」跟「集點的動力」接起來。轉換之後兩邊資料各自獨立 (願望清單項目沒有
//     被鎖住、獎勵項目也可以照常編輯)，只是透過 wishlist_item_id 記住彼此的關聯，方便互相
//     顯示「還差幾點」「這是從哪個願望轉過來的」。

const { Router } = require('../mini-http');
const { getDb } = require('../services/db');
const { requireAuth } = require('../middleware/auth');
const { getBalance } = require('../services/points');
const { getUserLinks, linkBelongsToUser, canAccessSharedItem, enrichShared } = require('../services/partnerShare');

const router = Router();

// v0.68：#12 願望清單串連財務目標——延遲 require finance.js (拿它匯出的 computeGoalProgress)，
// 避免跟 finance.js 之間互相 require 造成循環載入問題 (finance.js 目前沒有反向 require
// wishlist.js，但延遲載入比較保險，跟 export.js/monthlyBackup.js 的做法一致)。
function goalProjectionFor(db, userId, goalId, itemPrice) {
  if (!goalId || itemPrice == null) return null;
  const goal = db.prepare('SELECT * FROM finance_goals WHERE id = ? AND user_id = ? AND archived = 0').get(goalId, userId);
  if (!goal) return null;
  const { computeGoalProgress } = require('./finance');
  const progress = computeGoalProgress(db, userId, goal);
  // 用目標目前的月儲蓄速度，估算「淨儲蓄累積到願望的價格」大概還要幾個月，
  // 跟目標本身的 projectedDate (存到目標金額) 是分開的兩件事 (願望價格通常跟目標金額不同)。
  let monthsToAfford = null, projectedAffordDate = null;
  if (progress.netSaved >= itemPrice) {
    monthsToAfford = 0; projectedAffordDate = 'reached';
  } else if (progress.monthlyRate > 0.01) {
    monthsToAfford = Math.round(((itemPrice - progress.netSaved) / progress.monthlyRate) * 10) / 10;
    const d = new Date();
    d.setDate(d.getDate() + monthsToAfford * 30);
    projectedAffordDate = d.toISOString().slice(0, 10);
  }
  return {
    goalId: goal.id, goalName: goal.name, goalNetSaved: progress.netSaved, goalMonthlyRate: progress.monthlyRate,
    monthsToAfford, projectedAffordDate,
  };
}

const VALID_PRIORITIES = new Set(['low', 'medium', 'high']);
const PRIORITY_RANK = { high: 0, medium: 1, low: 2 };

function sortWishlist(rows) {
  rows.sort((a, b) => {
    if (a.completed !== b.completed) return a.completed - b.completed;
    const pr = (PRIORITY_RANK[a.priority] ?? 1) - (PRIORITY_RANK[b.priority] ?? 1);
    if (pr !== 0) return pr;
    return (b.updated_at || '').localeCompare(a.updated_at || '');
  });
  return rows;
}

router.get('/wishlist', requireAuth, (req, res) => {
  const db = getDb();
  const userId = req.session.userId;
  const links = getUserLinks(db, userId);
  const linkIds = links.map((l) => l.linkId);
  let rows;
  if (linkIds.length) {
    const placeholders = linkIds.map(() => '?').join(',');
    rows = db
      .prepare(`SELECT * FROM wishlist_items WHERE (link_id IS NULL AND user_id = ?) OR link_id IN (${placeholders})`)
      .all(userId, ...linkIds);
  } else {
    rows = db.prepare('SELECT * FROM wishlist_items WHERE user_id = ? AND link_id IS NULL').all(userId);
  }

  const balance = getBalance(db, userId);
  const rewardRows = db.prepare('SELECT id, wishlist_item_id, cost FROM point_rewards WHERE wishlist_item_id IS NOT NULL').all();
  const rewardByWishlistId = new Map(rewardRows.map((r) => [r.wishlist_item_id, r]));

  const enriched = rows.map((item) => {
    const reward = rewardByWishlistId.get(item.id);
    return {
      ...item,
      ...enrichShared(db, item, userId, links),
      reward: reward ? { id: reward.id, cost: reward.cost, canAffordNow: balance >= reward.cost } : null,
      goalProjection: goalProjectionFor(db, userId, item.goal_id, item.price),
    };
  });
  res.json(sortWishlist(enriched));
});

router.get('/wishlist/:id', requireAuth, (req, res) => {
  const db = getDb();
  const item = db.prepare('SELECT * FROM wishlist_items WHERE id = ?').get(req.params.id);
  if (!item || !canAccessSharedItem(db, item, req.session.userId)) return res.status(404).json({ error: '找不到這個願望' });
  res.json(item);
});

function resolveGoalId(db, userId, goalId) {
  if (goalId === undefined) return undefined; // 呼叫端沒帶這個欄位，維持原值不動
  if (goalId === null || goalId === '') return null;
  const goal = db.prepare('SELECT id FROM finance_goals WHERE id = ? AND user_id = ? AND archived = 0').get(goalId, userId);
  if (!goal) return false; // 用 false 代表「有帶值但驗證失敗」，跟「沒帶值」(undefined) 區分開來
  return goal.id;
}

router.post('/wishlist', requireAuth, (req, res) => {
  const { title, note, link, price, priority, linkId, goalId } = req.body || {};
  const trimmedTitle = String(title || '').trim();
  if (!trimmedTitle) return res.status(400).json({ error: '請輸入名稱' });
  const finalPriority = VALID_PRIORITIES.has(priority) ? priority : 'medium';
  let finalPrice = null;
  if (price !== undefined && price !== null && String(price).trim() !== '') {
    const n = Number(price);
    if (Number.isNaN(n) || n < 0) return res.status(400).json({ error: '價格格式不正確' });
    finalPrice = n;
  }
  const db = getDb();
  const userId = req.session.userId;
  let resolvedLinkId = null;
  if (linkId !== undefined && linkId !== null && linkId !== '') {
    if (!linkBelongsToUser(db, linkId, userId)) return res.status(400).json({ error: '找不到這個共同連結' });
    resolvedLinkId = linkId;
  }
  const resolvedGoalId = resolveGoalId(db, userId, goalId);
  if (resolvedGoalId === false) return res.status(400).json({ error: '找不到這個財務目標' });
  const now = new Date().toISOString();
  const result = db
    .prepare(
      'INSERT INTO wishlist_items (user_id, title, note, link, price, priority, completed, created_at, updated_at, link_id, created_by_user_id, goal_id) VALUES (?, ?, ?, ?, ?, ?, 0, ?, ?, ?, ?, ?)'
    )
    .run(userId, trimmedTitle, note || '', (link || '').trim() || null, finalPrice, finalPriority, now, now, resolvedLinkId, userId, resolvedGoalId || null);
  res.json({ id: result.lastInsertRowid });
});

router.put('/wishlist/:id', requireAuth, (req, res) => {
  const db = getDb();
  const item = db.prepare('SELECT * FROM wishlist_items WHERE id = ?').get(req.params.id);
  if (!item || !canAccessSharedItem(db, item, req.session.userId)) return res.status(404).json({ error: '找不到這個願望' });
  const { title, note, link, price, priority, goalId } = req.body || {};
  const trimmedTitle = title != null ? String(title).trim() : item.title;
  if (!trimmedTitle) return res.status(400).json({ error: '請輸入名稱' });
  const finalPriority = priority != null ? (VALID_PRIORITIES.has(priority) ? priority : item.priority) : item.priority;
  let finalPrice = item.price;
  if (price !== undefined) {
    if (price === null || String(price).trim() === '') {
      finalPrice = null;
    } else {
      const n = Number(price);
      if (Number.isNaN(n) || n < 0) return res.status(400).json({ error: '價格格式不正確' });
      finalPrice = n;
    }
  }
  const resolvedGoalId = resolveGoalId(db, req.session.userId, goalId);
  if (resolvedGoalId === false) return res.status(400).json({ error: '找不到這個財務目標' });
  db.prepare('UPDATE wishlist_items SET title = ?, note = ?, link = ?, price = ?, priority = ?, updated_at = ?, goal_id = ? WHERE id = ?').run(
    trimmedTitle,
    note != null ? note : item.note,
    link != null ? ((link || '').trim() || null) : item.link,
    finalPrice,
    finalPriority,
    new Date().toISOString(),
    resolvedGoalId === undefined ? item.goal_id : resolvedGoalId,
    item.id
  );
  res.json({ ok: true });
});

router.delete('/wishlist/:id', requireAuth, (req, res) => {
  const db = getDb();
  const item = db.prepare('SELECT * FROM wishlist_items WHERE id = ?').get(req.params.id);
  if (!item || !canAccessSharedItem(db, item, req.session.userId)) return res.status(404).json({ error: '找不到這個願望' });
  db.prepare('DELETE FROM wishlist_items WHERE id = ?').run(item.id);
  res.json({ ok: true });
});

router.post('/wishlist/:id/toggle', requireAuth, (req, res) => {
  const db = getDb();
  const item = db.prepare('SELECT * FROM wishlist_items WHERE id = ?').get(req.params.id);
  if (!item || !canAccessSharedItem(db, item, req.session.userId)) return res.status(404).json({ error: '找不到這個願望' });
  const nextCompleted = item.completed ? 0 : 1;
  db.prepare('UPDATE wishlist_items SET completed = ?, updated_at = ? WHERE id = ?').run(nextCompleted, new Date().toISOString(), item.id);
  res.json({ ok: true, completed: !!nextCompleted });
});

// v0.54：把願望清單項目轉換成點數獎勵目錄裡的一個獎勵項目。轉換之後兩邊各自獨立存在，只是
// 用 wishlist_item_id 記住彼此的關聯；共同建立的願望轉換出來的獎勵，也會沿用同一個 link_id，
// 雙方都看得到。一個願望只能轉換一次 (避免重複建立好幾個一樣的獎勵)。
router.post('/wishlist/:id/convert-to-reward', requireAuth, (req, res) => {
  const db = getDb();
  const userId = req.session.userId;
  const item = db.prepare('SELECT * FROM wishlist_items WHERE id = ?').get(req.params.id);
  if (!item || !canAccessSharedItem(db, item, userId)) return res.status(404).json({ error: '找不到這個願望' });

  const existing = db.prepare('SELECT id FROM point_rewards WHERE wishlist_item_id = ?').get(item.id);
  if (existing) return res.status(400).json({ error: '這個願望已經連結過獎勵了', rewardId: existing.id });

  const costNum = Number((req.body || {}).cost);
  if (!Number.isInteger(costNum) || costNum <= 0) return res.status(400).json({ error: '請輸入大於 0 的整數點數' });

  const now = new Date().toISOString();
  const result = db
    .prepare(
      'INSERT INTO point_rewards (user_id, title, cost, created_at, link_id, created_by_user_id, wishlist_item_id) VALUES (?, ?, ?, ?, ?, ?, ?)'
    )
    .run(userId, item.title, costNum, now, item.link_id || null, userId, item.id);
  res.json({ id: result.lastInsertRowid });
});

module.exports = router;
