// 專案看板 (v0.50)。固定三欄：待辦 (todo) / 進行中 (in_progress) / 完成 (done)。
// sort_order 是「該欄位目前最大值 + 1」往後接，移動到別欄時一樣接在目標欄最後面——
// 簡化版排序，不支援「插入到卡片之間」，先滿足最常見的「把卡片挪到下一欄」需求。

const { Router } = require('../mini-http');
const { getDb } = require('../services/db');
const { requireAuth } = require('../middleware/auth');

const router = Router();

const COLUMNS = ['todo', 'in_progress', 'done'];

function nextSortOrder(db, boardId, columnKey) {
  const row = db.prepare('SELECT MAX(sort_order) m FROM kanban_cards WHERE board_id = ? AND column_key = ?').get(boardId, columnKey);
  return (row.m || 0) + 1;
}

// v0.68：#9 家庭看板任務公平性統計——卡片可以指派給看板擁有者自己、或已透過邀請碼連結的
// 家人/伴侶 (跟 family-board.js 的「圈子」概念一致：只看一層直接連結，不遞移擴散)，
// 用來統計「這個看板上的卡片，實際上是誰在做」。
function circleMemberIds(db, userId) {
  const rows = db.prepare('SELECT user_a_id, user_b_id FROM partner_links WHERE user_a_id = ? OR user_b_id = ?').all(userId, userId);
  const linked = rows.map((r) => (r.user_a_id === userId ? r.user_b_id : r.user_a_id));
  return [userId, ...linked];
}
function userLabel(db, userId, selfId) {
  if (userId === selfId) return '我';
  const u = db.prepare('SELECT name, email FROM users WHERE id = ?').get(userId);
  return (u && (u.name || u.email)) || '（帳號已刪除）';
}

router.get('/kanban-boards', requireAuth, (req, res) => {
  const db = getDb();
  const boards = db.prepare('SELECT * FROM kanban_boards WHERE user_id = ? ORDER BY created_at DESC').all(req.session.userId);
  const summarized = boards.map((b) => {
    const cardCount = db.prepare('SELECT COUNT(*) c FROM kanban_cards WHERE board_id = ?').get(b.id).c;
    const doneCount = db.prepare("SELECT COUNT(*) c FROM kanban_cards WHERE board_id = ? AND column_key = 'done'").get(b.id).c;
    return { ...b, cardCount, doneCount };
  });
  res.json(summarized);
});

router.post('/kanban-boards', requireAuth, (req, res) => {
  const name = String((req.body || {}).name || '').trim();
  if (!name) return res.status(400).json({ error: '請輸入看板名稱' });
  const db = getDb();
  const result = db.prepare('INSERT INTO kanban_boards (user_id, name, created_at) VALUES (?, ?, ?)').run(req.session.userId, name, new Date().toISOString());
  res.json({ id: result.lastInsertRowid });
});

router.delete('/kanban-boards/:id', requireAuth, (req, res) => {
  const db = getDb();
  const board = db.prepare('SELECT * FROM kanban_boards WHERE id = ? AND user_id = ?').get(req.params.id, req.session.userId);
  if (!board) return res.status(404).json({ error: '找不到這個看板' });
  db.prepare('DELETE FROM kanban_boards WHERE id = ?').run(board.id);
  res.json({ ok: true });
});

router.get('/kanban-boards/:id', requireAuth, (req, res) => {
  const db = getDb();
  const board = db.prepare('SELECT * FROM kanban_boards WHERE id = ? AND user_id = ?').get(req.params.id, req.session.userId);
  if (!board) return res.status(404).json({ error: '找不到這個看板' });
  const cards = db.prepare('SELECT * FROM kanban_cards WHERE board_id = ? ORDER BY column_key, sort_order ASC').all(board.id);
  const selfId = req.session.userId;
  const withAssigneeLabel = cards.map((c) => ({ ...c, assigneeLabel: c.assignee_user_id ? userLabel(db, c.assignee_user_id, selfId) : null }));
  const columns = {};
  COLUMNS.forEach((k) => { columns[k] = withAssigneeLabel.filter((c) => c.column_key === k); });
  res.json({ ...board, columns, circleMembers: circleMemberIds(db, selfId).map((id) => ({ id, label: userLabel(db, id, selfId) })) });
});

function resolveAssignee(db, selfId, assigneeUserId) {
  if (assigneeUserId === undefined) return undefined;
  if (assigneeUserId === null || assigneeUserId === '') return null;
  const n = Number(assigneeUserId);
  if (!circleMemberIds(db, selfId).includes(n)) return false;
  return n;
}

router.post('/kanban-boards/:id/cards', requireAuth, (req, res) => {
  const db = getDb();
  const board = db.prepare('SELECT * FROM kanban_boards WHERE id = ? AND user_id = ?').get(req.params.id, req.session.userId);
  if (!board) return res.status(404).json({ error: '找不到這個看板' });
  const { title, note, column, assigneeUserId } = req.body || {};
  const trimmedTitle = String(title || '').trim();
  if (!trimmedTitle) return res.status(400).json({ error: '請輸入卡片標題' });
  const columnKey = COLUMNS.includes(column) ? column : 'todo';
  const resolvedAssignee = resolveAssignee(db, req.session.userId, assigneeUserId);
  if (resolvedAssignee === false) return res.status(400).json({ error: '指派對象必須是你自己或已連結的家人/伴侶' });
  const now = new Date().toISOString();
  const sortOrder = nextSortOrder(db, board.id, columnKey);
  const result = db
    .prepare('INSERT INTO kanban_cards (board_id, title, note, column_key, sort_order, created_at, updated_at, assignee_user_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)')
    .run(board.id, trimmedTitle, note || '', columnKey, sortOrder, now, now, resolvedAssignee || null);
  res.json({ id: result.lastInsertRowid });
});

router.put('/kanban-boards/:id/cards/:cardId', requireAuth, (req, res) => {
  const db = getDb();
  const board = db.prepare('SELECT * FROM kanban_boards WHERE id = ? AND user_id = ?').get(req.params.id, req.session.userId);
  if (!board) return res.status(404).json({ error: '找不到這個看板' });
  const card = db.prepare('SELECT * FROM kanban_cards WHERE id = ? AND board_id = ?').get(req.params.cardId, board.id);
  if (!card) return res.status(404).json({ error: '找不到這張卡片' });
  const { title, note, assigneeUserId } = req.body || {};
  const trimmedTitle = title != null ? String(title).trim() : card.title;
  if (!trimmedTitle) return res.status(400).json({ error: '請輸入卡片標題' });
  const resolvedAssignee = resolveAssignee(db, req.session.userId, assigneeUserId);
  if (resolvedAssignee === false) return res.status(400).json({ error: '指派對象必須是你自己或已連結的家人/伴侶' });
  db.prepare('UPDATE kanban_cards SET title = ?, note = ?, updated_at = ?, assignee_user_id = ? WHERE id = ?').run(
    trimmedTitle, note != null ? note : card.note, new Date().toISOString(),
    resolvedAssignee === undefined ? card.assignee_user_id : resolvedAssignee, card.id
  );
  res.json({ ok: true });
});

// 公平性統計：這個看板上每個被指派的人，分別做了多少張卡片 (已完成 vs 全部)，沒有被指派
// 的卡片不計入任何人 (顯示成 unassignedCount，讓使用者知道還有多少卡片沒分配)。
router.get('/kanban-boards/:id/fairness', requireAuth, (req, res) => {
  const db = getDb();
  const selfId = req.session.userId;
  const board = db.prepare('SELECT * FROM kanban_boards WHERE id = ? AND user_id = ?').get(req.params.id, selfId);
  if (!board) return res.status(404).json({ error: '找不到這個看板' });
  const cards = db.prepare('SELECT column_key, assignee_user_id FROM kanban_cards WHERE board_id = ?').all(board.id);
  const byAssignee = new Map();
  let unassignedCount = 0;
  cards.forEach((c) => {
    if (!c.assignee_user_id) { unassignedCount++; return; }
    if (!byAssignee.has(c.assignee_user_id)) byAssignee.set(c.assignee_user_id, { total: 0, done: 0 });
    const bucket = byAssignee.get(c.assignee_user_id);
    bucket.total++;
    if (c.column_key === 'done') bucket.done++;
  });
  const totalAssigned = [...byAssignee.values()].reduce((s, b) => s + b.total, 0);
  const stats = [...byAssignee.entries()].map(([userId, b]) => ({
    userId, label: userLabel(db, userId, selfId), total: b.total, done: b.done,
    sharePct: totalAssigned > 0 ? Math.round((b.total / totalAssigned) * 1000) / 10 : 0,
  })).sort((a, b) => b.total - a.total);
  res.json({ stats, unassignedCount, totalAssigned });
});

router.post('/kanban-boards/:id/cards/:cardId/move', requireAuth, (req, res) => {
  const db = getDb();
  const board = db.prepare('SELECT * FROM kanban_boards WHERE id = ? AND user_id = ?').get(req.params.id, req.session.userId);
  if (!board) return res.status(404).json({ error: '找不到這個看板' });
  const card = db.prepare('SELECT * FROM kanban_cards WHERE id = ? AND board_id = ?').get(req.params.cardId, board.id);
  if (!card) return res.status(404).json({ error: '找不到這張卡片' });
  const { column } = req.body || {};
  if (!COLUMNS.includes(column)) return res.status(400).json({ error: '欄位名稱不正確' });
  const sortOrder = nextSortOrder(db, board.id, column);
  db.prepare('UPDATE kanban_cards SET column_key = ?, sort_order = ?, updated_at = ? WHERE id = ?').run(
    column, sortOrder, new Date().toISOString(), card.id
  );
  res.json({ ok: true });
});

router.delete('/kanban-boards/:id/cards/:cardId', requireAuth, (req, res) => {
  const db = getDb();
  const board = db.prepare('SELECT * FROM kanban_boards WHERE id = ? AND user_id = ?').get(req.params.id, req.session.userId);
  if (!board) return res.status(404).json({ error: '找不到這個看板' });
  db.prepare('DELETE FROM kanban_cards WHERE id = ? AND board_id = ?').run(req.params.cardId, board.id);
  res.json({ ok: true });
});

module.exports = router;
