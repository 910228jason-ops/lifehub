const { Router } = require('../mini-http');
const { getDb } = require('../services/db');
const { requireAuth } = require('../middleware/auth');

const router = Router();

// 幫每筆任務附上小任務進度 (已完成/總數)，沒有拆小任務的話兩個數字都是 0，
// 前端看到 totalSubtasks === 0 就當作「沒有拆解小任務」，不顯示進度條。
function attachSubtaskProgress(db, userId, rows) {
  if (!rows.length) return rows;
  const ids = rows.map((r) => r.id);
  const placeholders = ids.map(() => '?').join(',');
  const counts = db
    .prepare(
      `SELECT task_id, COUNT(*) as total, SUM(completed) as done
       FROM task_subtasks WHERE user_id = ? AND task_id IN (${placeholders}) GROUP BY task_id`
    )
    .all(userId, ...ids);
  const byTask = {};
  counts.forEach((c) => { byTask[c.task_id] = c; });
  return rows.map((r) => {
    const c = byTask[r.id];
    return { ...r, totalSubtasks: c ? c.total : 0, completedSubtasks: c ? (c.done || 0) : 0 };
  });
}

router.get('/', requireAuth, (req, res) => {
  const db = getDb();
  const { status } = req.query; // 'pending' | 'completed' | undefined (全部)
  let rows;
  if (status === 'pending') {
    rows = db.prepare('SELECT * FROM tasks WHERE user_id = ? AND completed = 0 ORDER BY (due_date IS NULL), due_date ASC, CASE priority WHEN \'high\' THEN 0 WHEN \'medium\' THEN 1 ELSE 2 END ASC').all(req.session.userId);
  } else if (status === 'completed') {
    rows = db.prepare('SELECT * FROM tasks WHERE user_id = ? AND completed = 1 ORDER BY completed_at DESC LIMIT 100').all(req.session.userId);
  } else {
    rows = db.prepare('SELECT * FROM tasks WHERE user_id = ? ORDER BY completed ASC, (due_date IS NULL), due_date ASC').all(req.session.userId);
  }
  res.json(attachSubtaskProgress(db, req.session.userId, rows));
});

// ---- 小任務 (拆解成子項目 + 進度追蹤) ----
router.get('/:id/subtasks', requireAuth, (req, res) => {
  const db = getDb();
  const task = db.prepare('SELECT id FROM tasks WHERE id = ? AND user_id = ?').get(req.params.id, req.session.userId);
  if (!task) return res.status(404).json({ error: '找不到這筆任務' });
  const rows = db
    .prepare('SELECT * FROM task_subtasks WHERE task_id = ? AND user_id = ? ORDER BY sort_order ASC, id ASC')
    .all(req.params.id, req.session.userId);
  res.json(rows);
});

// v0.53：小任務現在也有自己的優先度跟精準提醒時間 (不再只有「標題+打勾」)，這裡的驗證邏輯
// 刻意跟主任務的 POST / 一致 (同一套 priority 選項、同一個 parseRemindAt 轉換)，讓子任務
// 感覺起來就是「縮小版的任務」，操作邏輯不用使用者重新學一遍。
router.post('/:id/subtasks', requireAuth, (req, res) => {
  const { title, priority, remindAt } = req.body || {};
  if (!title || !String(title).trim()) return res.status(400).json({ error: '請提供小任務標題' });
  const db = getDb();
  const task = db.prepare('SELECT id FROM tasks WHERE id = ? AND user_id = ?').get(req.params.id, req.session.userId);
  if (!task) return res.status(404).json({ error: '找不到這筆任務' });
  const p = ['low', 'medium', 'high'].includes(priority) ? priority : 'medium';
  const remindAtVal = parseRemindAt(remindAt);
  const maxOrder = db.prepare('SELECT COALESCE(MAX(sort_order), -1) as m FROM task_subtasks WHERE task_id = ?').get(req.params.id).m;
  const now = new Date().toISOString();
  const result = db
    .prepare('INSERT INTO task_subtasks (task_id, user_id, title, completed, priority, remind_at, remind_sent_at, sort_order, created_at) VALUES (?, ?, ?, 0, ?, ?, NULL, ?, ?)')
    .run(req.params.id, req.session.userId, String(title).trim(), p, remindAtVal, maxOrder + 1, now);
  res.json({ id: result.lastInsertRowid, ok: true });
});

router.put('/subtasks/:subId', requireAuth, (req, res) => {
  const { title, completed, priority, remindAt } = req.body || {};
  const db = getDb();
  const sub = db.prepare('SELECT * FROM task_subtasks WHERE id = ? AND user_id = ?').get(req.params.subId, req.session.userId);
  if (!sub) return res.status(404).json({ error: '找不到這筆小任務' });
  const nextRemindAt = remindAt !== undefined ? parseRemindAt(remindAt) : sub.remind_at;
  // 提醒時間有變動 (含被清空) 就重設「已推播」標記，邏輯跟主任務一樣，避免改成新時間後被
  // 誤判成已經推播過而跳過。
  const remindChanged = remindAt !== undefined && nextRemindAt !== sub.remind_at;
  db.prepare('UPDATE task_subtasks SET title = ?, completed = ?, priority = ?, remind_at = ?, remind_sent_at = ? WHERE id = ?').run(
    title != null ? String(title).trim() : sub.title,
    completed != null ? (completed ? 1 : 0) : sub.completed,
    priority !== undefined ? (['low', 'medium', 'high'].includes(priority) ? priority : sub.priority) : sub.priority,
    nextRemindAt,
    remindChanged ? null : sub.remind_sent_at,
    req.params.subId
  );
  res.json({ ok: true });
});

router.delete('/subtasks/:subId', requireAuth, (req, res) => {
  const db = getDb();
  db.prepare('DELETE FROM task_subtasks WHERE id = ? AND user_id = ?').run(req.params.subId, req.session.userId);
  res.json({ ok: true });
});

const RECURRENCE_OPTIONS = ['daily', 'weekly', 'monthly'];

function addRecurrence(dateStr, recurrence, interval) {
  if (!dateStr) return null;
  const d = new Date(dateStr + 'T00:00:00');
  if (Number.isNaN(d.getTime())) return null;
  const n = Math.max(1, Number(interval) || 1);
  if (recurrence === 'daily') d.setDate(d.getDate() + n);
  else if (recurrence === 'weekly') d.setDate(d.getDate() + 7 * n);
  else if (recurrence === 'monthly') d.setMonth(d.getMonth() + n);
  else return null;
  return d.toISOString().slice(0, 10);
}

// remindAt 是 ISO 時間戳記字串 (含秒)，代表「精準提醒」的目標時間點——跟 dueDate (只到天) 不同，
// 這個會被 push.js 的背景排程每 15 秒掃一次，時間一到就推播通知，適合「N 分鐘/秒後提醒我」這種
// 需要準時跳出通知的情境；沒帶這個欄位的任務只會顯示在待辦清單裡，不會觸發額外的推播。
function parseRemindAt(remindAt) {
  if (!remindAt) return null;
  const d = new Date(remindAt);
  if (Number.isNaN(d.getTime())) return null;
  return d.toISOString();
}

router.post('/', requireAuth, (req, res) => {
  const { title, note, dueDate, priority, energyLevel, recurrence, recurrenceInterval, remindAt } = req.body || {};
  if (!title || !String(title).trim()) return res.status(400).json({ error: '請提供任務標題' });
  const p = ['low', 'medium', 'high'].includes(priority) ? priority : 'medium';
  const e = ['low', 'medium', 'high'].includes(energyLevel) ? energyLevel : null;
  const r = RECURRENCE_OPTIONS.includes(recurrence) ? recurrence : null;
  const ri = Math.max(1, Number(recurrenceInterval) || 1);
  const remindAtVal = parseRemindAt(remindAt);
  const db = getDb();
  const now = new Date().toISOString();
  const result = db.prepare('INSERT INTO tasks (user_id, title, note, due_date, priority, energy_level, recurrence, recurrence_interval, completed, created_at, remind_at, remind_sent_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?, NULL)').run(
    req.session.userId, String(title).trim(), note || null, dueDate || null, p, e, r, ri, now, remindAtVal
  );
  res.json({ id: result.lastInsertRowid, ok: true });
});

router.put('/:id', requireAuth, (req, res) => {
  const { title, note, dueDate, priority, energyLevel, recurrence, recurrenceInterval, remindAt } = req.body || {};
  const db = getDb();
  const task = db.prepare('SELECT * FROM tasks WHERE id = ? AND user_id = ?').get(req.params.id, req.session.userId);
  if (!task) return res.status(404).json({ error: '找不到這筆任務' });
  const nextRemindAt = remindAt !== undefined ? parseRemindAt(remindAt) : task.remind_at;
  // 提醒時間有變動 (含被清空) 就重設「已推播」標記，不然改成新時間後背景排程會誤判成已經推播過而跳過
  const remindChanged = remindAt !== undefined && nextRemindAt !== task.remind_at;
  // v0.66：把 due_date 改到比原本更晚的日期，算一次「延期」。只有原本就有日期、新日期也有值、
  // 而且確實比原本晚才算數 (清空日期、往前改、第一次設定日期都不算延期)。
  const nextDueDate = dueDate !== undefined ? dueDate : task.due_date;
  const isPostpone = task.due_date && nextDueDate && nextDueDate > task.due_date;
  const nextPostponedCount = isPostpone ? (task.postponed_count || 0) + 1 : (task.postponed_count || 0);
  db.prepare('UPDATE tasks SET title = ?, note = ?, due_date = ?, priority = ?, energy_level = ?, recurrence = ?, recurrence_interval = ?, remind_at = ?, remind_sent_at = ?, postponed_count = ? WHERE id = ?').run(
    title != null ? String(title).trim() : task.title,
    note != null ? note : task.note,
    nextDueDate,
    ['low', 'medium', 'high'].includes(priority) ? priority : task.priority,
    energyLevel !== undefined ? (['low', 'medium', 'high'].includes(energyLevel) ? energyLevel : null) : task.energy_level,
    recurrence !== undefined ? (RECURRENCE_OPTIONS.includes(recurrence) ? recurrence : null) : task.recurrence,
    recurrenceInterval !== undefined ? Math.max(1, Number(recurrenceInterval) || 1) : task.recurrence_interval,
    nextRemindAt,
    remindChanged ? null : task.remind_sent_at,
    nextPostponedCount,
    req.params.id
  );
  res.json({ ok: true, postponedCount: nextPostponedCount });
});

// 完成任務時，如果這是一筆重複性任務，自動照設定的週期產生下一筆待辦，不用自己重新輸入一次
router.put('/:id/complete', requireAuth, (req, res) => {
  const db = getDb();
  const completed = req.body && req.body.completed != null ? !!req.body.completed : true;
  const task = db.prepare('SELECT * FROM tasks WHERE id = ? AND user_id = ?').get(req.params.id, req.session.userId);
  if (!task) return res.status(404).json({ error: '找不到這筆任務' });
  db.prepare('UPDATE tasks SET completed = ?, completed_at = ? WHERE id = ? AND user_id = ?').run(
    completed ? 1 : 0,
    completed ? new Date().toISOString() : null,
    req.params.id,
    req.session.userId
  );
  // 遊戲化點數：完成待辦 +2 點，但「每一筆任務終身只加一次」——用 points_awarded 欄位標記，
  // 不是「每天一次」這種節流，避免使用者靠「打勾→取消→再打勾」同一筆任務反覆刷點數。
  if (completed && !task.points_awarded) {
    require('../services/points').awardPoints(db, req.session.userId, 2, 'task_complete');
    db.prepare('UPDATE tasks SET points_awarded = 1 WHERE id = ?').run(req.params.id);
  }
  let nextTaskId = null;
  if (completed && task.recurrence) {
    const nextDue = addRecurrence(task.due_date, task.recurrence, task.recurrence_interval) || task.due_date;
    const now = new Date().toISOString();
    const result = db.prepare('INSERT INTO tasks (user_id, title, note, due_date, priority, energy_level, recurrence, recurrence_interval, completed, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, ?)').run(
      req.session.userId, task.title, task.note, nextDue, task.priority, task.energy_level, task.recurrence, task.recurrence_interval, now
    );
    nextTaskId = result.lastInsertRowid;
  }
  res.json({ ok: true, nextTaskId });
});

router.delete('/:id', requireAuth, (req, res) => {
  const db = getDb();
  // 資料庫沒開 PRAGMA foreign_keys，ON DELETE CASCADE 不會自動生效，這裡手動先清掉小任務再刪任務本身
  db.prepare('DELETE FROM task_subtasks WHERE task_id = ? AND user_id = ?').run(req.params.id, req.session.userId);
  db.prepare('DELETE FROM tasks WHERE id = ? AND user_id = ?').run(req.params.id, req.session.userId);
  res.json({ ok: true });
});

// v0.66：反覆延期超過門檻 (預設 3 次)、還沒完成的任務，代表這件事可能一直被拖著沒真的處理，
// 值得被特別標出來，而不是繼續無限期掛在清單上製造壓力。
router.get('/procrastinating', requireAuth, (req, res) => {
  const db = getDb();
  const rows = db
    .prepare('SELECT id, title, due_date, postponed_count FROM tasks WHERE user_id = ? AND completed = 0 AND postponed_count >= 3 ORDER BY postponed_count DESC')
    .all(req.session.userId);
  res.json(rows);
});

function moodBucketOf(score) {
  if (score == null) return null;
  if (score <= 4) return 'low';
  if (score <= 7) return 'medium';
  return 'high';
}

// 根據「今天的心情分數」跟「過去在不同心情狀態下，不同精力標籤任務的完成率」，
// 排出一份「今天建議先做」的清單。心情沒記錄或資料不夠時，就退回原本依優先度/期限的排序，不亂猜。
router.get('/suggest-today', requireAuth, (req, res) => {
  const db = getDb();
  const todayStr = new Date().toISOString().slice(0, 10);
  const moodToday = db.prepare('SELECT score FROM mood_entries WHERE user_id = ? AND entry_date = ?').get(req.session.userId, todayStr);
  const todayBucket = moodToday ? moodBucketOf(moodToday.score) : null;

  const pending = db
    .prepare(
      "SELECT * FROM tasks WHERE user_id = ? AND completed = 0 ORDER BY (due_date IS NULL), due_date ASC, CASE priority WHEN 'high' THEN 0 WHEN 'medium' THEN 1 ELSE 2 END ASC"
    )
    .all(req.session.userId);

  if (!todayBucket) {
    return res.json({ moodLogged: false, todayBucket: null, tasks: pending, note: '今天還沒有記錄心情，先用優先度/期限排序。' });
  }

  // 找出過去「完成當下」的心情分數與精力標籤的搭配，算每個精力標籤在各心情區間的完成率
  const history = db
    .prepare(
      `SELECT t.energy_level as energyLevel, m.score as moodScore
       FROM tasks t JOIN mood_entries m ON m.user_id = t.user_id AND m.entry_date = substr(t.completed_at, 1, 10)
       WHERE t.user_id = ? AND t.completed = 1 AND t.energy_level IS NOT NULL`
    )
    .all(req.session.userId);

  const bucketCounts = {}; // bucketCounts[bucket][energyLevel] = count
  history.forEach((h) => {
    const b = moodBucketOf(h.moodScore);
    if (!b) return;
    bucketCounts[b] = bucketCounts[b] || { low: 0, medium: 0, high: 0 };
    bucketCounts[b][h.energyLevel] = (bucketCounts[b][h.energyLevel] || 0) + 1;
  });

  const counts = bucketCounts[todayBucket];
  const hasEnoughData = counts && (counts.low + counts.medium + counts.high) >= 5;

  // 沒有足夠歷史資料時，用常識性的預設順序：心情較低時，低精力任務排前面；心情好時，順序不變 (交給優先度)
  const energyRank = hasEnoughData
    ? ['low', 'medium', 'high'].sort((a, b) => (counts[b] || 0) - (counts[a] || 0))
    : (todayBucket === 'low' ? ['low', 'medium', 'high'] : ['high', 'medium', 'low', null]);

  const rankOf = (lvl) => {
    const idx = energyRank.indexOf(lvl);
    return idx === -1 ? energyRank.length : idx;
  };

  const sorted = [...pending].sort((a, b) => rankOf(a.energy_level) - rankOf(b.energy_level));

  res.json({
    moodLogged: true,
    todayBucket,
    todayScore: moodToday.score,
    usedHistory: hasEnoughData,
    tasks: sorted,
  });
});

// 每週回顧：純陳述這週完成了幾件、哪些一直被延後，不帶評價字眼
router.get('/review/week', requireAuth, (req, res) => {
  const db = getDb();
  const now = new Date();
  const weekAgo = new Date(now.getTime() - 7 * 24 * 3600 * 1000).toISOString().slice(0, 10);
  const todayStr = now.toISOString().slice(0, 10);

  const completedThisWeek = db
    .prepare("SELECT * FROM tasks WHERE user_id = ? AND completed = 1 AND substr(completed_at, 1, 10) >= ? ORDER BY completed_at DESC")
    .all(req.session.userId, weekAgo);

  // 「一直被延後」：due_date 已經過期超過 3 天，還沒完成
  const overdueThreshold = new Date(now.getTime() - 3 * 24 * 3600 * 1000).toISOString().slice(0, 10);
  const longPending = db
    .prepare("SELECT * FROM tasks WHERE user_id = ? AND completed = 0 AND due_date IS NOT NULL AND due_date < ? ORDER BY due_date ASC")
    .all(req.session.userId, overdueThreshold);

  const stillPending = db
    .prepare('SELECT COUNT(*) as c FROM tasks WHERE user_id = ? AND completed = 0')
    .get(req.session.userId).c;

  res.json({
    rangeFrom: weekAgo,
    rangeTo: todayStr,
    completedCount: completedThisWeek.length,
    completedTasks: completedThisWeek.slice(0, 20),
    longPendingTasks: longPending.slice(0, 20),
    stillPendingCount: stillPending,
  });
});

// v0.68：#7 任務精力等級 vs 完成效率分析——統計不同精力標籤 (low/medium/high) 的任務
// 完成率，以及「從建立到完成」平均花了多久 (小時)，幫使用者看出「哪種精力等級的任務
// 通常比較快處理掉、哪種容易拖」。
router.get('/energy-efficiency', requireAuth, (req, res) => {
  const db = getDb();
  const userId = req.session.userId;
  const rows = db
    .prepare('SELECT energy_level, completed, created_at, completed_at FROM tasks WHERE user_id = ? AND energy_level IS NOT NULL')
    .all(userId);

  if (rows.length < 5) {
    return res.json({ hasEnoughData: false, note: '還沒有足夠帶「精力等級」的任務資料 (至少需要 5 筆)，建立任務時記得選精力等級。' });
  }

  const byLevel = { low: { total: 0, completed: 0, durations: [] }, medium: { total: 0, completed: 0, durations: [] }, high: { total: 0, completed: 0, durations: [] } };
  rows.forEach((r) => {
    const bucket = byLevel[r.energy_level];
    if (!bucket) return;
    bucket.total++;
    if (r.completed && r.completed_at) {
      bucket.completed++;
      const hours = (new Date(r.completed_at) - new Date(r.created_at)) / (1000 * 60 * 60);
      if (hours >= 0) bucket.durations.push(hours);
    }
  });

  const summary = ['low', 'medium', 'high'].map((level) => {
    const b = byLevel[level];
    const avgHours = b.durations.length ? Math.round((b.durations.reduce((s, h) => s + h, 0) / b.durations.length) * 10) / 10 : null;
    return {
      level,
      total: b.total,
      completed: b.completed,
      completionRate: b.total > 0 ? Math.round((b.completed / b.total) * 1000) / 10 : null,
      avgHoursToComplete: avgHours,
    };
  });

  res.json({ hasEnoughData: true, summary, disclaimer: '依你自己建立任務時標記的精力等級統計，僅供自我觀察參考。' });
});

module.exports = router;
