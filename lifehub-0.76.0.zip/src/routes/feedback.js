// 意見回饋：任何登入的使用者都能送出 (問題回報/建議/其他)，但只有管理者帳號
// (見 src/services/admin.js) 能看到全部人的列表——一般使用者送出後看不到列表，
// 也看不到別人 (或自己) 之前寫過什麼，避免大家的回饋內容互相看得到造成尷尬。
//
// 注意：這支路由沒有在 server.js 用 app.mount() 單獨掛載，而是被 debug.js
// (已掛載在 /api) 合併進去，變成 /api/feedback——因為這個專案的部署流程是把
// zip 內容貼進 GitHub 網頁編輯器，「刻意不去動 server.js」，所以新功能盡量透過
// 擴充已經掛載好的路由檔案來加，不用每次新增功能都要多動一支 server.js。

const { Router } = require('../mini-http');
const { getDb } = require('../services/db');
const { requireAuth } = require('../middleware/auth');
const { isAdminEmail } = require('../services/admin');

const router = Router();

const CATEGORIES = new Set(['bug', 'suggestion', 'other']);

router.post('/feedback', requireAuth, (req, res) => {
  const { message, category } = req.body || {};
  const text = String(message || '').trim();
  if (!text) return res.status(400).json({ error: '請輸入回饋內容' });
  if (text.length > 2000) return res.status(400).json({ error: '內容太長了 (上限 2000 字)' });
  const cat = CATEGORIES.has(category) ? category : 'other';

  const db = getDb();
  const now = new Date().toISOString();
  db.prepare('INSERT INTO feedback (user_id, category, message, created_at) VALUES (?, ?, ?, ?)').run(
    req.session.userId,
    cat,
    text,
    now
  );
  res.json({ ok: true });
});

router.get('/feedback', requireAuth, (req, res) => {
  const db = getDb();
  const me = db.prepare('SELECT email FROM users WHERE id = ?').get(req.session.userId);
  if (!isAdminEmail(me && me.email)) {
    return res.status(403).json({ error: '沒有權限查看' });
  }
  const rows = db
    .prepare(
      `SELECT feedback.id, feedback.category, feedback.message, feedback.created_at,
              users.name AS user_name, users.email AS user_email
       FROM feedback
       JOIN users ON users.id = feedback.user_id
       ORDER BY feedback.id DESC
       LIMIT 500`
    )
    .all();
  res.json({ items: rows });
});

// 刪除單筆回饋：只有管理者能刪 (伺服器端再檢查一次 email，不是只靠前端不顯示刪除鈕)。
// 刪掉的是回饋本身，不影響送出這筆回饋的使用者帳號或其他資料。
router.delete('/feedback/:id', requireAuth, (req, res) => {
  const db = getDb();
  const me = db.prepare('SELECT email FROM users WHERE id = ?').get(req.session.userId);
  if (!isAdminEmail(me && me.email)) {
    return res.status(403).json({ error: '沒有權限刪除' });
  }
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) return res.status(400).json({ error: '無效的 id' });
  const info = db.prepare('DELETE FROM feedback WHERE id = ?').run(id);
  if (info.changes === 0) return res.status(404).json({ error: '找不到這筆回饋 (可能已經被刪過了)' });
  res.json({ ok: true });
});

// v0.63：使用者問「最近這幾天有誰開過這個 App」才發現系統從來沒記錄過登入時間，加了
// last_login_at 欄位 (見 migrations/050、src/routes/auth.js 的 /login) 之後，這裡讓管理者
// 能直接查看清單，不用另外接 DB 工具或用 /api/debug 的 Token 查。放在這支檔案是因為這裡
// 已經有 isAdminEmail 的權限檢查模式可以直接沿用，不用重新寫一套。
router.get('/admin/users', requireAuth, (req, res) => {
  const db = getDb();
  const me = db.prepare('SELECT email FROM users WHERE id = ?').get(req.session.userId);
  if (!isAdminEmail(me && me.email)) {
    return res.status(403).json({ error: '沒有權限查看' });
  }
  // 有登入過的 (last_login_at 不是 NULL) 依最近登入時間排在前面；從來沒登入過的 (帳號建立
  // 在這個功能上線之前、或者從那之後就沒再登入過) 排在最後，用 email 排序讓順序穩定。
  const rows = db
    .prepare('SELECT id, name, email, created_at, last_login_at FROM users ORDER BY (last_login_at IS NULL) ASC, last_login_at DESC, email ASC')
    .all();
  res.json({ items: rows });
});

// v0.64：使用者登入紀錄清單只能一筆一筆看，看不出「這個 App 到底有沒有人在用、用的頻率
// 有沒有在下降」這種趨勢問題。這裡改用 login_events (見 migrations/052) 算「週活躍使用者
// 數」(distinct user_id)，回傳最近 N 週 (預設 12 週) 的週次資料，前端畫成簡單的長條圖。
// 週的切法：以「今天」為基準，往回切成 7 天一組 (不是曆法上的週一到週日，這樣不管哪天看
// 都是「最近 7 天、再前 7 天...」的滾動視窗，比較符合「最近活躍度」的直覺)。
router.get('/admin/usage-stats', requireAuth, (req, res) => {
  const db = getDb();
  const me = db.prepare('SELECT email FROM users WHERE id = ?').get(req.session.userId);
  if (!isAdminEmail(me && me.email)) {
    return res.status(403).json({ error: '沒有權限查看' });
  }
  const WEEKS = 12;
  const now = Date.now();
  const weeks = [];
  for (let i = WEEKS - 1; i >= 0; i--) {
    const end = now - i * 7 * 24 * 60 * 60 * 1000;
    const start = end - 7 * 24 * 60 * 60 * 1000;
    const startIso = new Date(start).toISOString();
    const endIso = new Date(end).toISOString();
    const row = db
      .prepare('SELECT COUNT(DISTINCT user_id) c FROM login_events WHERE created_at >= ? AND created_at < ?')
      .get(startIso, endIso);
    weeks.push({ weekEndingAt: endIso, activeUsers: row ? row.c : 0 });
  }
  const totalUsers = db.prepare('SELECT COUNT(*) c FROM users').get().c;
  const loggedInEver = db.prepare('SELECT COUNT(*) c FROM users WHERE last_login_at IS NOT NULL').get().c;
  res.json({ weeks, totalUsers, loggedInEver });
});

// v0.69：管理者後台獨立成分頁後，最上面加一張「快速摘要」卡片，一眼看到幾個最常想知道的
// 數字 (不用另外展開下面幾張卡片才看得到)：目前帳號數、最近 7 天活躍人數、累積回饋數、
// 待處理的問題回報數 (category = 'bug'，這裡沒有「已處理」狀態欄位，所以只能列出全部
// bug 類回饋的數量，實際上有沒有處理過還是要點進「所有回饋」自己看)。
router.get('/admin/summary', requireAuth, (req, res) => {
  const db = getDb();
  const me = db.prepare('SELECT email FROM users WHERE id = ?').get(req.session.userId);
  if (!isAdminEmail(me && me.email)) {
    return res.status(403).json({ error: '沒有權限查看' });
  }
  const totalUsers = db.prepare('SELECT COUNT(*) c FROM users').get().c;
  const sevenDaysAgoIso = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString();
  const activeUsersLast7Days = db
    .prepare('SELECT COUNT(DISTINCT user_id) c FROM login_events WHERE created_at >= ?')
    .get(sevenDaysAgoIso).c;
  const totalFeedback = db.prepare('SELECT COUNT(*) c FROM feedback').get().c;
  const bugReports = db.prepare("SELECT COUNT(*) c FROM feedback WHERE category = 'bug'").get().c;
  const newUsersLast7Days = db.prepare('SELECT COUNT(*) c FROM users WHERE created_at >= ?').get(sevenDaysAgoIso).c;
  res.json({ totalUsers, activeUsersLast7Days, totalFeedback, bugReports, newUsersLast7Days });
});

// v0.70：任何登入的使用者切分頁時，前端會呼叫這支路由記一筆「切去哪個分頁」
// (見 migrations/058 的 tab_usage_events)，只記分頁名稱跟時間，不記分頁裡實際做了什麼，
// 讓管理者後台能看「這週熱門功能」。刻意用 fire-and-forget 的方式呼叫 (前端不等回應)，
// 就算這支路由暫時失敗也不該影響使用者正常切分頁，所以這裡也不回傳太多內容、失敗了
// 前端也不會特別提示錯誤。
const VALID_TAB_PATTERN = /^[a-zA-Z0-9_-]{1,40}$/;
router.post('/tab-usage', requireAuth, (req, res) => {
  const tab = req.body && req.body.tab;
  if (!tab || !VALID_TAB_PATTERN.test(String(tab))) {
    return res.status(400).json({ error: '無效的分頁名稱' });
  }
  const db = getDb();
  db.prepare('INSERT INTO tab_usage_events (user_id, tab, created_at) VALUES (?, ?, ?)').run(
    req.session.userId,
    String(tab),
    new Date().toISOString()
  );
  // 這張表只用來看「最近一段時間的相對熱門程度」，不需要無限保留，順手只留最近 90 天，
  // 避免長期使用後這張表無限增長 (跟 app_logs 只留最近 500 筆是類似的考量，只是這裡用
  // 時間而不是筆數當保留條件，因為使用量本來就會隨使用者數增加而變多)。
  db.prepare("DELETE FROM tab_usage_events WHERE created_at < ?").run(
    new Date(Date.now() - 90 * 24 * 60 * 60 * 1000).toISOString()
  );
  res.json({ ok: true });
});

// v0.70：管理者後台新增「錯誤日誌摘要」——直接從 app_logs 抓最近幾筆 level='error' 的
// 紀錄，不用再另外開 /api/debug 貼 X-Debug-Token 才看得到，比較順手。
router.get('/admin/error-logs', requireAuth, (req, res) => {
  const db = getDb();
  const me = db.prepare('SELECT email FROM users WHERE id = ?').get(req.session.userId);
  if (!isAdminEmail(me && me.email)) {
    return res.status(403).json({ error: '沒有權限查看' });
  }
  const rows = db
    .prepare("SELECT level, message, meta_json, created_at FROM app_logs WHERE level = 'error' ORDER BY id DESC LIMIT 20")
    .all();
  res.json({ items: rows });
});

// v0.70：管理者後台新增「這週熱門功能」——統計最近 7 天每個分頁被切換的次數，由多到少
// 排序，讓你看得出哪些功能做了卻幾乎沒人用、哪些是大家常用的核心功能。用 distinct user_id
// 算「有幾個不同的人用過」，另外也給總次數，兩個角度互補 (次數高但只有 1 個人用，跟次數
// 普通但很多人都用過，代表的意義不一樣)。
router.get('/admin/feature-usage', requireAuth, (req, res) => {
  const db = getDb();
  const me = db.prepare('SELECT email FROM users WHERE id = ?').get(req.session.userId);
  if (!isAdminEmail(me && me.email)) {
    return res.status(403).json({ error: '沒有權限查看' });
  }
  const sevenDaysAgoIso = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString();
  const rows = db
    .prepare(
      `SELECT tab, COUNT(*) AS totalSwitches, COUNT(DISTINCT user_id) AS uniqueUsers
       FROM tab_usage_events
       WHERE created_at >= ?
       GROUP BY tab
       ORDER BY totalSwitches DESC`
    )
    .all(sevenDaysAgoIso);
  res.json({ items: rows, sinceIso: sevenDaysAgoIso });
});

module.exports = router;
