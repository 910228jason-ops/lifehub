const { Router } = require('../mini-http');
const { getDb } = require('../services/db');
const { requireAuth } = require('../middleware/auth');

const router = Router();

// 把資料庫存的 JSON 字串 tags 解回陣列，順便把「心情模組實際記錄的分數」(mood_entries，
// 跟日記自己的 mood 欄位是分開的兩份資料) 一起帶出來，讓日記列表可以直接顯示情緒關聯，
// 不用另外呼叫心情模組的 API 再自己比對日期。
function attachMoodAndTags(rows, db, userId) {
  if (!rows.length) return rows;
  const dates = [...new Set(rows.map((r) => r.entry_date))];
  const placeholders = dates.map(() => '?').join(',');
  const moodRows = db
    .prepare(`SELECT entry_date, score FROM mood_entries WHERE user_id = ? AND entry_date IN (${placeholders})`)
    .all(userId, ...dates);
  const moodByDate = new Map(moodRows.map((m) => [m.entry_date, m.score]));
  return rows.map((r) => ({
    ...r,
    tags: r.tags ? JSON.parse(r.tags) : [],
    moodScore: moodByDate.has(r.entry_date) ? moodByDate.get(r.entry_date) : null,
  }));
}

router.get('/', requireAuth, (req, res) => {
  const db = getDb();
  const { from, to, q, tag } = req.query;
  const clauses = ['user_id = ?'];
  const params = [req.session.userId];
  if (from && to) {
    clauses.push('entry_date BETWEEN ? AND ?');
    params.push(from, to);
  }
  if (q && q.trim()) {
    clauses.push('content LIKE ?');
    params.push(`%${q.trim()}%`);
  }
  if (tag && tag.trim()) {
    // tags 存成 JSON 陣列字串 (例如 '["工作","旅行"]')，用 LIKE 比對標籤名稱本身即可，
    // 資料量不大不需要為此正規化成獨立的標籤表。
    clauses.push('tags LIKE ?');
    params.push(`%"${tag.trim()}"%`);
  }
  const limitClause = from && to ? '' : ' LIMIT 100';
  const rows = db
    .prepare(`SELECT * FROM diary_entries WHERE ${clauses.join(' AND ')} ORDER BY entry_date DESC${limitClause}`)
    .all(...params);
  res.json(attachMoodAndTags(rows, db, req.session.userId));
});

// v0.68：#6 日記關鍵字/人物頻率分析——非 AI 的純統計，不做語意理解：
//   1. 人物：直接比對「人際關係」清單裡每個人的姓名在日記內容中出現的次數，這個最準確。
//   2. 關鍵字：中文沒有空白分詞，這裡沒有斷詞函式庫，改用「連續 2 個字」(bigram) 出現頻率
//      當作近似的關鍵字統計，濾掉常見的虛詞/標點組合，抓出出現次數最高的前幾組，
//      當作「這段時間常提到的詞」的粗略參考，不是精準的關鍵字抽取。
// 注意：這支路由必須註冊在 GET /:date 之前——mini-http 是照註冊順序、依「同樣的路徑
// 片段數」比對，先註冊的 /:date 會把 /keyword-frequency 誤判成 date 參數吃掉。
const STOPWORD_BIGRAMS = new Set([
  '的是', '是我', '我的', '了一', '一個', '一下', '這個', '那個', '因為', '所以', '但是',
  '今天', '昨天', '明天', '還是', '可以', '不會', '不是', '就是', '有點', '覺得', '一直',
  '真的', '什麼', '這樣', '那樣', '之後', '之前', '現在', '自己', '沒有', '應該',
]);
router.get('/keyword-frequency', requireAuth, (req, res) => {
  const db = getDb();
  const userId = req.session.userId;
  const n = Math.min(Math.max(Number(req.query.days) || 90, 1), 365);
  const since = new Date();
  since.setDate(since.getDate() - n);
  const sinceStr = since.toISOString().slice(0, 10);
  const rows = db.prepare('SELECT content FROM diary_entries WHERE user_id = ? AND entry_date >= ?').all(userId, sinceStr);

  if (rows.length < 3) {
    return res.json({ hasEnoughData: false, note: '日記紀錄還不夠多 (至少需要 3 篇)，先多寫幾篇再回來看。' });
  }

  const people = db.prepare('SELECT id, name FROM relationships WHERE user_id = ?').all(userId);
  const peopleCounts = people
    .map((p) => {
      const re = new RegExp(p.name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g');
      let count = 0;
      rows.forEach((r) => { count += ((r.content || '').match(re) || []).length; });
      return { id: p.id, name: p.name, count };
    })
    .filter((p) => p.count > 0)
    .sort((a, b) => b.count - a.count)
    .slice(0, 10);

  const bigramCounts = new Map();
  const CJK_RE = /[一-鿿]/;
  rows.forEach((r) => {
    const content = (r.content || '').replace(/\s+/g, '');
    for (let i = 0; i < content.length - 1; i++) {
      const bg = content.slice(i, i + 2);
      if (!CJK_RE.test(bg[0]) || !CJK_RE.test(bg[1])) continue;
      if (STOPWORD_BIGRAMS.has(bg)) continue;
      bigramCounts.set(bg, (bigramCounts.get(bg) || 0) + 1);
    }
  });
  const keywords = [...bigramCounts.entries()]
    .filter(([, c]) => c >= 2)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 15)
    .map(([word, count]) => ({ word, count }));

  res.json({
    hasEnoughData: true,
    entryCount: rows.length,
    people: peopleCounts,
    keywords,
    disclaimer: '關鍵字是用「連續兩個字」出現頻率做的粗略統計，不是語意分析，僅供參考。',
  });
});

router.get('/:date', requireAuth, (req, res) => {
  const db = getDb();
  const row = db
    .prepare('SELECT * FROM diary_entries WHERE user_id = ? AND entry_date = ?')
    .get(req.session.userId, req.params.date);
  if (!row) return res.json(null);
  res.json(attachMoodAndTags([row], db, req.session.userId)[0]);
});

router.put('/:date', requireAuth, (req, res) => {
  const { content, mood, tags } = req.body || {};
  const tagsJson = Array.isArray(tags)
    ? JSON.stringify(tags.filter((t) => t && String(t).trim()).map((t) => String(t).trim()))
    : null;
  const db = getDb();
  const now = new Date().toISOString();
  const existing = db
    .prepare('SELECT id FROM diary_entries WHERE user_id = ? AND entry_date = ?')
    .get(req.session.userId, req.params.date);

  if (existing) {
    db.prepare('UPDATE diary_entries SET content = ?, mood = ?, tags = ?, updated_at = ? WHERE id = ?').run(
      content || '',
      mood || null,
      tagsJson,
      now,
      existing.id
    );
  } else {
    db.prepare(
      'INSERT INTO diary_entries (user_id, entry_date, content, mood, tags, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)'
    ).run(req.session.userId, req.params.date, content || '', mood || null, tagsJson, now, now);
    // 遊戲化點數：只在「新增一篇日記」時加點 (不是每次編輯都加)，日記本來就是一天一篇，
    // 這裡的 !existing 剛好等於「今天第一次寫」，不需要額外的節流邏輯。
    if (content && content.trim()) {
      require('../services/points').awardPoints(db, req.session.userId, 3, 'diary');
    }
  }
  res.json({ ok: true });
});

router.delete('/:date', requireAuth, (req, res) => {
  const db = getDb();
  db.prepare('DELETE FROM diary_entries WHERE user_id = ? AND entry_date = ?').run(
    req.session.userId,
    req.params.date
  );
  res.json({ ok: true });
});

// 從本機文字檔匯入日記 (前端以 <input type="file"> 讀取內容後以純文字 POST 上來，
// 這裡只負責寫入指定日期，避免在伺服器端直接存取使用者電腦檔案系統)
router.post('/import', requireAuth, (req, res) => {
  const { date, content } = req.body || {};
  if (!date || typeof content !== 'string') return res.status(400).json({ error: '缺少 date 或 content' });
  const db = getDb();
  const now = new Date().toISOString();
  const existing = db
    .prepare('SELECT id FROM diary_entries WHERE user_id = ? AND entry_date = ?')
    .get(req.session.userId, date);
  if (existing) {
    db.prepare('UPDATE diary_entries SET content = ?, updated_at = ? WHERE id = ?').run(content, now, existing.id);
  } else {
    db.prepare(
      'INSERT INTO diary_entries (user_id, entry_date, content, created_at, updated_at) VALUES (?, ?, ?, ?, ?)'
    ).run(req.session.userId, date, content, now, now);
  }
  res.json({ ok: true });
});

module.exports = router;
