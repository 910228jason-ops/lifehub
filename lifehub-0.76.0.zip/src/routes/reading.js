// 讀書分類：閱讀/戲劇進度追蹤 (v0.44)。書跟戲劇/影集共用同一張表 (type 欄位區分)，
// 因為需要記錄的欄位其實一樣：標題、狀態 (想看/在看/看完)、進度 (第幾集/第幾頁，自由文字，
// 不同媒介的「進度」單位差異太大，用自由文字比硬做成數字欄位實用)、評分、心得。

const { Router } = require('../mini-http');
const { getDb } = require('../services/db');
const { requireAuth } = require('../middleware/auth');

const router = Router();
const VALID_TYPES = ['book', 'drama'];
const VALID_STATUSES = ['want', 'in_progress', 'done'];

router.get('/reading', requireAuth, (req, res) => {
  const db = getDb();
  const { status, type } = req.query;
  const clauses = ['user_id = ?'];
  const params = [req.session.userId];
  if (status && VALID_STATUSES.includes(status)) { clauses.push('status = ?'); params.push(status); }
  if (type && VALID_TYPES.includes(type)) { clauses.push('type = ?'); params.push(type); }
  const rows = db
    .prepare(`SELECT * FROM reading_items WHERE ${clauses.join(' AND ')} ORDER BY updated_at DESC`)
    .all(...params);
  res.json(rows);
});

router.post('/reading', requireAuth, (req, res) => {
  const { type, title, status, progress, rating, note } = req.body || {};
  const trimmedTitle = String(title || '').trim();
  if (!trimmedTitle) return res.status(400).json({ error: '請輸入書名/劇名' });
  const finalType = VALID_TYPES.includes(type) ? type : 'book';
  const finalStatus = VALID_STATUSES.includes(status) ? status : 'want';
  const ratingNum = rating != null && rating !== '' ? Number(rating) : null;
  if (ratingNum != null && (!Number.isInteger(ratingNum) || ratingNum < 1 || ratingNum > 5)) {
    return res.status(400).json({ error: '評分必須是 1-5 的整數' });
  }
  const db = getDb();
  const now = new Date().toISOString();
  const result = db
    .prepare('INSERT INTO reading_items (user_id, type, title, status, progress, rating, note, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)')
    .run(req.session.userId, finalType, trimmedTitle, finalStatus, progress || null, ratingNum, note || null, now, now);
  res.json({ id: result.lastInsertRowid });
});

router.put('/reading/:id', requireAuth, (req, res) => {
  const db = getDb();
  const item = db.prepare('SELECT * FROM reading_items WHERE id = ? AND user_id = ?').get(req.params.id, req.session.userId);
  if (!item) return res.status(404).json({ error: '找不到這筆紀錄' });
  const { type, title, status, progress, rating, note } = req.body || {};
  const trimmedTitle = title != null ? String(title).trim() : item.title;
  if (!trimmedTitle) return res.status(400).json({ error: '書名/劇名不能空白' });
  const finalType = VALID_TYPES.includes(type) ? type : item.type;
  const finalStatus = VALID_STATUSES.includes(status) ? status : item.status;
  const ratingNum = rating != null && rating !== '' ? Number(rating) : null;
  if (ratingNum != null && (!Number.isInteger(ratingNum) || ratingNum < 1 || ratingNum > 5)) {
    return res.status(400).json({ error: '評分必須是 1-5 的整數' });
  }
  db.prepare(
    'UPDATE reading_items SET type = ?, title = ?, status = ?, progress = ?, rating = ?, note = ?, updated_at = ? WHERE id = ?'
  ).run(finalType, trimmedTitle, finalStatus, progress || null, ratingNum, note || null, new Date().toISOString(), item.id);
  res.json({ ok: true });
});

router.delete('/reading/:id', requireAuth, (req, res) => {
  const db = getDb();
  db.prepare('DELETE FROM reading_items WHERE id = ? AND user_id = ?').run(req.params.id, req.session.userId);
  res.json({ ok: true });
});

// v0.68：#8 閱讀進度停滯偵測——「在看」狀態、但超過一段時間沒有更新 (updated_at 太舊)
// 的書/劇，列出來提醒使用者可能忘記了，或者可以考慮暫停/放棄，決定權還是在使用者自己。
// 注意：這支必須註冊在 GET /reading (列表) 之後就好，不會跟 PUT/DELETE /reading/:id 衝突
// (不同 HTTP method 不會互相搶路由)，但路徑本身要帶 /reading 前綴，這個檔案裡的路由都是掛在
// debug.js 合併進 /api 的同一個 router，不是獨立掛在 /api/reading 底下。
router.get('/reading/stagnant', requireAuth, (req, res) => {
  const db = getDb();
  const rawDays = Number(req.query.days);
  const thresholdDays = Math.min(Math.max(Number.isFinite(rawDays) ? rawDays : 14, 0), 180);
  const rows = db
    .prepare("SELECT * FROM reading_items WHERE user_id = ? AND status = 'in_progress' ORDER BY updated_at ASC")
    .all(req.session.userId);
  const now = Date.now();
  const stagnant = rows
    .map((r) => ({ ...r, daysSinceUpdate: Math.floor((now - new Date(r.updated_at).getTime()) / 86400000) }))
    .filter((r) => r.daysSinceUpdate >= thresholdDays);
  res.json({ thresholdDays, items: stagnant });
});

module.exports = router;
