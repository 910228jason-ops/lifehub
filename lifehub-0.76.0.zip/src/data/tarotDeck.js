// 塔羅牌 78 張牌卡資料 (v0.70)。刻意做成純靜態資料、不接任何外部 API——
// 抽牌本身只是從這個陣列裡隨機挑一張 (加上是否逆位)，牌義文字也是寫死在這裡，
// 這樣「占卜」這個功能才能跟專案裡其他功能一樣做到零外部依賴、離線也能用。
//
// 結構：22 張大阿爾克那 (Major Arcana，編號 0-21) + 56 張小阿爾克那 (Minor Arcana，
// 權杖/聖杯/寶劍/錢幣四個花色，每個花色 Ace-10 + 侍者/騎士/皇后/國王 共 14 張)。
// 每張牌都有 key (唯一代碼)、name (中文牌名)、arcana ('major'/'minor')、
// upright { keyword, meaning }、reversed { keyword, meaning }。

const MAJOR_ARCANA = [
  { key: 'major-00', name: '愚人 The Fool', upright: { keyword: '冒險、新開始', meaning: '象徵未知的旅程即將展開，帶著初心與信任跨出第一步，先別想太多後果，勇敢嘗試。' }, reversed: { keyword: '魯莽、猶豫', meaning: '可能因為想太多而不敢行動，或是相反地衝動行事沒做好準備，提醒你先評估風險。' } },
  { key: 'major-01', name: '魔術師 The Magician', upright: { keyword: '創造、資源整合', meaning: '你手邊已經有需要的工具跟能力，只是還沒把它們整合起來，現在是主動出擊、化想法為行動的時機。' }, reversed: { keyword: '欺瞞、資源浪費', meaning: '可能有能力沒發揮，或是用手段操弄局面，提醒你檢視自己是否誠實面對目標。' } },
  { key: 'major-02', name: '女祭司 The High Priestess', upright: { keyword: '直覺、潛意識', meaning: '答案不在外面，而在你內心深處，這張牌鼓勵你安靜下來，相信自己的直覺與內在智慧。' }, reversed: { keyword: '忽視直覺、資訊隱瞞', meaning: '可能有些事情被隱藏或你選擇忽略內心的聲音，提醒你重新誠實面對自己真正的感受。' } },
  { key: 'major-03', name: '皇后 The Empress', upright: { keyword: '豐盛、滋養', meaning: '代表創造力、滋養與豐收，適合投入需要耐心培養的事情，也提醒你多照顧自己與身邊的人。' }, reversed: { keyword: '過度付出、停滯', meaning: '可能因為過度付出而忽略自己，或創造力/計畫暫時卡住，需要重新找回平衡。' } },
  { key: 'major-04', name: '皇帝 The Emperor', upright: { keyword: '秩序、掌控', meaning: '象徵結構、紀律與領導力，適合建立規則、訂定計畫，用穩定的方式掌握局面。' }, reversed: { keyword: '固執、失控', meaning: '可能太想控制一切反而僵化，或是相反地失去主導權，提醒你檢視自己是不是抓太緊了。' } },
  { key: 'major-05', name: '教皇 The Hierophant', upright: { keyword: '傳統、指引', meaning: '代表傳統智慧、體制內的建議或值得信任的導師，這時適合遵循既有的方法或尋求前輩意見。' }, reversed: { keyword: '打破常規、質疑權威', meaning: '可能想挑戰既有規則、走自己的路，或是對傳統的建議感到不認同，提醒你找到適合自己的方式。' } },
  { key: 'major-06', name: '戀人 The Lovers', upright: { keyword: '選擇、連結', meaning: '象徵重要的關係或抉擇，通常跟價值觀的一致有關，提醒你誠實面對自己真正想要的是什麼。' }, reversed: { keyword: '失衡、猶豫不決', meaning: '關係可能出現裂痕，或是面對選擇時遲遲下不了決定，值得重新檢視雙方是否還在同一條路上。' } },
  { key: 'major-07', name: '戰車 The Chariot', upright: { keyword: '意志、前進', meaning: '代表憑著堅定意志力克服阻礙、向前衝刺，這是行動力很強的一張牌，適合把握機會全力以赴。' }, reversed: { keyword: '失控、方向不明', meaning: '可能用力過猛卻找不到方向，或是內外拉扯讓你動彈不得，提醒你先釐清目標再出發。' } },
  { key: 'major-08', name: '力量 Strength', upright: { keyword: '溫柔的堅韌', meaning: '真正的力量不是蠻幹，而是用耐心、同理與內在的柔軟去化解困難，相信自己可以撐過去。' }, reversed: { keyword: '自我懷疑、耗竭', meaning: '可能對自己失去信心，或長期硬撐已經耗盡能量，提醒你先照顧好自己再談其他事。' } },
  { key: 'major-09', name: '隱士 The Hermit', upright: { keyword: '沉澱、內省', meaning: '適合暫時抽離人群，給自己一段安靜獨處的時間，答案往往在向內探索之後才會浮現。' }, reversed: { keyword: '孤立、逃避', meaning: '獨處可能變成過度封閉自己、逃避該面對的人事物，提醒你留意跟外界失聯太久了。' } },
  { key: 'major-10', name: '命運之輪 Wheel of Fortune', upright: { keyword: '轉變、機運', meaning: '代表事情正在轉向一個新的階段，變化可能突如其來，但整體方向是往前推進的，順勢而為即可。' }, reversed: { keyword: '停滯、外力干擾', meaning: '可能感覺運氣不站在自己這邊，或計畫被外在因素打斷，提醒你耐心等待下一輪轉機。' } },
  { key: 'major-11', name: '正義 Justice', upright: { keyword: '公平、因果', meaning: '代表理性判斷、承擔責任與因果報應，這個時候適合做出公正、經得起檢驗的決定。' }, reversed: { keyword: '不公、逃避責任', meaning: '可能感覺被不公平對待，或是自己在逃避該負的責任，提醒你重新檢視事情的來龍去脈。' } },
  { key: 'major-12', name: '倒吊人 The Hanged Man', upright: { keyword: '換個角度、暫停', meaning: '鼓勵你先停下腳步，用不同的角度看待目前的處境，有些犧牲或等待其實是必要的過渡。' }, reversed: { keyword: '拖延、抗拒改變', meaning: '可能一直原地打轉、不願意換個角度思考，提醒你太久的停滯可能只是在逃避該做的改變。' } },
  { key: 'major-13', name: '死神 Death', upright: { keyword: '結束、轉化', meaning: '象徵一個階段真正的結束，才能讓新的階段開始，雖然聽起來沉重，但通常代表必要的蛻變。' }, reversed: { keyword: '抗拒結束、拖泥帶水', meaning: '可能明明該放下的事還緊抓著不放，讓自己一直卡在舊的階段走不出來。' } },
  { key: 'major-14', name: '節制 Temperance', upright: { keyword: '平衡、調和', meaning: '代表耐心地把不同的元素調和在一起，適合用溫和、循序漸進的方式處理事情，而不是走極端。' }, reversed: { keyword: '失衡、過猶不及', meaning: '生活的某個部分可能太過或太少，提醒你重新找回中庸、平衡的步調。' } },
  { key: 'major-15', name: '惡魔 The Devil', upright: { keyword: '束縛、慾望', meaning: '提醒你留意讓自己深陷其中、難以自拔的習慣或關係，這些束縛往往是自己選擇留下的。' }, reversed: { keyword: '掙脫束縛、覺察', meaning: '代表你開始意識到某個讓你受困的模式，並且有機會慢慢掙脫它，是很好的覺察時機。' } },
  { key: 'major-16', name: '高塔 The Tower', upright: { keyword: '劇變、崩解', meaning: '代表突如其來、無法迴避的變動，雖然過程震撼，但往往是打破不再適用的舊有結構的必經之路。' }, reversed: { keyword: '延遲的崩解、恐懼改變', meaning: '可能一直害怕面對即將發生的變動，或是把該處理的問題一直往後拖延，反而累積更大的風險。' } },
  { key: 'major-17', name: '星星 The Star', upright: { keyword: '希望、療癒', meaning: '在經歷風雨之後，這是一張帶來希望與平靜的牌，提醒你相信情況正在慢慢好轉。' }, reversed: { keyword: '失望、信心不足', meaning: '可能暫時感覺不到希望、對未來失去信心，提醒你給自己多一點耐心，光還在，只是還沒亮起來。' } },
  { key: 'major-18', name: '月亮 The Moon', upright: { keyword: '不安、潛意識', meaning: '代表模糊不清、帶點焦慮的階段，很多事情還看不清楚真相，這時候直覺比邏輯更值得參考。' }, reversed: { keyword: '真相浮現、走出困惑', meaning: '原本混沌不明的狀況開始逐漸明朗，提醒你即將看清楚原本被隱藏或誤解的真相。' } },
  { key: 'major-19', name: '太陽 The Sun', upright: { keyword: '喜悅、成功', meaning: '代表明朗、正向、順遂的能量，通常是很好的牌，適合大方展現自己、享受這段順利的時光。' }, reversed: { keyword: '暫時的低潮、過度樂觀', meaning: '原本該有的好心情被烏雲暫時遮蔽，或是太過樂觀而忽略了該注意的細節。' } },
  { key: 'major-20', name: '審判 Judgement', upright: { keyword: '覺醒、重生', meaning: '代表一次重要的自我檢視與覺醒，過去的經驗被重新看見意義，適合做出一個關鍵的決定並向前邁進。' }, reversed: { keyword: '自我懷疑、逃避檢視', meaning: '可能還沒準備好面對真實的自己，或是對過去的選擇感到懊悔卻遲遲無法放下。' } },
  { key: 'major-21', name: '世界 The World', upright: { keyword: '完成、圓滿', meaning: '代表一個階段圓滿落幕，過去的努力終於有了成果，也是準備好迎接下一段新旅程的時刻。' }, reversed: { keyword: '未竟之事、延遲完成', meaning: '事情可能還差臨門一腳沒有真正完成，提醒你不要在最後階段鬆懈，好好收尾。' } },
];

// 小阿爾克那：四個花色各有自己的核心主題，1-10 號 (數字牌) 用「花色主題 + 數字階段」
// 組合出牌義，宮廷牌 (侍者/騎士/皇后/國王) 則用「花色主題 + 這個角色的個性」組合，
// 這樣 56 張牌義都是有系統、不是隨便寫的，同時避免要手刻 56 段完全獨立的文案。
const SUITS = [
  { key: 'wands', name: '權杖', theme: '行動力、熱情、事業與創意上的衝勁' },
  { key: 'cups', name: '聖杯', theme: '情感、關係、內心的感受與連結' },
  { key: 'swords', name: '寶劍', theme: '思緒、溝通、衝突與理性判斷' },
  { key: 'pentacles', name: '錢幣', theme: '物質、金錢、健康與實際生活層面' },
];

const NUMBER_STAGES = [
  null, // 佔位，index 對齊 1-10
  { name: '王牌 Ace', upKeyword: '新的開始', up: '一個全新的契機正要萌芽，帶著最純粹的能量出現，適合把握這股初始的動力。', downKeyword: '錯失機會、遲疑', down: '機會可能已經出現卻沒被把握住，或是心裡還沒準備好接住這個新的開始。' },
  { name: '二', upKeyword: '抉擇、夥伴關係', up: '通常牽涉到兩股力量的協調，可能是合作、平衡或是一個需要做決定的分岔路口。', downKeyword: '猶豫不決、失衡', down: '在兩個選項之間拉扯不下，或是原本該平衡的關係/資源出現傾斜。' },
  { name: '三', upKeyword: '成長、初步成果', up: '前期的努力開始看到一點成果，也可能代表團隊合作或群體支持帶來的正向發展。', downKeyword: '延遲、合作出狀況', down: '原本該有的進展慢了下來，或是合作/群體中出現摩擦，需要重新協調。' },
  { name: '四', upKeyword: '穩定、暫歇', up: '代表一個相對穩定、可以喘口氣的階段，適合鞏固現有的成果，享受階段性的安穩。', downKeyword: '停滯太久、無聊', down: '安穩久了可能變成無趣或停滯不前，提醒你留意是不是該找點新的刺激或動力。' },
  { name: '五', upKeyword: '衝突、挑戰', up: '出現需要面對的競爭、衝突或挑戰，雖然不舒服，但也是釐清真正想要什麼的過程。', downKeyword: '衝突升溫或和解', down: '衝突可能持續延燒到難以收拾，也可能代表你正在學習從紛爭中找到和解的方法，需視情境判斷。' },
  { name: '六', upKeyword: '恢復、支持', up: '經歷過前面的挑戰後，事情開始朝正向恢復，也可能得到來自他人的支持與協助。', downKeyword: '重蹈覆轍、拒絕幫助', down: '可能不自覺又走回舊有的困境，或是明明有人願意幫忙卻拒絕接受。' },
  { name: '七', upKeyword: '堅持、評估', up: '需要在過程中重新評估策略，同時也考驗你是否有耐心繼續堅持下去。', downKeyword: '放棄太早、力不從心', down: '可能因為壓力太大而想放棄，或是感覺自己已經沒有足夠的力氣繼續撐下去。' },
  { name: '八', upKeyword: '快速推進、行動', up: '事情正在加速前進，訊息、機會或行動一件接一件到來，適合順勢加快腳步。', downKeyword: '延誤、方向混亂', down: '原本該加速的事情卻卡住了，或是行動太快反而讓方向變得混亂，需要重新聚焦。' },
  { name: '九', upKeyword: '接近完成、韌性', up: '已經走到接近終點的階段，過程雖然辛苦，但也累積出足夠的韌性去撐到最後。', downKeyword: '身心俱疲、過度防備', down: '長期的堅持讓你身心俱疲，或是因為受過傷而過度防備，難以真正放鬆下來。' },
  { name: '十', upKeyword: '完成、階段結尾', up: '代表一個循環走到了盡頭，該經歷的都經歷了，準備好進入下一個全新的階段。', downKeyword: '負擔過重、拖延收尾', down: '可能揹負了超出負荷的責任，或是明明該結束的事情卻遲遲沒有真正收尾。' },
];

const COURT_CARDS = [
  { key: 'page', name: '侍者 Page', upKeyword: '學習、初心者', up: '代表帶著好奇心與初學者心態去探索這個花色代表的領域，適合保持開放、勇於嘗試。', downKeyword: '不成熟、三分鐘熱度', down: '可能因為經驗不足而做出不夠周全的判斷，或是對新事物只有一時的熱情。' },
  { key: 'knight', name: '騎士 Knight', upKeyword: '行動、追求', up: '代表朝著目標積極行動、勇往直前，帶著這個花色的能量全力衝刺。', downKeyword: '衝動、魯莽', down: '行動力用錯地方，變成衝動行事、欠缺考慮後果，容易把事情搞砸。' },
  { key: 'queen', name: '皇后 Queen', upKeyword: '成熟、內化的智慧', up: '代表已經把這個花色代表的特質內化成熟，能夠用溫和而堅定的方式運用這股能量照顧自己與他人。', downKeyword: '情緒化、過度付出', down: '可能因為太在意他人感受而委屈自己，或是被情緒主導了原本該有的判斷力。' },
  { key: 'king', name: '國王 King', upKeyword: '掌握、權威', up: '代表對這個花色代表的領域已經有純熟的掌控力，能夠有智慧、有紀律地運用這股力量。', downKeyword: '獨裁、濫用權力', down: '可能太執著於掌控一切，用強硬甚至不合理的方式對待身邊的人或事。' },
];

function buildMinorArcana() {
  const cards = [];
  SUITS.forEach((suit) => {
    for (let n = 1; n <= 10; n++) {
      const stage = NUMBER_STAGES[n];
      cards.push({
        key: `minor-${suit.key}-${n}`,
        name: `${suit.name}${stage.name}`,
        upright: { keyword: stage.upKeyword, meaning: `【${suit.theme}】${stage.up}` },
        reversed: { keyword: stage.downKeyword, meaning: `【${suit.theme}】${stage.down}` },
      });
    }
    COURT_CARDS.forEach((court) => {
      cards.push({
        key: `minor-${suit.key}-${court.key}`,
        name: `${suit.name}${court.name}`,
        upright: { keyword: court.upKeyword, meaning: `【${suit.theme}】${court.up}` },
        reversed: { keyword: court.downKeyword, meaning: `【${suit.theme}】${court.down}` },
      });
    });
  });
  return cards;
}

const TAROT_DECK = [
  ...MAJOR_ARCANA.map((c) => ({ ...c, arcana: 'major' })),
  ...buildMinorArcana().map((c) => ({ ...c, arcana: 'minor' })),
];

// 保險起見在載入時檢查一次張數跟 key 不重複，78 張牌任何一張錯了都會在啟動時就發現，
// 不會等到使用者實際抽到那張牌才發現資料有問題。
if (TAROT_DECK.length !== 78) {
  throw new Error(`塔羅牌資料張數不對，應該是 78 張，實際是 ${TAROT_DECK.length} 張`);
}
const seenKeys = new Set();
TAROT_DECK.forEach((c) => {
  if (seenKeys.has(c.key)) throw new Error(`塔羅牌資料有重複的 key: ${c.key}`);
  seenKeys.add(c.key);
});

function getCardByKey(key) {
  return TAROT_DECK.find((c) => c.key === key) || null;
}

module.exports = { TAROT_DECK, getCardByKey };
