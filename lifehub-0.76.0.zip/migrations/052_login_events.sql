-- v0.64：users.last_login_at (v0.63) 只存「最後一次」登入時間，沒辦法回答「每週有幾個人
-- 在用」這種隨時間變化的問題。新增 login_events 記錄每一次登入 (只存 user_id + 時間)，
-- 用來算週活躍使用者數，讓管理者儀表板能看趨勢而不是只看單一時間點的清單。
CREATE TABLE IF NOT EXISTS login_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_login_events_created_at ON login_events (created_at);
CREATE INDEX IF NOT EXISTS idx_login_events_user_id ON login_events (user_id);
