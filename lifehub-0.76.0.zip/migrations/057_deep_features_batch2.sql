-- v0.68.0：第二批 14 個深度功能所需的最小 schema 異動。
-- 大多數新功能都是純統計端點、不需要新欄位；這裡只加真的需要持久化的三件事：
--   1. kanban_cards.assignee_user_id：專案看板卡片可以指派給自己或已連結的家人/伴侶，
--      用來統計「家庭看板任務公平性」(誰做了多少)。
--   2. wishlist_items.goal_id：願望清單項目可以連結一個財務目標，估算大概何時存得到。
--   3. notification_send_log：記錄每一次真的送出的推播內容「類型」，用來回頭比對使用者
--      有沒有因此採取行動 (完成任務/繳帳單/記心情...)，算出「通知有效性」。

ALTER TABLE kanban_cards ADD COLUMN assignee_user_id INTEGER;
ALTER TABLE wishlist_items ADD COLUMN goal_id INTEGER REFERENCES finance_goals(id) ON DELETE SET NULL;

CREATE TABLE IF NOT EXISTS notification_send_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type TEXT NOT NULL,
  sent_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_notification_send_log_user_type ON notification_send_log(user_id, type, sent_at);
