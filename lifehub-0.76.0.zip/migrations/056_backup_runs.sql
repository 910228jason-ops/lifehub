-- v0.67：資料自動備份排程——記錄「哪個月份已經自動備份過」，避免伺服器重開機/多次檢查
-- 時重複備份同一個月份。run_period 是 YYYY-MM，一個月只會有一筆紀錄。
CREATE TABLE IF NOT EXISTS backup_runs (
  run_period TEXT PRIMARY KEY,
  ran_at TEXT NOT NULL,
  user_count INTEGER NOT NULL DEFAULT 0
);
