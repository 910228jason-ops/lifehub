-- v0.62：熱門關鍵字 chip 原本是寫死的固定清單，使用者希望改成「真的統計出來的」。
-- 這裡新增一張表記錄每一次關鍵字搜尋 (「臨時揪一波」跟「地點資料庫」都算)，之後
-- GET /places/popular-keywords 從這張表統計出現次數最多的關鍵字，取代/補充寫死的清單。
-- 只存關鍵字文字本身 + 是誰搜的 + 時間，不存搜尋結果，資料量小、也沒有敏感資訊。
CREATE TABLE IF NOT EXISTS place_keyword_searches (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  keyword TEXT NOT NULL,
  user_id INTEGER,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_place_keyword_searches_keyword ON place_keyword_searches(keyword);
CREATE INDEX IF NOT EXISTS idx_place_keyword_searches_created_at ON place_keyword_searches(created_at);
