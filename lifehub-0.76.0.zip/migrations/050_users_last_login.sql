-- v0.63：使用者問「最近這幾天有誰開過這個 App」，才發現系統從來沒有記錄過登入時間，
-- 完全答不出來。加這個欄位之後，每次登入成功就更新一次 (見 src/routes/auth.js 的 /login)，
-- 之後才有辦法回答這種問題。這個功能沒辦法回溯過去——加上去的當下，所有既有帳號的
-- last_login_at 都是 NULL，只有從現在開始的登入才會被記錄下來。
ALTER TABLE users ADD COLUMN last_login_at TEXT;
