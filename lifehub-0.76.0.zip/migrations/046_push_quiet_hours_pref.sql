-- v0.58.0：背景推播的靜音時段 (原本寫死在程式碼裡的晚上 11 點到早上 10 點) 改成
-- 使用者自己在「個人化設定」→「🔔 背景推播通知」調整起訖時間，存成 "HH:MM" 字串。
-- DEFAULT 維持跟舊版一樣的 23:00-10:00，既有帳號的行為不會因為這次改版而改變。
ALTER TABLE user_prefs ADD COLUMN quiet_hours_start TEXT NOT NULL DEFAULT '23:00';
ALTER TABLE user_prefs ADD COLUMN quiet_hours_end TEXT NOT NULL DEFAULT '10:00';
