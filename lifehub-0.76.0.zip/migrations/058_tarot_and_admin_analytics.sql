-- v0.70：塔羅占卜、管理者後台的「這週熱門功能」使用行為統計、心情紀錄可以順手標記天氣。

-- 占卜紀錄：每次抽牌 (可能一次抽多張，spread_type 決定張數) 存一筆，cards_json 存
-- 這次抽到的每張牌 key + 是否逆位，讓使用者之後可以在「占卜」分頁回顧抽過的牌。
CREATE TABLE IF NOT EXISTS tarot_draws (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  spread_type TEXT NOT NULL DEFAULT 'single',
  cards_json TEXT NOT NULL,
  question TEXT,
  note TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_tarot_draws_user ON tarot_draws(user_id, created_at DESC);

-- 分頁切換事件：只記錄「切去哪個分頁、什麼時候」，不記錄分頁裡的實際內容，用來讓管理者
-- 在後台看「這週熱門功能」——哪些分頁常被用、哪些做了卻幾乎沒人點，是很粗略的使用行為
-- 統計，不是完整的分析追蹤 (沒有記錄使用者在分頁裡做了什麼操作)。
CREATE TABLE IF NOT EXISTS tab_usage_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  tab TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_tab_usage_events_created ON tab_usage_events(created_at);

-- 心情紀錄可以順手標記當天天氣 (使用者自己選，不接氣象 API)，之後才能做「心情 x 天氣」
-- 的簡單關聯統計；NULL 代表沒有標記，舊資料自然都是 NULL，不影響既有紀錄。
ALTER TABLE mood_entries ADD COLUMN weather TEXT;
