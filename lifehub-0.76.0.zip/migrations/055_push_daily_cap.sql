-- v0.67：推播疲勞控管——之前只有「靜音時段」跟「90 秒內合併成一則」，沒有「一天最多推幾次」
-- 的上限。這張表記錄每個使用者「今天」已經送出過幾次非緊急推播 (緊急/使用者自訂精準提醒
-- 不算在這個上限裡，見 src/services/notifyQueue.js 的說明)，超過上限當天就不再推播非緊急
-- 內容 (首頁還是看得到，只是不會再跳通知)，隔天重新計算。
CREATE TABLE IF NOT EXISTS push_send_counts (
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  send_date TEXT NOT NULL, -- YYYY-MM-DD
  count INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (user_id, send_date)
);
