-- v0.66：任務拖延模式偵測——反覆把 due_date 往後延的任務，代表這件事可能被無限期拖著，
-- 值得被特別標出來問「是不是根本不該存在／該拆小／該找人幫忙」。新增計數欄位，每次把
-- 一筆任務的 due_date 改到比原本更晚的日期，就 +1 (見 src/routes/tasks.js 的 PUT /:id)。
ALTER TABLE tasks ADD COLUMN postponed_count INTEGER NOT NULL DEFAULT 0;

-- v0.66：帳單異常偵測——bill_payments 原本只記「哪個月份已繳」，沒記實際繳了多少錢，沒辦法
-- 比對金額有沒有異常升高 (例如訂閱悄悄漲價、用量異常)。新增選填的 amount 欄位，標記已繳時
-- 可以順便填實際金額 (不填就視為跟帳單設定的金額一樣)。
ALTER TABLE bill_payments ADD COLUMN amount REAL;
