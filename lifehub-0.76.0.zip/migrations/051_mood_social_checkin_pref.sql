-- v0.63：新增「心情持續偏低 + 剛好有該聯絡的人」這種跨模組提醒 (見 src/routes/insights.js)。
-- 這則提醒的推播文字會直接寫出「你最近心情比較低落」，顯示在手機鎖定畫面上不是每個人都
-- 想被別人看到，比一般提醒更敏感，所以比照另一半生理週期提醒 (push_partner_cycle_reminders)
-- 同一套「預設關閉、使用者自己決定要不要推播」的做法。首頁的提醒清單不受這個影響，
-- computeReminders() 算出來一律看得到，只有「要不要推播出去」由這個開關決定。
ALTER TABLE user_prefs ADD COLUMN push_mood_social_reminders INTEGER NOT NULL DEFAULT 0;
