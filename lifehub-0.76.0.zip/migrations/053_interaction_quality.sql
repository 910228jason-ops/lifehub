-- v0.65：relationships 目前只用「多久沒聯絡」判斷該不該提醒，但聯絡頻率高不代表關係品質好。
-- 讓每一筆互動紀錄可以選填一個簡單的「這次互動感覺」標記，長期累積下來能看出哪些關係是
-- 滋養性的、哪些是消耗性的，不是所有聯絡人一視同仁地被系統催促聯絡。
-- 合法值：'positive' (正向) / 'neutral' (普通) / 'draining' (勉強/消耗)，NULL 表示沒填。
ALTER TABLE relationship_interactions ADD COLUMN quality TEXT;
