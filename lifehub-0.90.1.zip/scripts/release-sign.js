#!/usr/bin/env node
// v0.90：發版簽章工具 (在「你自己的電腦」上用，不是在 VM 上)。只用 Node 內建 crypto (Ed25519)。
//
// 為什麼：2026/11《妮姬》PC 啟動器事件，是「官方發佈管道」被竄改，使用者照常更新就中毒。
// LifeHub 的發佈管道是「GitHub repo 裡的 zip → VM 解壓執行」，只要有人拿到你的 GitHub 登入
// (例如在中毒的電腦上登入過)，換掉 zip 就能在 VM 上跑任何程式、拿走整個資料庫。
// 簽章之後：只有持有私鑰的人簽過的 zip，VM 才會接受 (見 scripts/safe-update.js 與 server.js 的
// bootstrap)。GitHub 被入侵也換不掉，因為攻擊者沒有私鑰。
//
// 用法：
//   產生金鑰 (只做一次)：
//     node scripts/release-sign.js keygen <放金鑰的資料夾>
//       - 資料夾不能在 repo 裡面；私鑰會用你輸入的密語加密 (AES-256)，中毒的電腦偷走檔案也打不開。
//       - 產生 release-private.pem (私鑰，絕對不要上傳) 與 release-public.pem (公鑰，放到 VM)。
//   簽章：
//     node scripts/release-sign.js sign lifehub-0.90.0.zip <release-private.pem>
//       - 產生 lifehub-0.90.0.zip.sig，跟 zip 一起上傳到 GitHub。
//   驗證 (可選，確認簽章沒問題)：
//     node scripts/release-sign.js verify lifehub-0.90.0.zip <release-public.pem>
//
// 密語也可以用環境變數 LIFEHUB_SIGN_PASSPHRASE 給 (例如自動化測試)；平常建議互動輸入。
'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const FORMAT = 'LIFEHUB-RELEASE-1';

// 簽的內容同時綁定「檔名、版本、zip 的 SHA-256」：不能把舊版的簽章拿來配新的 zip，
// 也不能把舊版 zip 改名冒充新版 (safe-update.js 另外會擋降版)。
function releaseMessage(file, version, sha256) {
  return Buffer.from(`${FORMAT}\nfile=${file}\nversion=${version}\nsha256=${sha256}\n`, 'utf8');
}

function versionFromZipName(name) {
  const m = /^lifehub-(\d+\.\d+\.\d+)\.zip$/.exec(name);
  return m ? m[1] : null;
}

function signRelease(zipBuf, zipName, privateKey) {
  const version = versionFromZipName(zipName);
  if (!version) throw new Error(`檔名必須是 lifehub-<版本>.zip，例如 lifehub-0.90.0.zip (收到：${zipName})`);
  const sha256 = crypto.createHash('sha256').update(zipBuf).digest('hex');
  const sig = crypto.sign(null, releaseMessage(zipName, version, sha256), privateKey).toString('base64');
  return { format: FORMAT, file: zipName, version, sha256, sig };
}

// 回傳 { ok: true, version, sha256 } 或丟出錯誤 (訊息是給人看的中文)
function verifyRelease(zipBuf, zipName, sigJson, publicKey) {
  let s;
  try { s = typeof sigJson === 'string' ? JSON.parse(sigJson) : sigJson; } catch (e) { throw new Error('簽章檔不是有效的 JSON'); }
  if (!s || s.format !== FORMAT) throw new Error('簽章檔格式不認得');
  if (s.file !== zipName) throw new Error(`簽章是給 ${s.file} 的，不是 ${zipName}`);
  const version = versionFromZipName(zipName);
  if (!version || s.version !== version) throw new Error('簽章裡的版本跟檔名對不上');
  const sha256 = crypto.createHash('sha256').update(zipBuf).digest('hex');
  if (s.sha256 !== sha256) throw new Error('zip 內容跟簽章時不一樣 (SHA-256 不符)，可能被改過');
  const ok = crypto.verify(null, releaseMessage(zipName, version, sha256), publicKey, Buffer.from(String(s.sig || ''), 'base64'));
  if (!ok) throw new Error('簽章驗證失敗：不是用你的私鑰簽的');
  return { ok: true, version, sha256 };
}

function askHidden(question) {
  if (process.env.LIFEHUB_SIGN_PASSPHRASE) return Promise.resolve(process.env.LIFEHUB_SIGN_PASSPHRASE);
  if (!process.stdin.isTTY) return Promise.reject(new Error('沒有互動式終端機，請用環境變數 LIFEHUB_SIGN_PASSPHRASE 提供密語'));
  return new Promise((resolve) => {
    process.stdout.write(question);
    const stdin = process.stdin;
    stdin.setRawMode(true);
    stdin.resume();
    stdin.setEncoding('utf8');
    let buf = '';
    const onData = (ch) => {
      if (ch === '\r' || ch === '\n' || ch === '\u0004') {
        stdin.setRawMode(false); stdin.pause(); stdin.removeListener('data', onData);
        process.stdout.write('\n');
        resolve(buf);
      } else if (ch === '\u0003') {
        process.stdout.write('\n'); process.exit(130);
      } else if (ch === '\u007f' || ch === '\b') {
        buf = buf.slice(0, -1);
      } else {
        buf += ch;
      }
    };
    stdin.on('data', onData);
  });
}

function isInside(child, parent) {
  const rel = path.relative(path.resolve(parent), path.resolve(child));
  return rel === '' || (!rel.startsWith('..') && !path.isAbsolute(rel));
}

async function cmdKeygen(dir) {
  if (!dir) throw new Error('請指定放金鑰的資料夾，例如：node scripts/release-sign.js keygen C:\\Users\\你\\lifehub-release-key');
  const repoRoot = path.join(__dirname, '..');
  if (isInside(dir, repoRoot)) throw new Error('金鑰資料夾不能放在專案裡面 (會被打包進 zip / 上傳到公開的 GitHub)');
  fs.mkdirSync(dir, { recursive: true });
  const privPath = path.join(dir, 'release-private.pem');
  const pubPath = path.join(dir, 'release-public.pem');
  if (fs.existsSync(privPath)) throw new Error(`${privPath} 已經存在，不會覆蓋 (要換金鑰請先自己把舊的移走)`);
  const pass1 = await askHidden('設定私鑰密語 (至少 10 個字，輸入時不會顯示)：');
  if (pass1.length < 10) throw new Error('密語太短，至少 10 個字');
  if (!process.env.LIFEHUB_SIGN_PASSPHRASE) {
    const pass2 = await askHidden('再輸入一次：');
    if (pass1 !== pass2) throw new Error('兩次輸入不一樣');
  }
  const { publicKey, privateKey } = crypto.generateKeyPairSync('ed25519');
  fs.writeFileSync(privPath, privateKey.export({ type: 'pkcs8', format: 'pem', cipher: 'aes-256-cbc', passphrase: pass1 }), { mode: 0o600 });
  const pubPem = publicKey.export({ type: 'spki', format: 'pem' });
  fs.writeFileSync(pubPath, pubPem);
  console.log(`\n私鑰 (不要上傳、不要傳給任何人，建議另外備份到隨身碟)：${privPath}`);
  console.log(`公鑰 (要放到 VM 的 ~/lifehub-updater/release-public.pem)：${pubPath}\n`);
  console.log(pubPem);
}

async function cmdSign(zipPath, privPath) {
  if (!zipPath || !privPath) throw new Error('用法：node scripts/release-sign.js sign <lifehub-x.y.z.zip> <release-private.pem>');
  const pass = await askHidden('私鑰密語：');
  let privateKey;
  try { privateKey = crypto.createPrivateKey({ key: fs.readFileSync(privPath), passphrase: pass }); } catch (e) {
    throw new Error(/decrypt|passphrase/i.test(e.message) ? '密語不對，打不開私鑰' : `讀不到私鑰：${e.message}`);
  }
  const zipBuf = fs.readFileSync(zipPath);
  const sig = signRelease(zipBuf, path.basename(zipPath), privateKey);
  // 簽完立刻用對應的公鑰驗一次，確保簽出來的東西 VM 一定認得
  verifyRelease(zipBuf, path.basename(zipPath), sig, crypto.createPublicKey(privateKey));
  const sigPath = zipPath + '.sig';
  fs.writeFileSync(sigPath, JSON.stringify(sig, null, 2) + '\n');
  console.log(`已簽章：${sigPath}`);
  console.log(`版本 ${sig.version}，SHA-256 ${sig.sha256}`);
  console.log('把 zip 和 .sig 兩個檔案一起上傳到 GitHub (並刪掉舊版的 zip 與 .sig)。');
}

function cmdVerify(zipPath, pubPath) {
  if (!zipPath || !pubPath) throw new Error('用法：node scripts/release-sign.js verify <lifehub-x.y.z.zip> <release-public.pem>');
  const r = verifyRelease(fs.readFileSync(zipPath), path.basename(zipPath), fs.readFileSync(zipPath + '.sig', 'utf8'), crypto.createPublicKey(fs.readFileSync(pubPath)));
  console.log(`簽章正確：版本 ${r.version}，SHA-256 ${r.sha256}`);
}

module.exports = { FORMAT, releaseMessage, versionFromZipName, signRelease, verifyRelease };

if (require.main === module) {
  const [cmd, a, b] = process.argv.slice(2);
  const run = cmd === 'keygen' ? () => cmdKeygen(a) : cmd === 'sign' ? () => cmdSign(a, b) : cmd === 'verify' ? () => cmdVerify(a, b) : null;
  if (!run) {
    console.log('用法：\n  node scripts/release-sign.js keygen <金鑰資料夾>\n  node scripts/release-sign.js sign <zip> <release-private.pem>\n  node scripts/release-sign.js verify <zip> <release-public.pem>');
    process.exit(2);
  }
  Promise.resolve().then(run).catch((e) => { console.error('錯誤：' + e.message); process.exit(1); });
}
