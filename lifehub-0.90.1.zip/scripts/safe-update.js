#!/usr/bin/env node
// v0.90：VM 上用的「安全更新」，取代原本的 `git pull && sudo systemctl restart lifehub`。
//
// ⚠️ 這支檔案要「複製到 repo 外面」再執行 (建議 ~/lifehub-updater/safe-update.js)，公鑰放在同一個
// 資料夾 (release-public.pem)。理由：如果它放在 repo 裡，攻擊者入侵 GitHub 後可以連它一起改掉。
// 放在 repo 外面，只有能 SSH 進 VM 的人才改得到。
//
// 它會做的事 (任何一步不對就停下來，什麼都不改)：
//   1. git fetch，看遠端要更新成什麼。
//   2. 遠端根目錄必須剛好一個 lifehub-<版本>.zip，加上 lifehub-<版本>.zip.sig。
//   3. 用 repo 外面的公鑰驗證簽章 (zip 的 SHA-256、檔名、版本都綁在簽章裡)。
//   4. 不准降版 (擋「拿舊版有漏洞的 zip + 它當年的真簽章」重放)。
//   5. 遠端歷史必須是目前版本的延續 (擋 force push 改寫歷史)。
//   6. 這次更新裡，zip 以外被新增/修改的檔案 (例如根目錄的 server.js)，內容必須跟簽過名的 zip
//      裡面同一個檔案一模一樣——不然攻擊者可以不動 zip、直接改 repo 裡的 server.js。
//   7. 都通過才 `git merge --ff-only`，加 --restart 時再 `sudo systemctl restart lifehub`。
//
// 用法 (在 VM 上)：
//   node ~/lifehub-updater/safe-update.js            # 只檢查 + 更新檔案
//   node ~/lifehub-updater/safe-update.js --restart  # 通過後順便重啟服務
// 其他選項：--repo <路徑> (預設 ~/lifehub)、--key <公鑰> (預設跟這支檔案同資料夾的 release-public.pem)、
//          --ref <遠端分支> (預設目前分支的 upstream，沒有的話 origin/main)、--check (只檢查，不更新)
//
// 只用 Node 內建模組；這支檔案刻意自給自足 (不 require 專案裡的任何東西)。
'use strict';
const fs = require('fs');
const os = require('os');
const path = require('path');
const zlib = require('zlib');
const crypto = require('crypto');
const { execFileSync } = require('child_process');

const FORMAT = 'LIFEHUB-RELEASE-1';

function parseArgs(argv) {
  const o = { repo: path.join(os.homedir(), 'lifehub'), key: path.join(__dirname, 'release-public.pem'), ref: null, restart: false, check: false, allowInsideRepo: false };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--repo') o.repo = argv[++i];
    else if (a === '--key') o.key = argv[++i];
    else if (a === '--ref') o.ref = argv[++i];
    else if (a === '--restart') o.restart = true;
    else if (a === '--check') o.check = true;
    else if (a === '--allow-inside-repo') o.allowInsideRepo = true; // 只給自動測試用
    else throw new Error(`不認得的參數：${a}`);
  }
  return o;
}

function git(repo, args, opts = {}) {
  // core.quotePath=false：中文檔名不要被 git 轉成 "\346\227…" 這種跳脫字串
  return execFileSync('git', ['-C', repo, '-c', 'core.quotePath=false', ...args], { encoding: opts.buffer ? 'buffer' : 'utf8', maxBuffer: 512 * 1024 * 1024, stdio: ['ignore', 'pipe', 'pipe'] });
}

function isInside(child, parent) {
  const rel = path.relative(path.resolve(parent), path.resolve(child));
  return rel === '' || (!rel.startsWith('..') && !path.isAbsolute(rel));
}

function releaseMessage(file, version, sha256) {
  return Buffer.from(`${FORMAT}\nfile=${file}\nversion=${version}\nsha256=${sha256}\n`, 'utf8');
}
function versionFromZipName(name) {
  const m = /^lifehub-(\d+\.\d+\.\d+)\.zip$/.exec(name);
  return m ? m[1] : null;
}
function verifyRelease(zipBuf, zipName, sigText, publicKey) {
  let s;
  try { s = JSON.parse(sigText); } catch (e) { throw new Error('簽章檔不是有效的 JSON'); }
  if (!s || s.format !== FORMAT) throw new Error('簽章檔格式不認得');
  if (s.file !== zipName) throw new Error(`簽章是給 ${s.file} 的，不是 ${zipName}`);
  const version = versionFromZipName(zipName);
  if (!version || s.version !== version) throw new Error('簽章裡的版本跟檔名對不上');
  const sha256 = crypto.createHash('sha256').update(zipBuf).digest('hex');
  if (s.sha256 !== sha256) throw new Error('zip 內容跟簽章時不一樣 (SHA-256 不符)');
  if (!crypto.verify(null, releaseMessage(zipName, version, sha256), publicKey, Buffer.from(String(s.sig || ''), 'base64'))) {
    throw new Error('簽章驗證失敗：不是用你的私鑰簽的');
  }
  return { version, sha256 };
}

function cmpVersion(a, b) {
  const pa = a.split('.').map(Number), pb = b.split('.').map(Number);
  for (let i = 0; i < 3; i++) if (pa[i] !== pb[i]) return pa[i] - pb[i];
  return 0;
}

// 讀 zip 的所有檔案 → Map(名稱 → Buffer)。跟 server.js 的 bootstrap 用同樣的 central directory 讀法。
function readZip(buf) {
  let eocd = -1;
  for (let i = buf.length - 22; i >= 0; i--) if (buf.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
  if (eocd < 0) throw new Error('zip 格式不正確 (找不到 EOCD)');
  const count = buf.readUInt16LE(eocd + 10);
  let off = buf.readUInt32LE(eocd + 16);
  const files = new Map();
  for (let i = 0; i < count; i++) {
    if (buf.readUInt32LE(off) !== 0x02014b50) throw new Error('zip central directory 格式異常');
    const method = buf.readUInt16LE(off + 10);
    const csize = buf.readUInt32LE(off + 20);
    const nlen = buf.readUInt16LE(off + 28), xlen = buf.readUInt16LE(off + 30), clen = buf.readUInt16LE(off + 32);
    const lho = buf.readUInt32LE(off + 42);
    const name = buf.toString('utf8', off + 46, off + 46 + nlen);
    if (!name.endsWith('/')) {
      const start = lho + 30 + buf.readUInt16LE(lho + 26) + buf.readUInt16LE(lho + 28);
      const data = buf.subarray(start, start + csize);
      files.set(name, method === 0 ? Buffer.from(data) : zlib.inflateRawSync(data));
    }
    off += 46 + nlen + xlen + clen;
  }
  return files;
}

function main() {
  const o = parseArgs(process.argv.slice(2));
  const repo = path.resolve(o.repo);
  if (!fs.existsSync(path.join(repo, '.git'))) throw new Error(`${repo} 不是 git repo (用 --repo 指定專案路徑)`);
  if (isInside(__filename, repo) && !o.allowInsideRepo) {
    throw new Error('這支 safe-update.js 放在 repo 裡面，攻擊者可以連它一起改掉。請先複製到 repo 外面再執行，例如：\n' +
      '  mkdir -p ~/lifehub-updater && cp ~/lifehub/scripts/safe-update.js ~/lifehub-updater/\n' +
      '  node ~/lifehub-updater/safe-update.js');
  }
  if (!fs.existsSync(o.key)) throw new Error(`找不到公鑰 ${o.key} (請把 release-public.pem 放到這支檔案旁邊，或用 --key 指定)`);
  if (isInside(o.key, repo)) throw new Error('公鑰不能放在 repo 裡面 (攻擊者可以把它換成自己的)');
  const publicKey = crypto.createPublicKey(fs.readFileSync(o.key));

  console.log('[1/6] git fetch');
  git(repo, ['fetch', '--quiet']);
  let ref = o.ref;
  if (!ref) {
    try { ref = git(repo, ['rev-parse', '--abbrev-ref', '--symbolic-full-name', '@{u}']).trim(); } catch (e) { ref = 'origin/main'; }
  }
  const head = git(repo, ['rev-parse', 'HEAD']).trim();
  const target = git(repo, ['rev-parse', ref]).trim();
  if (head === target) { console.log(`已經是最新 (${ref})，不用更新。`); return; }

  console.log(`[2/6] 檢查 ${ref} 的歷史`);
  try { git(repo, ['merge-base', '--is-ancestor', head, target]); } catch (e) {
    throw new Error(`遠端 ${ref} 不是目前版本的延續 (歷史被改寫過，例如 force push)。這很可疑，先不要更新，到 GitHub 看看發生什麼事。`);
  }

  console.log('[3/6] 找 zip 與簽章');
  const rootFiles = git(repo, ['ls-tree', '--name-only', target]).split('\n').filter(Boolean);
  const zips = rootFiles.filter((f) => f.toLowerCase().endsWith('.zip'));
  if (zips.length !== 1) throw new Error(`遠端根目錄要剛好 1 個 zip，現在有 ${zips.length} 個：${zips.join(', ') || '(沒有)'}`);
  const zipName = zips[0];
  if (!rootFiles.includes(zipName + '.sig')) throw new Error(`遠端沒有 ${zipName}.sig (沒簽章的版本不接受)`);
  const zipBuf = git(repo, ['show', `${target}:${zipName}`], { buffer: true });
  const sigText = git(repo, ['show', `${target}:${zipName}.sig`]);

  console.log('[4/6] 驗證簽章');
  const { version, sha256 } = verifyRelease(zipBuf, zipName, sigText, publicKey);
  console.log(`      ✓ ${zipName} 簽章正確 (SHA-256 ${sha256.slice(0, 16)}…)`);
  const files = readZip(zipBuf);
  const pkgInZip = files.get('package.json');
  if (!pkgInZip || JSON.parse(pkgInZip.toString('utf8')).version !== version) throw new Error('zip 裡 package.json 的版本跟檔名不一致');
  // 「目前版本」取兩者較新的：上次 safe-update 驗證過的版本 (.bootstrap/verified-release.json)，
  // 和正在跑的 package.json (bootstrap 解壓後才會更新，所以更新完還沒重啟時會是舊的)。
  let installed = null;
  for (const f of [path.join(repo, '.bootstrap', 'verified-release.json'), path.join(repo, 'package.json')]) {
    try {
      const v = JSON.parse(fs.readFileSync(f, 'utf8')).version;
      if (/^\d+\.\d+\.\d+$/.test(v) && (!installed || cmpVersion(v, installed) > 0)) installed = v;
    } catch (e) { /* 沒有就跳過 */ }
  }
  if (installed && cmpVersion(version, installed) < 0) {
    throw new Error(`遠端是 ${version}，比目前的 ${installed} 舊。拒絕降版 (可能是有人拿舊版重放)。`);
  }

  console.log('[5/6] 檢查 zip 以外的變更');
  const diff = git(repo, ['diff', '--name-status', '--no-renames', head, target]).split('\n').filter(Boolean);
  const problems = [];
  const deleted = [];
  for (const line of diff) {
    const [status, p] = line.split('\t');
    if (p === zipName || p === zipName + '.sig') continue;
    if (status === 'D') { deleted.push(p); continue; }
    const inZip = files.get(p);
    if (!inZip) { problems.push(`${p} (不在簽過名的 zip 裡)`); continue; }
    const remote = git(repo, ['show', `${target}:${p}`], { buffer: true });
    if (!remote.equals(inZip)) problems.push(`${p} (跟 zip 裡的版本不一樣)`);
  }
  if (problems.length) {
    throw new Error('這次更新除了 zip 以外還改了這些檔案，而且沒有簽章保護，拒絕更新：\n  - ' + problems.join('\n  - ') +
      '\n如果是你自己改的，請把改動放進 zip 裡重新簽章；如果不是你，GitHub 帳號可能被入侵了。');
  }
  if (deleted.length) console.log(`      (刪除的檔案：${deleted.join(', ')})`);
  console.log(`      ✓ ${diff.length} 個變更都在簽章保護內`);

  if (o.check) { console.log(`\n--check：全部檢查通過，可以更新到 ${version}。沒有改任何東西。`); return; }

  console.log('[6/6] 更新檔案');
  git(repo, ['merge', '--ff-only', '--quiet', target]);
  try {
    fs.mkdirSync(path.join(repo, '.bootstrap'), { recursive: true });
    fs.writeFileSync(path.join(repo, '.bootstrap', 'verified-release.json'), JSON.stringify({ file: zipName, version, sha256, verifiedAt: new Date().toISOString() }, null, 2));
  } catch (e) { /* 只是紀錄，失敗不影響 */ }
  console.log(`      ✓ 已更新到 ${version}`);
  if (o.restart) {
    console.log('重新啟動服務 (sudo systemctl restart lifehub)…');
    execFileSync('sudo', ['systemctl', 'restart', 'lifehub'], { stdio: 'inherit' });
    console.log('完成。約 30 秒後打開 /api/health 確認 version 是 ' + version);
  } else {
    console.log('接著執行：sudo systemctl restart lifehub');
  }
}

try { main(); } catch (e) {
  console.error('\n✗ ' + e.message);
  if (e.stderr && e.stderr.length) console.error(String(e.stderr).trim());
  process.exit(1);
}
