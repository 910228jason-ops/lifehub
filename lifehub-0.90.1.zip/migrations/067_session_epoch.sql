-- v0.90.0：讓「已經發出去的登入 cookie」可以被作廢。
-- 登入 cookie 是用 SESSION_SECRET 簽章的 (不是存在伺服器上的 session)，原本沒辦法讓它提早失效：
-- 手機掉了、或電腦中毒被偷走 cookie (例如 2026/11《妮姬》PC 啟動器事件那種會偷瀏覽器資料的
-- 惡意程式)，改密碼也擋不住，對方 30 天內都還是登入狀態。
-- 現在 cookie 裡記一個 epoch，每次請求跟這個欄位比對；「登出所有裝置」或改/重設密碼時 +1，
-- 舊 cookie 全部失效。預設 0，跟舊 cookie (沒有 epoch，視為 0) 相容，升級時不會把大家登出。
ALTER TABLE users ADD COLUMN session_epoch INTEGER NOT NULL DEFAULT 0;
