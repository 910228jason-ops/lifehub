// mini-http.js — 極簡的 Express 風格路由/伺服器框架，只用 Node.js 內建 http/crypto/fs 模組。
//
// 為什麼不用 Express？
// 這個沙盒環境目前無法連線到 npm 套件源 (registry.npmjs.org / pypi.org 皆回傳
// host_not_allowed)，所以原型完全改用 Node.js 內建模組實作，零外部依賴。
// 這裡刻意模仿 Express 慣用的 API 形狀 (Router().get/post/put/delete、
// req.params/req.query/req.body、res.json/res.status)，
// 如果未來正式環境要換回 Express，路由檔案(src/routes/*.js)幾乎不用改，
// 只要把 `require('../mini-http')` 換回 `require('express')` 並调整少量差異即可。

const http = require('http');
const { URL } = require('url');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const logger = require('./services/logger');

// 支援 Express 慣用的 router.get(path, middleware1, middleware2, ..., handler) 寫法：
// 除了最後一個函式以外，其餘視為中介層 (簽章為 (req,res,next))，
// 需呼叫 next() 才會繼續往下一個執行；最後一個函式視為最終處理常式 (簽章為 (req,res))。
function compose(handlers) {
  return async function (req, res) {
    let i = 0;
    async function next(err) {
      if (err) throw err;
      if (i >= handlers.length) return;
      const fn = handlers[i++];
      if (fn.length >= 3) return fn(req, res, next);
      return fn(req, res);
    }
    await next();
  };
}

function Router() {
  const routes = [];
  const add = (method) => (pattern, ...handlers) => routes.push({ method, pattern, handler: compose(handlers) });
  return { routes, get: add('GET'), post: add('POST'), put: add('PUT'), delete: add('DELETE') };
}

function matchPath(pattern, pathname) {
  const pp = pattern.split('/').filter(Boolean);
  const ap = pathname.split('/').filter(Boolean);
  if (pp.length !== ap.length) return null;
  const params = {};
  for (let i = 0; i < pp.length; i++) {
    if (pp[i].startsWith(':')) params[pp[i].slice(1)] = decodeURIComponent(ap[i]);
    else if (pp[i] !== ap[i]) return null;
  }
  return params;
}

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
};


// ---- 靜態檔案：壓縮 + ETag (v0.85) ----
// 舊版對所有靜態檔案下 `no-store`，確保手機上一定拿到最新部署的 app.js/style.css，但代價是
// 每次打開 App 都要重新下載完整的 ~550KB app.js + ~115KB style.css (而且沒有壓縮)。
// 現在改成：
//   1) `Cache-Control: no-cache` + ETag：瀏覽器每次仍然會先問伺服器「有沒有新版」(所以
//      「部署了新版、手機還在跑舊的」那個問題不會回來)，但檔案沒變時伺服器只回 304，
//      不用重新下載內容。ETag 由檔案大小 + 修改時間組成，重新部署 (解壓新 zip) 一定會變。
//   2) 文字類檔案 (js/css/html/json/svg) 在瀏覽器支援時用 gzip 壓縮後再送，app.js 傳輸量
//      大約剩 1/4。壓縮結果依「路徑 + ETag」暫存在記憶體，同一版檔案只壓一次。
const zlib = require('zlib');
const COMPRESSIBLE_EXT = new Set(['.js', '.css', '.html', '.json', '.svg', '.txt', '.webmanifest']);
const gzipCache = new Map(); // filePath -> { etag, buf }

function serveStaticFile(req, res, filePath) {
  const stat = fs.statSync(filePath);
  const ext = path.extname(filePath);
  const etag = `W/"${stat.size.toString(16)}-${Math.floor(stat.mtimeMs).toString(16)}"`;
  res.setHeader('content-type', MIME[ext] || 'application/octet-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('ETag', etag);
  res.setHeader('Vary', 'Accept-Encoding');
  const inm = req.headers && req.headers['if-none-match'];
  if (inm && inm.split(/\s*,\s*/).includes(etag)) {
    res.statusCode = 304;
    res.end();
    return;
  }
  const acceptsGzip = /\bgzip\b/.test((req.headers && req.headers['accept-encoding']) || '');
  if (acceptsGzip && COMPRESSIBLE_EXT.has(ext) && stat.size > 1024) {
    let cached = gzipCache.get(filePath);
    if (!cached || cached.etag !== etag) {
      cached = { etag, buf: zlib.gzipSync(fs.readFileSync(filePath), { level: 6 }) };
      gzipCache.set(filePath, cached);
    }
    res.setHeader('Content-Encoding', 'gzip');
    res.setHeader('Content-Length', cached.buf.length);
    if (req.method === 'HEAD') { res.end(); return; }
    res.end(cached.buf);
    return;
  }
  res.setHeader('Content-Length', stat.size);
  if (req.method === 'HEAD') { res.end(); return; }
  fs.createReadStream(filePath).pipe(res);
}

// ---- 安全標頭 (v0.90) ----
// 背景：2026/11 的《妮姬》PC 啟動器事件，是官方發佈的 JS 被竄改後，在使用者端執行任意程式。
// LifeHub 前端本來就不載入任何外部 JS，這裡再用 CSP 把它變成「瀏覽器強制」的規則：
//   - script-src 'self'：只能跑本站的 /js/app.js，不能載入外站 script，也不能執行內嵌 script /
//     onclick="..." (index.html 已改成 data-onclick，見 app.js 最後面)。
//   - connect-src 'self'：就算被塞進惡意程式，也不能用 fetch/XHR 把資料送到別的網站。
//   - img-src 'self' data: blob:：擋掉用 <img src="https://壞人/?資料"> 偷偷外傳。
//   - frame-ancestors 'none' + X-Frame-Options：別的網站不能用 iframe 嵌入 LifeHub 騙人點擊。
//   - style-src 允許 'unsafe-inline'：app.js 大量用 style 屬性排版，CSS 不能執行程式，風險低。
// 新增功能如果真的需要連外部網站 (例如前端直接呼叫外部 API)，要在這裡明確加白名單。
const CSP = [
  "default-src 'self'",
  "script-src 'self'",
  "style-src 'self' 'unsafe-inline'",
  "img-src 'self' data: blob:",
  "font-src 'self' data:",
  "connect-src 'self'",
  "worker-src 'self'",
  "manifest-src 'self'",
  "media-src 'self' blob:",
  "object-src 'none'",
  "base-uri 'self'",
  "form-action 'self'",
  "frame-ancestors 'none'",
].join('; ');

function setSecurityHeaders(res, https) {
  res.setHeader('Content-Security-Policy', CSP);
  // v0.90.1：HSTS——瀏覽器記住「這個網站只用 HTTPS」180 天，之後就算打 http:// 也不會先用明碼
  // 連線 (原本第一次會先送一個 http 請求，連登入 cookie 一起送出去，才被 308 轉到 https)。
  // 只在真的是 HTTPS 時送；本機開發 (http://localhost) 不送，不然瀏覽器會記住 localhost 只能 HTTPS。
  if (https) res.setHeader('Strict-Transport-Security', 'max-age=15552000');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'same-origin');
  res.setHeader('Cross-Origin-Opener-Policy', 'same-origin');
}

function parseCookies(header) {
  const out = {};
  (header || '').split(';').forEach((p) => {
    const idx = p.indexOf('=');
    if (idx === -1) return;
    out[p.slice(0, idx).trim()] = decodeURIComponent(p.slice(idx + 1).trim());
  });
  return out;
}
function sign(payload, secret) {
  const json = Buffer.from(JSON.stringify(payload)).toString('base64url');
  const sig = crypto.createHmac('sha256', secret).update(json).digest('base64url');
  return `${json}.${sig}`;
}
function unsign(token, secret) {
  if (!token) return null;
  const dot = token.lastIndexOf('.');
  if (dot === -1) return null;
  const json = token.slice(0, dot);
  const sig = token.slice(dot + 1);
  const expected = crypto.createHmac('sha256', secret).update(json).digest('base64url');
  if (sig.length !== expected.length || !crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return null;
  try {
    return JSON.parse(Buffer.from(json, 'base64url').toString());
  } catch {
    return null;
  }
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', (chunk) => {
      data += chunk;
      if (data.length > 5_000_000) req.destroy(new Error('Request body too large'));
    });
    req.on('end', () => resolve(data));
    req.on('error', reject);
  });
}

function createApp() {
  const mounts = [];
  let staticDir = null;
  let sessionOpts = null;

  const app = {
    mount(prefix, router) {
      mounts.push({ prefix, router });
    },
    setStatic(dir) {
      staticDir = dir;
    },
    setSession(opts) {
      // v0.90：不管 server.js 傳進來什麼，金鑰一律經過 resolveSessionSecret() 把關 (沒設/範例值/
      // 太短就改用自動產生的 session.secret)，並加上 epoch 檢查讓舊 cookie 可以被作廢。
      // 刻意放在這裡而不是 server.js：server.js 由 bootstrap 解壓後要「再重開一次」才會生效。
      const sec = require('./services/sessionSecurity');
      const { getDb, DB_PATH } = require('./services/db');
      const { secret, source } = sec.resolveSessionSecret(DB_PATH);
      if (source !== 'env') logger.info(`[session] 使用${source === 'file' ? '自動產生的 session.secret' : '暫時性的隨機金鑰'} 簽章登入 cookie`, {});
      sessionOpts = { ...opts, secret, validate: opts.validate || sec.makeSessionValidator(getDb) };
    },
    listen(port, cb) {
      const server = http.createServer((req, res) => handleReq(req, res));
      server.listen(port, cb);
      return server;
    },
  };

  async function handleReq(req, res) {
    const startedAt = Date.now();
    res.on('finish', () => {
      if (process.env.DEBUG === 'true') {
        logger.debug(`${req.method} ${req.path || req.url} -> ${res.statusCode} (${Date.now() - startedAt}ms)`);
      }
      if (res.statusCode >= 500) {
        logger.error(`${req.method} ${req.path || req.url} -> ${res.statusCode}`);
      }
    });

    try {
      req.isHttps = require('./services/sessionSecurity').isHttpsRequest(req);
      setSecurityHeaders(res, req.isHttps);
      const u = new URL(req.url, 'http://localhost');
      req.path = decodeURIComponent(u.pathname);
      req.query = Object.fromEntries(u.searchParams.entries());

      res.json = (obj) => {
        if (!res.headersSent) res.setHeader('content-type', 'application/json; charset=utf-8');
        res.end(JSON.stringify(obj));
      };
      res.status = (code) => {
        res.statusCode = code;
        return res;
      };

      if (['POST', 'PUT', 'DELETE', 'PATCH'].includes(req.method)) {
        const raw = await readBody(req);
        try {
          req.body = raw ? JSON.parse(raw) : {};
        } catch {
          req.body = {};
        }
      } else {
        req.body = {};
      }

      if (sessionOpts) {
        const cookies = parseCookies(req.headers.cookie);
        let initial = unsign(cookies[sessionOpts.name], sessionOpts.secret) || {};
        let invalidated = false;
        if (sessionOpts.validate && !sessionOpts.validate(initial)) {
          // 已被「登出所有裝置」/改密碼作廢的舊 cookie：當成沒登入，並在回應時把 cookie 蓋掉
          initial = {};
          invalidated = true;
        }
        req.session = { ...initial };
        req._sessionSnapshot = invalidated ? '__invalidated__' : JSON.stringify(initial);
        // v0.90.1：改版前發出的 cookie 沒有 Secure。HTTPS 下第一次看到這種 cookie 時標記一下，
        // 讓這次回應重新發一次 (會帶 Secure)，之後就不會再重發。
        if (req.isHttps && initial.userId && !initial.sec) req.session.sec = 1;
      }

      // 注意：req.session 是在 route handler 執行「期間」被修改的 (例如登入時設定
      // req.session.userId)，所以不能在呼叫 handler 之前就把 cookie 寫進 header —
      // 那樣寫入的還是修改前的舊值。正確做法是在「第一次真的要送出回應資料」的當下
      // (也就是 res.write / res.end 第一次被呼叫時) 才回頭檢查 req.session 目前的最終內容，
      // 並把 Set-Cookie 加上去，這樣不管 handler 什麼時候修改 session 都能正確反映。
      const finalizeSession = () => {
        if (!sessionOpts || res.headersSent) return;
        if (req.session === null || req.session === undefined) {
          res.setHeader('Set-Cookie', `${sessionOpts.name}=; Path=/; HttpOnly; SameSite=Lax${req.isHttps ? '; Secure' : ''}; Max-Age=0`);
          return;
        }
        const serialized = JSON.stringify(req.session);
        if (serialized !== req._sessionSnapshot) {
          const token = sign(req.session, sessionOpts.secret);
          const maxAgeSec = Math.floor((sessionOpts.maxAge || 2592000000) / 1000);
          // v0.90.1：HTTPS 時加 Secure，cookie 永遠不會用明碼 http 送出
          res.setHeader('Set-Cookie', `${sessionOpts.name}=${token}; Path=/; HttpOnly; SameSite=Lax${req.isHttps ? '; Secure' : ''}; Max-Age=${maxAgeSec}`);
        }
      };
      let sessionFinalized = false;
      const ensureSessionFinalized = () => {
        if (sessionFinalized) return;
        sessionFinalized = true;
        finalizeSession();
      };
      const originalWrite = res.write.bind(res);
      const originalEnd = res.end.bind(res);
      res.write = (...args) => {
        ensureSessionFinalized();
        return originalWrite(...args);
      };
      res.end = (...args) => {
        ensureSessionFinalized();
        return originalEnd(...args);
      };

      for (const m of mounts) {
        if (req.path === m.prefix || req.path.startsWith(m.prefix + '/')) {
          const subPath = req.path.slice(m.prefix.length) || '/';
          for (const route of m.router.routes) {
            if (route.method !== req.method) continue;
            const params = matchPath(route.pattern, subPath);
            if (params) {
              req.params = params;
              try {
                await route.handler(req, res);
              } catch (err) {
                logger.error('路由處理發生例外', { path: req.path, message: err.message, stack: err.stack });
                if (!res.headersSent) res.status(500).json({ error: '伺服器發生錯誤，請稍後再試' });
              }
              return;
            }
          }
        }
      }

      if (staticDir) {
        const rel = req.path === '/' ? '/index.html' : req.path;
        const filePath = path.normalize(path.join(staticDir, rel));
        if (filePath.startsWith(staticDir) && fs.existsSync(filePath) && fs.statSync(filePath).isFile()) {
          serveStaticFile(req, res, filePath);
          return;
        }
      }

      res.status(404).json({ error: 'Not Found' });
    } catch (err) {
      logger.error('伺服器層級例外', { message: err.message, stack: err.stack });
      if (!res.headersSent) res.status(500).json({ error: '伺服器發生錯誤' });
      else res.end();
    }
  }

  return app;
}

module.exports = { createApp, Router };
