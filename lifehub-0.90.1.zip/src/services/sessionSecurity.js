// v0.90：登入安全相關的共用邏輯。
//   1. resolveSessionSecret()：SESSION_SECRET 沒設、或還是範例值時，自動產生一把隨機金鑰存在
//      資料庫同目錄的 session.secret (權限 600)，不再退回寫死的 'dev-secret-change-me'
//      (那個字串在公開 repo 裡，任何人都能用它偽造任何使用者的登入 cookie)。
//   2. validateSession()：每次請求檢查 cookie 裡的 epoch 跟 users.session_epoch 一致，
//      「登出所有裝置」/改密碼後舊 cookie 立刻失效 (migration 067)。
//   3. 登入/重設碼的嘗試次數限制 (記憶體內，重開機會歸零，對個人/家庭用的規模夠用)。

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const logger = require('./logger');

const KNOWN_WEAK_SECRETS = new Set(['', 'dev-secret-change-me', 'change-me-to-a-random-string', 'change-me', 'secret']);

function resolveSessionSecret(dbPath) {
  const fromEnv = (process.env.SESSION_SECRET || '').trim();
  if (fromEnv && !KNOWN_WEAK_SECRETS.has(fromEnv) && fromEnv.length >= 16) return { secret: fromEnv, source: 'env' };
  const file = path.join(path.dirname(dbPath), 'session.secret');
  try {
    if (!fs.existsSync(file)) {
      fs.mkdirSync(path.dirname(file), { recursive: true });
      fs.writeFileSync(file, crypto.randomBytes(48).toString('base64'), { mode: 0o600 });
      logger.info('[session] SESSION_SECRET 沒設定或太弱，已自動產生隨機金鑰 (session.secret)。所有人需要重新登入一次。', {});
    }
    const s = fs.readFileSync(file, 'utf8').trim();
    if (s.length >= 32) return { secret: s, source: 'file' };
  } catch (e) {
    logger.error('[session] 無法讀寫 session.secret', { message: e.message });
  }
  // 讀寫都失敗 (例如磁碟唯讀)：這次開機用一把隨機金鑰，至少不會是公開的預設值。重開機後大家要重新登入。
  return { secret: crypto.randomBytes(48).toString('base64'), source: 'ephemeral' };
}

// cookie 內容 → 是否仍然有效。只檢查有 userId 的 session；沒登入的 session 一律放行。
function makeSessionValidator(getDb) {
  return function validateSession(session) {
    if (!session || !session.userId) return true;
    try {
      const row = getDb().prepare('SELECT session_epoch FROM users WHERE id = ?').get(session.userId);
      if (!row) return false; // 帳號已不存在
      return (session.epoch || 0) === (row.session_epoch || 0);
    } catch (e) {
      // 欄位還不存在 (migration 尚未套用) 時不要把所有人擋在外面
      return true;
    }
  };
}

function currentEpoch(db, userId) {
  try {
    const row = db.prepare('SELECT session_epoch FROM users WHERE id = ?').get(userId);
    return row ? row.session_epoch || 0 : 0;
  } catch (e) { return 0; }
}

// 讓這個使用者所有已發出的登入 cookie 失效，回傳新的 epoch
function bumpEpoch(db, userId) {
  db.prepare('UPDATE users SET session_epoch = session_epoch + 1 WHERE id = ?').run(userId);
  return currentEpoch(db, userId);
}

// ---- 嘗試次數限制 ----
// 同一個 email 15 分鐘內最多失敗 8 次；同一個 IP 15 分鐘內最多失敗 30 次 (擋換帳號亂猜)。
// 只計「失敗」，成功登入會清掉該 email 的計數。超過時回 429 + 還要等幾分鐘。
const WINDOW_MS = 15 * 60 * 1000;
const LIMITS = { email: 8, ip: 30 };
const failures = new Map(); // key -> [timestamps]

function isLoopback(addr) {
  return addr === '127.0.0.1' || addr === '::1' || addr === '::ffff:127.0.0.1';
}

// 判斷「連線是不是本機的反向代理 (Caddy) 轉進來的」。正式環境 node 只聽本機、3000 port 不對外，
// 所以來自 127.0.0.1 的連線一定是 Caddy；TRUST_PROXY=1 則是給代理不在本機的部署方式用。
function fromTrustedProxy(req) {
  return process.env.TRUST_PROXY === '1' || isLoopback(req.socket && req.socket.remoteAddress);
}

function clientIp(req) {
  // v0.90.1：正式站前面有 Caddy，所有連線的來源都是 127.0.0.1，v0.90 的「同一 IP 錯 30 次」因此
  // 變成全站共用一個計數 (陌生人猜錯 30 次就能讓全家登不進去)。現在來自代理時改看
  // X-Forwarded-For 的「最後一段」——那是 Caddy 自己加上去、看到的真實連線 IP；前面幾段
  // 是用戶端自己送的，可以偽造，所以不用。直接連線 (沒有代理) 時完全不看這個標頭。
  if (fromTrustedProxy(req)) {
    const parts = String(req.headers['x-forwarded-for'] || '').split(',').map((s) => s.trim()).filter(Boolean);
    if (parts.length) return parts[parts.length - 1];
  }
  return (req.socket && req.socket.remoteAddress) || 'unknown';
}

// 這個請求在使用者那端是不是 HTTPS (Caddy 會帶 X-Forwarded-Proto)
function isHttpsRequest(req) {
  if (req.socket && req.socket.encrypted) return true;
  return fromTrustedProxy(req) && String(req.headers['x-forwarded-proto'] || '').split(',')[0].trim() === 'https';
}

function recent(key, now) {
  const arr = (failures.get(key) || []).filter((t) => now - t < WINDOW_MS);
  if (arr.length) failures.set(key, arr); else failures.delete(key);
  return arr;
}

// 回傳 null = 可以嘗試；回傳數字 = 還要等幾分鐘
function checkAttemptAllowed(kind, req, email) {
  const now = Date.now();
  const keys = [[`${kind}:ip:${clientIp(req)}`, LIMITS.ip]];
  if (email) keys.push([`${kind}:email:${String(email).trim().toLowerCase()}`, LIMITS.email]);
  let waitMs = 0;
  for (const [key, limit] of keys) {
    const arr = recent(key, now);
    if (arr.length >= limit) waitMs = Math.max(waitMs, WINDOW_MS - (now - arr[0]));
  }
  return waitMs > 0 ? Math.max(1, Math.ceil(waitMs / 60000)) : null;
}

function recordFailure(kind, req, email) {
  const now = Date.now();
  const keys = [`${kind}:ip:${clientIp(req)}`];
  if (email) keys.push(`${kind}:email:${String(email).trim().toLowerCase()}`);
  for (const key of keys) {
    const arr = recent(key, now);
    arr.push(now);
    failures.set(key, arr);
  }
  if (failures.size > 10000) { // 防止被灌爆記憶體：清掉最舊的一半
    const drop = Math.floor(failures.size / 2);
    let i = 0;
    for (const k of failures.keys()) { if (i++ >= drop) break; failures.delete(k); }
  }
}

function clearFailures(kind, email) {
  if (email) failures.delete(`${kind}:email:${String(email).trim().toLowerCase()}`);
}

module.exports = {
  resolveSessionSecret, makeSessionValidator, currentEpoch, bumpEpoch,
  checkAttemptAllowed, recordFailure, clearFailures, clientIp, isHttpsRequest,
};
