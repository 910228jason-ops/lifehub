// twtime.js — 台灣時間 (UTC+8) 的日期工具 (v0.90)。
//
// 為什麼需要：GCP VM 預設時區是 UTC，`new Date().toISOString().slice(0, 10)` 拿到的是 UTC 日期，
// 台灣早上 8 點前會被算成「前一天」(習慣打卡記到昨天、服藥提醒 08:00 變成台灣 16:00 才響……)。
// v0.88/v0.89 已經各自修過帳單、生日倒數；v0.90 起伺服器端判斷「今天/這個月/幾點」一律用這裡。
//
// 做法：把時間加 8 小時後只用 getUTC* / toISOString 讀，結果完全不受伺服器 TZ 設定影響
// (伺服器設成 UTC 或 Asia/Taipei 都一樣)。台灣沒有日光節約時間，固定 +8 就是正確的。
// 日期字串 'YYYY-MM-DD' 的加減一律用 UTC 午夜計算，避免本地時區把日期推前/推後一天。

const TW_OFFSET_MS = 8 * 60 * 60 * 1000;
const pad = (n) => String(n).padStart(2, '0');

// 回傳「台灣牆上時間」的 Date：只能用 getUTC* 讀 (例如 twShift().getUTCHours() = 台灣的幾點)。
function twShift(d = new Date()) {
  return new Date(d.getTime() + TW_OFFSET_MS);
}

// 某個時間點在台灣是哪一天 'YYYY-MM-DD'
function twDateStr(d = new Date()) {
  return twShift(d).toISOString().slice(0, 10);
}

function twToday() {
  return twDateStr();
}

// 'YYYY-MM'
function twMonth() {
  return twToday().slice(0, 7);
}

// 台灣現在幾點幾分 'HH:MM'
function twHHMM(d = new Date()) {
  const t = twShift(d);
  return `${pad(t.getUTCHours())}:${pad(t.getUTCMinutes())}`;
}

// 'YYYY-MM-DD' 加減 n 天 (n 可以是負數)
function addDaysStr(ymd, n) {
  const d = new Date(ymd + 'T00:00:00Z');
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
}

// 'YYYY-MM-DD' 加減 n 個月 (跟 Date#setMonth 一樣：1/31 + 1 個月會溢位到 3 月初)
function addMonthsStr(ymd, n) {
  const d = new Date(ymd + 'T00:00:00Z');
  d.setUTCMonth(d.getUTCMonth() + n);
  return d.toISOString().slice(0, 10);
}

// 台灣的 n 天前 'YYYY-MM-DD'
function twDaysAgo(n) {
  return addDaysStr(twToday(), -n);
}

// 台灣今天的 UTC 午夜 Date，用來做「差幾天」的計算 (搭配 getUTC* / setUTCDate)
function twTodayDate() {
  return new Date(twToday() + 'T00:00:00Z');
}

module.exports = { TW_OFFSET_MS, twShift, twDateStr, twToday, twMonth, twHHMM, addDaysStr, addMonthsStr, twDaysAgo, twTodayDate };
