// 誰是「管理者」(能看到所有使用者送出的意見回饋、管理者統計、異地備份設定與金鑰)。
// 預設是專案擁有者的 email，若之後要換人，用環境變數 ADMIN_EMAIL 覆蓋即可，不用改程式碼。
//
// v0.90.1 安全修正：原本只要「email 轉小寫後等於 ADMIN_EMAIL」就算管理者，但註冊時檢查 email
// 重複是分大小寫的，任何人註冊 `910228Jason@gmail.com` 就能變成管理者 (還能看到備份金鑰)。
// 現在改成：管理者 = 「正規化後 email 等於 ADMIN_EMAIL 的帳號中，最早建立 (id 最小) 的那一個」。
// 就算資料庫裡已經有大小寫不同的冒牌帳號，它的 id 一定比本人大，不會被當成管理者。
// 新註冊也會先正規化 email 並做不分大小寫的重複檢查 (見 routes/auth.js)。

const ADMIN_EMAIL = normalizeEmail(process.env.ADMIN_EMAIL || '910228jason@gmail.com');

function normalizeEmail(email) {
  return String(email == null ? '' : email).trim().toLowerCase();
}

// 管理者帳號的 id；還沒註冊時回傳 null
function adminUserId(db) {
  const row = db.prepare('SELECT id FROM users WHERE lower(trim(email)) = ? ORDER BY id ASC LIMIT 1').get(ADMIN_EMAIL);
  return row ? row.id : null;
}

function isAdminUser(db, userId) {
  if (!userId) return false;
  const id = adminUserId(db);
  return id != null && Number(id) === Number(userId);
}

module.exports = { ADMIN_EMAIL, normalizeEmail, adminUserId, isAdminUser };
