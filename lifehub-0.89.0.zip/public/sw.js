// LifeHub Service Worker。
//
// 1) 背景推播：接住 push 事件，顯示成系統通知；點下去就把使用者帶回 App。
// 2) v0.88 訊號差也能打開：
//    - App 外殼 (/, css, js, manifest, 圖示) 用「網路優先」：有網路一律拿最新版 (伺服器有
//      ETag，沒改過只回 304，很省流量)；4 秒沒回應或離線才用上次存下來的版本。所以不會
//      發生「一直卡在舊版畫面」的問題。
//    - GET /api/... 的資料也是網路優先，離線時顯示「上次看到的內容」(標記成離線資料)。
//      登入、登出、除錯相關的 API 不存；登出時整個資料快取會被清掉 (見 app.js doLogout)。
//    - 送出資料 (POST/PUT/DELETE) 一律不經過快取，離線時會直接失敗、由畫面提示稍後再試。

const SHELL_CACHE = 'lifehub-shell-v1';
const API_CACHE = 'lifehub-api-v1';
const SHELL_URLS = ['/', '/css/style.css', '/js/app.js', '/manifest.json', '/icons/icon-192.png', '/icons/icon-180.png'];
const NETWORK_TIMEOUT_MS = 4000;

self.addEventListener('install', (event) => {
  self.skipWaiting();
  event.waitUntil(
    caches.open(SHELL_CACHE).then((c) => Promise.all(SHELL_URLS.map((u) => c.add(u).catch(() => {}))))
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    const keep = new Set([SHELL_CACHE, API_CACHE]);
    for (const k of await caches.keys()) if (!keep.has(k)) await caches.delete(k);
    await self.clients.claim();
  })());
});

self.addEventListener('message', (event) => {
  if (event.data === 'clear-api-cache') event.waitUntil(caches.delete(API_CACHE));
});

function isShellRequest(url, req) {
  if (req.mode === 'navigate') return true;
  return url.pathname === '/' || url.pathname === '/index.html' || url.pathname === '/manifest.json' ||
    url.pathname.startsWith('/css/') || url.pathname.startsWith('/js/') || url.pathname.startsWith('/icons/');
}
function isCacheableApi(url) {
  if (!url.pathname.startsWith('/api/')) return false;
  if (url.pathname === '/api/auth/me') return true; // 離線時才知道「誰登入著」，登出會清掉
  return !/^\/api\/(auth|debug|backup|admin|export|assistant)\b/.test(url.pathname);
}

// 網路優先：timeout 內網路有回就用網路 (順便更新快取)；逾時或失敗才用快取。
async function networkFirst(req, cacheName, cacheKey, markOffline) {
  const cache = await caches.open(cacheName);
  const network = fetch(req).then((res) => {
    if (res && res.ok) cache.put(cacheKey, res.clone()).catch(() => {});
    return res;
  });
  network.catch(() => {}); // 避免 unhandled rejection
  const timeout = new Promise((resolve) => setTimeout(() => resolve('timeout'), NETWORK_TIMEOUT_MS));
  const first = await Promise.race([network.catch(() => 'error'), timeout]);
  if (first !== 'timeout' && first !== 'error') return first;
  const cached = await cache.match(cacheKey);
  if (cached) {
    if (!markOffline) return cached;
    const headers = new Headers(cached.headers);
    headers.set('x-lifehub-offline', '1');
    return new Response(await cached.blob(), { status: cached.status, statusText: cached.statusText, headers });
  }
  return network; // 沒有快取就只能等網路 (或失敗)
}

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;
  if (isShellRequest(url, req)) {
    const key = req.mode === 'navigate' ? '/' : url.pathname;
    event.respondWith(networkFirst(req, SHELL_CACHE, key, false));
  } else if (isCacheableApi(url)) {
    event.respondWith(networkFirst(req, API_CACHE, req.url, true));
  }
});

self.addEventListener('push', (event) => {
  let data = { title: '提醒', body: '有新的提醒，點開看看' };
  try {
    if (event.data) data = event.data.json();
  } catch (e) {
    try { data.body = event.data.text(); } catch (e2) { /* 忽略，用預設值 */ }
  }

  event.waitUntil(
    self.registration.showNotification(data.title || '提醒', {
      body: data.body || '',
      icon: data.icon || '/icons/icon-192.png',
      badge: '/icons/icon-192.png',
      tag: 'lifehub-reminder', // 同一個 tag：新的提醒進來時取代舊的，通知欄不會愈疊愈多
      renotify: true,
    })
  );
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientsList) => {
      for (const client of clientsList) {
        if ('focus' in client) return client.focus();
      }
      if (self.clients.openWindow) return self.clients.openWindow('/');
    })
  );
});
