// ===================== 共用工具 =====================
const state = { user: null, prefs: null };

// ===================== 深色模式 =====================
// theme 存的是使用者「選擇」：'light' / 'dark' / 'auto' (跟著系統)。
// 還沒登入 (登入畫面) 或帳號設定還沒抓回來之前，沒有帳號層級的偏好可以參考，先跟著系統。
function computeEffectiveTheme(pref) {
  if (pref === 'dark') return 'dark';
  if (pref === 'light') return 'light';
  const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
  return prefersDark ? 'dark' : 'light';
}
function applyTheme(pref) {
  const effective = computeEffectiveTheme(pref);
  if (effective === 'dark') document.documentElement.setAttribute('data-theme', 'dark');
  else document.documentElement.removeAttribute('data-theme');
}
applyTheme('auto'); // 登入畫面先跟著系統偏好，登入後會再套用這個帳號自己存的設定
if (window.matchMedia) {
  window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => {
    // 只有選「自動」的人需要跟著系統即時切換；已經手動選了淺色/深色的人不應該被打擾
    if (!state.prefs || state.prefs.theme === 'auto' || !state.prefs.theme) applyTheme('auto');
  });
}
async function setThemePref(pref) {
  applyTheme(pref);
  if (!state.prefs) return;
  state.prefs.theme = pref;
  try { await api('/prefs', { method: 'PUT', body: state.prefs }); } catch (e) {}
  renderSettings();
}

// ===================== 側欄收合 =====================
function toggleSidebar() {
  const sb = $('#sidebar');
  const collapsed = sb.classList.toggle('collapsed');
  $('#sidebarToggle').textContent = collapsed ? '▸' : '◂';
  try { localStorage.setItem('lifehub_sidebar_collapsed', collapsed ? '1' : '0'); } catch (e) {}
}
function restoreSidebarState() {
  try {
    if (localStorage.getItem('lifehub_sidebar_collapsed') === '1') {
      $('#sidebar').classList.add('collapsed');
      $('#sidebarToggle').textContent = '▸';
    }
  } catch (e) {}
}

// ===================== 星空背景 =====================
function initStarfield() {
  const canvas = $('#starfield');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  let stars = [];
  function resize() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    const count = Math.round((canvas.width * canvas.height) / 9000);
    stars = Array.from({ length: count }, () => ({
      x: Math.random() * canvas.width,
      y: Math.random() * canvas.height,
      r: Math.random() * 1.3 + 0.3,
      base: Math.random() * 0.5 + 0.25,
      speed: Math.random() * 0.015 + 0.004,
      phase: Math.random() * Math.PI * 2,
    }));
  }
  function draw(t) {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = '#eaf0fb';
    stars.forEach((s) => {
      const twinkle = reduceMotion ? s.base : s.base + Math.sin(t * s.speed + s.phase) * 0.35;
      ctx.globalAlpha = Math.max(0.08, Math.min(1, twinkle));
      ctx.beginPath();
      ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
      ctx.fill();
    });
    ctx.globalAlpha = 1;
    if (!reduceMotion) requestAnimationFrame(draw);
  }
  window.addEventListener('resize', resize);
  resize();
  draw(0);
}

function $(sel) { return document.querySelector(sel); }
function el(tag, attrs = {}, children = []) {
  const e = document.createElement(tag);
  // 像 checked/selected/disabled 這種布林屬性，HTML 只看「有沒有這個屬性」不看值，
  // 所以 setAttribute(k, false) 還是會被瀏覽器當成「有設定」而顯示成 checked/selected/disabled，
  // 這裡特別處理：值是 false 就整個不設定，值是 true 就設成空字串。
  const BOOLEAN_ATTRS = new Set(['checked', 'selected', 'disabled', 'readonly', 'required', 'multiple']);
  Object.entries(attrs).forEach(([k, v]) => {
    if (k === 'html') e.innerHTML = v;
    else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else if (BOOLEAN_ATTRS.has(k)) { if (v) e.setAttribute(k, ''); }
    else e.setAttribute(k, v);
  });
  // 防呆：children 只要不是「已經是 DOM Node」的東西 (例如不小心直接塞了數字、布林值)，
  // 一律轉成文字節點，不要讓 appendChild 直接炸掉 (之前選股工具的漲跌欄位就是踩到這個)。
  (Array.isArray(children) ? children : [children]).forEach((c) => {
    if (c == null) return;
    e.appendChild(c instanceof Node ? c : document.createTextNode(String(c)));
  });
  return e;
}
// v0.78（Phase 4）：陽春 <select> 改成圖示/分段按鈕樣式的共用元件。
// 設計上刻意「掛皮不換骨」──回傳的容器元素本身用 Object.defineProperty 模擬原生
// select 的 .value getter/setter，所以呼叫端原本讀寫 $('#xxx').value 或監聽 onchange
// 的程式碼完全不用改，只要把 el('select', {...}, [...]) 換成 chipSelectEl({...}) 即可。
// variant: 'chips' (預設，多選項自然換行)｜'segmented' (二選一等寬相連)｜'icons' (純圖示小方格)
function chipSelectEl({ id, options, value, onchange, variant, style }) {
  const wrap = el('div', {
    id,
    class: 'chip-select-row' + (variant === 'segmented' ? ' segmented' : variant === 'icons' ? ' icon-grid' : ''),
    style: style || '',
  });
  let current = value != null ? value : '';
  function renderChips() {
    wrap.innerHTML = '';
    options.forEach((o) => {
      wrap.appendChild(el('button', {
        type: 'button',
        class: 'chip-select-btn' + (current === o.value ? ' selected' : ''),
        onclick: () => {
          current = o.value;
          renderChips();
          if (onchange) onchange({ target: wrap });
        },
      }, o.label));
    });
  }
  renderChips();
  Object.defineProperty(wrap, 'value', {
    get() { return current; },
    set(v) { current = v; renderChips(); },
  });
  return wrap;
}
// 骨架屏 (skeleton) 載入佔位：取代單純的「載入中...」文字，用會閃爍的灰色色塊模擬
// 內容大概的形狀，視覺上比較不會有「卡住了」的感覺，也更像原生 App 常見的載入手感。
function skeletonLines(n = 2) {
  const wrap = el('div', { class: 'skeleton-wrap' });
  for (let i = 0; i < n; i++) {
    wrap.appendChild(el('div', { class: 'skeleton-line' + (i === n - 1 ? ' short' : '') }));
  }
  return wrap;
}
function showToast(msg) {
  const t = $('#toast');
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 2200);
}
async function api(path, opts = {}) {
  let res;
  try {
    res = await fetch('/api' + path, {
      headers: { 'content-type': 'application/json' },
      ...opts,
      body: opts.body ? JSON.stringify(opts.body) : undefined,
    });
  } catch (e) {
    // v0.88：離線/訊號差時 fetch 直接丟 TypeError，換成看得懂的訊息
    if (!navigator.onLine || e instanceof TypeError) { setOfflineBanner(true); throw new Error('目前沒有網路，等連上再試一次'); }
    throw e;
  }
  if (res.headers.get('x-lifehub-offline') === '1') setOfflineBanner(true);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
  return data;
}
function fmtNum(n) { return Number(n || 0).toLocaleString('zh-Hant-TW'); }
function fmtMoney(n) { return 'NT$ ' + Number(n || 0).toLocaleString('zh-Hant-TW'); }
// 旅遊分帳可能不是台幣計價 (例如整趟旅程用日圓結算)，這裡不能寫死 NT$，要照旅程的 base_currency 顯示
function fmtCurrency(n, currency) { return `${currency || 'TWD'} ${Number(n || 0).toLocaleString('zh-Hant-TW')}`; }

// ===================== Auth =====================
function toggleAuth(showRegister) {
  $('#loginForm').style.display = showRegister ? 'none' : 'block';
  $('#registerForm').style.display = showRegister ? 'block' : 'none';
  $('#forgotPasswordForm').style.display = 'none';
}
function toggleForgotPassword(show) {
  $('#loginForm').style.display = show ? 'none' : 'block';
  $('#registerForm').style.display = 'none';
  $('#forgotPasswordForm').style.display = show ? 'block' : 'none';
  $('#fpError').textContent = '';
}

async function doLogin() {
  try {
    const user = await api('/auth/login', {
      method: 'POST',
      body: { email: $('#loginEmail').value.trim(), password: $('#loginPassword').value },
    });
    clearOfflineApiCache(); // 換帳號登入時不要看到上一個帳號的離線資料
    onAuthed(user);
  } catch (e) { $('#loginError').textContent = e.message; }
}
async function doRegister() {
  try {
    const user = await api('/auth/register', {
      method: 'POST',
      body: { name: $('#regName').value.trim(), email: $('#regEmail').value.trim(), password: $('#regPassword').value },
    });
    await onAuthed(user);
    // 這組備用重設碼只會在這次回應出現一次，之後就只存雜湊值、拿不回明碼了，
    // 一定要在進到首頁之後馬上跳出來提醒使用者記下來。要等 onAuthed 回傳的 promise
    // 完成 (代表 switchTab('dashboard') 也跑完了)，不然彈窗會被 switchTab 內建的
    // closeSheet() 立刻關掉。
    if (user.recoveryCode) showRecoveryCodeModal(user.recoveryCode, true);
  } catch (e) { $('#regError').textContent = e.message; }
}
async function doForgotPassword() {
  $('#fpError').textContent = '';
  const email = $('#fpEmail').value.trim();
  const recoveryCode = $('#fpCode').value.trim();
  const newPassword = $('#fpNewPassword').value;
  if (!email || !recoveryCode || !newPassword) { $('#fpError').textContent = '請填寫全部欄位'; return; }
  try {
    await api('/auth/forgot-password', { method: 'POST', body: { email, recoveryCode, newPassword } });
    showToast('密碼已重設，請用新密碼登入');
    $('#loginEmail').value = email;
    $('#fpEmail').value = ''; $('#fpCode').value = ''; $('#fpNewPassword').value = '';
    toggleForgotPassword(false);
  } catch (e) { $('#fpError').textContent = e.message; }
}

// 顯示備用重設碼的彈窗 (共用底部彈窗元件)。isNew=true 代表這是「剛註冊/剛重新產生」的
// 第一次顯示，文案會特別強調「只會顯示這一次」。
function showRecoveryCodeModal(code, isNew) {
  openSheet('備用重設碼', () => {
    const wrap = el('div', { class: 'recovery-code-modal' });
    wrap.appendChild(el('p', { class: 'hint' },
      isNew
        ? '請把下面這組重設碼記下來 (截圖或存到密碼管理器)，之後忘記密碼時要用它 + email 才能自己重設密碼。這組碼「只會顯示這一次」，離開這個畫面後就看不到明碼了。'
        : '這是剛剛重新產生的新重設碼，一樣只會顯示這一次，請立刻記下來。舊的重設碼已經失效。'
    ));
    const codeBox = el('div', { class: 'recovery-code-box' }, code);
    wrap.appendChild(codeBox);
    wrap.appendChild(el('button', {
      class: 'btn btn-ghost recovery-copy-btn',
      onclick: async () => {
        try { await navigator.clipboard.writeText(code); showToast('已複製到剪貼簿'); }
        catch (e) { showToast('複製失敗，請手動選取文字'); }
      },
    }, '📋 複製'));
    wrap.appendChild(el('button', { class: 'btn btn-primary recovery-confirm-btn', onclick: () => closeSheet() }, '我已經記下來了'));
    return wrap;
  });
}
// v0.88：離線提示條。資料來自 Service Worker 快取 (上次看到的內容) 或網路斷掉時顯示，
// 連回網路就自動收起來。
function setOfflineBanner(show) {
  let bar = document.getElementById('offlineBanner');
  if (!show) { if (bar) bar.remove(); return; }
  if (bar) return;
  bar = el('div', { id: 'offlineBanner', class: 'offline-banner', role: 'status' }, '離線中：顯示上次看到的內容，新增或修改要等連上網路');
  document.body.appendChild(bar);
}
window.addEventListener('offline', () => setOfflineBanner(true));
window.addEventListener('online', () => {
  setOfflineBanner(false);
  if (state.user && typeof switchTab === 'function' && currentTab) switchTab(currentTab);
});
function clearOfflineApiCache() {
  try {
    if (navigator.serviceWorker && navigator.serviceWorker.controller) navigator.serviceWorker.controller.postMessage('clear-api-cache');
    if (window.caches) caches.delete('lifehub-api-v1').catch(() => {});
  } catch (e) { /* ignore */ }
}
// App 外殼離線快取不依賴推播支援 (iOS 沒加入主畫面也一樣能用)，一載入就註冊。
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => { navigator.serviceWorker.register('/sw.js').catch(() => {}); });
}

async function doLogout() {
  try { await api('/auth/logout', { method: 'POST' }); } catch (e) { /* 離線也要能登出畫面 */ }
  clearOfflineApiCache();
  state.user = null;
  $('#shell').style.display = 'none';
  $('#authScreen').style.display = 'flex';
  toggleAuth(false); // 回到登入畫面，不要停留在登出前剛好開著的註冊/忘記密碼表單
}
function onAuthed(user) {
  state.user = user;
  $('#authScreen').style.display = 'none';
  $('#shell').style.display = 'flex';
  $('#userName').textContent = user.name;
  $('#userAvatar').textContent = (user.name || '?').slice(0, 1).toUpperCase();
  // v0.69：管理者後台獨立成一個分頁，不用再滑到「個人化設定」最下面才看得到——
  // 只有管理者帳號登入時，才把頂欄跟側欄的入口顯示出來，一般使用者連按鈕本身都看不到。
  if ($('#adminTopbarBtn')) $('#adminTopbarBtn').style.display = user.isAdmin ? '' : 'none';
  if ($('#navAdminItem')) $('#navAdminItem').style.display = user.isAdmin ? '' : 'none';
  restoreSidebarState();
  // 回傳這個 promise 是為了讓呼叫的地方 (例如註冊後要跳出備用重設碼彈窗) 可以先
  // await 到「首頁真的載入完成、switchTab('dashboard') 也跑完」之後再開自己的彈窗——
  // 不然 switchTab 內建會呼叫 closeSheet()，時間點沒抓好的話，剛開的彈窗會立刻被關掉。
  return loadPrefsAndBoot();
}
initStarfield();

async function loadPrefsAndBoot() {
  try {
    state.prefs = await api('/prefs');
  } catch (e) { /* 忽略，用預設值 */ }
  applyTheme(state.prefs && state.prefs.theme);
  renderBottomNav(); // 底部導覽列釘選項目跟著 prefs 一起套用，登入後才畫，避免用到還沒讀到的預設值
  setupBottomNavAutoHide(); // 捲動自動隱藏/邊緣滑動叫回，只要掛一次監聽即可
  currentTab = null; // 確保登入後第一次進首頁也會正確設定網址列 hash
  try { history.replaceState({ tab: 'dashboard' }, '', '#dashboard'); } catch (e) {}
  switchTab('dashboard'); // switchTab 現在會自己呼叫 renderDashboard()，這裡不用再手動呼叫一次
  try {
    const health = await api('/health');
    $('#appVersion').textContent = health.version;
  } catch (e) {}
  checkMoodReminder();
  checkGeneralReminders();
  registerPushServiceWorker();
}

// 如果是從別的地方帶著 hash 網址進來 (或按了瀏覽器上一頁/下一頁)，切到對應分頁。
// 注意：LifeHub 切分頁本身不會往 history 疊新的一筆 (見 switchTab 內的說明)，
// 所以這個監聽平常幾乎不會被自己的分頁切換觸發到，只處理「真的有網址列 history 變化」的情況。
window.addEventListener('popstate', (ev) => {
  if (!state.user) return; // 還沒登入時 (auth 畫面) 不處理，避免誤動作
  const tab = (ev.state && ev.state.tab) || 'dashboard';
  switchTab(tab, { fromPopstate: true });
});

// ---------- 站內提醒強化 ----------
// 除了首頁/心情頁面上的關心 banner，這裡再加兩層：
//   1) 側邊欄「心情陪伴」旁邊的小紅點，不管現在在哪個分頁都看得到，不用特地點進心情頁才知道。
//   2) 瀏覽器原生通知 (需要使用者自己按同意)，一天最多提醒一次，避免打擾。
async function checkMoodReminder() {
  try {
    const summary = await api('/mood/summary?days=7');
    const navItem = $('#navMoodItem');
    if (navItem) {
      const existingDot = navItem.querySelector('.nav-alert-dot');
      if (summary.careMessage) {
        if (!existingDot) navItem.appendChild(el('span', { class: 'nav-alert-dot' }));
      } else if (existingDot) {
        existingDot.remove();
      }
    }
    // v0.84.2：只有設定頁開了心情相關推播 (careNotifyAllowed) 才跳前景通知，側欄紅點照常顯示。
    if (summary.careMessage && summary.careNotifyAllowed && 'Notification' in window && Notification.permission === 'granted') {
      const lastNotified = localStorage.getItem('lifehub_mood_reminder_date');
      const today = todayStr();
      if (lastNotified !== today) {
        new Notification('LifeHub 心情陪伴', { body: summary.careMessage, icon: undefined });
        localStorage.setItem('lifehub_mood_reminder_date', today);
      }
    }
  } catch (e) { /* 提醒功能失敗不影響主要功能，安靜跳過 */ }
}

async function enableMoodBrowserNotification() {
  if (!('Notification' in window)) { showToast('這個瀏覽器不支援通知功能'); return; }
  const perm = await Notification.requestPermission();
  if (perm === 'granted') {
    showToast('已開啟瀏覽器通知，心情需要關心時會提醒你');
    checkMoodReminder();
    checkGeneralReminders();
  } else {
    showToast('沒有開啟通知權限，之後可以在瀏覽器設定裡再打開');
  }
}

// ---------- 主動式提醒：側欄紅點 + 瀏覽器通知 ----------
// 跟上面的心情提醒是同一套機制、同一組瀏覽器通知權限，這裡把範圍擴大到帳單/待辦/預算。
// 注意：這裡用的是 Notification API 的「前景通知」，只有在這個分頁/App 開著的時候才會跳出來，
// 手機螢幕熄滅或 App 被關掉時不會收到——這需要 Service Worker + Web Push 才做得到，是完全
// 不同的機制 (見 sidebar 個人化設定頁的說明)，目前還沒做。
async function checkGeneralReminders() {
  try {
    const data = await api('/insights/reminders');
    const items = data.items || [];
    const byTab = {};
    items.forEach((it) => { byTab[it.tab] = (byTab[it.tab] || 0) + 1; });
    ['bills', 'tasks'].forEach((tabKey) => {
      const navItem = document.querySelector(`.nav-item[data-tab="${tabKey}"]`);
      if (!navItem) return;
      const existingDot = navItem.querySelector('.nav-alert-dot');
      if (byTab[tabKey]) {
        if (!existingDot) navItem.appendChild(el('span', { class: 'nav-alert-dot' }));
      } else if (existingDot) {
        existingDot.remove();
      }
    });

    // v0.84.2：前景通知改用 notifyItems (已依設定頁推播開關過濾，跟背景推播同一份規則)；
    // 側欄紅點仍然看完整的 items。舊版伺服器沒有 notifyItems 時寧可不跳，也不要無視開關。
    const notifyItems = Array.isArray(data.notifyItems) ? data.notifyItems : [];
    if (notifyItems.length && 'Notification' in window && Notification.permission === 'granted') {
      const lastNotified = localStorage.getItem('lifehub_general_reminder_date');
      const today = todayStr();
      if (lastNotified !== today) {
        const top = notifyItems[0];
        const extra = notifyItems.length > 1 ? `，還有 ${notifyItems.length - 1} 件其他提醒` : '';
        new Notification('LifeHub 提醒', { body: `${top.text}${extra}` });
        localStorage.setItem('lifehub_general_reminder_date', today);
      }
    }
  } catch (e) { /* 提醒功能失敗不影響主要功能，安靜跳過 */ }
}

// v0.65：/insights/reminders 算出來的洞察 (情緒化消費偵測、心情趨勢分級等) 之前完全沒地方
// 顯示 (首頁的「主動式提醒」區塊已經整個移除)，這個共用函式讓各分頁自己在最上面顯示跟
// 自己相關的那幾種洞察，篩不到符合的項目時容器維持空白，不會出現空卡片。
async function loadTabInsightAlerts(containerId, types) {
  const holder = $('#' + containerId);
  if (!holder) return;
  try {
    const data = await api('/insights/reminders');
    const items = (data.items || []).filter((it) => types.includes(it.type));
    holder.innerHTML = '';
    items.forEach((it) => {
      const colorClass = it.severity === 'critical' ? 'insight-alert-critical' : it.severity === 'warning' ? 'insight-alert-warning' : 'insight-alert-info';
      holder.appendChild(el('div', { class: `card insight-alert-card ${colorClass}` }, [
        el('div', { style: 'display:flex;gap:8px;align-items:flex-start' }, [
          el('span', { style: 'font-size:20px;line-height:1' }, it.icon || '💡'),
          el('span', {}, it.text),
        ]),
      ]));
    });
  } catch (e) { /* 洞察載入失敗不影響分頁其他功能，安靜跳過 */ }
}

// ---------- 背景推播通知 (Web Push) ----------
// 跟上面 checkGeneralReminders() 的差異：那個是「前景通知」，只有分頁開著才有用；
// 這裡是真的 Service Worker + Push 訂閱，螢幕熄滅、App 沒開著也收得到 (iOS 需要先
// 「加入主畫面」變成 PWA、iOS 16.4 以上才支援)。伺服器端邏輯見 src/routes/push.js
// 的背景排程 + src/services/webpush.js 的加密/簽章實作。
function urlBase64ToUint8Array(base64String) {
  const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
  const rawData = atob(base64);
  const outputArray = new Uint8Array(rawData.length);
  for (let i = 0; i < rawData.length; i++) outputArray[i] = rawData.charCodeAt(i);
  return outputArray;
}

async function registerPushServiceWorker() {
  if (!('serviceWorker' in navigator) || !('PushManager' in window)) return;
  try {
    await navigator.serviceWorker.register('/sw.js');
  } catch (e) { /* 註冊失敗不影響其他功能，安靜跳過 */ }
  updatePushStatusUI();
}

// 目前訂閱狀態，給設定頁顯示用；不強迫使用者一定要開，純粹告知現況。
// `serviceWorker.ready` 在極少數情況 (例如註冊被瀏覽器擴充功能擋掉) 可能永遠不會
// resolve，這裡加一個 5 秒逾時保護，避免設定頁的「檢查中...」卡住不會消失。
function withTimeout(promise, ms) {
  return Promise.race([
    promise,
    new Promise((_, reject) => setTimeout(() => reject(new Error('timeout')), ms)),
  ]);
}

async function getPushSubscriptionStatus() {
  if (!('serviceWorker' in navigator) || !('PushManager' in window)) return 'unsupported';
  try {
    const reg = await withTimeout(navigator.serviceWorker.ready, 5000);
    const sub = await reg.pushManager.getSubscription();
    return sub ? 'subscribed' : 'unsubscribed';
  } catch (e) {
    // 注意：這裡刻意回傳 'unsubscribed' 而不是 'unsupported'——瀏覽器明明支援 Push API，
    // 只是這次檢查逾時或暫時出錯，回傳 'unsupported' 會把按鈕整個藏起來，讓使用者沒辦法
    // 再按一次重試，體驗更差。
    return 'unsubscribed';
  }
}

async function updatePushStatusUI() {
  const el2 = $('#pushStatusText');
  if (!el2) return; // 不在設定頁時不用管
  const status = await getPushSubscriptionStatus();
  const labels = {
    unsupported: '這個瀏覽器不支援背景推播通知',
    unsubscribed: '目前未開啟',
    subscribed: '已開啟：螢幕熄滅或 App 沒開著時也會收到提醒',
  };
  el2.textContent = labels[status] || '';
  const btn = $('#pushToggleBtn');
  if (btn) {
    if (status === 'unsupported') { btn.style.display = 'none'; }
    else { btn.style.display = ''; btn.textContent = status === 'subscribed' ? '關閉背景推播' : '開啟背景推播通知'; }
  }
  const testBtn = $('#pushTestBtn');
  if (testBtn) testBtn.style.display = status === 'subscribed' ? '' : 'none';
}

// 立刻送一則測試通知，不用等背景排程 (最長 30 分鐘) 才能確認手機/電腦真的收得到。
async function sendTestPush() {
  try {
    const res = await api('/push/test', { method: 'POST' });
    if (res.ok) {
      showToast('測試通知已送出，注意看看手機/電腦有沒有跳出通知');
    } else {
      showToast('送出了，但推播服務回應失敗，可能要重新開啟一次背景推播');
    }
  } catch (e) {
    showToast('送出失敗：' + e.message);
  }
}

async function togglePushSubscription() {
  const status = await getPushSubscriptionStatus();
  if (status === 'subscribed') {
    await disablePushNotifications();
  } else {
    await enablePushNotifications();
  }
}

async function enablePushNotifications() {
  if (!('serviceWorker' in navigator) || !('PushManager' in window)) {
    showToast('這個瀏覽器不支援背景推播通知');
    return;
  }
  try {
    const perm = await Notification.requestPermission();
    if (perm !== 'granted') {
      showToast('沒有開啟通知權限，之後可以在瀏覽器設定裡再打開');
      return;
    }
    const reg = await withTimeout(navigator.serviceWorker.ready, 8000);
    const { publicKey } = await api('/push/vapid-public-key');
    const sub = await reg.pushManager.subscribe({
      userVisibleOnly: true,
      applicationServerKey: urlBase64ToUint8Array(publicKey),
    });
    const subJson = sub.toJSON();
    await api('/push/subscribe', { method: 'POST', body: { endpoint: subJson.endpoint, keys: subJson.keys } });
    showToast('已開啟背景推播通知');
  } catch (e) {
    showToast('開啟失敗：' + e.message);
  }
  updatePushStatusUI();
}

async function disablePushNotifications() {
  try {
    const reg = await withTimeout(navigator.serviceWorker.ready, 8000);
    const sub = await reg.pushManager.getSubscription();
    if (sub) {
      await api('/push/unsubscribe', { method: 'POST', body: { endpoint: sub.endpoint } });
      await sub.unsubscribe();
    }
    showToast('已關閉背景推播通知');
  } catch (e) {
    showToast('關閉失敗：' + e.message);
  }
  updatePushStatusUI();
}

// ===================== Tab 切換 =====================
const TAB_TITLES = { dashboard: '我的首頁', travel: '交通與旅遊', diary: '日記', mood: '心情陪伴', finance: '記帳', bills: '帳單提醒', calendar: '行事曆', tasks: '待辦事項', health: '健康紀錄', relationships: '人際關係', partnerCare: '陪伴另一半', familyBoard: '家庭公告欄', reading: '讀書', habits: '習慣養成', kanban: '專案看板', routineTemplates: '固定行程模板', notes: '個人筆記', tarot: '占卜', wishlist: '願望清單', annualReview: '年度回顧', splitGroups: '揪團分帳', assistant: 'AI 助理', rewards: '獎勵頁面', settings: '個人化設定', admin: '管理者後台' };
let currentTab = null;
// v0.16.1 曾經讓每次切分頁都往 history 疊一筆新紀錄，想讓「側滑返回上一頁」在 Safari
// 分頁裡變成「回到上一個分頁」而不是直接離開網站。但實際在真的 iPhone 上測試後發現：
// WebKit 的側滑返回手勢預覽動畫，是設計給「真的換了一個網頁」的情境用的，對這種完全
// 靠 JS pushState 疊出來的同頁分頁切換，動畫沒有正確的「上一頁畫面」可以顯示，側滑到
// 一半常常會卡住、畫面整個往右歪掉/裁切一塊 (使用者實測回報過兩次)。這個問題比「側滑
// 可以換分頁」這個小方便更嚴重，所以改回不疊新的 history 紀錄；只用 replaceState 讓網址
// 列的 hash 跟著目前分頁換 (重新整理網頁還是會停在正確分頁)，不會製造側滑手勢可以卡住的
// 「假的上一頁」。iOS「加入主畫面」的獨立視窗模式本來就沒有側滑返回手勢 (蘋果系統限制)，
// 這裡完全不影響那個情境。
//
// v0.34：使用者還是想要「左邊緣右滑 = 回上一頁」的動作，但吸取上面的教訓，這次完全不碰
// 瀏覽器 history/pushState (避免又跟 iOS Safari 自己的側滑手勢打架)，改成自己在記憶體裡
// 維護一份「上一個分頁」的堆疊 (tabBackStack)：每次「主動」切分頁 (不是透過返回手勢) 就把
// 切換前的分頁記下來；邊緣右滑時彈出堆疊最上面那個分頁切過去，感覺就像系統的返回手勢，
// 但底層完全是純 JS 陣列操作，跟瀏覽器導航機制無關。
let tabBackStack = [];
function switchTab(tab, opts = {}) {
  if (!TAB_TITLES[tab]) tab = 'dashboard'; // history 裡存到不合法的分頁名稱時，安全回到首頁
  if (!opts.fromPopstate && tab !== currentTab) {
    try { history.replaceState({ tab }, '', '#' + tab); } catch (e) {}
  }
  if (!opts.isBack && currentTab && tab !== currentTab) {
    tabBackStack.push(currentTab);
    if (tabBackStack.length > 20) tabBackStack.shift(); // 上限 20 筆，避免長時間使用後無限增長
  }
  currentTab = tab;
  // v0.70：管理者後台「這週熱門功能」的資料來源——每次切分頁順手記一筆 (fire-and-forget，
  // 不 await、失敗也不管，不能因為這個統計用途影響到正常切分頁的體驗)。只記分頁名稱，
  // 不記分頁裡實際做了什麼操作。
  if (state.user) {
    api('/tab-usage', { method: 'POST', body: { tab } }).catch(() => {});
  }
  document.querySelectorAll('.nav-item').forEach((n) => n.classList.toggle('active', n.dataset.tab === tab));
  document.querySelectorAll('.bn-item').forEach((n) => n.classList.toggle('active', n.dataset.tab === tab));
  document.querySelectorAll('.tab-panel').forEach((p) => (p.style.display = 'none'));
  closeSheet(); // 切換分頁時，如果「更多」選單還開著就一起收起來
  if ($('#bottomNavMobile')) $('#bottomNavMobile').classList.remove('bn-hidden'); // 每次切分頁都重新顯示導覽列，不會停在上個分頁捲動時被隱藏的狀態
  // 心情頁、行事曆頁是鎖住視窗高度的固定版面 (flex column)，其他頁維持一般區塊排版。
  const activePanel = $(`#tab-${tab}`);
  activePanel.style.display = (tab === 'mood' || tab === 'calendar') ? 'flex' : 'block';
  // 切換分頁時加一個很輕的淡入位移動畫，感覺比「直接跳」滑順、比較不生硬；
  // 用移除再加回 class 的方式強制重新觸發動畫 (不然同一個 class 已經在身上，瀏覽器不會重播)。
  activePanel.classList.remove('tab-anim-in');
  void activePanel.offsetWidth;
  activePanel.classList.add('tab-anim-in');
  $('#pageTitle').textContent = TAB_TITLES[tab];
  // 首頁 (dashboard) 原本沒有被列在這裡——第一次登入時是靠 loadPrefsAndBoot() 自己另外呼叫
  // renderDashboard()，但這代表「切去別的分頁、再切回首頁」永遠不會重新整理，帳單/待辦/行事曆
  // 這些摘要卡片會停在剛登入當下的舊資料，即使背後資料已經改變也不會更新，要整頁重新整理才會恢復。
  // 這裡補上，讓首頁跟其他分頁一樣「每次切過去就重新抓最新資料」。
  if (tab === 'dashboard') renderDashboard();
  if (tab === 'travel') renderTravel();
  if (tab === 'diary') renderDiary();
  if (tab === 'mood') renderMood();
  if (tab === 'finance') renderFinance();
  if (tab === 'bills') renderBills();
  if (tab === 'calendar') renderCalendar();
  if (tab === 'tasks') renderTasks();
  if (tab === 'health') renderHealth();
  if (tab === 'relationships') renderRelationships();
  if (tab === 'partnerCare') renderPartnerCare();
  if (tab === 'familyBoard') renderFamilyBoard();
  if (tab === 'splitGroups') renderSplitGroups();
  if (tab === 'reading') renderReading();
  if (tab === 'habits') renderHabits();
  if (tab === 'kanban') renderKanban();
  if (tab === 'routineTemplates') renderRoutineTemplates();
  if (tab === 'notes') renderNotes();
  if (tab === 'tarot') renderTarot();
  if (tab === 'wishlist') renderWishlist();
  if (tab === 'annualReview') renderAnnualReview();
  if (tab === 'rewards') renderRewards();
  if (tab === 'assistant') renderAssistant();
  if (tab === 'settings') renderSettings();
  if (tab === 'admin') renderAdmin();
}

// ===================== 手機底部導覽：可自訂釘選 / 更多選單 / 首頁自訂 (共用同一個底部彈出面板) =====================
// v0.32 之前「首頁、股票、記帳、待辦」是寫死釘在底部，其餘 10 個分頁收進「更多」。
// 使用者反映想自訂底部那幾個常駐的位置，改成：「首頁」固定當第一個 (隨時回得去)，
// 其餘全部 13 個分頁都可以自由挑最多 3 個釘在底部 (state.prefs.bottomNavPinned)，
// 沒被釘選的自動收進「更多」彈出選單、也是首頁「全部功能」捷徑格的來源清單。
// 每個項目多一個 category，讓「全部功能」格子跟側欄可以依用途分組顯示，而不是 13 個(以後
// 會更多)全部平鋪在一起。分類本身的順序/標籤定義在下面的 NAV_CATEGORY_ORDER。
const ALL_NAV_ITEMS = [
  { icon: '✅', label: '待辦事項', tab: 'tasks', category: 'todo' },
  { icon: '🔁', label: '習慣養成', tab: 'habits', category: 'todo' },
  { icon: '🗂️', label: '專案看板', tab: 'kanban', category: 'todo' },
  { icon: '🗓️', label: '固定行程模板', tab: 'routineTemplates', category: 'todo' },
  { icon: '💰', label: '記帳', tab: 'finance', category: 'money' },
  { icon: '🧾', label: '帳單提醒', tab: 'bills', category: 'money' },
  { icon: '📔', label: '日記', tab: 'diary', category: 'life' },
  { icon: '💗', label: '心情陪伴', tab: 'mood', category: 'life' },
  { icon: '🩺', label: '健康紀錄', tab: 'health', category: 'life' },
  { icon: '📝', label: '個人筆記', tab: 'notes', category: 'life' },
  { icon: '🔮', label: '占卜', tab: 'tarot', category: 'life' },
  { icon: '🤝', label: '人際關係', tab: 'relationships', category: 'people' },
  { icon: '🌷', label: '陪伴另一半', tab: 'partnerCare', category: 'people' },
  { icon: '📌', label: '家庭公告欄', tab: 'familyBoard', category: 'people' },
  { icon: '🧮', label: '揪團分帳', tab: 'splitGroups', category: 'people' },
  { icon: '📅', label: '行事曆', tab: 'calendar', category: 'schedule' },
  { icon: '🚄', label: '交通與旅遊', tab: 'travel', category: 'schedule' },
  { icon: '📚', label: '讀書', tab: 'reading', category: 'collect' },
  { icon: '🎀', label: '願望清單', tab: 'wishlist', category: 'collect' },
  { icon: '🎊', label: '年度回顧', tab: 'annualReview', category: 'other' },
  { icon: '🤖', label: 'AI 助理', tab: 'assistant', category: 'other' },
  { icon: '🎁', label: '獎勵頁面', tab: 'rewards', category: 'other' },
  { icon: '⚙️', label: '個人化設定', tab: 'settings', category: 'other' },
];

// 分類的顯示順序跟標籤。之後陸續加新功能 (家庭公告欄→people、習慣養成/專案看板→todo、
// 讀書/願望清單→collect、獎勵頁面/年度回顧→other...) 都歸到現有分類，不需要另外發明新的
// category key，畫格子的地方 (buildCategorizedNavGrid) 會自動略過完全沒有項目的分類。
const NAV_CATEGORY_ORDER = ['todo', 'money', 'life', 'people', 'schedule', 'collect', 'other'];
const NAV_CATEGORY_LABELS = {
  todo: '待辦與習慣', money: '財務', life: '生活記錄', people: '人際',
  schedule: '行程與交通', collect: '收藏與興趣', other: '總覽與其他',
};

// 把 orderedMoreNavItems() 排好的清單，依 NAV_CATEGORY_ORDER 分組、加上分類標題，畫成
// 「全部功能」格子。renderRow 是實際畫單一項目格子的函式 (呼叫端傳入，這樣手機/桌面可以
// 共用同一份分組邏輯，只是格子本身的 DOM/樣式不同)。
function buildCategorizedNavGrid(items, gridClass, renderRow) {
  const wrap = el('div', {});
  const byCategory = new Map();
  items.forEach((item) => {
    const cat = item.category || 'other';
    if (!byCategory.has(cat)) byCategory.set(cat, []);
    byCategory.get(cat).push(item);
  });
  NAV_CATEGORY_ORDER.forEach((cat) => {
    const catItems = byCategory.get(cat);
    if (!catItems || !catItems.length) return; // 這個分類目前沒有任何項目就整段不顯示
    wrap.appendChild(el('div', { class: 'nav-cat-label' }, NAV_CATEGORY_LABELS[cat] || cat));
    const grid = el('div', { class: gridClass });
    catItems.forEach((item) => grid.appendChild(renderRow(item)));
    wrap.appendChild(grid);
  });
  return wrap;
}
const DEFAULT_BOTTOM_NAV_PINNED = ['finance', 'tasks', 'calendar'];
const BOTTOM_NAV_MAX = 3;

// 讀出目前釘在底部的最多 3 個分頁；會過濾掉不存在的 tab key，且沒設定過時退回預設值，
// 避免資料庫裡存了舊資料或手動改壞了設定時，底部導覽整個變成空的。
function bottomNavPinnedTabs() {
  const saved = (state.prefs && state.prefs.bottomNavPinned) || DEFAULT_BOTTOM_NAV_PINNED;
  const validKeys = new Set(ALL_NAV_ITEMS.map((i) => i.tab));
  const cleaned = [...new Set(saved)].filter((k) => validKeys.has(k)).slice(0, BOTTOM_NAV_MAX);
  return cleaned.length ? cleaned : DEFAULT_BOTTOM_NAV_PINNED;
}

// 依 state.prefs.moreNavOrder (存 tab key 陣列) 排序「沒有被釘在底部」的其餘分頁，用法跟
// 首頁小工具的 orderedMobileWidgets() 一樣：沒排過序、或有新項目還沒被排進去的，排在後面。
// 這份清單同時是首頁「全部功能」捷徑格、跟手機底部導覽「更多」彈出選單的來源。
function orderedMoreNavItems() {
  const pinned = new Set(bottomNavPinnedTabs());
  const pool = ALL_NAV_ITEMS.filter((i) => !pinned.has(i.tab));
  const order = (state.prefs && state.prefs.moreNavOrder) || [];
  const orderIndex = new Map(order.map((k, i) => [k, i]));
  return [...pool].sort((a, b) => {
    const ia = orderIndex.has(a.tab) ? orderIndex.get(a.tab) : 1000 + pool.indexOf(a);
    const ib = orderIndex.has(b.tab) ? orderIndex.get(b.tab) : 1000 + pool.indexOf(b);
    return ia - ib;
  });
}

function openMoreNavOrderSheet() {
  openSheet('排序「全部功能」捷徑', () => {
    const wrap = el('div', {});
    wrap.appendChild(el('p', { class: 'hint', style: 'margin:0 0 12px' }, '按住左邊的 ⠿ 拖曳可以調整順序，會同時套用在首頁跟手機底部「更多」選單。想調整底部常駐的項目，請到「個人化設定」→「底部導覽列」。'));
    const listEl = el('div', { class: 'widget-order-list' });
    orderedMoreNavItems().forEach((item) => {
      listEl.appendChild(el('div', { class: 'module-toggle-row widget-order-row', 'data-key': item.tab }, [
        el('span', { class: 'widget-drag-handle' }, '⠿'),
        el('span', { class: 'widget-order-label' }, `${item.icon} ${item.label}`),
      ]));
    });
    wrap.appendChild(listEl);
    setupMoreNavDragReorder(listEl);
    return wrap;
  });
}

// 依目前釘選重畫底部導覽列 DOM (登入後、以及每次釘選變動後都要呼叫)。
// 「首頁」永遠固定第一個、不能被移除，避免使用者不小心把回首頁的路徑弄丟。
function renderBottomNav() {
  const nav = $('#bottomNavMobile');
  if (!nav) return;
  nav.innerHTML = '';
  nav.appendChild(el('div', { class: `bn-item${currentTab === 'dashboard' || !currentTab ? ' active' : ''}`, 'data-tab': 'dashboard', onclick: () => switchTab('dashboard') }, [
    el('span', { class: 'bn-icon' }, '🏠'), el('span', {}, '首頁'),
  ]));
  bottomNavPinnedTabs().forEach((tabKey) => {
    const item = ALL_NAV_ITEMS.find((i) => i.tab === tabKey);
    if (!item) return;
    nav.appendChild(el('div', { class: `bn-item${currentTab === tabKey ? ' active' : ''}`, 'data-tab': tabKey, onclick: () => switchTab(tabKey) }, [
      el('span', { class: 'bn-icon' }, item.icon), el('span', {}, item.label),
    ]));
  });
  nav.appendChild(el('div', { class: 'bn-item', onclick: () => toggleMoreSheet() }, [
    el('span', { class: 'bn-icon' }, '⋯'), el('span', {}, '更多'),
  ]));
}

// v0.33：有些分頁內容比較長，往下捲動時固定在底部的導覽列會一直蓋住正在看的內容 (使用者
// 實際回報過心情陪伴分頁往下滑會被擋住)。往下捲動超過一點距離就自動滑出畫面讓出空間，
// 往上捲動馬上滑回來——這是大部分 App (Instagram、Threads 那類) 常見的做法，這部分維持
// 原樣不動。
//
// v0.34：左邊緣右滑原本只是「把導覽列叫回來」，使用者反應希望它真的做到「回上一頁」——
// 現在改成：如果有彈出面板 (更多選單/自訂面板等) 開著就先關掉它；不然就跳回上一個分頁，
// 感覺跟 iPhone/Android 系統手勢很像，但完全是自己在記憶體堆疊 (tabBackStack) 操作，
// 沒有用到瀏覽器 history/pushState，不會跟 iOS Safari 自己的側滑返回手勢衝突 (先前這個
// 問題就是因為疊了太多 history 紀錄造成的，這次刻意避開同一個坑)。
let bottomNavAutoHideSetup = false;
function setupBottomNavAutoHide() {
  if (bottomNavAutoHideSetup) return; // 只需要掛一次監聽，避免重覆呼叫時疊加好幾份
  bottomNavAutoHideSetup = true;
  const main = $('.main');
  const nav = $('#bottomNavMobile');
  if (!main || !nav) return;

  let lastScrollTop = main.scrollTop;
  const HIDE_THRESHOLD = 8; // 捲動距離小於這個門檻不處理，避免手抖或慣性回彈時一直閃爍
  const MIN_SCROLL_TOP_TO_HIDE = 32; // 剛進分頁、還在最上面的時候不隱藏，避免一進分頁就看不到導覽列
  main.addEventListener('scroll', () => {
    const st = main.scrollTop;
    const dy = st - lastScrollTop;
    if (Math.abs(dy) < HIDE_THRESHOLD) return;
    if (dy > 0 && st > MIN_SCROLL_TOP_TO_HIDE) nav.classList.add('bn-hidden'); // 往下捲：滑出去讓內容看得更完整
    else nav.classList.remove('bn-hidden'); // 往上捲：馬上滑回來 (這部分行為不變)
    lastScrollTop = st;
  }, { passive: true });

  // 從螢幕最左邊 (24px 內) 開始、往右滑超過一點距離，觸發「回上一頁」。
  let edgeTouchStartX = null, edgeTouchStartY = null, edgeTouchActive = false;
  document.addEventListener('touchstart', (e) => {
    if (!e.touches || !e.touches.length) return;
    const t = e.touches[0];
    edgeTouchActive = t.clientX <= 24;
    edgeTouchStartX = t.clientX;
    edgeTouchStartY = t.clientY;
  }, { passive: true });
  document.addEventListener('touchmove', (e) => {
    if (!edgeTouchActive || edgeTouchStartX == null || !e.touches || !e.touches.length) return;
    const t = e.touches[0];
    const dx = t.clientX - edgeTouchStartX;
    const dy = Math.abs(t.clientY - edgeTouchStartY);
    if (dx > 40 && dy < 50) {
      handleEdgeSwipeBack();
      edgeTouchActive = false; // 觸發一次就結束，避免同一次手勢重複觸發
    }
  }, { passive: true });
  document.addEventListener('touchend', () => { edgeTouchActive = false; }, { passive: true });
}

// 左邊緣右滑的實際動作：面板優先 (先關掉擋在最上面的彈出面板)，沒有面板才跳回上一個分頁。
// 堆疊是空的 (已經在最一開始進來的分頁，通常是首頁) 時，跟系統的返回手勢一樣不做任何事。
function handleEdgeSwipeBack() {
  const overlay = $('#sheetOverlay');
  if (overlay && overlay.classList.contains('show')) { closeSheet(); return; }
  if (tabBackStack.length) {
    const prevTab = tabBackStack.pop();
    switchTab(prevTab, { isBack: true });
  }
}

function openBottomNavCustomizeSheet() {
  openSheet('自訂底部導覽列', () => {
    const wrap = el('div', {});
    wrap.appendChild(el('p', { class: 'hint', style: 'margin:0 0 12px' }, '「🏠 首頁」固定在最左邊，方便隨時點回去；下面最多再選 3 個你最常用的功能釘在底部，按住 ⠿ 拖曳可以調整順序，沒釘選的都收在「更多」裡一樣找得到。'));

    const pinned = bottomNavPinnedTabs();
    wrap.appendChild(el('div', { class: 'dash-section-title', style: 'margin:4px 0 8px' }, `已釘選（${pinned.length}/${BOTTOM_NAV_MAX}）`));
    const pinnedListEl = el('div', { class: 'widget-order-list' });
    if (!pinned.length) {
      pinnedListEl.appendChild(el('div', { class: 'empty-state' }, '目前沒有釘選任何項目，底部只會顯示「首頁」跟「更多」'));
    }
    pinned.forEach((tabKey) => {
      const item = ALL_NAV_ITEMS.find((i) => i.tab === tabKey);
      if (!item) return;
      pinnedListEl.appendChild(el('div', { class: 'module-toggle-row widget-order-row', 'data-key': item.tab }, [
        el('span', { class: 'widget-drag-handle' }, '⠿'),
        el('span', { class: 'widget-order-label' }, `${item.icon} ${item.label}`),
        el('button', { class: 'btn btn-ghost', style: 'padding:5px 10px;font-size:12px', onclick: () => toggleBottomNavPin(item.tab, false) }, '移除'),
      ]));
    });
    wrap.appendChild(pinnedListEl);
    setupBottomNavDragReorder(pinnedListEl);

    wrap.appendChild(el('div', { class: 'dash-section-title', style: 'margin:18px 0 8px' }, '其他分頁（點「釘選」加入底部）'));
    const pinnedSet = new Set(pinned);
    const otherListEl = el('div', {});
    ALL_NAV_ITEMS.filter((i) => !pinnedSet.has(i.tab)).forEach((item) => {
      otherListEl.appendChild(el('div', { class: 'module-toggle-row' }, [
        el('span', {}, `${item.icon} ${item.label}`),
        el('button', { class: 'btn btn-ghost', style: 'padding:5px 10px;font-size:12px', onclick: () => toggleBottomNavPin(item.tab, true) }, '📌 釘選'),
      ]));
    });
    wrap.appendChild(otherListEl);
    return wrap;
  });
}

async function toggleBottomNavPin(tabKey, addIt) {
  let pinned = bottomNavPinnedTabs();
  if (addIt) {
    if (pinned.length >= BOTTOM_NAV_MAX) { showToast(`最多只能釘選 ${BOTTOM_NAV_MAX} 個，請先移除一個再加入新的`); return; }
    pinned = [...pinned, tabKey];
  } else {
    pinned = pinned.filter((k) => k !== tabKey);
  }
  await saveBottomNavPinned(pinned);
  openBottomNavCustomizeSheet(); // 重新畫一次面板，讓「已釘選」跟「其他分頁」清單立刻反映最新狀態
}

// 跟 setupMoreNavDragReorder 邏輯完全一樣，只是存的 prefs 欄位不同 (bottomNavPinned)，
// 獨立寫一份避免互相牽動兩種不同用途的清單。
function setupBottomNavDragReorder(listEl) {
  let dragRow = null, startY = 0, rowHeight = 1;
  listEl.querySelectorAll('.widget-drag-handle').forEach((handle) => {
    handle.addEventListener('pointerdown', (e) => {
      dragRow = handle.closest('.widget-order-row');
      if (!dragRow) return;
      startY = e.clientY;
      rowHeight = dragRow.offsetHeight || 1;
      dragRow.classList.add('dragging');
      try { handle.setPointerCapture(e.pointerId); } catch (err) {}
      e.preventDefault();
    });
  });
  listEl.addEventListener('pointermove', (e) => {
    if (!dragRow) return;
    const dy = e.clientY - startY;
    dragRow.style.transform = `translateY(${dy}px)`;
    const rows = Array.from(listEl.querySelectorAll('.widget-order-row'));
    const dragIndex = rows.indexOf(dragRow);
    const targetIndex = Math.max(0, Math.min(rows.length - 1, dragIndex + Math.round(dy / rowHeight)));
    if (targetIndex !== dragIndex) {
      const targetRow = rows[targetIndex];
      if (dy > 0) listEl.insertBefore(dragRow, targetRow.nextSibling);
      else listEl.insertBefore(dragRow, targetRow);
      startY = e.clientY;
      dragRow.style.transform = '';
    }
  });
  function endDrag() {
    if (!dragRow) return;
    dragRow.classList.remove('dragging');
    dragRow.style.transform = '';
    dragRow = null;
    const newOrder = Array.from(listEl.querySelectorAll('.widget-order-row')).map((r) => r.dataset.key);
    saveBottomNavPinned(newOrder);
  }
  listEl.addEventListener('pointerup', endDrag);
  listEl.addEventListener('pointercancel', endDrag);
}
async function saveBottomNavPinned(pinnedArr) {
  state.prefs = state.prefs || {};
  state.prefs.bottomNavPinned = pinnedArr;
  renderBottomNav();
  try {
    await api('/prefs', { method: 'PUT', body: state.prefs });
  } catch (e) { showToast('儲存失敗：' + e.message); }
}

// 跟首頁小工具的拖曳排序 (setupWidgetDragReorder) 邏輯完全一樣，只是存的 prefs 欄位不同
// (moreNavOrder 而不是 moduleOrder)、而且這份清單只有排序沒有開關，所以獨立寫一份，
// 避免硬把兩種不同用途的清單塞進同一個函式、互相牽動。
function setupMoreNavDragReorder(listEl) {
  let dragRow = null, startY = 0, rowHeight = 1;
  listEl.querySelectorAll('.widget-drag-handle').forEach((handle) => {
    handle.addEventListener('pointerdown', (e) => {
      dragRow = handle.closest('.widget-order-row');
      if (!dragRow) return;
      startY = e.clientY;
      rowHeight = dragRow.offsetHeight || 1;
      dragRow.classList.add('dragging');
      try { handle.setPointerCapture(e.pointerId); } catch (err) {}
      e.preventDefault();
    });
  });
  listEl.addEventListener('pointermove', (e) => {
    if (!dragRow) return;
    const dy = e.clientY - startY;
    dragRow.style.transform = `translateY(${dy}px)`;
    const rows = Array.from(listEl.querySelectorAll('.widget-order-row'));
    const dragIndex = rows.indexOf(dragRow);
    const targetIndex = Math.max(0, Math.min(rows.length - 1, dragIndex + Math.round(dy / rowHeight)));
    if (targetIndex !== dragIndex) {
      const targetRow = rows[targetIndex];
      if (dy > 0) listEl.insertBefore(dragRow, targetRow.nextSibling);
      else listEl.insertBefore(dragRow, targetRow);
      startY = e.clientY;
      dragRow.style.transform = '';
    }
  });
  function endDrag() {
    if (!dragRow) return;
    dragRow.classList.remove('dragging');
    dragRow.style.transform = '';
    dragRow = null;
    const newOrder = Array.from(listEl.querySelectorAll('.widget-order-row')).map((r) => r.dataset.key);
    saveMoreNavOrder(newOrder);
  }
  listEl.addEventListener('pointerup', endDrag);
  listEl.addEventListener('pointercancel', endDrag);
}
async function saveMoreNavOrder(order) {
  state.prefs = state.prefs || {};
  state.prefs.moreNavOrder = order;
  try {
    await api('/prefs', { method: 'PUT', body: state.prefs });
  } catch (e) { showToast('排序儲存失敗：' + e.message); }
  if ($('#tab-dashboard') && $('#tab-dashboard').classList.contains('active')) renderDashboard();
}

function openSheet(title, bodyBuilder) {
  $('#sheetTitle').textContent = title;
  const body = $('#sheetBody');
  body.innerHTML = '';
  body.appendChild(bodyBuilder());
  $('#sheetOverlay').classList.add('show');
}
function closeSheet(ev) {
  if (ev && ev.target !== ev.currentTarget) return; // 點面板內容不應該關閉，只有點背景遮罩或明確呼叫才關
  const overlay = $('#sheetOverlay');
  if (overlay) overlay.classList.remove('show');
}
// v0.85：「更多」選單最上面多一排「最常用」——依自己最近 30 天實際打開各分頁的次數
// (/tab-usage/mine，資料來自本來就在記的分頁切換紀錄)，不需要任何設定。已經釘在底部
// 導覽列的、首頁、設定頁不列入；次數太少 (< 3 次) 的不算「常用」，資料不夠時整排不顯示。
// 下面的分類清單維持原樣 (含使用者自己拖曳排過的順序)，這排只是多一個捷徑。
let myTabUsageCache = null;
function refreshMyTabUsage() {
  return api('/tab-usage/mine').then((d) => { myTabUsageCache = d.items || []; return myTabUsageCache; }).catch(() => myTabUsageCache || []);
}
function frequentNavItems(max = 4) {
  if (!myTabUsageCache || !myTabUsageCache.length) return [];
  const excluded = new Set([...bottomNavPinnedTabs(), 'dashboard', 'settings', 'admin']);
  const byTab = new Map(ALL_NAV_ITEMS.map((i) => [i.tab, i]));
  return myTabUsageCache
    .filter((r) => r.count >= 3 && !excluded.has(r.tab) && byTab.has(r.tab))
    .slice(0, max)
    .map((r) => byTab.get(r.tab));
}

function splitRarelyUsedNavItems(items, frequent) {
  const usage = myTabUsageCache || [];
  const total = usage.reduce((n, r) => n + r.count, 0);
  const freqSet = new Set((frequent || []).map((i) => i.tab));
  const pool = items.filter((i) => !freqSet.has(i.tab));
  if (total < 30) return { main: pool, rare: [] };
  const used = new Set(usage.filter((r) => r.count > 0).map((r) => r.tab));
  const keep = new Set(['settings']);
  return {
    main: pool.filter((i) => used.has(i.tab) || keep.has(i.tab)),
    rare: pool.filter((i) => !used.has(i.tab) && !keep.has(i.tab)),
  };
}

function toggleMoreSheet() {
  const overlay = $('#sheetOverlay');
  if (overlay && overlay.classList.contains('show')) { closeSheet(); return; }
  const render = () => openSheet('更多功能', () => {
    const wrap = el('div', {});
    const frequent = frequentNavItems();
    if (frequent.length) {
      wrap.appendChild(el('div', { class: 'nav-cat-label' }, '最常用'));
      const grid = el('div', { class: 'widget-grid shortcuts' });
      frequent.forEach((s) => grid.appendChild(el('div', { class: 'widget wshort light shortcut', onclick: () => switchTab(s.tab) }, [
        el('div', { class: 'ic' }, s.icon),
        el('div', { class: 'lb' }, s.label),
      ])));
      wrap.appendChild(grid);
    }
    // v0.87：最近 30 天完全沒打開過的功能，收進最下面的「較少使用」(預設收合)，畫面不再
    // 一次攤開 20 幾個圖示。只有累積了足夠的使用紀錄 (30 天內至少 30 次切換) 才這樣做，
    // 剛開始用、資料還不夠的時候維持全部顯示。不會刪掉或停用任何功能。
    const tile = (s) => el('div', { class: 'widget wshort light shortcut', onclick: () => switchTab(s.tab) }, [
      el('div', { class: 'ic' }, s.icon),
      el('div', { class: 'lb' }, s.label),
    ]);
    const { main: mainItems, rare } = splitRarelyUsedNavItems(orderedMoreNavItems(), frequent);
    wrap.appendChild(buildCategorizedNavGrid(mainItems, 'widget-grid shortcuts', tile));
    if (rare.length) {
      const g = el('div', { class: 'widget-grid shortcuts' });
      rare.forEach((s) => g.appendChild(tile(s)));
      wrap.appendChild(el('details', { class: 'nav-rare' }, [
        el('summary', {}, `較少使用（${rare.length}）`),
        el('p', { class: 'hint', style: 'margin:4px 0 8px' }, '最近 30 天沒有打開過的功能，常用之後會自動回到上面。'),
        g,
      ]));
    }
    // 側欄的版本號 (#appVersion) 在手機版整個側欄都是 display:none，手機上完全看不到，
    // 這裡把同一個值再顯示一次，「更多」選單是手機上唯一固定找得到的地方。
    const versionText = ($('#appVersion') && $('#appVersion').textContent) || '-';
    wrap.appendChild(el('div', { class: 'hint', style: 'text-align:center;margin-top:16px' }, [
      `v${versionText} · `,
      el('a', { style: 'color:var(--accent);cursor:pointer', onclick: () => showDebug() }, '系統狀態'),
    ]));
    return wrap;
  });
  // 第一次打開時快取還沒有資料：先照原樣顯示，資料回來後如果有「最常用」再重畫一次；
  // 之後每次打開都用上一次的快取立刻顯示，背景順手更新。
  const hadCache = myTabUsageCache !== null;
  render();
  refreshMyTabUsage().then(() => {
    const stillOpen = $('#sheetOverlay') && $('#sheetOverlay').classList.contains('show');
    if (!hadCache && stillOpen && frequentNavItems().length) render();
  });
}

// ===================== 下拉重新整理 (手機 App 殼模式) =====================
// 桌面版是整個網頁自己捲動，手機獨立視窗模式下改成「外殼固定、只有 .main 內部捲動」
// (見 style.css 的 app-shell 區塊)，所以下拉手勢也只需要盯著 .main 這個容器，
// 拉到頂端 (scrollTop<=0) 再繼續往下拉超過門檻，放開就重新整理「目前這個分頁」的資料。
(function setupPullToRefresh() {
  const mainEl = document.querySelector('.main');
  const indicator = document.getElementById('pullRefreshIndicator');
  if (!mainEl || !indicator) return;
  const THRESHOLD = 70;
  // 螢幕最右邊這一小塊寬度是 iOS 原生「捲軸提示條」會出現、也可以直接拖曳的地方，這裡故意
  // 不去接手這個區域的觸控事件，避免我們自己的下拉重新整理邏輯跟原生捲軸的拖曳手勢同時
  // 搶著移動畫面 (使用者回報「滑到某個角度、靠右邊一點往右滑」有機率讓畫面跳動，這是目前
  // 排查下來最吻合的成因：兩邊各自用自己的方式在同一時間更新畫面位置，才會看起來在晃)。
  const RIGHT_EDGE_GUARD = 24;
  let startX = null, startY = null, pulling = false, refreshing = false;
  const isMobileLayout = () => window.matchMedia('(max-width: 760px)').matches;

  const CURRENT_TAB_RENDERERS = {
    dashboard: renderDashboard, travel: renderTravel, diary: renderDiary,
    mood: renderMood, finance: renderFinance, bills: renderBills, calendar: renderCalendar,
    tasks: renderTasks, health: renderHealth, relationships: renderRelationships,
    partnerCare: renderPartnerCare, familyBoard: renderFamilyBoard, splitGroups: renderSplitGroups, reading: renderReading, habits: renderHabits, kanban: renderKanban, routineTemplates: renderRoutineTemplates, notes: renderNotes, wishlist: renderWishlist, annualReview: renderAnnualReview, assistant: renderAssistant, rewards: renderRewards, settings: renderSettings,
  };

  mainEl.addEventListener('touchstart', (e) => {
    if (!isMobileLayout() || !state.user || refreshing) { pulling = false; return; }
    const touchX = e.touches[0].clientX;
    const nearRightEdge = touchX >= mainEl.getBoundingClientRect().right - RIGHT_EDGE_GUARD;
    if (mainEl.scrollTop <= 0 && !nearRightEdge) {
      startY = e.touches[0].clientY; startX = touchX; pulling = true;
    } else {
      startY = null; startX = null; pulling = false;
    }
  }, { passive: true });

  mainEl.addEventListener('touchmove', (e) => {
    if (!pulling || startY == null) return;
    const dy = e.touches[0].clientY - startY;
    const dx = Math.abs(e.touches[0].clientX - startX);
    // 這個手勢橫向位移比縱向位移還大，代表不是單純的下拉手勢 (可能是原生捲軸拖曳或其他
    // 手勢)，直接放棄這次下拉重新整理，避免繼續寫入 indicator 樣式跟原生手勢搶畫面。
    if (dx > Math.abs(dy)) { pulling = false; indicator.style.transform = ''; indicator.style.opacity = ''; indicator.classList.remove('ready'); return; }
    if (dy <= 0) { indicator.style.transform = ''; indicator.style.opacity = ''; indicator.classList.remove('ready'); return; }
    const pull = Math.min(dy * 0.5, 90);
    indicator.style.transform = `translateY(${pull}px)`;
    indicator.style.opacity = String(Math.min(pull / THRESHOLD, 1));
    const ready = pull >= THRESHOLD;
    indicator.classList.toggle('ready', ready);
    indicator.textContent = ready ? '⬆️ 放開重新整理' : '⬇️ 下拉重新整理';
  }, { passive: true });

  mainEl.addEventListener('touchend', () => {
    if (!pulling) return;
    pulling = false;
    const shouldRefresh = indicator.classList.contains('ready');
    indicator.classList.remove('ready');
    indicator.style.transform = '';
    indicator.style.opacity = '';
    startY = null; startX = null;
    if (shouldRefresh) doPullRefresh();
    else indicator.textContent = '⬇️ 下拉重新整理';
  });

  async function doPullRefresh() {
    refreshing = true;
    indicator.classList.add('spinning');
    indicator.style.opacity = '1';
    indicator.textContent = '🔄 重新整理中...';
    try {
      const fn = CURRENT_TAB_RENDERERS[currentTab];
      if (fn) await fn();
    } catch (e) { /* 個別分頁自己的 API 已經有錯誤處理，這裡不用重複跳錯誤訊息 */ }
    indicator.classList.remove('spinning');
    indicator.textContent = '✅ 已更新';
    setTimeout(() => {
      indicator.style.opacity = '0';
      indicator.textContent = '⬇️ 下拉重新整理';
      refreshing = false;
    }, 700);
  }
})();

// ===================== 防止畫面卡在橫向位移 (保險機制) =====================
// 查出來的根本原因：`.main` 原本只設定了 overflow-y，CSS 規則會讓它「順便」變成一個
// 獨立的水平捲動容器；只要任何原因讓它的 scrollLeft 被推離 0 (即使現在已經補上
// overflow-x: hidden，很多瀏覽器對 overflow:hidden 的容器還是可以用程式/系統行為
// 把 scrollLeft 設成非 0，只是使用者自己滑不動而已)，畫面就會一直卡在偏移的狀態，因為
// 之前完全沒有任何地方會把它拉回來。這裡加一個保險：只要偵測到 `.main` 或它的祖先
// (#app / body / html) 的 scrollLeft 不是 0，就立刻拉回 0，不管是什麼原因造成的。
(function guardAgainstStuckHorizontalScroll() {
  const targets = [document.documentElement, document.body, document.getElementById('app'), document.querySelector('.main')].filter(Boolean);
  const resetIfNeeded = (el) => { if (el.scrollLeft !== 0) el.scrollLeft = 0; };
  targets.forEach((el) => {
    el.addEventListener('scroll', () => resetIfNeeded(el), { passive: true });
  });
  // 切換分頁、視窗尺寸變化 (例如螢幕旋轉、鍵盤彈出) 時也順手檢查一次。
  window.addEventListener('resize', () => targets.forEach(resetIfNeeded));
  const origSwitchTab = window.switchTab;
  if (typeof origSwitchTab === 'function') {
    window.switchTab = function (...args) {
      const ret = origSwitchTab.apply(this, args);
      targets.forEach(resetIfNeeded);
      return ret;
    };
  }
})();

// ===================== 意見回饋 =====================
// 右上角 💬 按鈕，app 跟電腦版網頁共用同一顆按鈕、同一個彈窗 (共用底部彈窗元件)，
// 送出後只有管理者帳號看得到列表 (見 renderSettings 裡的「所有回饋」區塊)。
const FEEDBACK_CATEGORIES = [
  { key: 'bug', label: '🐛 問題回報' },
  { key: 'suggestion', label: '💡 建議' },
  { key: 'other', label: '💬 其他' },
];
function openFeedbackModal() {
  let selectedCategory = 'suggestion';
  openSheet('意見回饋', () => {
    const wrap = el('div', { class: 'feedback-form' });
    wrap.appendChild(el('p', { class: 'hint' }, '有任何想法、卡住的地方、或希望新增的功能，都可以直接寫在這裡，我會看到。'));

    const catRow = el('div', { class: 'feedback-cat-row' });
    const catBtns = {};
    FEEDBACK_CATEGORIES.forEach((c) => {
      const btn = el('button', {
        class: 'feedback-cat-btn' + (c.key === selectedCategory ? ' active' : ''),
        onclick: () => {
          selectedCategory = c.key;
          Object.entries(catBtns).forEach(([k, b]) => b.classList.toggle('active', k === selectedCategory));
        },
      }, c.label);
      catBtns[c.key] = btn;
      catRow.appendChild(btn);
    });
    wrap.appendChild(catRow);

    const textarea = el('textarea', {
      class: 'feedback-textarea',
      placeholder: '想說什麼都可以寫在這裡...',
      rows: 5,
    });
    wrap.appendChild(textarea);

    const submitBtn = el('button', {
      class: 'btn btn-primary feedback-submit-btn',
      onclick: async () => {
        const message = textarea.value.trim();
        if (!message) { showToast('請先輸入內容再送出'); return; }
        submitBtn.disabled = true;
        submitBtn.textContent = '送出中...';
        try {
          await api('/feedback', { method: 'POST', body: { message, category: selectedCategory } });
          showToast('謝謝你的回饋！已經收到了 🙏');
          closeSheet();
        } catch (e) {
          showToast(e.message || '送出失敗，請稍後再試');
          submitBtn.disabled = false;
          submitBtn.textContent = '送出回饋';
        }
      },
    }, '送出回饋');
    wrap.appendChild(submitBtn);

    return wrap;
  });
}

// ===================== 全站搜尋 (v0.76) =====================
// 右上角 🔍，用同一個底部彈窗元件。輸入關鍵字打 /api/search，後端會分別對待辦事項/日記/
// 個人筆記/願望清單/讀書清單各自查一次、依模組分組回傳，這裡只負責分組顯示跟「點下去切換
// 分頁」，不做跳到那個項目自動捲動高亮這麼深——先讓「找得到在哪個分頁」堪用即可。
let globalSearchDebounceTimer = null;
function openGlobalSearch() {
  openSheet('🔍 搜尋全部', () => {
    const wrap = el('div', { class: 'global-search-wrap' });
    const input = el('input', { id: 'globalSearchInput', placeholder: '搜尋待辦事項／日記／筆記／願望清單／讀書清單...', style: 'width:100%' });
    const resultsArea = el('div', { id: 'globalSearchResults', style: 'margin-top:10px' });
    input.addEventListener('input', () => {
      clearTimeout(globalSearchDebounceTimer);
      const q = input.value.trim();
      if (!q) { resultsArea.innerHTML = ''; return; }
      globalSearchDebounceTimer = setTimeout(() => runGlobalSearch(q, resultsArea), 300);
    });
    wrap.appendChild(input);
    wrap.appendChild(resultsArea);
    setTimeout(() => input.focus(), 50);
    return wrap;
  });
}
async function runGlobalSearch(q, resultsArea) {
  resultsArea.innerHTML = '';
  resultsArea.appendChild(el('div', { class: 'hint' }, '搜尋中...'));
  try {
    const { results } = await api(`/search?q=${encodeURIComponent(q)}`);
    resultsArea.innerHTML = '';
    if (!results.length) {
      resultsArea.appendChild(el('div', { class: 'empty-state' }, '沒有找到符合的內容'));
      return;
    }
    const grouped = {};
    results.forEach((r) => { (grouped[r.module] = grouped[r.module] || []).push(r); });
    Object.values(grouped).forEach((items) => {
      const first = items[0];
      resultsArea.appendChild(el('div', { class: 'hint', style: 'font-weight:700;margin:10px 0 4px' }, `${first.icon} ${first.moduleLabel}`));
      items.forEach((r) => {
        resultsArea.appendChild(el('div', {
          class: 'global-search-result-item',
          onclick: () => { closeSheet(); switchTab(r.tab); },
        }, [
          el('div', { style: 'font-weight:600' }, r.title),
          r.snippet ? el('div', { class: 'hint', style: 'margin-top:2px' }, r.snippet) : null,
        ].filter(Boolean)));
      });
    });
  } catch (e) {
    resultsArea.innerHTML = '';
    resultsArea.appendChild(el('div', { class: 'empty-state' }, '搜尋失敗：' + e.message));
  }
}

// ===================== SVG 圖表小工具 =====================
// 依 dataviz 規範：細線條、圓角端點、2px 間距、淺色 gridline、tooltip 互動
function svgEl(tag, attrs) {
  const e = document.createElementNS('http://www.w3.org/2000/svg', tag);
  Object.entries(attrs).forEach(([k, v]) => e.setAttribute(k, v));
  return e;
}

// 水平長條圖 (用於記帳分類金額) — 類別色依固定順序指派
const CATEGORICAL = ['--series-blue', '--series-orange', '--series-aqua', '--series-yellow', '--series-magenta', '--series-green', '--series-violet', '--series-red'];
function cssVar(name) { return getComputedStyle(document.documentElement).getPropertyValue(name).trim(); }

function renderBarChart(container, data, opts = {}) {
  // data: [{label, value}]
  container.innerHTML = '';
  if (!data.length) { container.appendChild(el('div', { class: 'empty-state' }, opts.emptyText || '目前沒有資料')); return; }
  const width = container.clientWidth || 400;
  const rowH = 30;
  const height = data.length * rowH + 10;
  const max = Math.max(...data.map((d) => d.value), 1);
  const svg = svgEl('svg', { width: '100%', height, viewBox: `0 0 ${width} ${height}` });

  data.forEach((d, i) => {
    const y = i * rowH + 6;
    // 預留右側 90px 給數值標籤，避免最大值那一列的長條把標籤擠出容器外
    const barW = Math.max(4, (d.value / max) * (width - 140 - 90));
    const color = cssVar(CATEGORICAL[i % CATEGORICAL.length]);
    svg.appendChild(svgEl('rect', { x: 110, y, width: barW, height: 14, rx: 4, fill: color }));
    const label = svgEl('text', { x: 0, y: y + 11, 'font-size': 12, fill: cssVar('--text-secondary') });
    label.textContent = d.label.length > 10 ? d.label.slice(0, 10) + '…' : d.label;
    svg.appendChild(label);
    const val = svgEl('text', { x: 110 + barW + 8, y: y + 11, 'font-size': 12, fill: cssVar('--text-primary') });
    val.textContent = opts.money ? fmtMoney(d.value) : fmtNum(d.value);
    svg.appendChild(val);

    const hit = svgEl('rect', { x: 110, y, width: Math.max(barW, 4), height: 14, fill: 'transparent' });
    hit.addEventListener('mousemove', (ev) => showTooltip(ev, `${d.label}: ${opts.money ? fmtMoney(d.value) : fmtNum(d.value)}`));
    hit.addEventListener('mouseleave', hideTooltip);
    svg.appendChild(hit);
  });
  container.appendChild(svg);
}

// 發散長條圖 (法人買賣超: 正值買超=blue, 負值賣超=red, 0軸=灰色基準線)
function renderDivergingChart(container, data) {
  container.innerHTML = '';
  if (!data.length) { container.appendChild(el('div', { class: 'empty-state' }, '目前沒有可用的法人買賣超資料')); return; }
  const width = container.clientWidth || 500;
  const height = 180;
  const padL = 10, padR = 10, padTop = 10, padBottom = 24;
  const plotW = width - padL - padR;
  const plotH = height - padTop - padBottom;
  const max = Math.max(...data.map((d) => Math.abs(d.netBuySell)), 1);
  const barW = Math.max(6, plotW / data.length - 6);
  const midY = padTop + plotH / 2;

  const svg = svgEl('svg', { width: '100%', height, viewBox: `0 0 ${width} ${height}` });
  svg.appendChild(svgEl('line', { x1: padL, x2: width - padR, y1: midY, y2: midY, stroke: cssVar('--baseline'), 'stroke-width': 1 }));

  data.forEach((d, i) => {
    const x = padL + i * (plotW / data.length) + (plotW / data.length - barW) / 2;
    const h = (Math.abs(d.netBuySell) / max) * (plotH / 2 - 4);
    const isBuy = d.netBuySell >= 0;
    const y = isBuy ? midY - h : midY;
    const color = isBuy ? cssVar('--series-blue') : cssVar('--series-red');
    svg.appendChild(svgEl('rect', { x, y, width: barW, height: Math.max(h, 1), rx: 3, fill: color }));

    const hit = svgEl('rect', { x, y: padTop, width: barW, height: plotH, fill: 'transparent' });
    hit.addEventListener('mousemove', (ev) => showTooltip(ev, `${d.date}: ${isBuy ? '買超' : '賣超'} ${fmtNum(Math.abs(d.netBuySell))} 股`));
    hit.addEventListener('mouseleave', hideTooltip);
    svg.appendChild(hit);

    if (i % Math.ceil(data.length / 6 || 1) === 0) {
      const lbl = svgEl('text', { x: x + barW / 2, y: height - 6, 'font-size': 10, 'text-anchor': 'middle', fill: cssVar('--text-muted') });
      lbl.textContent = (d.date || '').slice(4);
      svg.appendChild(lbl);
    }
  });
  container.appendChild(svg);
  container.appendChild(el('div', { class: 'legend' }, [
    el('div', { class: 'legend-item' }, [el('div', { class: 'legend-dot', style: `background:${cssVar('--series-blue')}` }), '買超 (法人淨買進)']),
    el('div', { class: 'legend-item' }, [el('div', { class: 'legend-dot', style: `background:${cssVar('--series-red')}` }), '賣超 (法人淨賣出)']),
  ]));
}

// 折線圖 (記帳月趨勢: 收入 vs 支出 兩條線)
function renderLineChart(container, series) {
  // series: [{name, color, points:[{x,y}]}]
  container.innerHTML = '';
  const allPoints = series.flatMap((s) => s.points);
  if (!allPoints.length) { container.appendChild(el('div', { class: 'empty-state' }, '目前沒有可用的趨勢資料')); return; }
  const width = container.clientWidth || 500;
  const height = 200;
  const padL = 40, padR = 16, padTop = 16, padBottom = 26;
  const plotW = width - padL - padR;
  const plotH = height - padTop - padBottom;
  const xs = [...new Set(allPoints.map((p) => p.x))];
  // 支援負值 (例如淨資產累計結餘可能是負的)：用實際的 min/max 範圍縮放，不假設一定從 0 開始
  const rawMin = Math.min(...allPoints.map((p) => p.y), 0);
  const rawMax = Math.max(...allPoints.map((p) => p.y), 0);
  const span = rawMax - rawMin || Math.abs(rawMax) * 0.2 || 1;
  // 全部都是非負值時維持原本「從 0 開始」的畫法，只有真的出現負值時才往下留白，
  // 不然本來就從 0 起跳的圖表 (例如收支金額) 會無緣無故變成從負數開始
  const yMin = rawMin < 0 ? rawMin - span * 0.05 : 0;
  const yMax = rawMax + span * 0.05;
  const yAt = (v) => padTop + plotH - ((v - yMin) / (yMax - yMin)) * plotH;

  const svg = svgEl('svg', { width: '100%', height, viewBox: `0 0 ${width} ${height}` });
  for (let g = 0; g <= 4; g++) {
    const y = padTop + (plotH / 4) * g;
    const v = yMax - ((yMax - yMin) / 4) * g;
    svg.appendChild(svgEl('line', { x1: padL, x2: width - padR, y1: y, y2: y, stroke: cssVar('--grid-line'), 'stroke-width': 1 }));
    const val = svgEl('text', { x: 4, y: y + 4, 'font-size': 10, fill: cssVar('--text-muted') });
    val.textContent = fmtNum(Math.round(v));
    svg.appendChild(val);
  }
  // 0 這條基準線如果落在圖表範圍內，特別標出來，負值時比較看得出「虧」跟「賺」的分界
  if (yMin < 0 && yMax > 0) {
    const zeroY = yAt(0);
    svg.appendChild(svgEl('line', { x1: padL, x2: width - padR, y1: zeroY, y2: zeroY, stroke: cssVar('--text-muted'), 'stroke-width': 1, 'stroke-dasharray': '3,3' }));
  }

  series.forEach((s) => {
    const pts = xs.map((x) => {
      const p = s.points.find((pt) => pt.x === x);
      return { x, y: p ? p.y : 0 };
    });
    const path = pts.map((p, i) => {
      const px = padL + (xs.indexOf(p.x) / Math.max(xs.length - 1, 1)) * plotW;
      const py = yAt(p.y);
      return `${i === 0 ? 'M' : 'L'}${px},${py}`;
    }).join(' ');
    svg.appendChild(svgEl('path', { d: path, fill: 'none', stroke: s.color, 'stroke-width': 2, 'stroke-linecap': 'round' }));

    pts.forEach((p) => {
      const px = padL + (xs.indexOf(p.x) / Math.max(xs.length - 1, 1)) * plotW;
      const py = yAt(p.y);
      const dot = svgEl('circle', { cx: px, cy: py, r: 4, fill: s.color });
      dot.addEventListener('mousemove', (ev) => showTooltip(ev, `${s.name} ${p.x}: ${fmtMoney(p.y)}`));
      dot.addEventListener('mouseleave', hideTooltip);
      svg.appendChild(dot);
    });
  });

  xs.forEach((x, i) => {
    const px = padL + (i / Math.max(xs.length - 1, 1)) * plotW;
    const lbl = svgEl('text', { x: px, y: height - 6, 'font-size': 10, 'text-anchor': 'middle', fill: cssVar('--text-muted') });
    lbl.textContent = x;
    svg.appendChild(lbl);
  });

  container.appendChild(svg);
  container.appendChild(el('div', { class: 'legend' }, series.map((s) =>
    el('div', { class: 'legend-item' }, [el('div', { class: 'legend-dot', style: `background:${s.color}` }), s.name])
  )));
}

// 股價走勢圖 (收盤價 + MA5 + MA20)：y 軸依價格範圍縮放 (不從 0 開始，股價圖慣例)
function renderPriceChart(container, points) {
  container.innerHTML = '';
  if (!points || points.length < 2) { container.appendChild(el('div', { class: 'empty-state' }, '歷史資料不足，無法繪製走勢圖')); return; }
  const width = container.clientWidth || 600;
  const height = 220;
  const padL = 48, padR = 14, padTop = 12, padBottom = 26;
  const plotW = width - padL - padR, plotH = height - padTop - padBottom;
  const vals = points.flatMap((p) => [p.close, p.ma5, p.ma20]).filter((v) => v != null);
  const vMin = Math.min(...vals), vMax = Math.max(...vals);
  const span = vMax - vMin || vMax * 0.02 || 1;
  const lo = vMin - span * 0.08, hi = vMax + span * 0.08;
  const xAt = (i) => padL + (i / Math.max(points.length - 1, 1)) * plotW;
  const yAt = (v) => padTop + plotH - ((v - lo) / (hi - lo)) * plotH;

  const svg = svgEl('svg', { width: '100%', height, viewBox: `0 0 ${width} ${height}` });
  for (let g = 0; g <= 4; g++) {
    const y = padTop + (plotH / 4) * g;
    const v = hi - ((hi - lo) / 4) * g;
    svg.appendChild(svgEl('line', { x1: padL, x2: width - padR, y1: y, y2: y, stroke: cssVar('--grid-line'), 'stroke-width': 1 }));
    const lbl = svgEl('text', { x: 4, y: y + 4, 'font-size': 10, fill: cssVar('--text-muted') });
    lbl.textContent = v >= 1000 ? Math.round(v).toLocaleString() : v.toFixed(1);
    svg.appendChild(lbl);
  }

  const series = [
    { key: 'close', name: '收盤價', color: cssVar('--series-blue'), w: 2 },
    { key: 'ma5', name: 'MA5', color: cssVar('--series-orange'), w: 1.5 },
    { key: 'ma20', name: 'MA20', color: cssVar('--series-aqua'), w: 1.5 },
  ];
  series.forEach((s) => {
    let d = '';
    points.forEach((p, i) => {
      const v = p[s.key];
      if (v == null) return;
      d += `${d ? 'L' : 'M'}${xAt(i).toFixed(1)},${yAt(v).toFixed(1)} `;
    });
    if (d) svg.appendChild(svgEl('path', { d: d.trim(), fill: 'none', stroke: s.color, 'stroke-width': s.w, 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }));
  });

  const colW = plotW / points.length;
  points.forEach((p, i) => {
    const hit = svgEl('rect', { x: xAt(i) - colW / 2, y: padTop, width: colW, height: plotH, fill: 'transparent' });
    hit.addEventListener('mousemove', (ev) => showTooltip(ev,
      `${p.date} 收盤 ${p.close}${p.ma5 != null ? ' · MA5 ' + p.ma5 : ''}${p.ma20 != null ? ' · MA20 ' + p.ma20 : ''}`));
    hit.addEventListener('mouseleave', hideTooltip);
    svg.appendChild(hit);
  });

  const step = Math.max(1, Math.ceil(points.length / 5));
  points.forEach((p, i) => {
    if (i % step !== 0 && i !== points.length - 1) return;
    const lbl = svgEl('text', { x: xAt(i), y: height - 6, 'font-size': 10, 'text-anchor': 'middle', fill: cssVar('--text-muted') });
    lbl.textContent = String(p.date || '').slice(-5);
    svg.appendChild(lbl);
  });

  container.appendChild(svg);
  container.appendChild(el('div', { class: 'legend' }, series.map((s) =>
    el('div', { class: 'legend-item' }, [el('div', { class: 'legend-dot', style: `background:${s.color}` }), s.name])
  )));
}

function showTooltip(ev, text) {
  const tip = $('#tooltip');
  tip.textContent = text;
  tip.style.left = ev.pageX + 12 + 'px';
  tip.style.top = ev.pageY + 12 + 'px';
  tip.style.opacity = '1';
}
function hideTooltip() { $('#tooltip').style.opacity = '0'; }

// ===================== Dashboard =====================
// 首頁的樣貌會依當下時段變化 (早晨/午後/傍晚/深夜)，不會永遠都是「晨間簡報」那一種形式，
// 每個時段有自己的徽章文字、問候語、跟摘要按鈕的語氣。
const DASH_PERIODS = {
  morning: {
    icon: '☀️', label: '晨間', badgeSuffix: '晨間時光',
    greetings: [
      '新的一天，先深呼吸一口再開始 🌿',
      '不用急，先把自己準備好就好 ✨',
      '今天想做的事，先做一件小小的就好 🌤️',
    ],
    briefBtn: '產生晨間摘要',
  },
  afternoon: {
    icon: '🌤️', label: '午後', badgeSuffix: '午後時光',
    greetings: [
      '午後了，休息一下再繼續也可以 🍃',
      '不管上午過得如何，下半天重新開始就好 💫',
      '喝口水、動一動，替下午充個電 ☕',
    ],
    briefBtn: '產生午後摘要',
  },
  evening: {
    icon: '🌇', label: '傍晚', badgeSuffix: '傍晚時光',
    greetings: [
      '今天也辛苦了，慢慢收尾就好 🌿',
      '不管今天過得如何，你都做得很好 ✨',
      '晚餐前，先鬆口氣吧 🌆',
    ],
    briefBtn: '產生傍晚摘要',
  },
  night: {
    icon: '🌙', label: '深夜', badgeSuffix: '深夜時光',
    greetings: [
      '累的時候，休息也是一種前進 🍃',
      '慢慢來也沒關係，你的步調就是最好的步調 🌙',
      '有你在乎的事情，本身就是一件很棒的事 💫',
    ],
    briefBtn: '產生深夜摘要',
  },
};

function getDayPeriod() {
  const h = new Date().getHours();
  if (h >= 5 && h < 11) return 'morning';
  if (h >= 11 && h < 17) return 'afternoon';
  if (h >= 17 && h < 21) return 'evening';
  return 'night';
}

// v0.28.0 首頁重新設計：不分桌面版/手機版兩套版面，統一用單欄「以 app 為主」的排版，
// 全程沒有左右並排的欄位，天生就不會有橫向捲動的問題。待辦事項跟行事曆合併成一條清單
// (依「離現在最近」排序)，取代原本兩張各自獨立、內容還會重複的卡片；心情可以直接在首頁打卡；
// 問候語下面固定會有一句隨機的正向話語 (沿用 DASH_PERIODS 既有的語句庫，每個時段各自一組)。
function renderDashboard() {
  const c = $('#tab-dashboard');
  c.innerHTML = '';
  const period = getDayPeriod();
  const meta = DASH_PERIODS[period];
  const quote = meta.greetings[Math.floor(Math.random() * meta.greetings.length)];

  const WEEKDAY_LABEL = ['日', '一', '二', '三', '四', '五', '六'];
  const now = new Date();
  const dateLabel = `${now.getMonth() + 1}月${now.getDate()}日 星期${WEEKDAY_LABEL[now.getDay()]} · ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

  const enabled = (state.prefs && state.prefs.enabledModules) || {};
  const isOn = (key) => enabled[key] !== false;

  const wrap = el('div', { class: 'dash-unified' });

  wrap.appendChild(el('div', { class: 'dash-hero-eyebrow' }, `${meta.icon} ${dateLabel}`));
  wrap.appendChild(el('div', { class: 'dash-hero-name' }, `哈囉，${state.user ? state.user.name : ''}`));
  wrap.appendChild(el('div', { id: 'dashHeroSub', class: 'dash-hero-sub' }, skeletonLines(1)));
  wrap.appendChild(el('div', { id: 'dashHeroQuote', class: 'dash-hero-quote' }, quote));

  // v0.87：快速記一筆——打「午餐 120」記帳、打「明天 繳電話費」新增待辦，不用切分頁。
  wrap.appendChild(quickInputCardEl());

  // v0.85 首頁排序 (跟使用者在設計稿上確認過)：問候 → 今天 (完成度 + 待辦/行程清單)
  // → 今天的心情 → 問 AI → 家庭公告欄 → 更多。每一段包成一張圓角卡片 (.dash-v2-card)，
  // 不再是一整頁平鋪的文字。區塊內的 id 全部沿用，載入資料的函式都不用改。
  // (v0.28 的順序是 AI → 家庭公告欄 → 待辦；這次把「今天要做什麼」移到最上面。)
  if (isOn('tasks')) {
    wrap.appendChild(el('section', { class: 'dash-v2-card' }, [
      el('div', { class: 'dash-section-title-row' }, [
        el('div', { class: 'dash-section-title' }, '✅ 今天'),
        el('div', {}, [
          el('button', { class: 'dash-section-action', onclick: (ev) => { ev.stopPropagation(); dashUnifiedSort = dashUnifiedSort === 'time' ? 'priority' : 'time'; loadDashUnifiedTasks(); } }, dashUnifiedSort === 'time' ? '排序：時間' : '排序：優先度'),
        ]),
      ]),
      el('div', { id: 'dashStatStrip', class: 'dash-stat-strip' }),
      // v0.89：生日、紀念日倒數 (14 天內，最多 3 筆)。沒有就整段不出現。
      el('div', { id: 'dashUpcoming' }),
      el('div', { id: 'dashUnifiedList', class: 'dash-unified-list' }, skeletonLines(3)),
      el('button', { class: 'dash-v2-link', onclick: () => switchTab('tasks') }, '看全部待辦 →'),
    ]));
  }

  if (isOn('mood')) {
    wrap.appendChild(el('section', { class: 'dash-v2-card' }, [
      el('div', { class: 'dash-section-title-row' }, [el('div', { class: 'dash-section-title' }, '💗 今天的心情')]),
      el('div', { id: 'moodSummaryBody', class: 'dash-mood-inline' }, skeletonLines(2)),
    ]));
  }

  wrap.appendChild(el('section', { class: 'dash-v2-card' }, [
    el('div', { class: 'dash-section-title-row' }, [el('div', { class: 'dash-section-title' }, '🤖 問 AI 助理')]),
    el('div', { class: 'dash-hero-ask' }, [
      el('input', { id: 'dashAskInput', placeholder: '想問 AI 什麼呢？', 'aria-label': '問 AI 助理', onkeydown: (ev) => { if (ev.key === 'Enter') dashAskAI(); } }),
      el('button', { class: 'btn btn-primary', onclick: () => dashAskAI() }, '送出'),
    ]),
    el('div', { class: 'dash-brief-box dash-hero-brief' }, [
      el('button', { class: 'btn btn-secondary dash-brief-btn', onclick: () => generateDashBriefing(period) }, `📋 ${meta.briefBtn}`),
      el('div', { id: 'dashBriefResult', class: 'dash-brief-result', style: 'display:none' }),
    ]),
  ]));

  wrap.appendChild(el('section', { class: 'dash-v2-card' }, [
    el('div', { class: 'dash-section-title-row' }, [
      el('div', { class: 'dash-section-title' }, '📌 家庭公告欄'),
      el('button', { class: 'dash-section-action', onclick: () => switchTab('familyBoard') }, '查看全部'),
    ]),
    el('div', { id: 'dashFamilyBoardBody' }, skeletonLines(2)),
  ]));

  // v0.87：「更多」摘要與「全部功能」原本是頁面最底下平鋪的文字和一大片小圖示，改成兩張
  // 可以收合的卡片；「全部功能」跟底部導覽列的「更多」重複，預設收合。
  const moreCard = el('section', { class: 'card dash-v2-card' }, [
    el('h3', {}, '📋 其他摘要'),
    el('div', { style: 'display:flex;justify-content:flex-end;margin:-6px 0 2px' }, [
      el('button', { class: 'dash-section-action', onclick: () => openCustomizeSheet() }, '✏️ 自訂'),
    ]),
  ]);
  const moreList = el('div', { class: 'dash-more-list' });
  if (isOn('finance')) moreList.appendChild(dashMoreRow('💰', '記帳流水', 'financeSummaryBody', () => switchTab('finance')));
  if (isOn('bills')) moreList.appendChild(dashMoreRow('🧾', '帳單提醒', 'billsSummaryBody', () => switchTab('bills')));
  moreList.appendChild(dashMoreRow('📔', '日記隨筆', 'diarySummaryBody', () => switchTab('diary')));
  moreList.appendChild(dashMoreRow('📊', '本週動態', 'weeklyDigestBody', null));
  moreCard.appendChild(moreList);
  wrap.appendChild(moreCard);
  makeCardCollapsible(moreCard, 'dashboard', true);

  const allCard = el('section', { class: 'card dash-v2-card' }, [
    el('h3', {}, '🧭 全部功能'),
    el('div', { style: 'display:flex;justify-content:flex-end;margin:-6px 0 6px' }, [
      el('button', { class: 'dash-section-action', onclick: () => openMoreNavOrderSheet() }, '↕️ 排序'),
    ]),
    buildCategorizedNavGrid(orderedMoreNavItems(), 'widget-grid shortcuts', (s) =>
      el('div', { class: 'widget wshort light shortcut', onclick: () => switchTab(s.tab) }, [
        el('div', { class: 'ic' }, s.icon),
        el('div', { class: 'lb' }, s.label),
      ])
    ),
  ]);
  wrap.appendChild(allCard);
  makeCardCollapsible(allCard, 'dashboard', false);

  c.appendChild(wrap);

  if (isOn('tasks')) loadDashUnifiedTasks(); else loadDashHeroSubFallback();
  if (isOn('tasks') && isOn('relationships')) loadDashUpcoming();
  if (isOn('finance')) loadDashFinanceSummary();
  loadDashDiarySummary();
  if (isOn('bills')) loadDashBillsSummary();
  if (isOn('mood')) loadDashMoodSummary();
  loadDashFamilyBoardPreview();
  // loadDashReminders() 不再呼叫：首頁已經沒有 #dashRemindersWrap 這個容器了 (整個「主動式提醒」
  // 區塊移除)，繼續呼叫只會是一次浪費的 API request、抓回來的資料也沒地方放。
  loadDashWeeklyDigest();
  loadDashHeroMoodAccent();
}

// 問候卡片那句話 (dash-hero-quote) 左邊那條細線跟文字顏色，依「這個人自己最近 7 天」的
// 心情平均分數做一點點局部點綴——不是整站配色都跟著動 (介面色系是刻意設計過的低調高級感，
// 全站套用風險太高)，只在這張最貼近「陪伴」語氣的卡片上做小小的個人化。
// 沒有紀錄 (average === null) 或抓取失敗時，保持原本的金色，不猜測、不強加顏色。
async function loadDashHeroMoodAccent() {
  const quoteEl = $('#dashHeroQuote');
  if (!quoteEl) return;
  try {
    const summary = await api('/mood/summary?days=7');
    const avg = summary.average;
    if (avg == null) return; // 沒紀錄，維持預設金色
    let color = null;
    if (avg <= 4) color = '#c17a5e'; // 偏低：溫暖赤陶色，陪伴感而不是「警示」的冷色
    else if (avg >= 8) color = '#3fa9a0'; // 偏高：清爽活力的綠松色
    if (color) {
      quoteEl.style.borderLeftColor = color;
      quoteEl.style.color = color;
    }
  } catch (e) {
    // 抓取失敗就維持預設樣式，不影響首頁其他內容
  }
}

// ===================== v0.87 快速記一筆 =====================
// 一行字判斷要記帳還是新增待辦，完全用規則、不需要 AI (沒網路、沒設定 AI 金鑰也能用)。
// 判斷邏輯：
//   - 有金額 (數字，可帶 $ / NT / 元 / 塊) → 記帳。預設支出；有「薪水/收入/獎金/退款」等字 → 收入。
//     分類用關鍵字猜 (午餐→餐飲、捷運→交通…)，猜不到就「其他」。有「昨天」就記昨天。
//   - 沒有金額 → 待辦。認得「今天/明天/後天/週X/下週X/M/D/M月D日」當期限，「重要/緊急」當高優先度。
// 數字後面接「點/號/日/月/:」或寫成 M/D 的，視為時間或日期，不當金額。
const QUICK_CATEGORY_KEYWORDS = [
  ['餐飲', /早餐|午餐|晚餐|宵夜|消夜|飲料|咖啡|便當|奶茶|點心|下午茶|火鍋|外送|吃|餐|麵|飯|食/],
  ['交通', /捷運|公車|高鐵|台鐵|火車|計程車|uber|加油|油錢|停車|機票|車資|悠遊卡|一卡通/i],
  ['娛樂', /電影|遊戲|ktv|唱歌|門票|演唱會|netflix|spotify|youtube|訂閱|旅遊/i],
  ['購物', /衣服|鞋|網購|蝦皮|momo|淘寶|全聯|超市|好市多|costco|家樂福|買/i],
  ['居家', /房租|水費|電費|瓦斯|網路費|電話費|日用品|衛生紙|洗衣|家具/],
  ['醫療', /看醫生|掛號|藥|診所|醫院|牙醫|健保|保險/],
  ['教育', /書|課程|學費|補習|教材/],
];
const QUICK_INCOME_RE = /薪水|薪資|收入|獎金|退款|入帳|分紅|零用錢收/;
const QUICK_WEEKDAYS = { 一: 1, 二: 2, 三: 3, 四: 4, 五: 5, 六: 6, 日: 0, 天: 0 };

function quickParseDate(text) {
  const now = new Date();
  const ymd = (d) => fmtYMD(d);
  const plus = (n) => { const d = new Date(now); d.setDate(d.getDate() + n); return d; };
  let m;
  if ((m = text.match(/大後天/))) return { date: ymd(plus(3)), rest: text.replace(m[0], ' ') };
  if ((m = text.match(/後天/))) return { date: ymd(plus(2)), rest: text.replace(m[0], ' ') };
  if ((m = text.match(/明天/))) return { date: ymd(plus(1)), rest: text.replace(m[0], ' ') };
  if ((m = text.match(/今天/))) return { date: ymd(now), rest: text.replace(m[0], ' ') };
  if ((m = text.match(/昨天/))) return { date: ymd(plus(-1)), rest: text.replace(m[0], ' '), past: true };
  if ((m = text.match(/(下)?(?:週|周|星期|禮拜)([一二三四五六日天])/))) {
    const target = QUICK_WEEKDAYS[m[2]];
    const dow = now.getDay();
    // 「週三」= 這週還沒過的那個週三 (今天就是週三就算今天)；「下週三」= 下個星期一開始那一週的週三
    const diff = m[1]
      ? (((8 - dow) % 7) || 7) + ((target + 6) % 7)
      : (target - dow + 7) % 7;
    return { date: ymd(plus(diff)), rest: text.replace(m[0], ' ') };
  }
  if ((m = text.match(/(\d{1,2})\s*[\/月]\s*(\d{1,2})\s*[日號]?/))) {
    const mo = Number(m[1]), d = Number(m[2]);
    if (mo >= 1 && mo <= 12 && d >= 1 && d <= 31) {
      let y = now.getFullYear();
      const cand = new Date(y, mo - 1, d);
      if (cand < new Date(now.getFullYear(), now.getMonth(), now.getDate())) y += 1;
      return { date: `${y}-${String(mo).padStart(2, '0')}-${String(d).padStart(2, '0')}`, rest: text.replace(m[0], ' ') };
    }
  }
  return { date: null, rest: text };
}

// v0.88：快速輸入支援國字數字，口語說法也算：
//   「午餐一百二」=120、「兩百五」=250、「三千五」=3500、「一萬二」=12000、「一百零五」=105、
//   「三月五號」=3月5號。「星期三／下週三」這種星期幾不轉，「十分好吃」「萬一」「千萬」也不轉。
const ZH_DIGIT = { 零: 0, 〇: 0, 一: 1, 二: 2, 兩: 2, 三: 3, 四: 4, 五: 5, 六: 6, 七: 7, 八: 8, 九: 9 };
const ZH_UNIT = { 十: 10, 百: 100, 千: 1000 };
function zhSectionToNum(s) {
  if (!/[十百千]/.test(s)) return Number([...s].map((c) => ZH_DIGIT[c]).join('')) || 0;
  let total = 0, digit = null, lastUnit = 0, hadZero = false;
  for (const c of s) {
    if (c in ZH_UNIT) { total += (digit === null ? 1 : digit) * ZH_UNIT[c]; lastUnit = ZH_UNIT[c]; digit = null; hadZero = false; }
    else if (ZH_DIGIT[c] === 0) { hadZero = true; digit = null; }
    else digit = ZH_DIGIT[c];
  }
  if (digit !== null) total += (lastUnit >= 100 && !hadZero) ? digit * lastUnit / 10 : digit;
  return total;
}
function zhToNumber(s) {
  const i = s.indexOf('萬');
  if (i < 0) return zhSectionToNum(s);
  const high = (i === 0 ? 1 : zhSectionToNum(s.slice(0, i))) * 10000;
  const low = s.slice(i + 1);
  if (!low) return high;
  if (low.length === 1 && low in ZH_DIGIT && ZH_DIGIT[low] > 0) return high + ZH_DIGIT[low] * 1000; // 一萬二
  return high + zhSectionToNum(low);
}
function normalizeChineseNumerals(text) {
  return text.replace(/[零〇一二兩三四五六七八九十百千萬]+/g, (run, idx, all) => {
    const prev = all[idx - 1] || '';
    const next = all[idx + run.length] || '';
    if (/[週周期拜]/.test(prev)) return run;
    if (/^[百千萬]/.test(run)) return run; // 萬一、千萬、百貨
    if (run === '十' && next === '分') return run; // 十分好吃
    const hasUnit = /[十百千萬]/.test(run);
    if (!hasUnit && !/[塊元號日月點]/.test(next)) return run; // 一起、一下
    const n = zhToNumber(run);
    return n > 0 ? String(n) : run;
  });
}

function parseQuickInput(raw) {
  const text = normalizeChineseNumerals((raw || '').trim());
  if (!text) return null;
  const { date, rest, past } = quickParseDate(text);
  const amtRe = /(NT\$?|\$)?\s*(\d{1,7}(?:\.\d{1,2})?)\s*(元|塊)?(?![\d.]*\s*[點:：號日月\/])/gi;
  let match = null, mm;
  while ((mm = amtRe.exec(rest)) !== null) match = mm;
  if (match) {
    const amount = Number(match[2]);
    let note = (rest.slice(0, match.index) + ' ' + rest.slice(match.index + match[0].length)).replace(/\s+/g, ' ').trim();
    const type = QUICK_INCOME_RE.test(note) ? 'income' : 'expense';
    let category = '其他';
    if (type === 'expense') { const hit = QUICK_CATEGORY_KEYWORDS.find(([, re]) => re.test(note)); if (hit) category = hit[0]; }
    return { kind: 'expense', type, amount, category, note, date: (date && past) ? date : (date || todayStr()) };
  }
  let title = rest.replace(/\s+/g, ' ').trim();
  let priority = 'medium';
  if (/重要|緊急|很急|急件/.test(title)) { priority = 'high'; title = title.replace(/重要|緊急|很急|急件/g, '').replace(/\s+/g, ' ').trim(); }
  if (!title) return null;
  return { kind: 'task', title, dueDate: date, priority };
}

function quickPreviewText(p) {
  if (!p) return '例如「午餐 120」記一筆帳，或「明天 繳電話費」新增待辦';
  const dayLabel = (d) => (d === todayStr() ? '今天' : d ? d.slice(5).replace('-', '/') : '');
  if (p.kind === 'expense') return `${p.type === 'income' ? '💰 收入' : '💸 支出'} NT$${p.amount.toLocaleString()} · ${p.category}${p.note ? ` · ${p.note}` : ''} · ${dayLabel(p.date)}`;
  return `✅ 待辦：${p.title}${p.dueDate ? ` · ${dayLabel(p.dueDate)}` : ''}${p.priority === 'high' ? ' · 高優先' : ''}`;
}

function quickInputCardEl() {
  const input = el('input', { id: 'quickInput', placeholder: '午餐 120 ／ 明天 繳電話費', 'aria-label': '快速記一筆', autocomplete: 'off', enterkeyhint: 'done' });
  const preview = el('div', { class: 'quick-preview' }, quickPreviewText(null));
  const btn = el('button', { class: 'btn btn-primary', disabled: true }, '記下');
  const refresh = () => {
    const p = parseQuickInput(input.value);
    preview.textContent = quickPreviewText(p);
    preview.classList.toggle('ready', !!p);
    btn.disabled = !p;
  };
  const submit = async () => {
    const p = parseQuickInput(input.value);
    if (!p) return;
    btn.disabled = true;
    try {
      if (p.kind === 'expense') {
        await api('/finance/transactions', { method: 'POST', body: { tx_date: p.date, type: p.type, category: p.category, amount: p.amount, note: p.note } });
        showToast(`已記帳：NT$${p.amount.toLocaleString()} ${p.category}`);
      } else {
        await api('/tasks', { method: 'POST', body: { title: p.title, dueDate: p.dueDate, priority: p.priority } });
        showToast(`已新增待辦：${p.title}`);
        if (typeof loadDashUnifiedTasks === 'function') loadDashUnifiedTasks();
      }
      input.value = '';
      refresh();
    } catch (e) { showToast('儲存失敗：' + e.message); btn.disabled = false; }
  };
  input.addEventListener('input', refresh);
  input.addEventListener('keydown', (ev) => { if (ev.key === 'Enter' && !ev.isComposing) { ev.preventDefault(); submit(); } });
  btn.addEventListener('click', submit);
  return el('section', { class: 'dash-v2-card quick-card' }, [
    el('div', { class: 'quick-row' }, [input, btn]),
    preview,
  ]);
}

function dashMoreRow(icon, title, bodyId, onClick, staticHint) {
  const body = staticHint
    ? el('div', { class: 'dash-more-content hint' }, staticHint)
    : el('div', { id: bodyId, class: 'dash-more-content' }, skeletonLines(1));
  return el('div', { class: `dash-more-row${onClick ? '' : ' no-click'}`, onclick: onClick || undefined }, [
    el('div', { class: 'dash-more-icon' }, icon),
    el('div', { class: 'dash-more-body' }, [
      el('div', { class: 'dash-more-title' }, title),
      body,
    ]),
  ]);
}

// 首頁待辦清單看的時候要「依時間 (離現在最近)」還是「依優先度」排序——只是這次看的當下想怎麼看，
// 不用跨裝置記住，用一般變數就好。
let dashUnifiedSort = 'time';

// tasks 關掉時 (isOn('tasks') === false) 上面的問候語副標題沒有待辦統計可以用，改顯示日期本身就好。
function loadDashHeroSubFallback() {
  const sub = $('#dashHeroSub');
  if (sub) sub.textContent = '祝你有美好的一天 🌿';
}

// 把「離現在這個時間點」的距離算出來，讓待辦事項跟行事曆事件可以合併排序——不論是剛好快到期
// 還是即將發生，越接近現在這個時刻的事情，就越應該排在使用者一打開首頁就看得到的最上面。
function dashItemTimestamp(item) {
  if (item.utype === 'task') {
    if (!item.due_date) return null;
    return new Date(`${item.due_date}T23:59:59`).getTime();
  }
  const time = item.start_time || '23:59';
  return new Date(`${item.event_date}T${time}:00`).getTime();
}

async function loadDashUnifiedTasks() {
  const listBody = $('#dashUnifiedList');
  const statStrip = $('#dashStatStrip');
  if (!listBody) return;
  try {
    const today = todayStr();
    const enabled = (state.prefs && state.prefs.enabledModules) || {};
    const includeCalendar = enabled.calendar !== false;
    const fromD = new Date(); const toD = new Date(); toD.setDate(toD.getDate() + 14);
    const [pending, done, calEvents] = await Promise.all([
      api('/tasks?status=pending'),
      api('/tasks?status=completed'),
      includeCalendar ? api(`/calendar?from=${fromD.toISOString().slice(0, 10)}&to=${toD.toISOString().slice(0, 10)}`) : Promise.resolve([]),
    ]);
    const calFiltered = calEvents.filter((ev) => ev.category !== 'auto-task');
    // /tasks?status=completed 回傳的是「全部歷史已完成任務」(最多 100 筆)，不是只有今天完成的——
    // 這裡的「今日完成度」标签只該算今天完成的筆數，不然使用者每天累積完成的任務只會一直往上疊加，
    // 完成度看起來就會一直變大、從來不會歸零重算，跟「今日」這個標籤名不符。
    const doneToday = done.filter((t) => (t.completed_at || '').slice(0, 10) === today);

    // 副標題跟統計條：完成度、已逾期件數、來自行事曆的件數。
    const overdueCount = pending.filter((t) => t.due_date && t.due_date < today).length;
    const totalForPct = pending.length + doneToday.length;
    const sub = $('#dashHeroSub');
    if (sub) sub.textContent = (pending.length + calFiltered.length) ? `今天有 ${pending.length + calFiltered.length} 件事在等你，慢慢來也沒關係。` : '目前沒有待辦或行程，好好休息一下吧 🌿';
    if (statStrip) {
      statStrip.innerHTML = '';
      const block = (icon, num, desc) => el('div', { class: 'dash-stat-block' }, [
        el('div', { class: 'dash-stat-icon' }, icon),
        el('div', { class: 'dash-stat-num' }, num),
        el('div', { class: 'dash-stat-desc' }, desc),
      ]);
      statStrip.appendChild(block('✅', `${doneToday.length} / ${totalForPct || 0}`, '今日完成度'));
      statStrip.appendChild(block('⏰', `${overdueCount} 件`, '已逾期'));
      statStrip.appendChild(block('📅', `${calFiltered.length} 件`, '來自行事曆'));
    }

    const items = [
      ...pending.map((t) => ({ ...t, utype: 'task' })),
      ...calFiltered.map((e) => ({ ...e, utype: 'calendar' })),
    ];

    const PRIORITY_RANK = { high: 0, medium: 1, low: 2 };
    let sorted;
    if (dashUnifiedSort === 'priority') {
      sorted = [...items].sort((a, b) => {
        const ra = a.utype === 'task' ? (PRIORITY_RANK[a.priority] ?? 1) : 1;
        const rb = b.utype === 'task' ? (PRIORITY_RANK[b.priority] ?? 1) : 1;
        return ra - rb;
      });
    } else {
      const nowMs = Date.now();
      sorted = [...items].sort((a, b) => {
        const ta = dashItemTimestamp(a);
        const tb = dashItemTimestamp(b);
        if (ta === null && tb === null) return 0;
        if (ta === null) return 1;
        if (tb === null) return -1;
        return Math.abs(ta - nowMs) - Math.abs(tb - nowMs);
      });
    }

    listBody.innerHTML = '';
    if (!sorted.length) {
      listBody.appendChild(el('div', { class: 'dash-unified-empty' }, '目前沒有待辦事項或近期行程 🎉'));
      return;
    }
    const nowMs = Date.now();
    sorted.slice(0, 8).forEach((item) => {
      listBody.appendChild(buildDashUnifiedRow(item, today, nowMs));
    });
    if (sorted.length > 8) {
      listBody.appendChild(el('div', { class: 'dash-unified-empty', style: 'cursor:pointer', onclick: () => switchTab('tasks') }, `還有 ${sorted.length - 8} 件，點這裡查看全部`));
    }
  } catch (e) {
    listBody.innerHTML = '';
    listBody.appendChild(el('div', { class: 'dash-unified-empty' }, '待辦/行事曆資料暫時無法取得'));
  }
}

// v0.89：首頁「今天」卡片裡的「即將到來」——資料來自人際關係分頁已經記的生日跟重要日期，
// 不需要多記任何東西。只講事實 (誰、還有幾天)，點一下跳到人際關係分頁。
async function loadDashUpcoming() {
  const box = $('#dashUpcoming');
  if (!box) return;
  let rows;
  try { rows = await api('/relationships/upcoming-dates?days=14&limit=3'); } catch (e) { return; }
  box.innerHTML = '';
  box.className = '';
  if (!rows || !rows.length) return;
  box.className = 'home-upcoming';
  box.appendChild(el('div', { class: 'home-upcoming-title' }, '即將到來'));
  rows.forEach((r) => {
    box.appendChild(el('button', { class: 'home-upcoming-row', onclick: () => switchTab('relationships') }, [
      el('span', { class: 'home-upcoming-icon', 'aria-hidden': 'true' }, r.kind === 'birthday' ? '🎂' : '💍'),
      el('span', { class: 'home-upcoming-name' }, r.label),
      el('span', { class: `home-upcoming-days${r.daysUntil === 0 ? ' is-today' : ''}` }, r.daysUntil === 0 ? '今天' : (r.daysUntil === 1 ? '明天' : `還有 ${r.daysUntil} 天`)),
    ]));
  });
}

function buildDashUnifiedRow(item, today, nowMs) {
  if (item.utype === 'calendar') {
    const ts = dashItemTimestamp(item);
    const soon = ts !== null && ts >= nowMs && ts - nowMs <= 3 * 60 * 60 * 1000;
    const dateLabel = item.event_date === today ? (item.start_time || '今天') : (item.event_date < today ? item.event_date.slice(5) : item.event_date.slice(5));
    return el('div', { class: 'utask-row', onclick: () => switchTab('calendar') }, [
      el('span', { class: 'utask-prio cal' }),
      el('span', { class: 'utask-dot' }, '●'),
      el('span', { class: 'utask-title' }, item.title),
      el('span', { class: 'utask-badge cal' }, '行事曆'),
      soon ? el('span', { class: 'utask-badge soon' }, '即將') : null,
      el('span', { class: `utask-meta${soon ? ' soon' : ''}` }, dateLabel),
    ].filter(Boolean));
  }
  const isOverdue = item.due_date && item.due_date < today;
  const ts = dashItemTimestamp(item);
  const soon = !isOverdue && ts !== null && ts >= nowMs && ts - nowMs <= 3 * 60 * 60 * 1000;
  const dateLabel = !item.due_date ? '未排定' : (isOverdue ? item.due_date.slice(5) : (item.due_date === today ? '今天' : item.due_date.slice(5)));
  return el('div', { class: 'utask-row' }, [
    el('span', { class: `utask-prio ${item.priority || 'low'}` }),
    el('input', { type: 'checkbox', class: 'utask-check', onclick: (ev) => ev.stopPropagation(), onchange: (ev) => dashCompleteUnifiedTask(item.id, ev) }),
    el('span', { class: 'utask-title' }, item.title),
    isOverdue ? el('span', { class: 'utask-badge overdue' }, '逾期') : (soon ? el('span', { class: 'utask-badge soon' }, '即將') : null),
    el('span', { class: `utask-meta${isOverdue ? ' overdue' : (soon ? ' soon' : '')}` }, dateLabel),
    isOverdue ? el('button', { class: 'utask-snooze', title: '延到今天', onclick: (ev) => dashSnoozeUnifiedTask(item.id, ev) }, '⏩') : null,
    el('button', { class: 'utask-del', title: '刪除', onclick: (ev) => dashDeleteUnifiedTask(item.id, ev) }, '×'),
  ].filter(Boolean));
}

async function dashCompleteUnifiedTask(id, ev) {
  if (ev) ev.stopPropagation();
  try {
    await api(`/tasks/${id}/complete`, { method: 'PUT', body: { completed: true } });
    loadDashUnifiedTasks();
  } catch (e) { showToast('更新失敗：' + e.message); }
}
async function dashDeleteUnifiedTask(id, ev) {
  if (ev) ev.stopPropagation();
  try {
    await api(`/tasks/${id}`, { method: 'DELETE' });
    loadDashUnifiedTasks();
  } catch (e) { showToast('刪除失敗：' + e.message); }
}
async function dashSnoozeUnifiedTask(id, ev) {
  if (ev) ev.stopPropagation();
  try {
    await api(`/tasks/${id}`, { method: 'PUT', body: { dueDate: todayStr() } });
    showToast('已延到今天');
    loadDashUnifiedTasks();
  } catch (e) { showToast('延期失敗：' + e.message); }
}

// ===================== 手機版首頁：小工具拼貼 =====================
// 每個小工具對應一個 enabledModules 的 key，跟桌面版首頁卡片共用同一份「自訂」設定。
// 注意：這裡故意不幫每個小工具寫死 size (大小/形狀)。之前的做法是「股票永遠是大方塊、
// 待辦永遠是小方塊」，使用者自己拖曳排序把小工具往前移動之後，因為大小還是跟著原本的
// 身分走，常常會排出「一個小方塊獨自卡在最上面」這種視覺上比例失衡、看起來很奇怪的版面。
// 現在改成：大小交給 widgetSizeForIndex() 依照「排在第幾個」決定 (見下面)，每個小工具的
// 內容 (數字 + 一行說明文字) 本來就很單純，放大方塊、小方塊、長條都看得下去，所以不管
// 使用者怎麼排序，版面永遠照著同一套「大、小、小、長」的節奏走，排起來都會是好看的。
const MOBILE_WIDGETS = [
  { key: 'tasks', label: '✅ 待辦', color: 'amber', bodyId: 'wTasksBody', tab: 'tasks', loader: (size) => loadMobileTasksWidget(size) },
  { key: 'mood', label: '💗 心情', color: 'sky', bodyId: 'wMoodBody', tab: 'mood', loader: (size) => loadMobileMoodWidget(size) },
  { key: 'finance', label: '💰 記帳', color: 'indigo', bodyId: 'wFinanceBody', tab: 'finance', loader: (size) => loadMobileFinanceWidget(size) },
  { key: 'bills', label: '🧾 帳單提醒', color: 'light', bodyId: 'wBillsBody', tab: 'bills', loader: (size) => loadMobileBillsWidget(size) },
  { key: 'calendar', label: '📅 行事曆', color: 'rose', bodyId: 'wCalendarBody', tab: 'calendar', loader: (size) => loadMobileCalendarWidget(size) },
];
// 排到「大方塊」(w2x2) 這個比較寬敞、垂直空間也夠的形狀時，心情/待辦這兩個小工具會顯示
// 比較完整的互動內容 (心情：可以直接點分數記錄；待辦：多顯示 1-2 筆待辦事項)。「長條」
// (w4x1) 雖然寬，但只有一列的高度塞不下 10 個評分按鈕，所以只有大方塊才會展開；排到小方塊
// /長條時空間不夠，維持原本精簡的摘要文字就好——桌面版本來就有這些完整內容，這裡是讓
// 手機版排到夠大的位置時也能對齊，而不是任何情況都只能點進去才看得到。
const WIDGET_SPACIOUS_SIZES = ['w2x2'];

// 版型節奏：大方塊 (2x2) → 小方塊 (1x1) → 小方塊 (1x1) → 長條 (4x1)，每 4 個一輪循環。
// 不管使用者把哪個小工具排到第幾個，都是照這個節奏決定形狀，所以排序永遠不會排出
// 「比例失衡」的版面 (例如原本只有一個小方塊卡在整排的開頭)。
const WIDGET_SIZE_PATTERN = ['w2x2', 'w1x1', 'w1x1', 'w4x1'];
function widgetSizeForIndex(index) {
  return WIDGET_SIZE_PATTERN[index % WIDGET_SIZE_PATTERN.length];
}

function buildMobileDashboard(period, meta, dateLabel) {
  const enabled = (state.prefs && state.prefs.enabledModules) || {};
  const isOn = (key) => enabled[key] !== false;
  const wrap = el('div', { class: 'dash-mobile-widgets' });

  wrap.appendChild(el('div', { class: 'dash-mobile-topline' }, [
    el('div', { class: 'dash-mobile-greet' }, [
      el('div', { class: 'hi' }, `${meta.icon} ${dateLabel}`),
      el('div', { class: 'name' }, `哈囉，${state.user ? state.user.name : ''}`),
    ]),
    el('button', { class: 'dash-customize-btn', onclick: openCustomizeSheet }, '✏️ 自訂'),
  ]));

  const activeWidgets = orderedMobileWidgets().filter((w) => isOn(w.key));
  if (activeWidgets.length) {
    const grid = el('div', { class: 'widget-grid' });
    activeWidgets.forEach((w, i) => {
      grid.appendChild(el('div', { class: `widget ${widgetSizeForIndex(i)} ${w.color}`, onclick: () => switchTab(w.tab) }, [
        el('div', { class: 'wt' }, w.label),
        el('div', { id: w.bodyId }, skeletonLines(1)),
      ]));
    });
    wrap.appendChild(grid);
  } else {
    wrap.appendChild(el('div', { class: 'empty-state' }, '首頁小工具都關掉了，按右上角「自訂」重新打開'));
  }

  wrap.appendChild(el('div', { class: 'section-label' }, '全部功能'));
  const shortcutGrid = el('div', { class: 'widget-grid shortcuts' });
  orderedMoreNavItems().forEach((s) => {
    shortcutGrid.appendChild(el('div', { class: 'widget wshort light shortcut', onclick: () => switchTab(s.tab) }, [
      el('div', { class: 'ic' }, s.icon),
      el('div', { class: 'lb' }, s.label),
    ]));
  });
  wrap.appendChild(shortcutGrid);
  return wrap;
}

// 小工具的資料要等 buildMobileDashboard() 回傳的 DOM 真的被插進頁面之後才能抓，
// 所以獨立成一個函式，由呼叫端在 appendChild 之後再呼叫 (見 renderDashboard())。
function loadMobileWidgetsData() {
  const enabled = (state.prefs && state.prefs.enabledModules) || {};
  const isOn = (key) => enabled[key] !== false;
  // 把「這個小工具排在第幾個、所以會是什麼形狀」一起傳給 loader，讓內容可以自己決定要
  // 顯示精簡摘要還是比較完整的互動內容 (例如心情卡排到夠寬的位置時，直接顯示評分按鈕)。
  orderedMobileWidgets().filter((w) => isOn(w.key)).forEach((w, i) => w.loader(widgetSizeForIndex(i)));
}

// 依照 state.prefs.moduleOrder (存的是 widget key 陣列) 排序 MOBILE_WIDGETS；
// 這個欄位在 prefs API 裡本來就存在，只是之前完全沒有前端功能在用，這次拿來做
// 「首頁小工具拖曳排序」剛好用得上，不用另外加新的資料庫欄位。沒排過序 (或有新
// 小工具還沒被排進去) 的項目，就照 MOBILE_WIDGETS 原本定義的順序排在後面。
function orderedMobileWidgets() {
  const order = (state.prefs && state.prefs.moduleOrder) || [];
  const orderIndex = new Map(order.map((k, i) => [k, i]));
  return [...MOBILE_WIDGETS].sort((a, b) => {
    const ia = orderIndex.has(a.key) ? orderIndex.get(a.key) : 1000 + MOBILE_WIDGETS.indexOf(a);
    const ib = orderIndex.has(b.key) ? orderIndex.get(b.key) : 1000 + MOBILE_WIDGETS.indexOf(b);
    return ia - ib;
  });
}

function openCustomizeSheet() {
  openSheet('自訂首頁小工具', () => {
    const wrap = el('div', {});
    wrap.appendChild(el('p', { class: 'hint', style: 'margin:0 0 12px' }, '關掉的項目暫時不會出現在首頁，隨時可以再打開；一般選單裡還是找得到，資料也不會被刪除。按住左邊的 ⠿ 拖曳可以調整首頁小工具的排列順序。'));
    const enabled = (state.prefs && state.prefs.enabledModules) || {};
    const listEl = el('div', { class: 'widget-order-list' });
    orderedMobileWidgets().forEach((w) => {
      listEl.appendChild(el('div', { class: 'module-toggle-row widget-order-row', 'data-key': w.key }, [
        el('span', { class: 'widget-drag-handle' }, '⠿'),
        el('span', { class: 'widget-order-label' }, w.label),
        el('label', { class: 'switch' }, [
          el('input', { type: 'checkbox', checked: enabled[w.key] !== false, onchange: (ev) => toggleDashWidget(w.key, ev.target.checked) }),
          el('span', { class: 'slider' }),
        ]),
      ]));
    });
    wrap.appendChild(listEl);
    setupWidgetDragReorder(listEl);
    return wrap;
  });
}

// 拖曳排序：用 Pointer Events (滑鼠/觸控通用同一套邏輯，不用分開寫兩份)。
// 拖曳過程中直接搬動 DOM 節點順序 (insertBefore)，放開時把目前的順序存回 prefs。
function setupWidgetDragReorder(listEl) {
  let dragRow = null, startY = 0, rowHeight = 1;
  listEl.querySelectorAll('.widget-drag-handle').forEach((handle) => {
    handle.addEventListener('pointerdown', (e) => {
      dragRow = handle.closest('.widget-order-row');
      if (!dragRow) return;
      startY = e.clientY;
      rowHeight = dragRow.offsetHeight || 1;
      dragRow.classList.add('dragging');
      try { handle.setPointerCapture(e.pointerId); } catch (err) {}
      e.preventDefault();
    });
  });
  listEl.addEventListener('pointermove', (e) => {
    if (!dragRow) return;
    const dy = e.clientY - startY;
    dragRow.style.transform = `translateY(${dy}px)`;
    const rows = Array.from(listEl.querySelectorAll('.widget-order-row'));
    const dragIndex = rows.indexOf(dragRow);
    const targetIndex = Math.max(0, Math.min(rows.length - 1, dragIndex + Math.round(dy / rowHeight)));
    if (targetIndex !== dragIndex) {
      const targetRow = rows[targetIndex];
      if (dy > 0) listEl.insertBefore(dragRow, targetRow.nextSibling);
      else listEl.insertBefore(dragRow, targetRow);
      startY = e.clientY;
      dragRow.style.transform = '';
    }
  });
  function endDrag() {
    if (!dragRow) return;
    dragRow.classList.remove('dragging');
    dragRow.style.transform = '';
    const finishedRow = dragRow;
    dragRow = null;
    const newOrder = Array.from(listEl.querySelectorAll('.widget-order-row')).map((r) => r.dataset.key);
    saveWidgetOrder(newOrder);
    void finishedRow; // 只是避免 lint 警告未使用變數，實際上不需要再對這個節點做事
  }
  listEl.addEventListener('pointerup', endDrag);
  listEl.addEventListener('pointercancel', endDrag);
}
async function saveWidgetOrder(order) {
  state.prefs.moduleOrder = order;
  try {
    await api('/prefs', { method: 'PUT', body: state.prefs });
  } catch (e) { showToast('排序儲存失敗：' + e.message); }
  renderDashboard();
}

async function toggleDashWidget(key, val) {
  state.prefs.enabledModules = { ...(state.prefs.enabledModules || {}), [key]: val };
  try {
    await api('/prefs', { method: 'PUT', body: state.prefs });
  } catch (e) { showToast('儲存失敗：' + e.message); }
  renderDashboard();
  // 首頁重新畫過之後，把「自訂」面板重新打開、停在同一個畫面，這樣連續關好幾個小工具不用一直重新點「自訂」
  openCustomizeSheet();
}

async function loadMobileTasksWidget(size) {
  const body = $('#wTasksBody');
  if (!body) return;
  try {
    const pending = await api('/tasks?status=pending');
    body.innerHTML = '';
    const overdue = pending.filter((t) => t.due_date && t.due_date < todayStr()).length;
    body.appendChild(el('div', { class: 'wv small' }, `${pending.length} 件`));
    body.appendChild(el('div', { class: 'w-sub' }, overdue ? `${overdue} 件已過期` : '待完成'));
    // 排到大方塊時，比照桌面版多顯示 1~2 筆待辦事項的標題，不用點進去才看得到內容是什麼；
    // 排到小方塊/長條時空間不夠，維持上面的精簡數字就好。
    if (WIDGET_SPACIOUS_SIZES.includes(size) && pending.length) {
      const list = el('div', { class: 'w-mini-list' });
      pending.slice(0, 2).forEach((t) => {
        list.appendChild(el('div', { class: 'w-mini-list-item' }, `${PRIORITY_LABEL[t.priority] || ''} ${t.title}`));
      });
      body.appendChild(list);
    }
  } catch (e) {
    body.innerHTML = '';
    body.appendChild(el('div', { class: 'w-sub' }, '暫時無法取得'));
  }
}

// 手機版心情小工具的快速評分狀態，跟桌面版 (dashMoodQuickScore 等) 分開一份，避免同一個
// 分頁裡桌面/手機兩份 DOM 同時存在時 (CSS 只是用 display:none 切換、兩份其實都在) 互相干擾。
let mobileMoodQuickScore = null;
async function loadMobileMoodWidget(size) {
  const body = $('#wMoodBody');
  if (!body) return;
  try {
    const today = todayStr();
    const rows = await api(`/mood/entries?from=${today}&to=${today}`);
    body.innerHTML = '';
    mobileMoodQuickScore = rows.length ? rows[0].score : null;

    // 排到大方塊時，直接比照桌面版放一排 1-10 分快速評分按鈕，不用點進心情頁才能記錄；
    // 排到小方塊/長條時空間放不下 10 個按鈕 (長條只有一列高度)，維持精簡摘要 + 點擊進頁面。
    if (WIDGET_SPACIOUS_SIZES.includes(size)) {
      body.appendChild(el('div', { class: 'w-sub' }, rows.length ? `今天已記錄 ${rows[0].score} 分` : '今天還沒記錄，點個分數快速記一下：'));
      const quickRow = el('div', { class: 'mood-score-row sm mobile-widget-mood-row', id: 'wMoodQuickRow' });
      for (let i = 1; i <= 10; i++) {
        quickRow.appendChild(el('button', {
          class: 'mood-score-btn sm' + (mobileMoodQuickScore === i ? ' selected' : ''),
          'data-score': i,
          onclick: (ev) => { ev.stopPropagation(); mobileQuickMoodPick(i); },
        }, String(i)));
      }
      body.appendChild(quickRow);
    } else {
      if (rows.length) {
        body.appendChild(el('div', { class: 'wv small' }, `${rows[0].score} 分`));
        body.appendChild(el('div', { class: 'w-sub' }, '今天已記錄'));
      } else {
        body.appendChild(el('div', { class: 'wv small' }, '😊'));
        body.appendChild(el('div', { class: 'w-sub' }, '點擊記錄心情'));
      }
    }
  } catch (e) {
    body.innerHTML = '';
    body.appendChild(el('div', { class: 'w-sub' }, '暫時無法取得'));
  }
}
async function mobileQuickMoodPick(score) {
  mobileMoodQuickScore = score;
  document.querySelectorAll('#wMoodQuickRow .mood-score-btn').forEach((b) => b.classList.toggle('selected', Number(b.dataset.score) === score));
  try {
    await api(`/mood/entries/${todayStr()}`, { method: 'PUT', body: { score, tags: [], note: '' } });
    showToast('已記錄今天的心情 💗');
  } catch (e) { showToast('儲存失敗：' + e.message); }
}
async function loadMobileFinanceWidget() {
  const body = $('#wFinanceBody');
  if (!body) return;
  try {
    const summary = await api('/finance/summary');
    const expense = (summary.totals || []).find((t) => t.type === 'expense')?.total || 0;
    body.innerHTML = '';
    body.appendChild(el('div', { class: 'wv' }, fmtMoney(expense)));
    body.appendChild(el('div', { class: 'w-sub' }, '本月支出'));
  } catch (e) {
    body.innerHTML = '';
    body.appendChild(el('div', { class: 'w-sub' }, '暫時無法取得'));
  }
}
async function loadMobileBillsWidget() {
  const body = $('#wBillsBody');
  if (!body) return;
  try {
    const res = await api('/bills/upcoming');
    const unpaid = res.bills.filter((b) => !b.paid);
    body.innerHTML = '';
    if (!res.bills.length) {
      body.appendChild(el('div', { class: 'wv small' }, '尚未加入'));
      body.appendChild(el('div', { class: 'w-sub' }, '點擊新增帳單'));
    } else if (!unpaid.length) {
      body.appendChild(el('div', { class: 'wv small' }, '都繳完了 🎉'));
    } else {
      body.appendChild(el('div', { class: 'wv small' }, unpaid[0].name));
      body.appendChild(el('div', { class: 'w-sub' }, `每月${unpaid[0].due_day}號・還有${unpaid.length}筆`));
    }
  } catch (e) {
    body.innerHTML = '';
    body.appendChild(el('div', { class: 'w-sub' }, '暫時無法取得'));
  }
}
async function loadMobileCalendarWidget() {
  const body = $('#wCalendarBody');
  if (!body) return;
  try {
    const today = new Date();
    const from = today.toISOString().slice(0, 10);
    const toD = new Date(today); toD.setDate(toD.getDate() + 14);
    const to = toD.toISOString().slice(0, 10);
    // 行事曆 API 會自動把待辦截止日整合進來 (方便在行事曆分頁一次看到全部行程)，但首頁/手機拼貼
    // 已經有獨立的「待辦事項」卡片在顯示同一批資料——兩邊都出現同一件事會讓人覺得重複、雜亂，
    // 這裡把 auto-task 類別濾掉，只保留真的行事曆行程跟帳單/生日這種待辦卡片不會顯示的類別。
    const events = (await api(`/calendar?from=${from}&to=${to}`)).filter((ev) => ev.category !== 'auto-task');
    body.innerHTML = '';
    if (!events.length) {
      body.appendChild(el('div', { class: 'wv small' }, '沒有排程'));
      body.appendChild(el('div', { class: 'w-sub' }, '接下來兩週'));
    } else {
      body.appendChild(el('div', { class: 'wv small' }, events[0].title.length > 8 ? events[0].title.slice(0, 8) + '…' : events[0].title));
      body.appendChild(el('div', { class: 'w-sub' }, `${events[0].event_date}${events.length > 1 ? ` 等${events.length}項` : ''}`));
    }
  } catch (e) {
    body.innerHTML = '';
    body.appendChild(el('div', { class: 'w-sub' }, '暫時無法取得'));
  }
}

function dashCard(icon, title, bodyId, onClick, staticHint) {
  const children = [el('h3', {}, [el('div', { class: 'hex-badge' }, icon), title])];
  if (staticHint) {
    children.push(el('p', { class: 'hint', style: 'margin-bottom:0' }, staticHint));
  } else if (bodyId) {
    children.push(el('div', { id: bodyId }, skeletonLines(2)));
  }
  return el('div', { class: `card dash-card${onClick ? ' clickable' : ''}`, onclick: onClick || undefined }, children);
}

// 主動式提醒：帳單快到期、預算超支、待辦逾期、好幾天沒記心情，集中列在首頁最上面，
// 不用自己一個一個分頁點進去才會發現。沒有任何提醒事項時，這個區塊直接不顯示 (不留空白卡片)。
async function loadDashReminders() {
  const wrap = $('#dashRemindersWrap');
  if (!wrap) return;
  try {
    const data = await api('/insights/reminders');
    wrap.innerHTML = '';
    if (!data.items || !data.items.length) return;
    const box = el('div', { class: 'dash-reminders-box' });
    data.items.forEach((item) => {
      box.appendChild(el('div', { class: `dash-reminder-item ${item.severity}`, onclick: () => switchTab(item.tab) }, [
        el('span', { class: 'dash-reminder-icon' }, item.icon),
        el('span', { class: 'dash-reminder-text' }, item.text),
      ]));
    });
    wrap.appendChild(box);
  } catch (e) { /* 靜默失敗，不影響首頁其他內容 */ }
}

// 本週動態：純程式算出來的幾句話 (心情/記帳/待辦/行事曆/日記)，不是 AI 寫的，資料就是資料。
async function loadDashWeeklyDigest() {
  const body = $('#weeklyDigestBody');
  if (!body) return;
  try {
    const data = await api('/insights/weekly');
    body.innerHTML = '';
    if (!data.lines || !data.lines.length) {
      body.appendChild(el('p', { class: 'hint', style: 'margin:0' }, '這週還沒有足夠的資料可以整理'));
      return;
    }
    const list = el('ul', { class: 'dash-mini-list' });
    data.lines.forEach((line) => list.appendChild(el('li', {}, [el('span', {}, line)])));
    body.appendChild(list);
  } catch (e) {
    body.innerHTML = '';
    body.appendChild(el('p', { class: 'hint', style: 'margin:0' }, '本週動態暫時無法取得'));
  }
}

// 首頁快速心情打卡：有些人比較懶，不想特地點進心情頁才能記錄，
// 所以直接在首頁的卡片裡放一列小分數按鈕 + 選填備註，點兩下就能存。
// 注意這裡的每個互動元件都要 stopPropagation()，不然點下去會被外層卡片的
// onclick 攔截、直接跳轉到心情頁而不是選分數。
let dashMoodQuickScore = null;

// 首頁「家庭公告欄」預覽：最多顯示 2 則 (置頂優先，API 本身回傳順序已經是置頂在前)，
// 沒連結任何家人時顯示邀請引導，讓使用者知道要往「家庭公告欄」分頁走才能開始用這個功能。
async function loadDashFamilyBoardPreview() {
  const body = $('#dashFamilyBoardBody');
  if (!body) return;
  try {
    const { posts, circleSize } = await api('/family-board');
    body.innerHTML = '';
    if (!circleSize) {
      body.appendChild(el('div', { class: 'dash-unified-empty', style: 'cursor:pointer', onclick: () => switchTab('familyBoard') }, '還沒連結家人，點這裡用邀請碼跟家人連結，開始共用公告欄'));
      return;
    }
    if (!posts.length) {
      body.appendChild(el('div', { class: 'dash-unified-empty', style: 'cursor:pointer', onclick: () => switchTab('familyBoard') }, '目前還沒有任何公告，點這裡發第一則'));
      return;
    }
    posts.slice(0, 2).forEach((p) => {
      body.appendChild(el('div', { class: 'utask-row', onclick: () => switchTab('familyBoard') }, [
        el('div', {}, [
          el('div', { style: 'font-weight:700' }, `${p.pinned ? '📌 ' : ''}${p.authorLabel}`),
          el('div', { class: 'hint', style: 'margin:2px 0 0' }, p.content.length > 40 ? p.content.slice(0, 40) + '…' : p.content),
        ]),
      ]));
    });
  } catch (e) {
    body.innerHTML = '';
    body.appendChild(el('div', { class: 'empty-state' }, '公告欄暫時無法取得'));
  }
}

async function loadDashMoodSummary() {
  const body = $('#moodSummaryBody');
  if (!body) return;
  try {
    const today = todayStr();
    const [todayRows, summary] = await Promise.all([
      api(`/mood/entries?from=${today}&to=${today}`),
      api('/mood/summary?days=7'),
    ]);
    body.innerHTML = '';
    dashMoodQuickScore = todayRows.length ? todayRows[0].score : null;

    if (summary.careMessage) {
      body.appendChild(el('div', { class: 'dash-care-banner' }, `💌 ${summary.careMessage}`));
    }
    if (todayRows.length) {
      body.appendChild(el('div', { class: 'stat-big' }, `${todayRows[0].score} 分`));
      body.appendChild(el('p', { class: 'hint', style: 'margin:4px 0 8px' }, `今天已記錄 · 近 7 天平均 ${summary.average != null ? summary.average : '--'} 分`));
    } else {
      body.appendChild(el('p', { class: 'hint', style: 'margin:0 0 6px' }, '今天還沒記錄，點個分數快速記一下：'));
    }

    const quickRow = el('div', { class: 'mood-score-row sm', id: 'dashMoodQuickRow' });
    for (let i = 1; i <= 10; i++) {
      quickRow.appendChild(el('button', {
        class: 'mood-score-btn sm' + (dashMoodQuickScore === i ? ' selected' : ''),
        'data-score': i,
        onclick: (ev) => { ev.stopPropagation(); dashQuickMoodPick(i); },
      }, String(i)));
    }
    body.appendChild(quickRow);

    body.appendChild(el('div', { class: 'dash-mood-quick-note', id: 'dashMoodQuickNoteRow', style: todayRows.length ? 'display:none' : 'display:flex' }, [
      el('input', { id: 'dashMoodQuickNote', placeholder: '想補充一句嗎？(選填)', value: todayRows.length ? (todayRows[0].note || '') : '', onclick: (ev) => ev.stopPropagation(), onkeydown: (ev) => ev.stopPropagation() }),
      el('button', { class: 'btn btn-primary', style: 'font-size:12px;padding:6px 10px', onclick: (ev) => { ev.stopPropagation(); saveDashQuickMood(); } }, '儲存'),
    ]));
  } catch (e) {
    body.innerHTML = '';
    body.appendChild(el('p', { class: 'hint', style: 'margin-bottom:0' }, '心情資料暫時無法取得'));
  }
}

function dashQuickMoodPick(score) {
  dashMoodQuickScore = score;
  document.querySelectorAll('#dashMoodQuickRow .mood-score-btn').forEach((b) => b.classList.toggle('selected', Number(b.dataset.score) === score));
  const noteRow = $('#dashMoodQuickNoteRow');
  if (noteRow) noteRow.style.display = 'flex';
}

async function saveDashQuickMood() {
  if (!dashMoodQuickScore) { showToast('先選一個 1-10 的分數'); return; }
  try {
    const noteEl = $('#dashMoodQuickNote');
    await api(`/mood/entries/${todayStr()}`, {
      method: 'PUT',
      body: { score: dashMoodQuickScore, tags: [], note: noteEl ? noteEl.value.trim() : '' },
    });
    showToast('已記錄今天的心情 💗');
    loadDashMoodSummary();
  } catch (e) { showToast('儲存失敗：' + e.message); }
}

async function loadDashCalendarSummary() {
  const body = $('#calendarSummaryBody');
  if (!body) return;
  try {
    const today = new Date();
    const from = today.toISOString().slice(0, 10);
    const toDate = new Date(today); toDate.setDate(toDate.getDate() + 14);
    const to = toDate.toISOString().slice(0, 10);
    // 行事曆 API 會自動把待辦截止日整合進來 (方便在行事曆分頁一次看到全部行程)，但首頁/手機拼貼
    // 已經有獨立的「待辦事項」卡片在顯示同一批資料——兩邊都出現同一件事會讓人覺得重複、雜亂，
    // 這裡把 auto-task 類別濾掉，只保留真的行事曆行程跟帳單/生日這種待辦卡片不會顯示的類別。
    const events = (await api(`/calendar?from=${from}&to=${to}`)).filter((ev) => ev.category !== 'auto-task');
    body.innerHTML = '';
    if (!events.length) {
      body.appendChild(el('p', { class: 'hint', style: 'margin-bottom:0' }, '接下來兩週沒有安排的行程'));
    } else {
      const list = el('ul', { style: 'list-style:none;padding:0;margin:0;display:flex;flex-direction:column;gap:6px' });
      events.slice(0, 3).forEach((ev) => {
        list.appendChild(el('li', { style: 'font-size:12.5px;color:var(--text-secondary)' }, `${ev.event_date}${ev.start_time ? ' ' + ev.start_time : ''} · ${ev.title}`));
      });
      body.appendChild(list);
      if (events.length > 3) body.appendChild(el('p', { class: 'hint', style: 'margin:6px 0 0' }, `還有 ${events.length - 3} 項行程，點卡片查看完整行事曆`));
    }
  } catch (e) {
    body.innerHTML = '';
    body.appendChild(el('p', { class: 'hint', style: 'margin-bottom:0' }, '行事曆資料暫時無法取得'));
  }
}

async function loadDashFinanceSummary() {
  const body = $('#financeSummaryBody');
  if (!body) return;
  try {
    const summary = await api('/finance/summary');
    const income = (summary.totals || []).find((t) => t.type === 'income')?.total || 0;
    const expense = (summary.totals || []).find((t) => t.type === 'expense')?.total || 0;
    body.innerHTML = '';
    body.appendChild(el('div', { class: 'stat-big' }, fmtMoney(expense)));
    body.appendChild(el('p', { class: 'hint', style: 'margin:4px 0 0' }, `本月支出 · 收入 ${fmtMoney(income)}`));
    const byExpense = (summary.byCategory || []).filter((c) => c.type === 'expense').slice(0, 4);
    if (byExpense.length) {
      const list = el('ul', { class: 'dash-mini-list' });
      byExpense.forEach((c) => {
        list.appendChild(el('li', {}, [el('span', { class: 'lbl' }, c.category), el('span', {}, fmtMoney(c.total))]));
      });
      body.appendChild(list);
    } else {
      body.appendChild(el('p', { class: 'hint', style: 'margin:8px 0 0' }, '本月還沒有記帳紀錄，點卡片新增一筆'));
    }
  } catch (e) {
    body.innerHTML = '';
    body.appendChild(el('p', { class: 'hint', style: 'margin-bottom:0' }, '記帳資料暫時無法取得'));
  }
}

async function loadDashDiarySummary() {
  const body = $('#diarySummaryBody');
  if (!body) return;
  try {
    const entries = await api('/diary?from=0001-01-01&to=9999-12-31');
    body.innerHTML = '';
    if (!entries.length) {
      body.appendChild(el('p', { class: 'hint', style: 'margin-bottom:0' }, '還沒有日記，點卡片開始寫下今天'));
    } else {
      body.appendChild(el('p', { class: 'hint', style: 'margin-bottom:8px' }, `共 ${entries.length} 篇日記，最近寫的：`));
      const list = el('div', { style: 'display:flex;flex-direction:column;gap:10px' });
      entries.slice(0, 3).forEach((entry) => {
        const snippet = (entry.content || '').slice(0, 34);
        list.appendChild(el('div', {}, [
          el('div', { style: 'font-size:11.5px;color:var(--text-muted)' }, entry.entry_date),
          el('div', { style: 'font-size:12.5px;color:var(--text-secondary)' }, snippet + (entry.content && entry.content.length > 34 ? '…' : '')),
        ]));
      });
      body.appendChild(list);
    }
  } catch (e) {
    body.innerHTML = '';
    body.appendChild(el('p', { class: 'hint', style: 'margin-bottom:0' }, '日記資料暫時無法取得'));
  }
}

// ---- 首頁「待辦事項」卡片：3 種可切換的呈現樣式 (使用者自己在卡片上選、立刻看到效果並記住選擇) ----
// grouped=分組統計條 (已過期/今天/全部待完成三個彩色泡泡＋清單)；progress=完成進度環 (圓環百分比＋
// 可直接勾選完成)；focus=今日焦點 (只列今天+已過期、字級加大，其餘收成一行連結)。
const TASK_WIDGET_STYLE_LABELS = { grouped: '樣式A：分組統計', progress: '樣式B：進度環', focus: '樣式C：今日焦點' };

function buildTasksDashCard() {
  const style = (state.prefs && state.prefs.taskWidgetStyle) || 'progress';
  const header = el('h3', {}, [
    el('div', { class: 'hex-badge' }, '✅'),
    '待辦事項',
    el('select', {
      style: 'margin-left:auto;font-size:11px;padding:3px 6px;width:auto;border-radius:6px;',
      onclick: (ev) => ev.stopPropagation(),
      onchange: (ev) => { ev.stopPropagation(); setTaskWidgetStyle(ev.target.value); },
    }, Object.entries(TASK_WIDGET_STYLE_LABELS).map(([val, label]) => el('option', { value: val, selected: val === style }, label))),
  ]);
  return el('div', { class: 'card dash-card clickable', onclick: () => switchTab('tasks') }, [
    header,
    el('div', { id: 'tasksSummaryBody' }, skeletonLines(2)),
  ]);
}

// 進度環用 SVG 畫 (而不是 CSS conic-gradient)，這樣邊緣可以用 round linecap 收圓角、視覺上更精緻，
// 也留了轉場動畫的空間 (雖然目前每次都整個重建 DOM、動畫不會真的播放，但保留這個做法方便未來局部更新時直接受益)。
function buildProgressRingSvg(pct, size, strokeWidth) {
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference * (1 - Math.max(0, Math.min(100, pct)) / 100);
  const NS = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(NS, 'svg');
  svg.setAttribute('width', size);
  svg.setAttribute('height', size);
  svg.setAttribute('viewBox', `0 0 ${size} ${size}`);
  const bg = document.createElementNS(NS, 'circle');
  bg.setAttribute('cx', size / 2); bg.setAttribute('cy', size / 2); bg.setAttribute('r', radius);
  bg.setAttribute('fill', 'none'); bg.setAttribute('stroke', 'var(--surface-2)'); bg.setAttribute('stroke-width', strokeWidth);
  const fg = document.createElementNS(NS, 'circle');
  fg.setAttribute('cx', size / 2); fg.setAttribute('cy', size / 2); fg.setAttribute('r', radius);
  fg.setAttribute('fill', 'none'); fg.setAttribute('stroke', 'var(--accent)'); fg.setAttribute('stroke-width', strokeWidth);
  fg.setAttribute('stroke-linecap', 'round');
  fg.setAttribute('stroke-dasharray', String(circumference));
  fg.setAttribute('stroke-dashoffset', String(offset));
  fg.setAttribute('transform', `rotate(-90 ${size / 2} ${size / 2})`);
  fg.style.transition = 'stroke-dashoffset 0.5s ease';
  svg.appendChild(bg);
  svg.appendChild(fg);
  const wrap = el('div', { style: `position:relative;width:${size}px;height:${size}px;flex-shrink:0` }, [svg]);
  wrap.appendChild(el('div', {
    style: 'position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-size:14px;font-weight:800',
  }, `${pct}%`));
  return wrap;
}

async function setTaskWidgetStyle(style) {
  state.prefs = state.prefs || {};
  state.prefs.taskWidgetStyle = style;
  try { await api('/prefs', { method: 'PUT', body: state.prefs }); } catch (e) {}
  loadDashTasksSummary();
}

// 首頁待辦卡片這次看的時候要「依時間」還是「依優先度」排序——只是當下想怎麼看，不用跨裝置記住，
// 所以用一般變數就好，不用存進 prefs。
let dashTaskSortMode = 'time';

// 從首頁卡片直接勾選完成，不用先跳去待辦事項頁——跟 tasks.js 分頁的 completeTask 呼叫同一支 API，
// 完成後只重新整理這張卡片本身 (不用整個首頁重繪)，動作更輕、也不會打斷使用者正在看的其他卡片。
async function completeTaskFromDash(id, ev) {
  if (ev) ev.stopPropagation();
  try {
    await api(`/tasks/${id}/complete`, { method: 'PUT', body: { completed: true } });
    loadDashTasksSummary();
  } catch (e) { showToast('更新失敗：' + e.message); }
}

// 首頁直接刪除，不用先跳去待辦事項頁——這是使用者明確要求的「取消」功能，跟卡片本身的
// onclick (點卡片跳去待辦事項頁) 用 stopPropagation 隔開，不然點到 × 會先跳頁。
async function deleteTaskFromDash(id, ev) {
  if (ev) ev.stopPropagation();
  try {
    await api(`/tasks/${id}`, { method: 'DELETE' });
    loadDashTasksSummary();
  } catch (e) { showToast('刪除失敗：' + e.message); }
}

async function loadDashTasksSummary() {
  const body = $('#tasksSummaryBody');
  if (!body) return;
  const style = (state.prefs && state.prefs.taskWidgetStyle) || 'progress';
  try {
    const pending = await api('/tasks?status=pending');
    body.innerHTML = '';
    if (!pending.length) {
      body.appendChild(el('p', { class: 'hint', style: 'margin-bottom:0' }, '目前沒有待完成的任務 🎉'));
      return;
    }
    const today = todayStr();
    if (style === 'progress') {
      // /tasks?status=completed 回傳的是全部歷史已完成任務 (最多 100 筆)，不是只有今天——
      // 拿去跟「目前待完成」的 pending 混在一起算完成率，會因為歷史完成數只增不減，
      // 完成率跟著只漲不跌，圓環最後看起來永遠接近 100%。這裡只算「今天完成」的部分，
      // 跟 pending (現在還沒完成的) 才是同一個時間範圍、比例才有意義。
      const doneAll = await api('/tasks?status=completed');
      const done = doneAll.filter((t) => (t.completed_at || '').slice(0, 10) === today);
      const total = pending.length + done.length;
      const pct = total ? Math.round((done.length / total) * 100) : 0;
      const overdue = pending.filter((t) => t.due_date && t.due_date < today).length;
      const wrap = el('div', { style: 'display:flex;gap:16px;align-items:center;margin-bottom:12px' }, [
        buildProgressRingSvg(pct, 72, 7),
        el('div', {}, [
          el('div', { style: 'font-size:15px;font-weight:800' }, `還有 ${pending.length} 件待完成`),
          el('div', { class: 'hint', style: 'margin:2px 0 0' }, [
            `今天已完成 ${done.length} / ${total} 件`,
            overdue ? el('span', { style: 'color:var(--critical);font-weight:700' }, ` · ${overdue} 件已過期`) : null,
          ]),
        ]),
      ]);
      body.appendChild(wrap);

      // 排序方式：預設跟到期日一樣 (API 本來就是這樣排)，也可以切成依優先度——存在模組變數
      // 而不是 prefs，這只是「這次看的時候想怎麼排」，不需要跨裝置記住。
      const sortRow = el('div', { style: 'display:flex;gap:6px;margin-bottom:8px' }, [
        el('button', {
          class: `dash-sort-btn${dashTaskSortMode === 'time' ? ' active' : ''}`,
          onclick: (ev) => { ev.stopPropagation(); dashTaskSortMode = 'time'; loadDashTasksSummary(); },
        }, '🕐 依時間'),
        el('button', {
          class: `dash-sort-btn${dashTaskSortMode === 'priority' ? ' active' : ''}`,
          onclick: (ev) => { ev.stopPropagation(); dashTaskSortMode = 'priority'; loadDashTasksSummary(); },
        }, '🔥 依優先度'),
      ]);
      body.appendChild(sortRow);

      const PRIORITY_RANK = { high: 0, medium: 1, low: 2 };
      const priorityDotColor = { high: 'var(--critical)', medium: 'var(--warning)', low: 'var(--good)' };
      const sorted = dashTaskSortMode === 'priority'
        ? [...pending].sort((a, b) => (PRIORITY_RANK[a.priority] ?? 1) - (PRIORITY_RANK[b.priority] ?? 1))
        : pending;
      const list = el('div', { class: 'dash-mini-list dash-task-mini-list' });
      sorted.slice(0, 4).forEach((t) => {
        const isOverdue = t.due_date && t.due_date < today;
        const dateLabel = !t.due_date ? '' : (isOverdue ? '已過期' : (t.due_date === today ? '今天' : t.due_date.slice(5)));
        list.appendChild(el('div', { class: 'dash-task-row' }, [
          el('input', { type: 'checkbox', class: 'dash-check', onclick: (ev) => ev.stopPropagation(), onchange: (ev) => completeTaskFromDash(t.id, ev) }),
          el('span', { class: 'dash-task-dot', style: `background:${priorityDotColor[t.priority] || 'var(--text-muted)'}` }),
          el('span', { class: 'dash-task-title' }, t.title),
          dateLabel ? el('span', { class: `dash-task-date${isOverdue ? ' overdue' : ''}` }, dateLabel) : null,
          el('button', { class: 'dash-task-del', onclick: (ev) => deleteTaskFromDash(t.id, ev), title: '刪除' }, '×'),
        ]));
      });
      body.appendChild(list);
    } else if (style === 'focus') {
      const focus = pending.filter((t) => t.due_date && t.due_date <= today);
      const rest = pending.length - focus.length;
      body.appendChild(el('div', { style: 'font-size:16px;font-weight:800;margin-bottom:8px' }, focus.length ? `今天有 ${focus.length} 件事要處理` : '今天沒有急著要做的事 🎉'));
      focus.slice(0, 4).forEach((t) => {
        const isOverdue = t.due_date < today;
        body.appendChild(el('label', { style: `display:flex;align-items:center;gap:10px;padding:6px 0;font-size:14px;${isOverdue ? 'color:var(--critical)' : ''}` }, [
          el('input', { type: 'checkbox', style: 'width:16px;height:16px;flex:0 0 auto', onclick: (ev) => ev.stopPropagation(), onchange: (ev) => completeTaskFromDash(t.id, ev) }),
          el('span', {}, `${t.title}${isOverdue ? ' · 已過期' : ''}`),
        ]));
      });
      if (rest > 0) body.appendChild(el('div', { class: 'hint', style: 'margin-top:8px' }, `還有 ${rest} 件之後的待辦，點卡片查看全部`));
    } else {
      // grouped (預設)：已過期/今天/全部待完成三個彩色統計泡泡＋清單，過期的項目用紅字凸顯
      const overdue = pending.filter((t) => t.due_date && t.due_date < today).length;
      const dueToday = pending.filter((t) => t.due_date === today).length;
      const pill = (label, count, color) => el('span', { style: `font-size:13px;font-weight:700;padding:5px 12px;border-radius:999px;background:color-mix(in srgb, ${color} 16%, transparent);color:${color}` }, `${label} ${count}`);
      body.appendChild(el('div', { style: 'display:flex;gap:8px;margin-bottom:10px;flex-wrap:wrap' }, [
        overdue ? pill('⚠️ 已過期', overdue, 'var(--critical)') : null,
        pill('📍 今天', dueToday, 'var(--warning)'),
        pill('📋 全部待完成', pending.length, 'var(--text-secondary)'),
      ]));
      const list = el('div', { class: 'dash-mini-list' });
      pending.slice(0, 4).forEach((t) => {
        const isOverdue = t.due_date && t.due_date < today;
        list.appendChild(el('div', { style: `display:flex;justify-content:space-between;gap:8px;${isOverdue ? 'color:var(--critical);font-weight:600' : ''}` }, [
          el('span', {}, `${PRIORITY_LABEL[t.priority] || ''} ${t.title}`),
          el('span', { style: 'font-size:11.5px;opacity:0.75' }, t.due_date || ''),
        ]));
      });
      body.appendChild(list);
    }
  } catch (e) {
    body.innerHTML = '';
    body.appendChild(el('p', { class: 'hint', style: 'margin-bottom:0' }, '待辦資料暫時無法取得'));
  }
}

async function loadDashBillsSummary() {
  const body = $('#billsSummaryBody');
  if (!body) return;
  try {
    const res = await api('/bills/upcoming');
    body.innerHTML = '';
    const unpaid = res.bills.filter((b) => !b.paid);
    if (!res.bills.length) {
      body.appendChild(el('p', { class: 'hint', style: 'margin-bottom:0' }, '還沒有加入任何帳單'));
    } else if (!unpaid.length) {
      body.appendChild(el('p', { class: 'hint', style: 'margin-bottom:0' }, '這個月的帳單都繳完了 🎉'));
    } else {
      body.appendChild(el('p', { class: 'hint', style: 'margin-bottom:8px' }, `這個月還有 ${unpaid.length} 筆未繳，共 NT$ ${Math.round(res.totalUnpaid)}`));
      const list = el('div', { class: 'dash-mini-list' });
      unpaid.slice(0, 3).forEach((b) => list.appendChild(el('div', {}, `${b.name}（每月 ${b.due_day} 號）`)));
      body.appendChild(list);
    }
  } catch (e) {
    body.innerHTML = '';
    body.appendChild(el('p', { class: 'hint', style: 'margin-bottom:0' }, '帳單資料暫時無法取得'));
  }
}

function dashAskAI() {
  const input = $('#dashAskInput');
  const text = input ? input.value.trim() : '';
  if (!text) { switchTab('assistant'); return; }
  switchTab('assistant');
  state.assistantHistory = state.assistantHistory || [];
  const target = $('#assistantInput');
  if (target) { target.value = text; sendAssistantMessage(); }
}

// 手動觸發首頁摘要 (不是每次載入首頁就自動打 AI，避免不必要的 API 用量)
async function generateDashBriefing(period) {
  const box = $('#dashBriefResult');
  const btn = document.querySelector('.dash-brief-btn');
  if (!box) return;
  box.style.display = 'block';
  box.innerHTML = '';
  box.appendChild(el('p', { class: 'hint', style: 'margin:0' }, '整理中...'));
  if (btn) btn.disabled = true;
  try {
    const result = await api('/assistant/briefing', { method: 'POST', body: { period } });
    box.innerHTML = '';
    box.appendChild(el('p', { style: 'margin:0;white-space:pre-wrap' }, result.reply || '目前沒有特別的內容'));
  } catch (e) {
    box.innerHTML = '';
    box.appendChild(el('p', { class: 'hint', style: 'margin:0' }, '摘要暫時無法產生：' + e.message));
  } finally {
    if (btn) btn.disabled = false;
  }
}

// ===================== 交通與旅遊 =====================
const TRAVEL_SUB_TABS = [
  { key: 'train', label: '🚄 台鐵 / 高鐵' },
  { key: 'flight', label: '✈️ 機票' },
  { key: 'hotel', label: '🏨 住宿' },
  { key: 'itinerary', label: '🗺️ 行程規劃' },
  { key: 'places', label: '📍 臨時揪一波' },
  { key: 'packing', label: '🎒 行前打包' },
  { key: 'split', label: '💸 旅遊分帳' },
];
let travelSubTab = 'train';

function switchTravelSub(key) {
  travelSubTab = key;
  renderTravel();
}

function renderTravel() {
  const c = $('#tab-travel');
  c.innerHTML = '';

  // 次分頁：把「火車 / 機票 / 住宿 / 行程規劃」分開，一次只看一個，不要全部塞在同一畫面
  c.appendChild(el('div', { class: 'subnav' }, TRAVEL_SUB_TABS.map((t) =>
    el('div', {
      class: `subnav-item${travelSubTab === t.key ? ' active' : ''}`,
      onclick: () => switchTravelSub(t.key),
    }, t.label)
  )));

  const panel = (key, children) => el('div', { class: `subpanel${travelSubTab === key ? ' active' : ''}` }, children);

  c.appendChild(panel('train', [
    el('div', { class: 'card' }, [
      el('h3', {}, '台鐵 / 高鐵 時刻搜尋'),
      el('p', { class: 'hint' }, '資料來源：交通部 TDX 運輸資料流通服務。僅提供時刻/誤點/票價區間查詢，實際訂票請至官方售票網站。'),
      el('div', { class: 'form-row' }, [
        chipSelectEl({ id: 'trainMode', variant: 'segmented', value: 'tra', options: [{ value: 'tra', label: '台鐵 TRA' }, { value: 'thsr', label: '高鐵 THSR' }] }),
        el('input', { id: 'stationName', placeholder: '出發站，如 台北' }),
        el('input', { id: 'stationTo', placeholder: '目的站，如 台中' }),
        el('input', { id: 'trainDate', type: 'date', value: todayStr() }),
      ]),
      el('div', { class: 'form-row' }, [
        el('input', { id: 'timeFrom', type: 'time', value: '06:00' }),
        el('span', { style: 'align-self:center;color:var(--text-muted)' }, '～'),
        el('input', { id: 'timeTo', type: 'time', value: '22:00' }),
        el('input', { id: 'trainNoSearch', placeholder: '搜尋車次號碼 (選填)' }),
        el('button', { class: 'btn btn-primary', onclick: searchTrain }, '查詢'),
      ]),
      el('div', { id: 'trainResult' }),
    ]),
    el('div', { class: 'card' }, [
      el('h3', {}, '⭐ 我的收藏車次'),
      el('p', { class: 'hint' }, '收藏常搭的車次，下次不用重新查詢。'),
      el('div', { id: 'favoriteTrainsArea' }),
    ]),
  ]));

  c.appendChild(panel('flight', [
    el('div', { class: 'card' }, [
      el('h3', {}, '機票 — 各家航空公司/比價網站'),
      el('p', { class: 'hint' }, '目前沒有免費即時比價 API，這裡改用「深連結」方式：點下去會直接跳到該網站，並幫你帶入出發地/目的地/日期。真正一頁比全部價格需要另外申請商業合作 API。'),
      el('div', { class: 'form-row' }, [
        el('input', { id: 'flyFrom', placeholder: '出發地，如 台北' }),
        el('input', { id: 'flyTo', placeholder: '目的地，如 大阪' }),
        el('input', { id: 'flyDate', type: 'date' }),
        el('button', { class: 'btn btn-primary', onclick: searchFlightProviders }, '列出各家連結' ),
      ]),
      el('div', { id: 'flightResult' }),
    ]),
  ]));

  c.appendChild(panel('hotel', [
    el('div', { class: 'card' }, [
      el('h3', {}, '住宿 — 各家訂房網站'),
      el('div', { class: 'form-row' }, [
        el('input', { id: 'hotelCity', placeholder: '城市，如 大阪' }),
        el('input', { id: 'hotelCheckin', type: 'date' }),
        el('input', { id: 'hotelCheckout', type: 'date' }),
        el('button', { class: 'btn btn-primary', onclick: searchHotelProviders }, '列出各家連結'),
      ]),
      el('div', { id: 'hotelResult' }),
    ]),
  ]));

  c.appendChild(panel('itinerary', [
    el('div', { class: 'card' }, [
      el('h3', {}, '智慧行程規劃'),
      el('p', { class: 'hint' }, '輸入出發地、目的地與天數，產生行程草案；若目的地或出發地是已收錄城市 (目前：台中、新北)，會額外附上精選景點/美食/休閒推薦。'),
      el('div', { class: 'form-row' }, [
        el('input', { id: 'tripFrom', placeholder: '出發地' }),
        el('input', { id: 'tripTo', placeholder: '目的地' }),
        el('input', { id: 'tripDays', type: 'number', value: 3, min: 1, max: 14 }),
        el('button', { class: 'btn btn-primary', onclick: generateItinerary }, '產生行程'),
      ]),
      el('div', { id: 'itineraryResult' }),
    ]),
  ]));

  c.appendChild(panel('places', renderPlacesPanel()));

  c.appendChild(panel('packing', [
    el('div', { class: 'card' }, [
      el('h3', {}, '🎒 行前打包清單'),
      el('p', { class: 'hint' }, '常用清單，跟旅程無關的通用版；下面「旅遊分帳」建立旅程後，也可以在旅程裡建立專屬的打包清單。'),
      el('div', { class: 'form-row' }, [
        el('select', { id: 'packingTemplate' }, [
          el('option', { value: '' }, '套用範本...'),
          el('option', { value: 'general' }, '通用'),
          el('option', { value: 'beach' }, '海島/沙灘'),
          el('option', { value: 'cold' }, '寒冷天氣'),
          el('option', { value: 'business' }, '商務出差'),
        ]),
        el('button', { class: 'btn btn-ghost', onclick: applyPackingTemplate }, '套用'),
      ]),
      el('div', { class: 'form-row', style: 'margin-top:8px' }, [
        el('input', { id: 'packingItem', placeholder: '要帶的東西，如：護照' }),
        el('input', { id: 'packingCategory', placeholder: '分類 (選填)，如：證件' }),
        el('button', { class: 'btn btn-primary', onclick: addPackingItem }, '新增'),
      ]),
      el('div', { id: 'packingList', style: 'margin-top:12px' }, el('div', { class: 'empty-state' }, '載入中...')),
    ]),
  ]));

  c.appendChild(panel('split', renderTripSplitPanel()));

  if (travelSubTab === 'train') loadFavoriteTrains();
  if (travelSubTab === 'places') { populatePlaceCityDropdowns(); loadPlacesBrowseList(); refreshPopularKeywordChips(); }
  if (travelSubTab === 'packing') loadPackingList();
  if (travelSubTab === 'split') loadTrips();
}

// ---------- 行前打包清單 ----------
async function applyPackingTemplate() {
  const type = $('#packingTemplate').value;
  if (!type) return;
  const res = await api(`/travel/packing/template/${type}`);
  for (const item of res.items) {
    await api('/travel/packing', { method: 'POST', body: { item, category: '範本' } });
  }
  showToast('已套用範本');
  loadPackingList();
}
async function addPackingItem() {
  const item = $('#packingItem').value.trim();
  if (!item) { showToast('請填寫項目'); return; }
  await api('/travel/packing', { method: 'POST', body: { item, category: $('#packingCategory').value.trim() || '其他' } });
  $('#packingItem').value = ''; $('#packingCategory').value = '';
  loadPackingList();
}
async function loadPackingList() {
  const box = $('#packingList');
  if (!box) return;
  try {
    const rows = await api('/travel/packing');
    box.innerHTML = '';
    if (!rows.length) { box.appendChild(el('div', { class: 'empty-state' }, '還沒有打包項目，套用範本或自行新增')); return; }
    const byCategory = {};
    rows.forEach((r) => { (byCategory[r.category || '其他'] = byCategory[r.category || '其他'] || []).push(r); });
    Object.entries(byCategory).forEach(([cat, items]) => {
      box.appendChild(el('div', { class: 'label', style: 'margin:10px 0 4px;font-weight:700' }, cat));
      items.forEach((r) => {
        box.appendChild(el('div', { class: 'coping-note-item' }, [
          el('label', { class: 'content', style: 'display:flex;align-items:center;gap:8px;cursor:pointer' }, [
            el('input', { type: 'checkbox', checked: !!r.checked, onchange: (e) => togglePackingItem(r.id, e.target.checked) }),
            el('span', { style: r.checked ? 'text-decoration:line-through;color:var(--flat-sub)' : '' }, r.item),
          ]),
          el('button', { class: 'del-btn', onclick: () => deletePackingItem(r.id) }, '✕'),
        ]));
      });
    });
  } catch (e) { box.innerHTML = ''; box.appendChild(el('div', { class: 'empty-state' }, '清單暫時無法取得')); }
}
async function togglePackingItem(id, checked) {
  await api(`/travel/packing/${id}`, { method: 'PUT', body: { checked } });
}
async function deletePackingItem(id) {
  await api(`/travel/packing/${id}`, { method: 'DELETE' });
  loadPackingList();
}

// ---------- 旅遊分帳 ----------
let currentTripId = null;
function renderTripSplitPanel() {
  return el('div', {}, [
    el('div', { class: 'card' }, [
      el('h3', {}, '💸 建立新旅程'),
      el('p', { class: 'hint' }, '記下這趟旅程有誰、誰墊了什麼，最後自動算出最少筆數的轉帳建議——不管是一人先墊全部、還是大家輪流出都可以。'),
      el('div', { class: 'form-row' }, [
        el('input', { id: 'tripName', placeholder: '旅程名稱，如：東京五日遊' }),
        el('select', { id: 'tripCurrency' }, ['TWD', 'JPY', 'USD', 'KRW', 'EUR', 'HKD'].map((c) => el('option', { value: c }, c))),
        el('input', { id: 'tripParticipants', placeholder: '參與者，用逗號分隔，如：我,小明,小華' }),
      ]),
      el('button', { class: 'btn btn-primary', style: 'margin-top:10px', onclick: addTrip }, '建立旅程'),
    ]),
    el('div', { class: 'card' }, [
      el('h3', {}, '📋 旅程列表'),
      el('div', { id: 'tripList' }, el('div', { class: 'empty-state' }, '載入中...')),
    ]),
    el('div', { id: 'tripDetail' }),
  ]);
}

async function addTrip() {
  const name = $('#tripName').value.trim();
  if (!name) { showToast('請填寫旅程名稱'); return; }
  const names = $('#tripParticipants').value.split(',').map((s) => s.trim()).filter(Boolean);
  await api('/travel/trips', { method: 'POST', body: { name, baseCurrency: $('#tripCurrency').value, participantNames: names.length ? names : ['我'] } });
  $('#tripName').value = ''; $('#tripParticipants').value = '';
  showToast('已建立旅程');
  loadTrips();
}

async function loadTrips() {
  const box = $('#tripList');
  if (!box) return;
  try {
    const rows = await api('/travel/trips');
    box.innerHTML = '';
    if (!rows.length) { box.appendChild(el('div', { class: 'empty-state' }, '還沒有建立任何旅程')); return; }
    rows.forEach((t) => {
      box.appendChild(el('div', { class: 'coping-note-item', style: 'cursor:pointer', onclick: () => openTripDetail(t.id) }, [
        el('div', { class: 'content' }, [
          `${t.name} `,
          el('span', { class: `badge ${t.settled ? 'badge-neutral' : 'badge-positive'}` }, t.settled ? '已結清' : '進行中'),
          el('span', { class: 'hint', style: 'margin:0;margin-left:8px' }, t.base_currency),
        ]),
        el('button', { class: 'del-btn', onclick: (e) => { e.stopPropagation(); deleteTrip(t.id); } }, '✕'),
      ]));
    });
    if (currentTripId && rows.some((t) => t.id === currentTripId)) openTripDetail(currentTripId);
  } catch (e) { box.innerHTML = ''; box.appendChild(el('div', { class: 'empty-state' }, '旅程清單暫時無法取得')); }
}
async function deleteTrip(id) {
  await api(`/travel/trips/${id}`, { method: 'DELETE' });
  if (currentTripId === id) { currentTripId = null; $('#tripDetail').innerHTML = ''; }
  loadTrips();
}

async function openTripDetail(tripId) {
  currentTripId = tripId;
  const box = $('#tripDetail');
  box.innerHTML = '';
  const [participants, expenses, settlement] = await Promise.all([
    api(`/travel/trips/${tripId}/participants`),
    api(`/travel/trips/${tripId}/expenses`),
    api(`/travel/trips/${tripId}/settlement`),
  ]);

  box.appendChild(el('div', { class: 'card' }, [
    el('h3', {}, '➕ 新增花費'),
    el('div', { class: 'form-row' }, [
      el('select', { id: 'expPayer' }, participants.map((p) => el('option', { value: p.id }, p.name))),
      el('input', { id: 'expDesc', placeholder: '花費說明，如：晚餐' }),
      el('input', { id: 'expAmount', type: 'number', placeholder: '金額' }),
    ]),
    el('div', { class: 'form-row', style: 'margin-top:8px' }, [
      el('input', { id: 'expCurrency', placeholder: '幣別，如 JPY (預設同旅程幣別)' }),
      el('input', { id: 'expRate', type: 'number', placeholder: '匯率換算 (1 單位 = 多少旅程幣別，預設1)' }),
      el('input', { id: 'expDate', type: 'date', value: todayStr() }),
    ]),
    el('p', { class: 'hint', style: 'margin-top:8px' }, '預設由所有參與者均分，之後可以擴充自訂分攤比例。'),
    el('button', { class: 'btn btn-primary', style: 'margin-top:6px', onclick: () => addTripExpense(tripId) }, '新增花費'),
    el('div', { style: 'margin-top:10px' }, [
      el('input', { id: 'newParticipantName', placeholder: '新增參與者名字' }),
      el('button', { class: 'btn btn-ghost', onclick: () => addTripParticipant(tripId) }, '加入旅伴'),
    ]),
  ]));

  box.appendChild(el('div', { class: 'card' }, [
    el('h3', {}, '⚖️ 結算結果'),
    el('div', { class: 'stat-strip' }, settlement.balances.map((b) => el('div', { class: 'stat-item' }, [
      el('div', { class: 'k' }, b.name),
      el('div', { class: 'v num', style: b.net > 0 ? 'color:var(--good)' : b.net < 0 ? 'color:var(--critical)' : '' }, `${b.net > 0 ? '+' : ''}${fmtCurrency(b.net, settlement.baseCurrency)}`),
    ]))),
    el('p', { class: 'hint', style: 'margin-top:8px' }, settlement.disclaimer),
    settlement.transfers.length
      ? el('div', {}, settlement.transfers.map((t) => el('div', { class: 'mood-signal-item' }, `💰 ${t.from} → ${t.to}：${fmtCurrency(t.amount, settlement.baseCurrency)}`)))
      : el('div', { class: 'empty-state' }, '目前帳務已經打平，不需要轉帳'),
    !settlement.transfers.length && !expenses.length ? null : el('button', { class: 'btn btn-ghost', style: 'margin-top:8px', onclick: () => markTripSettled(tripId) }, '標記這趟旅程已結清'),
  ]));

  box.appendChild(el('div', { class: 'card' }, [
    el('h3', {}, '📜 花費紀錄'),
    !expenses.length
      ? el('div', { class: 'empty-state' }, '還沒有花費紀錄')
      : el('div', {}, expenses.map((e) => el('div', { class: 'coping-note-item' }, [
          el('div', { class: 'content' }, `${e.expense_date || ''} · ${e.description || '花費'} · ${e.payer_name} 墊付 ${fmtCurrency(e.amount, e.currency)}${e.exchange_rate !== 1 ? ` (≈${fmtCurrency(Math.round(e.amount * e.exchange_rate), settlement.baseCurrency)})` : ''}`),
          el('button', { class: 'del-btn', onclick: () => deleteTripExpense(tripId, e.id) }, '✕'),
        ]))),
  ]));
}

async function addTripParticipant(tripId) {
  const name = $('#newParticipantName').value.trim();
  if (!name) return;
  await api(`/travel/trips/${tripId}/participants`, { method: 'POST', body: { name } });
  $('#newParticipantName').value = '';
  openTripDetail(tripId);
}

async function addTripExpense(tripId) {
  const payerId = Number($('#expPayer').value);
  const amount = Number($('#expAmount').value);
  if (!payerId || !amount || amount <= 0) { showToast('請填寫墊款人與金額'); return; }
  try {
    await api(`/travel/trips/${tripId}/expenses`, {
      method: 'POST',
      body: {
        payerId, description: $('#expDesc').value.trim(), amount,
        currency: $('#expCurrency').value.trim() || undefined,
        exchangeRate: Number($('#expRate').value) || 1,
        expenseDate: $('#expDate').value,
      },
    });
    showToast('已新增花費');
    openTripDetail(tripId);
  } catch (e) { showToast('新增失敗：' + e.message); }
}
async function deleteTripExpense(tripId, expenseId) {
  await api(`/travel/trips/${tripId}/expenses/${expenseId}`, { method: 'DELETE' });
  openTripDetail(tripId);
}
async function markTripSettled(tripId) {
  await api(`/travel/trips/${tripId}`, { method: 'PUT', body: { settled: true } });
  showToast('已標記為結清');
  loadTrips();
}

const PROVIDER_COLORS = ['--series-blue', '--series-orange', '--series-aqua', '--series-violet', '--series-magenta', '--series-yellow'];
function providerList(providers) {
  return el('div', {}, providers.map((p, i) => el('a', { href: p.url, target: '_blank', rel: 'noopener', class: 'provider-item' }, [
    el('div', { class: 'p-left' }, [
      el('div', { class: 'p-avatar', style: `background:${cssVar(PROVIDER_COLORS[i % PROVIDER_COLORS.length])}` }, p.name.replace(/^[^一-龥A-Za-z]*/, '').slice(0, 1).toUpperCase()),
      el('div', {}, [
        el('div', { class: 'p-name' }, [
          p.name,
          el('span', { class: p.prefill ? 'tag tag-fill' : 'tag tag-manual' }, p.prefill ? '已帶入條件' : '需自行輸入'),
        ]),
        el('div', { class: 'p-note' }, p.note),
      ]),
    ]),
    el('span', { class: 'p-go' }, '前往 →'),
  ])));
}

async function searchTrain() {
  const mode = $('#trainMode').value;
  const station = $('#stationName').value.trim();
  const to = $('#stationTo').value.trim();
  const date = $('#trainDate').value;
  const timeFrom = $('#timeFrom').value;
  const timeTo = $('#timeTo').value;
  const trainNo = $('#trainNoSearch').value.trim();
  const resultBox = $('#trainResult');
  if (!station) return;
  resultBox.innerHTML = '查詢中...';
  try {
    const qs = new URLSearchParams({ station, to, date, timeFrom, timeTo, trainNo }).toString();
    const data = await api(`/travel/train/${mode}/board?${qs}`);
    resultBox.innerHTML = '';
    if (data.isDemo) resultBox.appendChild(el('div', { class: 'disclaimer' }, data.notice));
    if (data.trains) {
      if (!data.trains.length) { resultBox.appendChild(el('div', { class: 'empty-state' }, '這個時間範圍沒有符合的車次')); return; }
      const rows = data.trains.map((t) => el('tr', {}, [
        el('td', {}, t.trainNo),
        el('td', {}, t.departure),
        el('td', {}, t.arrival || '--'),
        el('td', {}, t.fare != null ? fmtMoney(t.fare) : '--'),
        el('td', {}, t.status),
        el('td', {}, el('button', { class: 'btn btn-ghost', onclick: () => favoriteTrain(mode, t, station, to) }, '⭐ 收藏')),
      ]));
      resultBox.appendChild(el('table', {}, [
        el('thead', {}, el('tr', {}, [el('th', {}, '車次'), el('th', {}, '出發'), el('th', {}, '到達'), el('th', {}, '票價(估)'), el('th', {}, '狀態'), el('th', {}, '')])),
        el('tbody', {}, rows),
      ]));
    } else if (data.raw) {
      resultBox.appendChild(el('pre', { style: 'font-size:11px;white-space:pre-wrap' }, JSON.stringify(data.raw, null, 2).slice(0, 3000)));
    }
  } catch (e) { resultBox.innerHTML = `查詢失敗: ${e.message}`; }
}

async function favoriteTrain(mode, train, fromStation, toStation) {
  try {
    await api('/travel/train/favorites', {
      method: 'POST',
      body: { mode, trainNo: train.trainNo, fromStation, toStation, departureTime: train.departure },
    });
    showToast('已收藏車次');
    loadFavoriteTrains();
  } catch (e) { showToast('收藏失敗: ' + e.message); }
}

async function loadFavoriteTrains() {
  const area = $('#favoriteTrainsArea');
  if (!area) return;
  try {
    const rows = await api('/travel/train/favorites');
    area.innerHTML = '';
    if (!rows.length) { area.appendChild(el('div', { class: 'empty-state' }, '還沒有收藏的車次')); return; }
    rows.forEach((r) => {
      const dateInputId = `favTrainDate-${r.id}`;
      area.appendChild(el('div', { style: 'display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid var(--grid-line);flex-wrap:wrap;gap:8px' }, [
        el('div', { style: 'font-size:13px' }, `${r.mode === 'THSR' ? '高鐵' : '台鐵'} ${r.train_no} · ${r.from_station}${r.to_station ? ' → ' + r.to_station : ''} · ${r.departure_time || ''}`),
        el('div', { style: 'display:flex;gap:6px;align-items:center' }, [
          el('input', { id: dateInputId, type: 'date', style: 'width:132px;padding:6px 8px;font-size:12px' }),
          el('button', { class: 'btn btn-ghost', style: 'font-size:12px', onclick: () => addFavoriteTrainToCalendar(r, dateInputId) }, '📅 加入行事曆'),
          el('button', { class: 'btn btn-ghost', onclick: () => deleteFavoriteTrain(r.id) }, '移除'),
        ]),
      ]));
    });
  } catch (e) { area.innerHTML = ''; }
}
async function deleteFavoriteTrain(id) {
  await api(`/travel/train/favorites/${id}`, { method: 'DELETE' });
  loadFavoriteTrains();
}
async function addFavoriteTrainToCalendar(r, dateInputId) {
  const date = $(`#${dateInputId}`).value;
  if (!date) { showToast('請先選擇日期'); return; }
  try {
    await api('/calendar', {
      method: 'POST',
      body: {
        event_date: date,
        start_time: r.departure_time || null,
        title: `🚄 ${r.mode === 'THSR' ? '高鐵' : '台鐵'} ${r.train_no} ${r.from_station}${r.to_station ? '→' + r.to_station : ''}`,
        category: 'travel',
      },
    });
    showToast('已加入行事曆');
  } catch (e) { showToast('加入失敗: ' + e.message); }
}

async function searchFlightProviders() {
  const from = $('#flyFrom').value.trim(), to = $('#flyTo').value.trim(), date = $('#flyDate').value;
  const box = $('#flightResult');
  if (!from || !to) return;
  box.innerHTML = '載入中...';
  try {
    const data = await api(`/travel/flights/providers?from=${encodeURIComponent(from)}&to=${encodeURIComponent(to)}&date=${date || ''}`);
    box.innerHTML = '';
    box.appendChild(providerList(data.providers));
  } catch (e) { box.innerHTML = `載入失敗: ${e.message}`; }
}

async function searchHotelProviders() {
  const city = $('#hotelCity').value.trim();
  const checkin = $('#hotelCheckin').value, checkout = $('#hotelCheckout').value;
  const box = $('#hotelResult');
  if (!city) return;
  box.innerHTML = '載入中...';
  try {
    const data = await api(`/travel/hotels/providers?city=${encodeURIComponent(city)}&checkin=${checkin || ''}&checkout=${checkout || ''}`);
    box.innerHTML = '';
    box.appendChild(providerList(data.providers));
  } catch (e) { box.innerHTML = `載入失敗: ${e.message}`; }
}

async function generateItinerary() {
  const from = $('#tripFrom').value.trim(), to = $('#tripTo').value.trim(), days = $('#tripDays').value;
  const box = $('#itineraryResult');
  if (!from || !to) return;
  box.innerHTML = '規劃中...';
  try {
    const data = await api('/travel/itinerary', { method: 'POST', body: { from, to, days } });
    box.innerHTML = '';
    box.appendChild(el('p', { class: 'hint' }, data.disclaimer));
    data.plan.forEach((d) => {
      box.appendChild(el('div', { style: 'margin-bottom:10px' }, [el('b', {}, d.title), el('div', { style: 'font-size:13px;color:var(--text-secondary)' }, d.suggestion)]));
    });
    if (data.curated) {
      box.appendChild(el('div', { style: 'margin-top:14px;padding-top:14px;border-top:1px solid var(--grid-line)' }, [
        el('div', { style: 'font-weight:700;margin-bottom:4px' }, `📍 ${data.curated.city} 精選推薦`),
        el('p', { class: 'hint' }, data.curated.sourceNote),
      ]));
      Object.entries(data.curated.categories).forEach(([cat, items]) => {
        const wrap = el('div', { style: 'margin-bottom:10px' }, [el('div', { style: 'font-size:13px;font-weight:600;margin-bottom:4px' }, cat)]);
        items.forEach((it) => {
          wrap.appendChild(el('div', { style: 'font-size:13px;margin-bottom:4px' }, [
            el('b', {}, it.name), el('span', { style: 'color:var(--text-muted)' }, ` — ${it.note}`),
          ]));
        });
        box.appendChild(wrap);
      });
    }
  } catch (e) { box.innerHTML = `規劃失敗: ${e.message}`; }
}

// ===================== 地點資料庫 + 臨時揪一波 (v0.55) =====================
// 設計理念：這是全 app 第一個「所有登入使用者共同看得到、共同貢獻」的公開資料 (不像其他
// 功能是私人資料或是伴侶連結才共享)。任何人都能新增/評分/檢舉，但只有新增的人能編輯/刪除，
// 避免公開資料被亂改。核心「臨時揪一波」流程完全是後端 SQL 篩選+排序+洗牌，不會呼叫內建 AI。
// v0.61：這份清單原本叫「心情」，但內容 (放鬆/美食/戶外/購物/拍照/夜景) 其實是地點的
// 「主題/情境」分類，跟使用者當下的心情狀態完全無關——沿用「心情」這個名字容易讓人誤會
// 這裡在問「你現在心情好不好」，所以介面文字全部改稱「主題」。變數名稱維持 PLACE_MOOD_TAGS
// /mood_tags 沒有跟著改，是因為後端資料庫欄位 (mood_tags) 牽動的地方太多，改名稱不影響
// 使用者體驗、只影響程式碼內部命名，優先度排在後面，先把使用者看得到的文字改對。
const PLACE_MOOD_TAGS = [
  { key: 'relax', label: '放鬆' },
  { key: 'food', label: '美食' },
  { key: 'outdoor', label: '戶外' },
  { key: 'shopping', label: '購物' },
  { key: 'photo', label: '拍照' },
  { key: 'night_view', label: '夜景' },
];
const PLACE_TRANSPORT_TAGS = [
  { key: 'walk', label: '步行' },
  { key: 'drive', label: '開車' },
  { key: 'bike', label: '騎車' },
];
// v0.61：使用者反應「主題」這 6 個固定分類太少、太粗，希望打關鍵字就能直接改變推薦內容，
// 不要被侷限在預先分好的分類裡。這裡是一份「常見關鍵字」快選清單，點了會直接把文字填進
// 關鍵字搜尋欄位，純粹省打字，跟 PLACE_MOOD_TAGS 那組結構化分類是兩套獨立機制——關鍵字
// 是自由文字比對地點名稱+介紹，主題分類是資料庫預先分類好的 mood_tags 欄位，兩個可以同時用
// (AND 條件)，例如選「主題=戶外」+ 打「寵物」，同時縮小範圍。
const PLACE_POPULAR_KEYWORDS = ['寵物友善', '親子', '免費', '老街', '溫泉', '打卡', '無障礙', '古蹟', '瀑布', '夜市'];
const PLACE_SOURCE_LABELS = { curated: '📌 精選', gov: '🏛️ 政府開放資料', user: '🙋 使用者新增' };
let placesState = { suggestExclude: [], lastSuggestCity: '', addMoodTags: new Set(), addTransportTags: new Set() };

function placeMoodLabel(tag) { const t = PLACE_MOOD_TAGS.find((x) => x.key === tag); return t ? t.label : tag; }
function placeTransportLabel(tag) { const t = PLACE_TRANSPORT_TAGS.find((x) => x.key === tag); return t ? t.label : tag; }
function placeRatingLabel(p) {
  if (p.ratingEnough) return `⭐ ${p.avgRating} (${p.ratingCount} 則評分)`;
  if (p.ratingCount) return `評分還太少，尚不顯示平均分 (${p.ratingCount} 則)`;
  return '尚無評分';
}

// v0.61：熱門關鍵字快選 chip，點了直接把文字填進對應的關鍵字輸入框，並立刻觸發查詢——
// 純粹省得使用者要自己想「要打什麼關鍵字」，跟下面 populatePlaceDistrictDropdown() 那種
// 「兩處共用同一支函式」的設計一樣，suggest/browse 兩處都共用這個 renderer。
// rowId 給 refreshPopularKeywordChips() (v0.62) 之後用真實統計資料整排換掉用的錨點。
function placeKeywordChipsRow(rowId, inputId, onSearch, keywords) {
  return el('div', { id: rowId, style: 'display:flex;gap:6px;flex-wrap:wrap;margin-top:6px' },
    (keywords || PLACE_POPULAR_KEYWORDS).map((kw) => el('span', {
      class: 'mood-tag-chip',
      style: 'cursor:pointer',
      onclick: () => { $(`#${inputId}`).value = kw; onSearch(); },
    }, kw))
  );
}

// v0.62：使用者反應「熱門關鍵字」不該是我寫死的固定清單，應該根據大家實際搜過什麼關鍵字
// 動態產生。頁面剛載入時先用上面寫死的 PLACE_POPULAR_KEYWORDS 墊著 (見 renderPlacesPanel())，
// 避免畫面空白；這支函式非同步抓真實統計資料回來後，把真實資料排在前面、寫死清單裡沒有
// 重複的補在後面 (湊到最多 10 個)，整排換掉。GET /places/popular-keywords 剛上線時可能還
// 沒有任何搜尋紀錄 (回傳空陣列)，這時候就完全不換，維持原本的寫死清單，不會讓畫面突然
// 變空——這也是為什麼採用「合併」而不是「取代」的設計。
async function refreshPopularKeywordChips() {
  let popular = [];
  try { popular = await api('/places/popular-keywords'); } catch (e) { return; }
  if (!popular.length) return;
  const merged = popular.map((r) => r.keyword);
  for (const kw of PLACE_POPULAR_KEYWORDS) {
    if (merged.length >= 10) break;
    if (!merged.includes(kw)) merged.push(kw);
  }
  const targets = [
    { rowId: 'placeSuggestKeywordChips', inputId: 'placeSuggestKeyword', onSearch: () => listPlacesForSuggestFilters() },
    { rowId: 'placeBrowseKeywordChips', inputId: 'placeBrowseKeyword', onSearch: () => loadPlacesBrowseList() },
  ];
  targets.forEach(({ rowId, inputId, onSearch }) => {
    const row = $(`#${rowId}`);
    if (!row) return;
    row.innerHTML = '';
    merged.forEach((kw) => row.appendChild(el('span', {
      class: 'mood-tag-chip',
      style: 'cursor:pointer',
      onclick: () => { $(`#${inputId}`).value = kw; onSearch(); },
    }, kw)));
  });
}

function renderPlacesPanel() {
  return [
    el('div', { class: 'card' }, [
      el('h3', {}, '📍 臨時揪一波'),
      el('p', { class: 'hint' }, '出遊前或臨時不知道去哪的時候用：選城市 (縣市範圍太大可以再選區縮小範圍) + 主題/交通方式，也可以直接打關鍵字 (地點名稱、介紹文字裡有的字都比對得到，不限於下面的主題分類)。「幫我選 3 個」會隨機抽，不滿意按「重抽」會避開剛剛抽過的；不想抽的話按「列出全部符合的地點」直接看完整清單，自己挑。'),
      el('div', { class: 'form-row' }, [
        el('select', { id: 'placeSuggestCity', onchange: () => populatePlaceDistrictDropdown('placeSuggestCity', 'placeSuggestDistrict') }, [el('option', { value: '' }, '請選擇城市...')]),
        el('select', { id: 'placeSuggestDistrict' }, [el('option', { value: '' }, '不限地區')]),
      ]),
      el('div', { class: 'form-row' }, [
        el('select', { id: 'placeSuggestMood' }, [
          el('option', { value: '' }, '不限主題'),
          ...PLACE_MOOD_TAGS.map((t) => el('option', { value: t.key }, t.label)),
        ]),
        el('select', { id: 'placeSuggestTransport' }, [
          el('option', { value: '' }, '不限交通'),
          ...PLACE_TRANSPORT_TAGS.map((t) => el('option', { value: t.key }, t.label)),
        ]),
      ]),
      el('div', { class: 'form-row' }, [
        el('input', { id: 'placeSuggestKeyword', type: 'text', placeholder: '想找什麼？打關鍵字 (例如：貓咪、免費停車、落羽松)' }),
        el('input', { id: 'placeSuggestMaxDuration', type: 'number', min: 0, placeholder: '停留時間上限(分鐘，選填)' }),
      ]),
      placeKeywordChipsRow('placeSuggestKeywordChips', 'placeSuggestKeyword', () => listPlacesForSuggestFilters()),
      el('div', { style: 'display:flex;gap:8px;flex-wrap:wrap;margin-top:10px' }, [
        el('button', { class: 'btn btn-primary', onclick: () => quickSuggestPlaces(false) }, '🎲 幫我選 3 個'),
        el('button', { class: 'btn btn-ghost', onclick: listPlacesForSuggestFilters }, '📋 列出全部符合的地點'),
      ]),
      el('div', { id: 'placesSuggestResult', style: 'margin-top:12px' }),
    ]),
    el('div', { class: 'card' }, [
      el('div', { style: 'display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap' }, [
        el('h3', {}, '🗂️ 地點資料庫'),
        el('button', { class: 'btn btn-ghost', onclick: openAddPlaceSheet }, '➕ 新增地點'),
      ]),
      el('p', { class: 'hint' }, '大家一起維護的公開地點清單：任何人都能新增/評分/檢舉已歇業或資訊過時的地點；只有新增的人可以編輯或刪除。新增地點 +3 點，第一次評分 +1 點。'),
      el('div', { class: 'form-row' }, [
        el('select', { id: 'placeBrowseCity', onchange: () => { populatePlaceDistrictDropdown('placeBrowseCity', 'placeBrowseDistrict'); loadPlacesBrowseList(); } }, [el('option', { value: '' }, '全部城市')]),
        el('select', { id: 'placeBrowseDistrict', onchange: loadPlacesBrowseList }, [el('option', { value: '' }, '不限地區')]),
      ]),
      el('div', { class: 'form-row' }, [
        el('select', { id: 'placeBrowseMood' }, [
          el('option', { value: '' }, '不限主題'),
          ...PLACE_MOOD_TAGS.map((t) => el('option', { value: t.key }, t.label)),
        ]),
        el('select', { id: 'placeBrowseTransport' }, [
          el('option', { value: '' }, '不限交通'),
          ...PLACE_TRANSPORT_TAGS.map((t) => el('option', { value: t.key }, t.label)),
        ]),
      ]),
      el('div', { class: 'form-row' }, [
        el('input', { id: 'placeBrowseKeyword', type: 'text', placeholder: '想找什麼？打關鍵字 (例如：貓咪、免費停車、落羽松)' }),
      ]),
      placeKeywordChipsRow('placeBrowseKeywordChips', 'placeBrowseKeyword', () => loadPlacesBrowseList()),
      el('div', { style: 'display:flex;gap:8px;flex-wrap:wrap;margin-top:10px' }, [
        el('button', { class: 'btn btn-ghost', onclick: loadPlacesBrowseList }, '🔍 查詢'),
      ]),
      el('div', { id: 'placesBrowseList', style: 'margin-top:12px' }, el('div', { class: 'empty-state' }, '載入中...')),
    ]),
  ];
}

// 城市下拉選單資料來源：改用真的存在於資料庫的城市清單，而不是讓使用者手打城市名稱
// (使用者才反應「選地區都沒有內容」——查了才發現是打字打成「台北市」跟資料庫存的「台北」
// 對不上，兩邊都改成同一份清單，就不會再打錯字或打了資料庫裡沒有的寫法就查到空的)。
async function populatePlaceCityDropdowns() {
  let cities = [];
  try { cities = await api('/places/cities'); } catch (e) { showToast('城市清單載入失敗：' + e.message); }
  const suggestSel = $('#placeSuggestCity');
  const browseSel = $('#placeBrowseCity');
  if (suggestSel) {
    const prev = suggestSel.value;
    suggestSel.innerHTML = '';
    suggestSel.appendChild(el('option', { value: '' }, cities.length ? '請選擇城市...' : '目前資料庫還沒有任何城市'));
    cities.forEach((c) => suggestSel.appendChild(el('option', { value: c.city }, `${c.city} (${c.count})`)));
    if (cities.some((c) => c.city === prev)) suggestSel.value = prev;
  }
  if (browseSel) {
    const prev = browseSel.value;
    browseSel.innerHTML = '';
    browseSel.appendChild(el('option', { value: '' }, '全部城市'));
    cities.forEach((c) => browseSel.appendChild(el('option', { value: c.city }, `${c.city} (${c.count})`)));
    if (cities.some((c) => c.city === prev)) browseSel.value = prev;
  }
  // 城市清單重新整理完後，如果剛好還記得之前選的城市 (select 的 value 沒被清掉)，順便把
  // 對應的「區」清單也重新載入一次，不然畫面重繪後區的下拉選單會變回「不限地區」但城市
  // 選單卻還顯示著原本選的城市，兩個欄位看起來不同步。
  if (suggestSel && suggestSel.value) await populatePlaceDistrictDropdown('placeSuggestCity', 'placeSuggestDistrict');
  if (browseSel && browseSel.value) await populatePlaceDistrictDropdown('placeBrowseCity', 'placeBrowseDistrict');
}

// v0.60：城市範圍太大 (新北市單一縣市 600+ 筆) 時，光靠城市篩選還是太多，使用者要求能
// 再選「區」縮小範圍。這個下拉選單的選項是動態的 (依選到的城市而變)，所以每次城市欄位
// 改變時都要重新打一次 API，跟 populatePlaceCityDropdowns() 那種「開頁就抓一次固定清單」
// 不一樣。citySelectId/districtSelectId 讓「臨時揪一波」跟「地點資料庫」兩處共用同一支
// 函式，不用寫兩份幾乎一樣的邏輯。
async function populatePlaceDistrictDropdown(citySelectId, districtSelectId) {
  const citySel = $(`#${citySelectId}`);
  const districtSel = $(`#${districtSelectId}`);
  if (!citySel || !districtSel) return;
  const city = citySel.value;
  const prev = districtSel.value;
  if (!city) {
    districtSel.innerHTML = '';
    districtSel.appendChild(el('option', { value: '' }, '不限地區'));
    return;
  }
  let districts = [];
  try { districts = await api(`/places/districts?city=${encodeURIComponent(city)}`); } catch (e) { showToast('地區清單載入失敗：' + e.message); }
  districtSel.innerHTML = '';
  districtSel.appendChild(el('option', { value: '' }, '不限地區'));
  districts.forEach((d) => districtSel.appendChild(el('option', { value: d.district }, `${d.district} (${d.count})`)));
  if (districts.some((d) => d.district === prev)) districtSel.value = prev;
}

async function quickSuggestPlaces(isRedraw) {
  const box = $('#placesSuggestResult');
  const city = $('#placeSuggestCity').value;
  if (!city) { box.innerHTML = ''; box.appendChild(el('div', { class: 'empty-state' }, '請先選擇城市')); return; }
  const district = $('#placeSuggestDistrict').value;
  const mood = $('#placeSuggestMood').value;
  const transport = $('#placeSuggestTransport').value;
  const keyword = $('#placeSuggestKeyword').value.trim();
  const maxDuration = $('#placeSuggestMaxDuration').value.trim();
  // 城市/區/關鍵字任何一個改變都要重置「已抽過」的排除清單，不然條件變了還在避開上一組條件
  // 抽過的地點 id，沒有意義；用 city+district+keyword 組成一個 key 一起比對。
  const suggestScopeKey = `${city}|${district}|${keyword}`;
  if (!isRedraw || placesState.lastSuggestCity !== suggestScopeKey) placesState.suggestExclude = [];
  placesState.lastSuggestCity = suggestScopeKey;

  const params = new URLSearchParams({ city, count: '3' });
  if (district) params.set('district', district);
  if (mood) params.set('mood', mood);
  if (transport) params.set('transport', transport);
  if (keyword) params.set('keyword', keyword);
  if (maxDuration) params.set('maxDuration', maxDuration);
  if (placesState.suggestExclude.length) params.set('exclude', placesState.suggestExclude.join(','));

  box.innerHTML = '';
  box.appendChild(skeletonLines(3));
  try {
    const data = await api(`/places/suggest/route?${params.toString()}`);
    box.innerHTML = '';
    if (!data.route.length) {
      box.appendChild(el('div', { class: 'empty-state' }, '這個城市還沒有符合條件的地點，先在下面「地點資料庫」新增幾個吧'));
      return;
    }
    placesState.suggestExclude = Array.from(new Set([...placesState.suggestExclude, ...data.route.map((p) => p.id)]));
    data.route.forEach((p) => box.appendChild(placeResultCard(p, keyword)));
    box.appendChild(el('div', { class: 'form-row', style: 'margin-top:10px' }, [
      el('button', { class: 'btn btn-ghost', onclick: () => quickSuggestPlaces(true) }, '🔄 不滿意，重抽'),
      el('span', { class: 'hint', style: 'align-self:center' }, `共 ${data.totalCandidates} 個候選地點`),
    ]));
  } catch (e) { box.innerHTML = ''; box.appendChild(el('div', { class: 'empty-state' }, `查詢失敗: ${e.message}`)); }
}

// v0.60：使用者明確表示「不想抽，想直接看」——跟 quickSuggestPlaces() 讀一樣的篩選條件
// (城市/區/主題/交通/關鍵字/停留時間上限)，但改叫 GET /places (跟「地點資料庫」共用的完整
// 清單 API，本來就支援這些 query 參數) 並依評分排序全部列出，而不是隨機抽 3 個。
async function listPlacesForSuggestFilters() {
  const box = $('#placesSuggestResult');
  const city = $('#placeSuggestCity').value;
  if (!city) { box.innerHTML = ''; box.appendChild(el('div', { class: 'empty-state' }, '請先選擇城市')); return; }
  const district = $('#placeSuggestDistrict').value;
  const mood = $('#placeSuggestMood').value;
  const transport = $('#placeSuggestTransport').value;
  const keyword = $('#placeSuggestKeyword').value.trim();
  const maxDuration = $('#placeSuggestMaxDuration').value.trim();

  const params = new URLSearchParams({ city, sort: 'rating' });
  if (district) params.set('district', district);
  if (mood) params.set('mood', mood);
  if (transport) params.set('transport', transport);
  if (keyword) params.set('keyword', keyword);
  if (maxDuration) params.set('maxDuration', maxDuration);

  box.innerHTML = '';
  box.appendChild(skeletonLines(3));
  try {
    const places = await api(`/places?${params.toString()}`);
    box.innerHTML = '';
    if (!places.length) {
      box.appendChild(el('div', { class: 'empty-state' }, '這個城市還沒有符合條件的地點，先在下面「地點資料庫」新增幾個吧'));
      return;
    }
    box.appendChild(el('div', { class: 'hint', style: 'margin-bottom:6px' }, `共 ${places.length} 個符合條件的地點，依評分排序`));
    places.forEach((p) => box.appendChild(placeResultCard(p, keyword)));
  } catch (e) { box.innerHTML = ''; box.appendChild(el('div', { class: 'empty-state' }, `查詢失敗: ${e.message}`)); }
}

// v0.62：關鍵字命中的地方要標出來，不然使用者搜尋「老街」卻抽到「十分瀑布公園」這種
// 「名稱沒有、介紹文字裡才有」的地點時，完全看不出來為什麼被推薦，會覺得莫名其妙、不信任
// 這個功能。這個函式把 text 裡符合 keyword 的部分包成 <mark>，其餘部分維持純文字，回傳一個
// 可以直接塞進 el() children 的陣列 (el() 本來就支援文字+DOM node 混合的陣列，見 el() 定義)。
// 大小寫/半形全形不特別處理，跟後端 LIKE 比對的邏輯保持一致 (子字串完全比對)。
function highlightKeyword(text, keyword) {
  const str = String(text || '');
  const kw = String(keyword || '').trim();
  if (!kw || !str.includes(kw)) return [str];
  const parts = [];
  let cursor = 0;
  let i = str.indexOf(kw);
  while (i !== -1) {
    if (i > cursor) parts.push(str.slice(cursor, i));
    parts.push(el('mark', { class: 'keyword-highlight' }, str.slice(i, i + kw.length)));
    cursor = i + kw.length;
    i = str.indexOf(kw, cursor);
  }
  if (cursor < str.length) parts.push(str.slice(cursor));
  return parts;
}

function placeMetaLine(p) {
  const parts = [];
  if (p.moodTags.length) parts.push(p.moodTags.map(placeMoodLabel).join('/'));
  if (p.transportTags.length) parts.push(p.transportTags.map(placeTransportLabel).join('/'));
  if (p.visit_duration_min) parts.push(`約 ${p.visit_duration_min} 分鐘`);
  return parts.join(' · ');
}

function placeResultCard(p, keyword) {
  return el('div', { class: 'card', style: 'margin-bottom:8px;padding:12px' }, [
    el('div', { style: 'display:flex;justify-content:space-between;align-items:flex-start;gap:8px' }, [
      el('div', {}, [
        el('div', { style: 'font-weight:700' }, highlightKeyword(p.name, keyword)),
        el('div', { class: 'hint' }, [p.city, p.district].filter(Boolean).join(' ')),
      ]),
      el('div', { style: 'text-align:right;font-size:12.5px;color:var(--text-muted)' }, placeRatingLabel(p)),
    ]),
    placeMetaLine(p) ? el('div', { style: 'margin-top:6px;font-size:12.5px;color:var(--text-muted)' }, placeMetaLine(p)) : null,
    p.note ? el('div', { style: 'margin-top:6px;font-size:13px' }, highlightKeyword(p.note, keyword)) : null,
  ]);
}

async function loadPlacesBrowseList() {
  const list = $('#placesBrowseList');
  const city = $('#placeBrowseCity').value;
  const district = $('#placeBrowseDistrict').value;
  const mood = $('#placeBrowseMood').value;
  const transport = $('#placeBrowseTransport').value;
  const keyword = $('#placeBrowseKeyword').value.trim();
  const params = new URLSearchParams({ sort: 'rating' });
  if (city) params.set('city', city);
  if (district) params.set('district', district);
  if (mood) params.set('mood', mood);
  if (transport) params.set('transport', transport);
  if (keyword) params.set('keyword', keyword);
  list.innerHTML = '';
  list.appendChild(skeletonLines(3));
  try {
    const places = await api(`/places?${params.toString()}`);
    list.innerHTML = '';
    if (!places.length) { list.appendChild(el('div', { class: 'empty-state' }, '目前沒有符合條件的地點，新增第一個吧')); return; }
    places.forEach((p) => list.appendChild(placeBrowseCard(p, keyword)));
  } catch (e) { list.innerHTML = ''; list.appendChild(el('div', { class: 'empty-state' }, `載入失敗: ${e.message}`)); }
}

// v0.80：評分／檢舉原本各自跳 prompt() (檢舉還先跳一個 confirm() 再跳一個 prompt()，
// 一次跳兩個彈窗)，改成點下去原地展開一個小表單 (跟願望清單「轉換成獎勵」同一套模式)。
let placeRatingOpenId = null;
let placeReportOpenId = null;

function placeBrowseCard(p, keyword) {
  const isMine = !!(state.user && p.created_by_user_id === state.user.id);
  return el('div', { class: 'card', style: 'margin-bottom:8px;padding:12px' }, [
    el('div', { style: 'display:flex;justify-content:space-between;align-items:flex-start;gap:8px' }, [
      el('div', {}, [
        el('div', { style: 'font-weight:700' }, highlightKeyword(p.name, keyword)),
        el('div', { class: 'hint' }, [p.city, p.district, p.address].filter(Boolean).join(' · ')),
      ]),
      el('div', { style: 'text-align:right;font-size:12.5px;color:var(--text-muted)' }, [
        el('div', {}, placeRatingLabel(p)),
        el('div', {}, PLACE_SOURCE_LABELS[p.source] || p.source),
      ]),
    ]),
    placeMetaLine(p) ? el('div', { style: 'margin-top:6px;font-size:12.5px;color:var(--text-muted)' }, placeMetaLine(p)) : null,
    p.hours_text ? el('div', { style: 'margin-top:4px;font-size:12.5px' }, `🕒 ${p.hours_text}`) : null,
    p.fee_info ? el('div', { style: 'font-size:12.5px' }, `💰 ${p.fee_info}`) : null,
    p.note ? el('div', { style: 'margin-top:6px;font-size:13px' }, highlightKeyword(p.note, keyword)) : null,
    p.status === 'needs_review' ? el('div', { style: 'margin-top:6px;font-size:12px;color:var(--danger,#e0554f)' }, '⚠️ 已被多人檢舉，待確認是否仍營業') : null,
    el('div', { class: 'form-row', style: 'margin-top:8px' }, [
      el('button', { class: 'btn btn-ghost', style: 'font-size:12px', onclick: () => { placeRatingOpenId = placeRatingOpenId === p.id ? null : p.id; placeReportOpenId = null; loadPlacesBrowseList(); } }, '⭐ 評分'),
      el('button', { class: 'btn btn-ghost', style: 'font-size:12px', onclick: () => { placeReportOpenId = placeReportOpenId === p.id ? null : p.id; placeRatingOpenId = null; loadPlacesBrowseList(); } }, '🚩 檢舉'),
      isMine ? el('button', { class: 'btn btn-ghost', style: 'font-size:12px', onclick: () => openEditPlaceSheet(p) }, '✏️ 編輯') : null,
      isMine ? el('button', { class: 'btn btn-ghost', style: 'font-size:12px', onclick: () => deletePlaceConfirm(p.id) }, '🗑️ 刪除') : null,
    ]),
    placeRatingOpenId === p.id
      ? el('div', { class: 'form-row', style: 'margin-top:8px;align-items:center' }, [
          el('span', { style: 'font-size:12px;color:var(--text-muted)' }, `幫「${p.name}」評分`),
          chipSelectEl({
            id: `placeRatingStars-${p.id}`, value: '',
            options: [1, 2, 3, 4, 5].map((n) => ({ value: String(n), label: '⭐'.repeat(n) })),
          }),
          el('button', { class: 'btn btn-ghost', style: 'font-size:12px', onclick: () => submitPlaceRating(p) }, '送出'),
          el('button', { class: 'btn btn-ghost', style: 'font-size:12px', onclick: () => { placeRatingOpenId = null; loadPlacesBrowseList(); } }, '取消'),
        ])
      : null,
    placeReportOpenId === p.id
      ? el('div', { style: 'margin-top:8px' }, [
          el('p', { class: 'hint', style: 'margin:0 0 6px' }, '確定要檢舉這個地點已歇業/資訊過時嗎？'),
          el('input', { id: `placeReportReason-${p.id}`, placeholder: '檢舉原因 (選填)', style: 'width:100%' }),
          el('div', { class: 'form-row', style: 'margin-top:6px' }, [
            el('button', { class: 'btn btn-ghost', style: 'font-size:12px', onclick: () => submitPlaceReport(p.id) }, '確定檢舉'),
            el('button', { class: 'btn btn-ghost', style: 'font-size:12px', onclick: () => { placeReportOpenId = null; loadPlacesBrowseList(); } }, '取消'),
          ]),
        ])
      : null,
  ]);
}

async function submitPlaceRating(p) {
  const starsStr = $(`#placeRatingStars-${p.id}`).value;
  const stars = Number(starsStr);
  if (!Number.isInteger(stars) || stars < 1 || stars > 5) { showToast('請先選擇星等'); return; }
  try {
    await api(`/places/${p.id}/rate`, { method: 'POST', body: { stars } });
    showToast('已送出評分 ⭐');
    placeRatingOpenId = null;
    loadPlacesBrowseList();
  } catch (e) { showToast('評分失敗：' + e.message); }
}

async function submitPlaceReport(id) {
  const reason = ($(`#placeReportReason-${id}`) && $(`#placeReportReason-${id}`).value) || '';
  try {
    const res = await api(`/places/${id}/report`, { method: 'POST', body: { reason } });
    showToast(res.status === 'needs_review' ? '已檢舉，這個地點已被標記為待確認' : '已送出檢舉，謝謝回報');
    placeReportOpenId = null;
    loadPlacesBrowseList();
  } catch (e) { showToast('檢舉失敗：' + e.message); }
}

async function deletePlaceConfirm(id) {
  if (!confirm('確定要刪除這個地點嗎？此動作無法復原。')) return;
  try {
    await api(`/places/${id}`, { method: 'DELETE' });
    showToast('已刪除');
    loadPlacesBrowseList();
  } catch (e) { showToast('刪除失敗：' + e.message); }
}

function placeFormBody(existing, onSubmit) {
  placesState.addMoodTags = new Set(existing ? existing.moodTags : []);
  placesState.addTransportTags = new Set(existing ? existing.transportTags : []);
  const wrap = el('div', {});
  wrap.appendChild(el('input', { id: 'placeFormName', placeholder: '地點名稱 *', value: existing ? existing.name : '', style: 'margin-bottom:8px' }));
  wrap.appendChild(el('input', { id: 'placeFormCity', placeholder: '城市 *', value: existing ? existing.city : '', style: 'margin-bottom:8px', disabled: !!existing }));
  wrap.appendChild(el('input', { id: 'placeFormDistrict', placeholder: '行政區 (選填)', value: (existing && existing.district) || '', style: 'margin-bottom:8px' }));
  wrap.appendChild(el('input', { id: 'placeFormAddress', placeholder: '地址 (選填)', value: (existing && existing.address) || '', style: 'margin-bottom:8px' }));
  wrap.appendChild(el('div', { class: 'hint', style: 'margin-bottom:4px' }, '主題標籤 (可複選)'));
  const moodRow = el('div', { class: 'mood-tag-row', style: 'margin-bottom:8px' });
  PLACE_MOOD_TAGS.forEach((t) => {
    moodRow.appendChild(el('button', {
      class: `mood-tag-chip${placesState.addMoodTags.has(t.key) ? ' selected' : ''}`,
      'data-tag': t.key,
      'data-kind': 'mood',
      onclick: (ev) => { ev.preventDefault(); togglePlaceFormTag('mood', t.key); },
    }, t.label));
  });
  wrap.appendChild(moodRow);
  wrap.appendChild(el('div', { class: 'hint', style: 'margin-bottom:4px' }, '交通方式 (可複選)'));
  const transRow = el('div', { class: 'mood-tag-row', style: 'margin-bottom:8px' });
  PLACE_TRANSPORT_TAGS.forEach((t) => {
    transRow.appendChild(el('button', {
      class: `mood-tag-chip${placesState.addTransportTags.has(t.key) ? ' selected' : ''}`,
      'data-tag': t.key,
      'data-kind': 'transport',
      onclick: (ev) => { ev.preventDefault(); togglePlaceFormTag('transport', t.key); },
    }, t.label));
  });
  wrap.appendChild(transRow);
  wrap.appendChild(el('input', { id: 'placeFormHours', placeholder: '營業時間 (選填)', value: (existing && existing.hours_text) || '', style: 'margin-bottom:8px' }));
  wrap.appendChild(el('input', { id: 'placeFormFee', placeholder: '費用 (選填)', value: (existing && existing.fee_info) || '', style: 'margin-bottom:8px' }));
  wrap.appendChild(el('input', { id: 'placeFormDuration', type: 'number', min: 0, placeholder: '預估停留時間(分鐘，選填)', value: (existing && existing.visit_duration_min) || '', style: 'margin-bottom:8px' }));
  wrap.appendChild(el('textarea', { id: 'placeFormNote', placeholder: '備註 (選填)，例如推薦原因、注意事項', style: 'margin-bottom:12px;width:100%;min-height:70px' }, (existing && existing.note) || ''));
  wrap.appendChild(el('button', { class: 'btn btn-primary', style: 'width:100%', onclick: onSubmit }, existing ? '儲存變更' : '新增地點'));
  return wrap;
}

function togglePlaceFormTag(kind, key) {
  const set = kind === 'mood' ? placesState.addMoodTags : placesState.addTransportTags;
  if (set.has(key)) set.delete(key); else set.add(key);
  document.querySelectorAll(`.mood-tag-chip[data-kind="${kind}"]`).forEach((b) => b.classList.toggle('selected', set.has(b.dataset.tag)));
}

function openAddPlaceSheet() {
  openSheet('新增地點', () => placeFormBody(null, submitNewPlace));
}
function openEditPlaceSheet(p) {
  openSheet('編輯地點', () => placeFormBody(p, () => submitEditPlace(p.id)));
}

function readPlaceFormBody() {
  return {
    name: $('#placeFormName').value.trim(),
    city: $('#placeFormCity').value.trim(),
    district: $('#placeFormDistrict').value.trim(),
    address: $('#placeFormAddress').value.trim(),
    moodTags: Array.from(placesState.addMoodTags),
    transportTags: Array.from(placesState.addTransportTags),
    hoursText: $('#placeFormHours').value.trim(),
    feeInfo: $('#placeFormFee').value.trim(),
    visitDurationMin: $('#placeFormDuration').value.trim() || null,
    note: $('#placeFormNote').value.trim(),
  };
}

async function submitNewPlace() {
  const body = readPlaceFormBody();
  if (!body.name) { showToast('請輸入地點名稱'); return; }
  if (!body.city) { showToast('請輸入城市'); return; }
  try {
    await api('/places', { method: 'POST', body });
    showToast('已新增地點 (+3 點)');
    closeSheet();
    populatePlaceCityDropdowns(); // 新增的城市如果之前沒出現過，讓下拉選單馬上看得到
    loadPlacesBrowseList();
  } catch (e) { showToast('新增失敗：' + e.message); }
}

async function submitEditPlace(id) {
  const body = readPlaceFormBody();
  if (!body.name) { showToast('請輸入地點名稱'); return; }
  delete body.city; // 城市建立後不開放修改，避免跟「臨時揪一波」的城市索引邏輯搞混
  try {
    await api(`/places/${id}`, { method: 'PUT', body });
    showToast('已儲存變更');
    closeSheet();
    loadPlacesBrowseList();
  } catch (e) { showToast('儲存失敗：' + e.message); }
}

// ===================== 日期/月曆共用工具 =====================
// 用本地時區組字串，不要用 toISOString()（那是 UTC，半夜時段會跟「今天」差一天）
function fmtYMD(date) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}
function todayStr() { return fmtYMD(new Date()); }
// 產生月曆格子 (含前後補空白，湊滿整週)，month 是 0-11
function monthGridDates(year, month) {
  const first = new Date(year, month, 1);
  const startWeekday = first.getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const cells = [];
  for (let i = 0; i < startWeekday; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(new Date(year, month, d));
  while (cells.length % 7 !== 0) cells.push(null);
  return cells;
}

// ===================== 日記 =====================
let diaryCalCursor = null;

function renderDiary() {
  const c = $('#tab-diary');
  c.innerHTML = '';
  const now = new Date();
  if (!diaryCalCursor) diaryCalCursor = { year: now.getFullYear(), month: now.getMonth() };

  c.appendChild(el('div', { class: 'grid-2' }, [
    el('div', { class: 'card', style: 'margin-bottom:0' }, [
      el('h3', {}, '寫日記'),
      el('div', { class: 'form-row' }, [
        el('input', { id: 'diaryDate', type: 'date', value: todayStr(), onchange: loadDiaryForDate }),
        el('label', { class: 'btn btn-ghost', style: 'cursor:pointer' }, [
          '📂 匯入文字',
          el('input', { type: 'file', accept: '.txt,.md', style: 'display:none', onchange: importDiaryFile }),
        ]),
      ]),
      el('textarea', { id: 'diaryContent', rows: 10, placeholder: '今天發生了什麼事...' }),
      el('div', { id: 'diaryTagEditor', class: 'diary-tag-editor' }),
      el('div', { style: 'margin-top:10px' }, el('button', { class: 'btn btn-primary', onclick: saveDiary }, '儲存')),
    ]),
    el('div', { class: 'card', style: 'margin-bottom:0' }, [
      el('h3', {}, '月曆瀏覽'),
      el('p', { class: 'hint' }, '藍色圓點代表當天有寫日記，點日期直接跳過去看/編輯。'),
      el('div', { id: 'diaryCalendar' }),
    ]),
  ]));

  c.appendChild(el('div', { class: 'card' }, [
    el('h3', {}, '搜尋日記'),
    el('div', { class: 'form-row' }, [
      el('input', { id: 'diarySearchInput', placeholder: '輸入關鍵字搜尋內容...', onkeydown: (ev) => { if (ev.key === 'Enter') searchDiary(); } }),
      el('button', { class: 'btn btn-primary', onclick: searchDiary }, '搜尋'),
      el('button', { class: 'btn btn-ghost', onclick: clearDiarySearch }, '清除'),
    ]),
  ]));

  c.appendChild(el('div', { class: 'card' }, [el('h3', {}, '日記列表'), el('div', { id: 'diaryList' })]));

  c.appendChild(el('div', { class: 'card' }, [
    el('h3', {}, '🔍 常提到的關鍵字/人物'),
    el('p', { class: 'hint' }, '近 90 天的日記統計，關鍵字是抓連續兩個字的出現頻率 (非語意分析)，人物則是比對「人際關係」清單的姓名。'),
    el('div', { id: 'diaryKeywordFrequency' }, el('div', { class: 'empty-state' }, '載入中...')),
  ]));

  loadDiaryForDate();
  loadDiaryList();
  renderDiaryCalendar();
  loadDiaryKeywordFrequency();
}

// v0.68：#6 日記關鍵字/人物頻率分析
async function loadDiaryKeywordFrequency() {
  const area = $('#diaryKeywordFrequency');
  if (!area) return;
  try {
    const r = await api('/diary/keyword-frequency?days=90');
    area.innerHTML = '';
    if (!r.hasEnoughData) { area.appendChild(el('div', { class: 'empty-state' }, r.note)); return; }
    if (r.people.length) {
      area.appendChild(el('div', { class: 'hint', style: 'font-weight:600;margin-bottom:4px' }, '👤 常提到的人'));
      area.appendChild(el('div', { class: 'mood-tag-row' }, r.people.map((p) => el('span', { class: 'mood-tag-chip selected', style: 'cursor:default' }, `${p.name} (${p.count})`))));
    }
    if (r.keywords.length) {
      area.appendChild(el('div', { class: 'hint', style: 'font-weight:600;margin:10px 0 4px' }, '🔤 常出現的詞'));
      area.appendChild(el('div', { class: 'mood-tag-row' }, r.keywords.map((k) => el('span', { class: 'mood-tag-chip', style: 'cursor:default' }, `${k.word} (${k.count})`))));
    }
    if (!r.people.length && !r.keywords.length) area.appendChild(el('div', { class: 'empty-state' }, '目前還看不出明顯的重複詞彙/人物'));
  } catch (e) { area.innerHTML = ''; area.appendChild(el('div', { class: 'empty-state' }, '分析資料暫時無法取得')); }
}

async function renderDiaryCalendar() {
  const box = $('#diaryCalendar');
  if (!box) return;
  const { year, month } = diaryCalCursor;
  const from = fmtYMD(new Date(year, month, 1));
  const to = fmtYMD(new Date(year, month + 1, 0));
  let marked = new Set();
  try {
    const rows = await api(`/diary?from=${from}&to=${to}`);
    marked = new Set(rows.map((r) => r.entry_date));
  } catch (e) { /* 忽略，當作沒有標記 */ }

  const cells = monthGridDates(year, month);
  const weekdayLabels = ['日', '一', '二', '三', '四', '五', '六'];
  box.innerHTML = '';
  box.appendChild(el('div', { style: 'display:flex;justify-content:space-between;align-items:center;margin-bottom:8px' }, [
    el('button', { class: 'btn btn-ghost', style: 'padding:4px 10px', onclick: () => shiftDiaryMonth(-1) }, '‹'),
    el('div', { style: 'font-weight:700;font-size:13.5px' }, `${year} 年 ${month + 1} 月`),
    el('button', { class: 'btn btn-ghost', style: 'padding:4px 10px', onclick: () => shiftDiaryMonth(1) }, '›'),
  ]));
  const grid = el('div', { class: 'mini-cal-grid' });
  weekdayLabels.forEach((w) => grid.appendChild(el('div', { class: 'mini-cal-weekday' }, w)));
  cells.forEach((d) => {
    if (!d) { grid.appendChild(el('div', { class: 'mini-cal-cell empty' })); return; }
    const dateStr = fmtYMD(d);
    const isToday = dateStr === todayStr();
    const hasEntry = marked.has(dateStr);
    grid.appendChild(el('div', {
      class: `mini-cal-cell${isToday ? ' today' : ''}${hasEntry ? ' has-mark' : ''}`,
      onclick: () => { $('#diaryDate').value = dateStr; loadDiaryForDate(); },
    }, [String(d.getDate()), hasEntry ? el('span', { class: 'mini-cal-dot' }) : null]));
  });
  box.appendChild(grid);
}
function shiftDiaryMonth(delta) {
  let { year, month } = diaryCalCursor;
  month += delta;
  if (month < 0) { month = 11; year -= 1; }
  if (month > 11) { month = 0; year += 1; }
  diaryCalCursor = { year, month };
  renderDiaryCalendar();
}

// 目前正在編輯的日記標籤 (陣列)，用一般變數存就好，儲存時才會真的送到後端。
let diaryTagsEditing = [];
// 目前套用的標籤篩選 (跟關鍵字搜尋是獨立的兩個條件，可以同時使用)。
let diaryTagFilterActive = null;

async function loadDiaryForDate() {
  const date = $('#diaryDate').value;
  try {
    const row = await api(`/diary/${date}`);
    $('#diaryContent').value = row ? row.content : '';
    diaryTagsEditing = row && row.tags ? row.tags : [];
  } catch (e) { $('#diaryContent').value = ''; diaryTagsEditing = []; }
  renderDiaryTagEditor();
}

function renderDiaryTagEditor() {
  const box = $('#diaryTagEditor');
  if (!box) return;
  box.innerHTML = '';
  diaryTagsEditing.forEach((tag) => {
    box.appendChild(el('span', { class: 'diary-tag-chip' }, [
      tag,
      el('button', { onclick: () => { diaryTagsEditing = diaryTagsEditing.filter((t) => t !== tag); renderDiaryTagEditor(); } }, '×'),
    ]));
  });
  box.appendChild(el('input', {
    id: 'diaryTagInput', placeholder: '+ 加標籤 (Enter 新增)', class: 'diary-tag-input',
    onkeydown: (ev) => {
      if (ev.key !== 'Enter') return;
      ev.preventDefault();
      const val = ev.target.value.trim();
      if (val && !diaryTagsEditing.includes(val)) diaryTagsEditing.push(val);
      ev.target.value = '';
      renderDiaryTagEditor();
    },
  }));
}

async function saveDiary() {
  const date = $('#diaryDate').value;
  const content = $('#diaryContent').value;
  try {
    await api(`/diary/${date}`, { method: 'PUT', body: { content, tags: diaryTagsEditing } });
    showToast('已儲存');
    loadDiaryList(currentDiaryQuery(), diaryTagFilterActive);
    renderDiaryCalendar();
  } catch (e) { showToast('儲存失敗: ' + e.message); }
}
function currentDiaryQuery() {
  const input = $('#diarySearchInput');
  return input ? input.value.trim() : '';
}
function importDiaryFile(ev) {
  const file = ev.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => { $('#diaryContent').value = reader.result; };
  reader.readAsText(file, 'utf-8');
}
function searchDiary() {
  loadDiaryList($('#diarySearchInput').value.trim(), diaryTagFilterActive);
}
function clearDiarySearch() {
  $('#diarySearchInput').value = '';
  diaryTagFilterActive = null;
  loadDiaryList();
}
function filterDiaryByTag(tag) {
  diaryTagFilterActive = diaryTagFilterActive === tag ? null : tag;
  loadDiaryList(currentDiaryQuery(), diaryTagFilterActive);
}
async function loadDiaryList(q, tag) {
  const list = $('#diaryList');
  list.innerHTML = '載入中...';
  try {
    const params = new URLSearchParams();
    if (q) params.set('q', q);
    if (tag) params.set('tag', tag);
    const qs = params.toString();
    const rows = await api(qs ? `/diary?${qs}` : '/diary');
    list.innerHTML = '';

    // 這批日記裡出現過的所有標籤，做成篩選用的小標籤列——只列真的有用過的標籤，
    // 不是每次都要自己記標籤名稱手動輸入才能篩。
    const allTags = [...new Set(rows.flatMap((r) => r.tags || []))];
    if (allTags.length) {
      const tagRow = el('div', { class: 'diary-tag-filter-row' });
      allTags.forEach((t) => {
        tagRow.appendChild(el('button', {
          class: `diary-tag-filter-btn${tag === t ? ' active' : ''}`,
          onclick: () => filterDiaryByTag(t),
        }, `# ${t}`));
      });
      list.appendChild(tagRow);
    }

    if (!rows.length) { list.appendChild(el('div', { class: 'empty-state' }, (q || tag) ? '沒有符合的日記' : '還沒有日記')); return; }
    rows.slice(0, 30).forEach((r) => {
      list.appendChild(el('div', {
        class: 'diary-list-row',
        onclick: () => { $('#diaryDate').value = r.entry_date; loadDiaryForDate(); },
      }, [
        el('div', { style: 'display:flex;align-items:center;gap:8px;flex-wrap:wrap' }, [
          el('b', {}, r.entry_date),
          r.moodScore != null ? el('span', { class: 'diary-mood-badge', title: '這天心情陪伴模組記錄的分數' }, `💗 ${r.moodScore}`) : null,
          ...(r.tags || []).map((t) => el('span', { class: 'diary-tag-chip readonly' }, t)),
        ].filter(Boolean)),
        el('div', { style: 'font-size:13px;color:var(--text-secondary);margin-top:4px' }, (r.content || '').slice(0, 80)),
      ]));
    });
  } catch (e) { list.innerHTML = '載入失敗'; }
}

// ===================== 記帳 =====================
const FINANCE_CATEGORIES = ['餐飲', '交通', '娛樂', '購物', '居家', '醫療', '教育', '其他'];
let financeBudgets = [];
let financeSummaryCache = null;

const FINANCE_VIEW_TABS = [
  { key: 'overview', label: '總覽' },
  { key: 'goals', label: '目標與預算' },
  { key: 'detail', label: '明細' },
];
let financeViewTab = 'overview';
function switchFinanceViewTab(tab) { financeViewTab = tab; renderFinance(); }

// v0.87：記帳事實摘要 (見 src/routes/financeInsights.js)
async function loadFinanceFacts() {
  const box = $('#financeFactsCard');
  if (!box) return;
  try {
    const { lines } = await api('/finance-insights');
    box.innerHTML = '';
    if (!lines || !lines.length) return;
    box.appendChild(el('div', { class: 'card finance-facts' }, [
      el('h3', {}, '📊 這個月到今天'),
      ...lines.map((t) => el('p', { class: 'finance-fact-line' }, t)),
    ]));
  } catch (e) { box.innerHTML = ''; }
}

function renderFinance() {
  const c = $('#tab-finance');
  c.innerHTML = '';

  const wrap = el('div', { class: 'finance-clean-wrap' });
  wrap.appendChild(el('div', { class: 'task-view-tabs' }, FINANCE_VIEW_TABS.map((t) =>
    el('button', { class: `task-view-tab${financeViewTab === t.key ? ' active' : ''}`, onclick: () => switchFinanceViewTab(t.key) }, t.label)
  )));

  const sections = el('div', { class: 'finance-clean-sections' });

  if (financeViewTab === 'overview') {
    // v0.65：情緒化消費偵測的結果 (見 src/routes/insights.js 的 emotional-spending-pattern)
    // 之前算出來後沒地方顯示 (首頁的「主動式提醒」區塊已經整個移除)，這裡在記帳分頁最上面
    // 顯示，沒有偵測到明顯模式時這張卡片不會出現 (不是空卡片墊著)。
    sections.appendChild(el('div', { id: 'financeInsightAlerts' }));
    // v0.87：把已經記過的帳整理成一兩句事實 (這個月 vs 上個月同期、增加最多的分類)，
    // 這個月記不到 3 筆時整張卡片不出現。
    sections.appendChild(el('div', { id: 'financeFactsCard' }));
    setTimeout(loadFinanceFacts, 0); // 等整個分頁掛進畫面之後再填

    // v0.87：原本表單上方有一段 Open Banking 的規劃說明 (跟記帳操作無關、每次都要先讀過)，拿掉。
    sections.appendChild(el('div', { class: 'card' }, [
      el('h3', {}, '新增一筆記帳'),
      el('div', { class: 'form-row' }, [
        el('input', { id: 'txDate', type: 'date', value: todayStr() }),
        chipSelectEl({ id: 'txType', variant: 'segmented', value: 'expense', options: [{ value: 'expense', label: '支出' }, { value: 'income', label: '收入' }] }),
        el('select', { id: 'txCategory', onchange: onTxCategoryChange }, [
          ...FINANCE_CATEGORIES.map((cat) => el('option', { value: cat }, cat)),
          el('option', { value: '__custom__' }, '✏️ 自訂分類...'),
        ]),
        el('input', { id: 'txAmount', type: 'number', placeholder: '金額' }),
      ]),
      el('div', { class: 'form-row' }, [
        el('input', { id: 'txCategoryCustom', placeholder: '輸入自訂分類名稱', style: 'display:none' }),
      ]),
      el('label', { style: 'display:block;font-size:13px;color:var(--text-secondary,#666);margin:10px 0 4px' }, '📝 這筆消費原因/備註 (選填，自己打字寫也可以)'),
      el('input', { id: 'txNote', list: 'txNoteList', placeholder: '例如：跟朋友聚餐、幫家人買日用品、加油...', style: 'width:100%' }),
      el('datalist', { id: 'txNoteList' }),
      el('button', { class: 'btn btn-primary', onclick: addTransaction, style: 'margin-top:10px' }, '新增'),
    ]));
    sections.appendChild(el('div', { class: 'grid-2' }, [
      el('div', { class: 'card' }, [el('h3', {}, '本月支出分類'), el('div', { id: 'financeBarChart' })]),
      el('div', { class: 'card' }, [el('h3', {}, '近12個月收支趨勢'), el('div', { id: 'financeLineChart' })]),
    ]));
    sections.appendChild(el('div', { class: 'grid-2' }, [
      el('div', { class: 'card' }, [
        el('h3', {}, '🔁 可能的固定支出/訂閱'),
        el('p', { class: 'hint' }, '依「備註+分類」找出在多個月份都出現、金額相近的支出，幫你整理成一份清單，是猜測不是保證。'),
        el('div', { id: 'subscriptionsArea' }, el('div', { class: 'empty-state' }, '載入中...')),
      ]),
      el('div', { class: 'card' }, [
        el('h3', {}, '📈 淨資產趨勢 (累計結餘)'),
        el('p', { class: 'hint' }, '每月收支的累計結餘隨時間的變化，不含投資部位市值。'),
        el('div', { id: 'networthChart' }),
      ]),
    ]));
    sections.appendChild(el('div', { class: 'card' }, [
      el('h3', {}, '🛟 緊急預備金'),
      el('p', { class: 'hint' }, '用最近的平均月支出，估算建議的緊急預備金水位，並看看目前現金結餘大概夠撐幾個月。'),
      el('div', { id: 'emergencyFundArea' }, el('div', { class: 'empty-state' }, '載入中...')),
    ]));
  } else if (financeViewTab === 'goals') {
    sections.appendChild(el('div', { class: 'card' }, [
      el('h3', {}, '🎯 財務目標'),
      el('p', { class: 'hint' }, '不用自己算存了多少，系統會用「設定目標之後的實際收入減支出」自動算進度，並用你的儲蓄速度推算大概什麼時候能達成。'),
      el('div', { class: 'form-row' }, [
        el('input', { id: 'goalName', placeholder: '目標名稱，例如：日本旅遊基金' }),
        el('input', { id: 'goalAmount', type: 'number', placeholder: '目標金額' }),
        el('input', { id: 'goalTargetDate', type: 'date', placeholder: '希望達成日 (選填)' }),
      ]),
      el('button', { class: 'btn btn-primary', onclick: addGoal, style: 'margin-top:6px' }, '新增目標'),
      el('div', { id: 'goalsArea', style: 'margin-top:14px' }),
    ]));
    sections.appendChild(el('div', { class: 'card' }, [
      el('h3', {}, '📊 預算設定'),
      el('p', { class: 'hint' }, '設定每個分類的每月預算上限，超支會用顏色提醒 (不會擋你記帳，只是提醒)。'),
      el('div', { id: 'budgetArea' }),
    ]));
  } else if (financeViewTab === 'detail') {
    sections.appendChild(el('div', { class: 'card' }, [el('h3', {}, '本月明細'), el('div', { id: 'txTable' })]));
  }

  wrap.appendChild(sections);
  c.appendChild(wrap);

  if (financeViewTab === 'overview') {
    loadFinanceOverview();
    loadSubscriptions();
    loadNetworthTrend();
    loadEmergencyFund();
    loadTabInsightAlerts('financeInsightAlerts', ['emotional-spending-pattern']);
  } else if (financeViewTab === 'goals') {
    loadBudgets();
    loadGoals();
  } else if (financeViewTab === 'detail') {
    loadFinanceDetail();
  }
}

async function loadSubscriptions() {
  const area = $('#subscriptionsArea');
  if (!area) return;
  try {
    const res = await api('/finance/subscriptions');
    area.innerHTML = '';
    if (!res.candidates.length) { area.appendChild(el('div', { class: 'empty-state' }, '目前資料還看不出明顯的固定支出模式')); return; }
    res.candidates.slice(0, 10).forEach((c) => {
      area.appendChild(el('div', { class: 'coping-note-item' }, [
        el('div', { class: 'content' }, [
          el('div', { style: 'font-weight:700' }, [`${c.note} (${c.category})`, c.reviewSuggested ? el('span', { style: 'margin-left:6px;font-size:11px;color:var(--warning);font-weight:600' }, '⚠️ 已持續 6 個月以上，值得檢查') : null].filter(Boolean)),
          el('div', { class: 'hint', style: 'margin:2px 0 0' }, `約 ${fmtMoney(c.avgAmount)}／次 · 出現在 ${c.monthsSeen} 個月 · 累計約 ${fmtMoney(c.totalPaid)} · 最近一次 ${c.lastDate}`),
        ]),
      ]));
    });
  } catch (e) { area.innerHTML = ''; area.appendChild(el('div', { class: 'empty-state' }, '暫時無法分析')); }
}

// v0.68：#15 緊急預備金計算機
async function loadEmergencyFund() {
  const area = $('#emergencyFundArea');
  if (!area) return;
  try {
    const r = await api('/finance/emergency-fund');
    area.innerHTML = '';
    if (!r.hasEnoughData) { area.appendChild(el('div', { class: 'empty-state' }, r.note)); return; }
    area.appendChild(el('p', {}, `近幾個月平均月支出約 ${fmtMoney(r.avgMonthlyExpense)}，建議緊急預備金約 ${fmtMoney(r.suggestedMin)} ~ ${fmtMoney(r.suggestedMax)}（3~6 個月生活費）。`));
    area.appendChild(el('p', {}, `目前現金結餘約 ${fmtMoney(r.currentCumulativeBalance)}，大概夠撐 ${r.monthsCovered ?? '—'} 個月（${r.statusLabel}）。`));
    area.appendChild(el('p', { class: 'hint' }, r.disclaimer));
  } catch (e) { area.innerHTML = ''; area.appendChild(el('div', { class: 'empty-state' }, '暫時無法計算')); }
}

async function loadNetworthTrend() {
  const box = $('#networthChart');
  if (!box) return;
  try {
    const res = await api('/finance/networth-trend');
    if (!res.trend.length) { box.innerHTML = ''; box.appendChild(el('div', { class: 'empty-state' }, '目前沒有可用的趨勢資料')); return; }
    renderLineChart(box, [
      { name: '累計結餘', color: cssVar('--series-violet'), points: res.trend.map((t) => ({ x: t.ym, y: t.cumulativeBalance })) },
    ]);
  } catch (e) { box.innerHTML = ''; box.appendChild(el('div', { class: 'empty-state' }, '暫時無法取得趨勢')); }
}

async function addGoal() {
  const name = $('#goalName').value.trim();
  const target_amount = Number($('#goalAmount').value);
  const target_date = $('#goalTargetDate').value || null;
  if (!name || !target_amount || target_amount <= 0) { showToast('請輸入目標名稱與大於 0 的金額'); return; }
  try {
    await api('/finance/goals', { method: 'POST', body: { name, target_amount, target_date } });
    $('#goalName').value = ''; $('#goalAmount').value = ''; $('#goalTargetDate').value = '';
    showToast('已新增目標');
    loadGoals();
  } catch (e) { showToast('新增失敗: ' + e.message); }
}

async function deleteGoal(id) {
  await api(`/finance/goals/${id}`, { method: 'DELETE' });
  loadGoals();
}

async function loadGoals() {
  const area = $('#goalsArea');
  if (!area) return;
  try {
    const goals = await api('/finance/goals');
    area.innerHTML = '';
    if (!goals.length) { area.appendChild(el('div', { class: 'empty-state' }, '還沒有設定財務目標')); return; }
    goals.forEach((g) => {
      const pct = Math.max(0, Math.min(100, g.progressPct));
      const barColor = pct >= 100 ? 'var(--good)' : pct >= 60 ? 'var(--series-blue)' : 'var(--warning)';
      let statusLine;
      if (g.projectedDate === 'reached') {
        statusLine = '🎉 已達成目標金額！';
      } else if (g.projectedDate) {
        statusLine = `依目前儲蓄速度，預估 ${g.projectedDate} 左右可達成` + (g.target_date ? (g.onTrack ? '（在預定日期內）' : '（可能會晚於預定日期，僅供參考）') : '');
      } else {
        statusLine = '目前還沒有明顯的淨儲蓄，先累積一些記帳紀錄';
      }
      area.appendChild(el('div', { style: 'padding:12px 0;border-bottom:1px solid var(--grid-line)' }, [
        el('div', { style: 'display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;margin-bottom:6px' }, [
          el('div', { style: 'font-weight:700;font-size:14px' }, g.name),
          el('div', { style: 'display:flex;gap:8px;align-items:center' }, [
            el('span', { style: 'font-size:12px;color:var(--text-muted)' }, `${fmtMoney(g.netSaved)} / ${fmtMoney(g.target_amount)} (${pct}%)`),
            el('button', { class: 'btn btn-ghost', style: 'padding:5px 10px;font-size:12px', onclick: () => deleteGoal(g.id) }, '刪除'),
          ]),
        ]),
        el('div', { style: 'height:6px;background:var(--gray-mid);border-radius:999px;overflow:hidden' }, [
          el('div', { style: `height:100%;width:${pct}%;background:${barColor}` }),
        ]),
        el('p', { class: 'hint', style: 'margin:6px 0 0' }, statusLine),
        g.confidenceLabel && g.confidenceLabel !== '資料不足' ? el('p', { class: 'hint', style: 'margin:2px 0 0' }, `📊 ${g.confidenceLabel}${g.requiredMonthlyRateForTargetDate != null ? `（要在預定日期前達成，平均每月大約需要淨存 ${fmtMoney(g.requiredMonthlyRateForTargetDate)}）` : ''}`) : null,
      ].filter(Boolean)));
    });
  } catch (e) { area.innerHTML = ''; area.appendChild(el('div', { class: 'hint' }, '目標載入失敗')); }
}

function onTxCategoryChange() {
  $('#txCategoryCustom').style.display = $('#txCategory').value === '__custom__' ? 'block' : 'none';
}

async function addTransaction() {
  const sel = $('#txCategory').value;
  const category = sel === '__custom__' ? ($('#txCategoryCustom').value.trim() || '未分類') : sel;
  const body = {
    tx_date: $('#txDate').value,
    type: $('#txType').value,
    category,
    amount: Number($('#txAmount').value),
    note: $('#txNote').value.trim(),
  };
  if (!body.amount) { showToast('請輸入金額'); return; }
  try {
    await api('/finance/transactions', { method: 'POST', body });
    $('#txCategoryCustom').value = ''; $('#txAmount').value = ''; $('#txNote').value = '';
    showToast('已新增');
    loadFinance();
    loadSubscriptions();
    loadNetworthTrend();
  } catch (e) { showToast('新增失敗: ' + e.message); }
}
async function deleteTransaction(id) {
  await api(`/finance/transactions/${id}`, { method: 'DELETE' });
  loadFinance();
  loadSubscriptions();
  loadNetworthTrend();
}

// 表單自動記憶：用之前打過的備註填 <datalist>，保留自由輸入的同時提供建議，減少重複打字
function populateTxNoteDatalist(rows) {
  const list = $('#txNoteList');
  if (!list) return;
  const notes = [...new Set(rows.map((r) => (r.note || '').trim()).filter(Boolean))];
  list.innerHTML = '';
  notes.slice(0, 50).forEach((n) => list.appendChild(el('option', { value: n })));
}

async function loadFinanceOverview() {
  try {
    const summary = await api('/finance/summary');
    // 用最近 200 筆全部紀錄 (不限本月) 來準備備註自動完成的建議清單，這樣過去打過的字都記得住
    api('/finance/transactions').then(populateTxNoteDatalist).catch(() => {});
    financeSummaryCache = summary;
    const expenseByCat = summary.byCategory.filter((r) => r.type === 'expense').map((r) => ({ label: r.category, value: r.total }));
    renderBarChart($('#financeBarChart'), expenseByCat, { money: true, emptyText: '本月尚無支出紀錄' });

    const months = [...new Set(summary.monthlyTrend.map((r) => r.ym))];
    const income = months.map((m) => ({ x: m, y: (summary.monthlyTrend.find((r) => r.ym === m && r.type === 'income') || {}).total || 0 }));
    const expense = months.map((m) => ({ x: m, y: (summary.monthlyTrend.find((r) => r.ym === m && r.type === 'expense') || {}).total || 0 }));
    renderLineChart($('#financeLineChart'), [
      { name: '收入', color: cssVar('--series-blue'), points: income },
      { name: '支出', color: cssVar('--series-red'), points: expense },
    ]);
    renderBudgetArea();
  } catch (e) { showToast('載入記帳資料失敗: ' + e.message); }
}

async function loadFinanceDetail() {
  try {
    const rows = await api('/finance/transactions?month=' + todayStr().slice(0, 7));
    populateTxNoteDatalist(rows);
    const table = $('#txTable');
    if (!table) return;
    table.innerHTML = '';
    if (!rows.length) { table.appendChild(el('div', { class: 'empty-state' }, '本月尚無紀錄')); return; }
    const trs = rows.map((r) => el('tr', {}, [
      el('td', {}, r.tx_date), el('td', {}, r.type === 'income' ? '收入' : '支出'), el('td', {}, r.category),
      el('td', { style: r.type === 'income' ? 'color:var(--good)' : 'color:var(--critical)' }, fmtMoney(r.amount)),
      el('td', {}, r.note || ''),
      el('td', {}, el('button', { class: 'btn btn-ghost', onclick: () => deleteTransaction(r.id) }, '刪除')),
    ]));
    table.appendChild(el('table', {}, [
      el('thead', {}, el('tr', {}, [el('th', {}, '日期'), el('th', {}, '類型'), el('th', {}, '分類'), el('th', {}, '金額'), el('th', {}, '備註'), el('th', {}, '')])),
      el('tbody', {}, trs),
    ]));
  } catch (e) { showToast('載入明細失敗: ' + e.message); }
}

// 兼容其他呼叫端 (例如新增/刪除交易後刷新)：依目前所在分頁刷新對應內容
async function loadFinance() {
  if (financeViewTab === 'detail') { await loadFinanceDetail(); }
  else if (financeViewTab === 'overview') { await loadFinanceOverview(); }
}

async function loadBudgets() {
  try { financeBudgets = await api('/finance/budgets'); } catch (e) { financeBudgets = []; }
  renderBudgetArea();
}

function renderBudgetArea() {
  const area = $('#budgetArea');
  if (!area) return;
  area.innerHTML = '';

  const spentByCategory = {};
  if (financeSummaryCache) {
    financeSummaryCache.byCategory.filter((r) => r.type === 'expense').forEach((r) => { spentByCategory[r.category] = r.total; });
  }
  const allCats = new Set(FINANCE_CATEGORIES);
  financeBudgets.forEach((b) => allCats.add(b.category));
  Object.keys(spentByCategory).forEach((cat) => allCats.add(cat));

  [...allCats].forEach((cat) => {
    const budget = financeBudgets.find((b) => b.category === cat);
    const limit = budget ? budget.monthly_limit : null;
    const spent = spentByCategory[cat] || 0;
    const pct = limit ? Math.round((spent / limit) * 100) : null;
    const barColor = pct == null ? 'var(--series-blue)' : pct >= 100 ? 'var(--critical)' : pct >= 70 ? 'var(--warning)' : 'var(--good)';
    const inputId = `budgetInput-${cat}`;

    area.appendChild(el('div', { style: 'padding:10px 0;border-bottom:1px solid var(--grid-line)' }, [
      el('div', { style: 'display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;margin-bottom:6px' }, [
        el('div', { style: 'font-weight:600;font-size:13.5px' }, cat),
        el('div', { style: 'display:flex;gap:8px;align-items:center' }, [
          el('span', { style: 'font-size:12px;color:var(--text-muted)' }, limit != null ? `${fmtMoney(spent)} / ${fmtMoney(limit)}` : `已花 ${fmtMoney(spent)}`),
          el('input', { id: inputId, type: 'number', placeholder: '預算上限', value: limit != null ? limit : '', style: 'width:100px;padding:5px 8px;font-size:12px' }),
          el('button', { class: 'btn btn-ghost', style: 'padding:5px 10px;font-size:12px', onclick: () => saveBudget(cat, inputId) }, '儲存'),
        ]),
      ]),
      limit != null ? el('div', { style: 'height:6px;background:var(--gray-mid);border-radius:999px;overflow:hidden' }, [
        el('div', { style: `height:100%;width:${Math.min(100, pct)}%;background:${barColor}` }),
      ]) : null,
    ]));
  });
}

async function saveBudget(cat, inputId) {
  const val = Number($(`#${inputId}`).value);
  if (!val || val <= 0) { showToast('請輸入有效的預算金額'); return; }
  try {
    await api(`/finance/budgets/${encodeURIComponent(cat)}`, { method: 'PUT', body: { monthly_limit: val } });
    showToast('已儲存預算');
    loadBudgets();
  } catch (e) { showToast('儲存失敗: ' + e.message); }
}

// ===================== 行事曆 =====================
const CALENDAR_CATEGORIES = [
  { key: 'meal', label: '🍜 飲食', colorVar: '--series-orange' },
  { key: 'movie', label: '🎬 電影', colorVar: '--series-violet' },
  { key: 'sport', label: '🏃 運動', colorVar: '--series-aqua' },
  { key: 'work', label: '💼 工作', colorVar: '--series-blue' },
  { key: 'date', label: '💗 約會', colorVar: '--series-magenta' },
  { key: 'travel', label: '🚄 交通旅遊', colorVar: '--series-green' },
  { key: 'other', label: '📌 其他', colorVar: '--series-yellow' },
];
// 跨模組自動整合進來的唯讀項目 (帳單到期/待辦截止/人際關係重要日子)，不會出現在
// 「新增行程」的分類選單裡 (使用者不能手動選這幾個)，只用來查顏色/圖示標籤。
const AUTO_CATEGORIES = [
  { key: 'auto-bill', label: '🧾 帳單到期', colorVar: '--critical' },
  { key: 'auto-task', label: '✅ 待辦截止', colorVar: '--series-blue' },
  { key: 'auto-date', label: '🎉 重要日子', colorVar: '--series-magenta' },
];
function calCategoryInfo(key) {
  return CALENDAR_CATEGORIES.find((c) => c.key === key) || AUTO_CATEGORIES.find((c) => c.key === key) || CALENDAR_CATEGORIES[CALENDAR_CATEGORIES.length - 1];
}
const RECURRENCE_LABELS = { '': '不重複', daily: '每天', weekly: '每週', monthly: '每月', yearly: '每年 (適合生日/紀念日)' };

let calCursor = null;
let calEventsCache = [];
let calLunarCache = {}; // { 'YYYY-MM-DD': { label, solarTerm } }
let selectedCalDate = null;
let calEditingId = null; // 目前正在編輯哪一筆行程 (null = 新增模式)

function renderCalendar() {
  const c = $('#tab-calendar');
  c.innerHTML = '';
  const now = new Date();
  if (!calCursor) calCursor = { year: now.getFullYear(), month: now.getMonth() };
  if (!selectedCalDate) selectedCalDate = todayStr();

  // 月曆放左邊 (畫面主體)，新增行程表單 + 選定日期行程放右邊直向排一起，
  // 桌面/大螢幕上這樣一畫面就能看到全部功能，不用再往下滑。
  // 手機版則完全是另一套邏輯 (見 CSS `@media (max-width:760px)` 底下 `#tab-calendar` 那段)：
  // 右邊「新增行程」「選定日期行程」這兩張卡片直接隱藏不會疊到下面去，改成點日期時用
  // 底部彈出面板 (openCalDaySheet) 呈現同樣的功能，月曆本體固定鎖住可視高度，一整頁看到
  // 完整月份、不需要再往下滑——這是使用者實際傳了 iPhone 內建行事曆的畫面來要求比照的。
  c.appendChild(el('div', { class: 'grid-cal' }, [
    el('div', { class: 'card' }, [
      el('div', { id: 'calMonthNav' }),
      // 手機版專用的快速操作列：「今天」跳回本月並選到今天、「＋」直接開啟新增行程面板，
      // 對應使用者參考截圖右上角「今天／＋」那兩個常駐按鈕，不用像桌面版一樣得往下滑到
      // 側邊欄位置才能新增行程。
      el('div', { class: 'cal-mobile-actions' }, [
        el('button', { class: 'btn btn-ghost', onclick: calJumpToday }, '📍 今天'),
        el('button', { class: 'btn btn-primary', onclick: () => openCalDaySheet(selectedCalDate) }, '＋ 新增行程'),
      ]),
      el('div', { id: 'calMonthGrid' }),
      el('div', { class: 'legend', style: 'margin-top:12px' }, [...CALENDAR_CATEGORIES, ...AUTO_CATEGORIES].map((cat) => el('div', { class: 'legend-item' }, [
        el('span', { class: 'legend-dot', style: `background:${cssVar(cat.colorVar)}` }), cat.label,
      ]))),
      el('p', { class: 'hint', style: 'margin-top:6px' }, '🧾/✅/🎉 這幾類是自動整合帳單到期日、待辦截止日、人際關係重要日子，唯讀顯示，要改請到原本的分頁。'),
    ]),
    el('div', { class: 'cal-side' }, [
      el('div', { class: 'card' }, [
        el('h3', { id: 'calFormTitle' }, '新增行程'),
        el('div', { class: 'form-row' }, [
          el('input', { id: 'calDate', type: 'date', value: todayStr() }),
          el('input', { id: 'calTime', type: 'time' }),
        ]),
        el('input', { id: 'calTitle', placeholder: '要做什麼事？', style: 'width:100%;margin-top:8px' }),
        el('div', { class: 'form-row', style: 'margin-top:8px' }, [
          el('select', { id: 'calCategory' }, CALENDAR_CATEGORIES.map((cat) => el('option', { value: cat.key }, cat.label))),
          chipSelectEl({ id: 'calRecurrence', value: '', options: Object.entries(RECURRENCE_LABELS).map(([k, v]) => ({ value: k, label: v })) }),
        ]),
        el('input', { id: 'calNote', placeholder: '備註 (選填)', style: 'width:100%;margin-top:8px' }),
        el('div', { style: 'display:flex;gap:8px;margin-top:10px' }, [
          el('button', { id: 'calSubmitBtn', class: 'btn btn-primary', style: 'flex:1', onclick: addCalendarEvent }, '新增'),
          el('button', { id: 'calCancelEditBtn', class: 'btn btn-ghost', style: 'display:none', onclick: () => cancelEditCalEvent('') }, '取消編輯'),
        ]),
      ]),
      el('div', { class: 'card' }, [el('h3', { id: 'calDayTitle' }, '選定日期的行程'), el('div', { id: 'calDayDetail' })]),
      el('div', { class: 'card' }, [
        el('h3', {}, '🔥 未來 30 天工作量'),
        el('p', { class: 'hint' }, '行程 + 待辦截止日的密度，跟同一天同一個時間點的行程衝突。'),
        el('div', { id: 'calWorkloadArea' }, el('div', { class: 'empty-state' }, '載入中...')),
      ]),
    ]),
  ]));

  loadCalendarMonth();
  loadCalWorkload();
}

// v0.68：#11 行事曆/任務工作量熱力圖與衝突偵測
async function loadCalWorkload() {
  const area = $('#calWorkloadArea');
  if (!area) return;
  try {
    const from = todayStr();
    const toD = new Date(); toD.setDate(toD.getDate() + 30);
    const to = fmtYMD(toD);
    const r = await api(`/calendar/workload-heatmap?from=${from}&to=${to}`);
    area.innerHTML = '';
    if (r.busiestDay) {
      area.appendChild(el('p', {}, `最忙的一天：${r.busiestDay.date}（${r.busiestDay.eventCount} 個行程 + ${r.busiestDay.taskCount} 筆待辦截止）`));
    } else {
      area.appendChild(el('div', { class: 'empty-state' }, '未來 30 天目前沒有安排行程或待辦截止日'));
    }
    if (r.conflicts.length) {
      area.appendChild(el('div', { class: 'hint', style: 'font-weight:600;margin:8px 0 4px;color:var(--warning)' }, '⚠️ 發現時間衝突'));
      r.conflicts.forEach((cf) => {
        area.appendChild(el('div', { class: 'mood-signal-item' }, `${cf.date} ${cf.time}：${cf.events.map((e) => e.title).join('、')}`));
      });
    }
  } catch (e) { area.innerHTML = ''; area.appendChild(el('div', { class: 'empty-state' }, '工作量資料暫時無法取得')); }
}

async function loadCalendarMonth() {
  const { year, month } = calCursor;
  const from = fmtYMD(new Date(year, month, 1));
  const to = fmtYMD(new Date(year, month + 1, 0));
  try {
    calEventsCache = await api(`/calendar?from=${from}&to=${to}`);
  } catch (e) { calEventsCache = []; }
  try {
    calLunarCache = await api(`/calendar/lunar-info?from=${from}&to=${to}`);
  } catch (e) { calLunarCache = {}; } // 農曆/節氣是點綴用途，拿不到不影響其他功能
  renderCalMonthNav();
  renderCalMonthGrid();
  renderCalDayDetail(selectedCalDate);
}

function renderCalMonthNav() {
  const nav = $('#calMonthNav');
  if (!nav) return;
  const { year, month } = calCursor;
  nav.innerHTML = '';
  nav.appendChild(el('div', { style: 'display:flex;justify-content:space-between;align-items:center;margin-bottom:12px' }, [
    el('button', { class: 'btn btn-ghost', onclick: () => shiftCalMonth(-1) }, '‹ 上個月'),
    el('div', { style: 'font-weight:800;font-size:16px' }, `${year} 年 ${month + 1} 月`),
    el('button', { class: 'btn btn-ghost', onclick: () => shiftCalMonth(1) }, '下個月 ›'),
  ]));
}
function shiftCalMonth(delta) {
  let { year, month } = calCursor;
  month += delta;
  if (month < 0) { month = 11; year -= 1; }
  if (month > 11) { month = 0; year += 1; }
  calCursor = { year, month };
  loadCalendarMonth();
}

function renderCalMonthGrid() {
  const grid = $('#calMonthGrid');
  if (!grid) return;
  grid.innerHTML = '';
  const { year, month } = calCursor;
  const cells = monthGridDates(year, month);
  const weekdayLabels = ['日', '一', '二', '三', '四', '五', '六'];
  const weekRows = cells.length / 7; // 4~6 週不等
  // 手機版鎖高度顯示整月不用滑動：週數不固定 (4~6 週)，用行內 style 動態指定
  // grid-template-rows (weekday 標題列固定高度、其餘週數平分剩餘空間)，這樣週數少的
  // 月份每格會自動長高一點，不會留一大塊空白；桌面版沒有鎖高度，這個 style 不影響版面。
  const wrap = el('div', { class: 'cal-grid', style: `grid-template-rows: auto repeat(${weekRows}, 1fr)` });
  weekdayLabels.forEach((w) => wrap.appendChild(el('div', { class: 'cal-weekday' }, w)));

  const byDate = {};
  calEventsCache.forEach((ev) => { (byDate[ev.event_date] = byDate[ev.event_date] || []).push(ev); });

  cells.forEach((d) => {
    if (!d) { wrap.appendChild(el('div', { class: 'cal-cell empty' })); return; }
    const dateStr = fmtYMD(d);
    const isToday = dateStr === todayStr();
    const isSelected = dateStr === selectedCalDate;
    const dayEvents = byDate[dateStr] || [];
    // 桌面版：完整文字小方塊，最多顯示 3 筆。
    const chips = dayEvents.slice(0, 3).map((ev) => {
      const info = calCategoryInfo(ev.category);
      return el('div', { class: 'cal-chip', style: `background:color-mix(in srgb, ${cssVar(info.colorVar)} 18%, transparent);color:${cssVar(info.colorVar)}` }, ev.title.slice(0, 8));
    });
    // 手機版：原本只顯示色點 (看得出「有幾件事」但看不出是什麼事)，改成比照使用者提供的
    // iPhone 內建行事曆截圖，直接顯示 1 筆事項的精簡文字色塊 (更全面，一眼看到內容)，
    // 超過 1 筆再疊一個「+N」小標籤，點進格子一樣能在底部彈出面板看到當天完整清單。
    const mobileChips = dayEvents.slice(0, 1).map((ev) => {
      const info = calCategoryInfo(ev.category);
      return el('div', { class: 'cal-chip-m', style: `background:color-mix(in srgb, ${cssVar(info.colorVar)} 22%, transparent);color:${cssVar(info.colorVar)}` }, ev.title.slice(0, 5));
    });
    const mobileMore = dayEvents.length > 1 ? el('div', { class: 'cal-more-m' }, `+${dayEvents.length - 1}`) : null;
    // 農曆日期／節氣，比照使用者提供的 iPhone 內建行事曆截圖：節氣是獨立的小標籤，
    // 農曆日期是數字旁邊的小字 (初一/十五/廿三這種)，農曆初一那天顯示月份名而不是「初一」，
    // 這樣掃過去比較容易看出「這個月什麼時候換了新的農曆月份」。
    const lunar = calLunarCache[dateStr];
    wrap.appendChild(el('div', {
      class: `cal-cell${isToday ? ' today' : ''}${isSelected ? ' selected' : ''}`,
      onclick: () => selectCalDate(dateStr),
    }, [
      el('div', { class: 'cal-daynum-row' }, [
        el('div', { class: 'cal-daynum' }, String(d.getDate())),
        lunar && lunar.label ? el('div', { class: 'cal-lunar-label' }, lunar.label) : null,
      ]),
      lunar && lunar.solarTerm ? el('div', { class: 'cal-solarterm-tag' }, lunar.solarTerm) : null,
      el('div', { class: 'cal-chips-desktop' }, [
        ...chips,
        dayEvents.length > 3 ? el('div', { class: 'cal-more' }, `+${dayEvents.length - 3}`) : null,
      ]),
      (mobileChips.length || mobileMore) ? el('div', { class: 'cal-chips-mobile' }, [...mobileChips, mobileMore]) : null,
    ]));
  });
  grid.appendChild(wrap);
}

// 事件清單本體抽成共用函式，桌面版側邊卡片、手機版底部彈出面板都用這份，
// 避免同樣的清單畫法維護兩份、之後改版容易兩邊漏改不一致。
// onEdit 可省略 (例如唯讀情境完全不給編輯功能)。跨模組自動整合進來的項目 (r.readonly)
// 不能刪除/編輯 (資料本體在帳單/待辦/人際關係分頁，這裡只是顯示)，改成一顆「前往查看」
// 按鈕直接切過去那個分頁。
function buildCalDayEventsList(dateStr, onDelete, onEdit) {
  const wrap = el('div', {});
  const events = calEventsCache
    .filter((ev) => ev.event_date === dateStr)
    .sort((a, b) => (a.start_time || '').localeCompare(b.start_time || ''));
  if (!events.length) {
    wrap.appendChild(el('div', { class: 'empty-state' }, '這天還沒有安排行程'));
    return wrap;
  }
  events.forEach((r) => {
    const info = calCategoryInfo(r.category);
    const actions = r.readonly
      ? [el('button', { class: 'btn btn-ghost', onclick: () => switchTab(r.sourceTab) }, '前往查看')]
      : [
          onEdit ? el('button', { class: 'btn btn-ghost', onclick: () => onEdit(r) }, '編輯') : null,
          el('button', { class: 'btn btn-ghost', onclick: () => onDelete(r.id) }, '刪除'),
        ];
    wrap.appendChild(el('div', { style: 'display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid var(--grid-line)' }, [
      el('div', {}, [
        el('span', { class: 'badge', style: `background:color-mix(in srgb, ${cssVar(info.colorVar)} 16%, transparent);color:${cssVar(info.colorVar)};margin-right:8px` }, info.label),
        el('span', { style: 'color:var(--series-blue);font-weight:600;margin-right:8px' }, r.start_time || '全天'),
        el('span', {}, r.title),
        r.recurrence ? el('span', { style: 'font-size:11px;color:var(--text-muted);margin-left:6px' }, `🔁 ${RECURRENCE_LABELS[r.recurrence] || ''}`) : null,
        r.note ? el('div', { style: 'font-size:12px;color:var(--text-muted);margin-top:2px' }, r.note) : null,
      ]),
      el('div', { style: 'display:flex;gap:4px' }, actions),
    ]));
  });
  return wrap;
}

function renderCalDayDetail(dateStr) {
  const title = $('#calDayTitle');
  if (title) title.textContent = `${dateStr} 的行程`;
  const box = $('#calDayDetail');
  if (!box) return;
  box.innerHTML = '';
  box.appendChild(buildCalDayEventsList(dateStr, deleteCalendarEvent, (ev) => startEditCalEvent(ev, '')));
}

// 手機版：點格子或按「＋新增行程」時，用既有的底部彈出面板 (openSheet，跟「更多功能」
// 選單同一套) 呈現「當天清單 + 新增表單」，取代桌面版固定顯示在側邊的那兩張卡片——
// 這樣月曆本體才能鎖住高度、一整頁看完整個月，不用再往下滑。
function isMobileCalendarViewport() {
  return window.matchMedia('(max-width: 760px)').matches;
}

function selectCalDate(dateStr) {
  selectedCalDate = dateStr;
  renderCalMonthGrid();
  renderCalDayDetail(dateStr);
  if (isMobileCalendarViewport()) openCalDaySheet(dateStr);
}

function calJumpToday() {
  const now = new Date();
  calCursor = { year: now.getFullYear(), month: now.getMonth() };
  selectedCalDate = todayStr();
  loadCalendarMonth();
}

function openCalDaySheet(dateStr) {
  const d = new Date(dateStr + 'T00:00:00');
  const weekday = ['日', '一', '二', '三', '四', '五', '六'][d.getDay()];
  openSheet(`${d.getMonth() + 1}月${d.getDate()}日（${weekday}）`, () => buildCalDaySheetBody(dateStr));
}

function buildCalDaySheetBody(dateStr) {
  const wrap = el('div', {}, [
    buildCalDayEventsList(dateStr, (id) => deleteCalendarEventFromSheet(id, dateStr), (ev) => startEditCalEvent(ev, 'sheet', dateStr)),
    el('div', { style: 'margin-top:16px;padding-top:14px;border-top:1px solid var(--border)' }, [
      el('div', { id: 'sheetCalFormTitle', style: 'font-weight:700;margin-bottom:8px;font-size:13px' }, '➕ 新增行程'),
      el('div', { class: 'form-row' }, [
        el('input', { id: 'sheetCalDate', type: 'date', value: dateStr }),
        el('input', { id: 'sheetCalTime', type: 'time' }),
      ]),
      el('input', { id: 'sheetCalTitle', placeholder: '要做什麼事？', style: 'width:100%;margin-top:8px' }),
      el('div', { class: 'form-row', style: 'margin-top:8px' }, [
        el('select', { id: 'sheetCalCategory' }, CALENDAR_CATEGORIES.map((cat) => el('option', { value: cat.key }, cat.label))),
        chipSelectEl({ id: 'sheetCalRecurrence', value: '', options: Object.entries(RECURRENCE_LABELS).map(([k, v]) => ({ value: k, label: v })) }),
      ]),
      el('input', { id: 'sheetCalNote', placeholder: '備註 (選填)', style: 'width:100%;margin-top:8px' }),
      el('div', { style: 'display:flex;gap:8px;margin-top:10px' }, [
        el('button', { id: 'sheetCalSubmitBtn', class: 'btn btn-primary', style: 'flex:1', onclick: () => addCalendarEventFromSheet(dateStr) }, '新增'),
        el('button', { id: 'sheetCalCancelEditBtn', class: 'btn btn-ghost', style: 'display:none', onclick: () => cancelEditCalEvent('sheet', dateStr) }, '取消編輯'),
      ]),
    ]),
  ]);
  return wrap;
}

// ---- 編輯行程：把既有行程的內容載入表單、切換成「更新」模式，兩邊 (桌面側欄／手機
// 底部面板) 共用同一套邏輯，用 idPrefix 區分要操作哪一組表單元素。 ----
function startEditCalEvent(ev, idPrefix) {
  calEditingId = ev.id;
  const pfx = idPrefix; // '' (桌面) 或 'sheet' (手機)
  const idOf = (base) => (pfx ? `${pfx}${base.charAt(0).toUpperCase()}${base.slice(1)}` : base);
  $(`#${idOf('calDate')}`).value = ev.event_date;
  $(`#${idOf('calTime')}`).value = ev.start_time || '';
  $(`#${idOf('calTitle')}`).value = ev.title;
  $(`#${idOf('calCategory')}`).value = ev.category;
  $(`#${idOf('calRecurrence')}`).value = ev.recurrence || '';
  $(`#${idOf('calNote')}`).value = ev.note || '';
  const submitBtn = $(`#${idOf('calSubmitBtn')}`);
  if (submitBtn) submitBtn.textContent = '更新行程';
  const cancelBtn = $(`#${idOf('calCancelEditBtn')}`);
  if (cancelBtn) cancelBtn.style.display = '';
  const formTitle = $(`#${idOf('calFormTitle')}`);
  if (formTitle) formTitle.textContent = '✏️ 編輯行程';
  if (pfx === 'sheet') showToast('已載入這筆行程，改好後按「更新行程」');
}

function cancelEditCalEvent(idPrefix) {
  calEditingId = null;
  const pfx = idPrefix;
  const idOf = (base) => (pfx ? `${pfx}${base.charAt(0).toUpperCase()}${base.slice(1)}` : base);
  const submitBtn = $(`#${idOf('calSubmitBtn')}`);
  if (submitBtn) submitBtn.textContent = '新增';
  const cancelBtn = $(`#${idOf('calCancelEditBtn')}`);
  if (cancelBtn) cancelBtn.style.display = 'none';
  const formTitle = $(`#${idOf('calFormTitle')}`);
  if (formTitle) formTitle.textContent = pfx === 'sheet' ? '➕ 新增行程' : '新增行程';
  [`${idOf('calTitle')}`, `${idOf('calNote')}`, `${idOf('calTime')}`].forEach((id) => { const elx = $(`#${id}`); if (elx) elx.value = ''; });
  const recEl = $(`#${idOf('calRecurrence')}`);
  if (recEl) recEl.value = '';
}

async function addCalendarEventFromSheet(dateStr) {
  const body = {
    event_date: $('#sheetCalDate').value,
    start_time: $('#sheetCalTime').value,
    title: $('#sheetCalTitle').value.trim(),
    note: $('#sheetCalNote').value.trim(),
    category: $('#sheetCalCategory').value,
    recurrence: $('#sheetCalRecurrence').value || undefined,
  };
  if (!body.event_date || !body.title) { showToast('請至少填日期與事項'); return; }
  try {
    if (calEditingId) {
      await api(`/calendar/${calEditingId}`, { method: 'PUT', body });
      showToast('已更新行程');
      calEditingId = null;
    } else {
      await api('/calendar', { method: 'POST', body });
      showToast('已新增行程');
    }
    if (body.event_date.slice(0, 7) === fmtYMD(new Date(calCursor.year, calCursor.month, 1)).slice(0, 7)) {
      selectedCalDate = body.event_date;
    }
    await loadCalendarMonth();
    openCalDaySheet(selectedCalDate); // 重新整理面板內容，順便切到剛新增/編輯那天
  } catch (e) { showToast((calEditingId ? '更新失敗: ' : '新增失敗: ') + e.message); }
}

async function deleteCalendarEventFromSheet(id, dateStr) {
  await api(`/calendar/${id}`, { method: 'DELETE' });
  await loadCalendarMonth();
  openCalDaySheet(dateStr);
}

async function addCalendarEvent() {
  const body = {
    event_date: $('#calDate').value,
    start_time: $('#calTime').value,
    title: $('#calTitle').value.trim(),
    note: $('#calNote').value.trim(),
    category: $('#calCategory').value,
    recurrence: $('#calRecurrence').value || undefined,
  };
  if (!body.event_date || !body.title) { showToast('請至少填日期與事項'); return; }
  try {
    if (calEditingId) {
      await api(`/calendar/${calEditingId}`, { method: 'PUT', body });
      showToast('已更新行程');
      cancelEditCalEvent('');
    } else {
      await api('/calendar', { method: 'POST', body });
      $('#calTitle').value = ''; $('#calNote').value = ''; $('#calTime').value = ''; $('#calRecurrence').value = '';
      showToast('已新增行程');
    }
    if (body.event_date.slice(0, 7) === fmtYMD(new Date(calCursor.year, calCursor.month, 1)).slice(0, 7)) {
      selectedCalDate = body.event_date;
    }
    loadCalendarMonth();
  } catch (e) { showToast((calEditingId ? '更新失敗: ' : '新增失敗: ') + e.message); }
}
async function deleteCalendarEvent(id) {
  if (calEditingId === id) cancelEditCalEvent('');
  await api(`/calendar/${id}`, { method: 'DELETE' });
  loadCalendarMonth();
}

// ---------- 行事曆訂閱 (.ics)：讓 Apple/Google 行事曆可以直接訂閱 ----------
function icsUrlFromToken(token) {
  return `${location.origin}/api/calendar/export.ics?token=${token}`;
}

async function loadIcsTokenStatus() {
  const box = $('#icsUrlBox');
  if (!box) return;
  try {
    const { token } = await api('/calendar/ics-token');
    renderIcsTokenUI(token);
  } catch (e) {
    box.textContent = '載入失敗：' + e.message;
  }
}

function renderIcsTokenUI(token) {
  const box = $('#icsUrlBox');
  const genBtn = $('#icsGenBtn');
  const copyBtn = $('#icsCopyBtn');
  const revokeBtn = $('#icsRevokeBtn');
  if (!box) return;
  if (token) {
    box.textContent = icsUrlFromToken(token);
    box.style.wordBreak = 'break-all';
    if (genBtn) genBtn.style.display = 'none';
    if (copyBtn) copyBtn.style.display = '';
    if (revokeBtn) revokeBtn.style.display = '';
  } else {
    box.textContent = '目前還沒有產生訂閱網址';
    if (genBtn) genBtn.style.display = '';
    if (copyBtn) copyBtn.style.display = 'none';
    if (revokeBtn) revokeBtn.style.display = 'none';
  }
}

async function generateIcsToken() {
  try {
    const { token } = await api('/calendar/ics-token', { method: 'POST' });
    renderIcsTokenUI(token);
    showToast('已產生訂閱網址，按下面「複製網址」貼到行事曆 App 裡');
  } catch (e) { showToast('產生失敗：' + e.message); }
}

async function copyIcsUrl() {
  const box = $('#icsUrlBox');
  if (!box) return;
  try {
    await navigator.clipboard.writeText(box.textContent);
    showToast('已複製到剪貼簿');
  } catch (e) { showToast('複製失敗，請手動選取文字複製'); }
}

async function revokeIcsToken() {
  try {
    await api('/calendar/ics-token/revoke', { method: 'POST' });
    renderIcsTokenUI(null);
    showToast('已停用這組訂閱網址');
  } catch (e) { showToast('停用失敗：' + e.message); }
}

// ===================== AI 助理 =====================
// 對話記錄改存資料庫 (見 /api/assistant/history)，重新整理頁面或換裝置登入都還在，
// 不再只是瀏覽器記憶體裡的暫時變數。
if (!state.assistantHistory) state.assistantHistory = [];
const ASSISTANT_SUGGESTIONS = ['幫我規劃這週的行程', '推薦一道今晚的晚餐食譜', '把這段文字翻譯成英文', '解釋一下這筆記帳該歸哪個分類'];
// v0.30.0 重新設計：拿掉浮起來的大卡片、光暈圓球、漸層對話泡泡，改成跟首頁同一套
// 「乾淨、有空間感」的視覺語言——細線分隔取代陰影卡片，顏色收斂成黑白灰+一點點主色，
// 版面本身直接用首頁那個 .dash-unified 容器 (單欄、置中、720px 上限)，兩個分頁看起來
// 才會像同一個系統設計出來的，而不是各自獨立的兩種風格。
function renderAssistant() {
  const c = $('#tab-assistant');
  c.innerHTML = '';
  const wrap = el('div', { class: 'dash-unified assistant-clean' });

  wrap.appendChild(el('div', { class: 'dash-hero-eyebrow' }, 'AI 助理'));
  wrap.appendChild(el('div', { class: 'assistant-clean-title' }, '有什麼想聊的嗎？'));
  wrap.appendChild(el('div', { class: 'dash-hero-sub' }, '生活規劃、旅遊行程、記帳建議、翻譯、食譜、單位換算——什麼都可以問，對話記錄會保存在你的帳號裡，換裝置登入也看得到。'));

  wrap.appendChild(el('div', { class: 'assistant-clean-suggest-row' }, ASSISTANT_SUGGESTIONS.map((s) =>
    el('span', { class: 'assistant-clean-chip', onclick: () => { $('#assistantInput').value = s; $('#assistantInput').focus(); } }, s)
  )));

  wrap.appendChild(el('div', { class: 'dash-section-title-row' }, [
    el('div', { class: 'dash-section-title' }, '對話'),
    el('button', { class: 'dash-section-action', onclick: clearAssistantHistory }, '🗑️ 清除對話'),
  ]));
  wrap.appendChild(el('div', { id: 'assistantMessages', class: 'chat-box assistant-clean-box' }, el('div', { class: 'empty-state' }, '載入中...')));
  wrap.appendChild(el('div', { class: 'dash-hero-ask assistant-clean-ask' }, [
    el('input', { id: 'assistantInput', placeholder: '輸入訊息，按 Enter 送出', onkeydown: (ev) => { if (ev.key === 'Enter') sendAssistantMessage(); } }),
    el('button', { class: 'btn btn-primary', onclick: sendAssistantMessage }, '送出'),
  ]));

  c.appendChild(wrap);
  loadAssistantHistory();
}
async function loadAssistantHistory() {
  try {
    state.assistantHistory = await api('/assistant/history');
  } catch (e) {
    state.assistantHistory = [];
  }
  renderAssistantMessages();
}
async function clearAssistantHistory() {
  try {
    await api('/assistant/history', { method: 'DELETE' });
    state.assistantHistory = [];
    renderAssistantMessages();
    showToast('已清除對話記錄');
  } catch (e) { showToast('清除失敗: ' + e.message); }
}
function renderAssistantMessages() {
  const box = $('#assistantMessages');
  if (!box) return;
  box.innerHTML = '';
  if (!state.assistantHistory.length) {
    box.appendChild(el('div', { class: 'empty-state' }, '還沒有對話，輸入訊息開始聊天吧'));
    return;
  }
  state.assistantHistory.forEach((m) => {
    box.appendChild(el('div', { class: 'chat-msg ' + (m.role === 'user' ? 'chat-user' : 'chat-ai') }, m.content));
    // AI 判斷使用者提到一件值得記錄的具體待辦事項時 (見 src/services/assistant.js 的
    // TASK_SUGGESTION 標記機制)，在這則訊息底下加一張確認卡片——一定要使用者自己按
    // 「加入待辦」才會真的呼叫建立任務的 API，AI 本身沒有能力直接幫忙新增任何東西。
    if (m.suggestedTask) {
      box.appendChild(renderTaskSuggestionCard(m));
    }
  });
  box.scrollTop = box.scrollHeight;
}

// 把「距離現在 X 秒」轉成人看得懂的敘述 (幾秒/幾分鐘/幾小時後)，給提醒確認卡片跟 toast 用。
function formatRelativeReminder(remindAtIso) {
  const diffMs = new Date(remindAtIso).getTime() - Date.now();
  const secs = Math.max(1, Math.round(diffMs / 1000));
  if (secs < 60) return `${secs} 秒後`;
  if (secs < 3600) return `${Math.round(secs / 60)} 分鐘後`;
  return `${Math.round(secs / 3600)} 小時後`;
}

function renderTaskSuggestionCard(m) {
  const t = m.suggestedTask;
  const parts = [`📌 要不要把這件事加入待辦事項：「${t.title}」`];
  if (t.remindAt) parts.push(`，並在 ${formatRelativeReminder(t.remindAt)}推播提醒你`);
  else if (t.dueDate) parts.push(`（${t.dueDate}）`);
  return el('div', { class: 'task-suggestion-card' }, [
    el('div', { class: 'task-suggestion-text' }, parts.join('')),
    t.remindAt ? el('div', { class: 'hint', style: 'margin-top:2px' }, '⏰ 如果還沒開啟背景推播通知，提醒可能不會準時跳出，可以去「個人化設定」開啟。') : null,
    el('div', { class: 'task-suggestion-actions' }, [
      el('button', { class: 'btn btn-primary', style: 'font-size:12px', onclick: () => confirmSuggestedTask(m) }, '✅ 加入待辦'),
      el('button', { class: 'btn btn-ghost', style: 'font-size:12px', onclick: () => dismissSuggestedTask(m) }, '不用了'),
    ]),
  ]);
}

async function confirmSuggestedTask(m) {
  try {
    await api('/tasks', { method: 'POST', body: { title: m.suggestedTask.title, dueDate: m.suggestedTask.dueDate || null, remindAt: m.suggestedTask.remindAt || null } });
    showToast(m.suggestedTask.remindAt ? `已加入待辦事項，${formatRelativeReminder(m.suggestedTask.remindAt)}會提醒你` : '已加入待辦事項');
  } catch (e) {
    showToast('加入失敗：' + e.message);
  }
  m.suggestedTask = null;
  renderAssistantMessages();
}

function dismissSuggestedTask(m) {
  m.suggestedTask = null;
  renderAssistantMessages();
}

async function sendAssistantMessage() {
  const input = $('#assistantInput');
  const text = input.value.trim();
  if (!text) return;
  state.assistantHistory.push({ role: 'user', content: text });
  input.value = '';
  renderAssistantMessages();
  try {
    const res = await api('/assistant/chat', { method: 'POST', body: { message: text } });
    state.assistantHistory.push({ role: 'assistant', content: res.reply, suggestedTask: res.suggestedTask || null });
    renderAssistantMessages();
  } catch (e) {
    state.assistantHistory.push({ role: 'assistant', content: '發生錯誤: ' + e.message });
    renderAssistantMessages();
  }
}

// ===================== 心情陪伴 =====================
// v0.31.0 重新設計：原本是「鎖在螢幕高度內的三欄儀表板」，11 張卡片同時擠在畫面上，
// 兩欄各自要獨立捲動才看得完，是典型的「硬塞進去、空間很小」。改成跟首頁/AI助理同一種
// 單欄、有呼吸感的版面，並用分頁籤把功能分成四組——每次只看一組，找東西不用在一堆卡片
// 裡面大海撈針，但完整功能一個都沒有拿掉。
const MOOD_TAGS = ['焦慮', '疲憊', '開心', '平靜', '煩躁', '難過', '有動力', '孤單'];
const moodState = { selectedScore: null, selectedTags: new Set(), chatHistory: null };
const MOOD_VIEW_TABS = [
  { key: 'today', label: '今天' },
  { key: 'thoughtwork', label: '想法練習' },
  { key: 'cycle', label: '生理週期' },
  { key: 'review', label: '回顧與洞察' },
];
let moodViewTab = 'today';

function switchMoodViewTab(tab) {
  moodViewTab = tab;
  renderMood();
}

// 「寫想法記錄」快捷按鈕過去是把畫面捲到深工具欄，現在改分頁籤了，改成切到「想法練習」
// 分頁再把游標帶到念頭欄位，體感上還是「按一下就到得了」。
function goToThoughtRecordTool() {
  switchMoodViewTab('thoughtwork');
  setTimeout(() => { const t = $('#trThought'); if (t) t.focus(); }, 50);
}

function renderMood() {
  const c = $('#tab-mood');
  c.innerHTML = '';
  moodState.selectedScore = null;
  moodState.selectedTags = new Set();

  const checkinCard = el('div', { class: 'card' }, [
    el('h3', {}, [el('div', { class: 'hex-badge' }, '💗'), '今天的你感覺怎麼樣？']),
    el('p', { class: 'hint' }, '點一個最貼近現在的分數，標籤跟備註都是選填。也可以往前選日期，補記錄過去幾天的心情。'),
    el('div', { class: 'form-row', style: 'margin-bottom:8px' }, [
      el('input', { id: 'moodEntryDate', type: 'date', max: todayStr(), value: todayStr(), onchange: onMoodEntryDateChange }),
      el('span', { id: 'moodEntryDateLabel', class: 'hint', style: 'margin:0;align-self:center' }, '今天'),
    ]),
    el('div', { class: 'mood-score-row', id: 'moodScoreRow' }),
    el('div', { class: 'mood-tag-row', id: 'moodTagRow' }),
    el('input', { id: 'moodNote', placeholder: '想多寫一點也可以，這裡沒有人會評論你 (選填)' }),
    el('div', { style: 'margin-top:8px' }, [
      el('p', { class: 'hint', style: 'margin:0 0 6px' }, '今天天氣 (選填)：'),
      chipSelectEl({
        id: 'moodWeatherSelect', value: '',
        options: [
          { value: '', label: '不特別記錄' },
          { value: 'sunny', label: '☀️ 晴天' },
          { value: 'cloudy', label: '☁️ 陰天' },
          { value: 'rainy', label: '🌧️ 雨天' },
          { value: 'cold', label: '🥶 寒冷' },
          { value: 'hot', label: '🥵 悶熱' },
        ],
      }),
    ]),
    el('div', { style: 'margin-top:12px;display:flex;gap:8px;flex-wrap:wrap' }, [
      el('button', { class: 'btn btn-primary', id: 'moodSaveBtn', onclick: saveMoodEntry }, '儲存今天的紀錄'),
      el('button', { class: 'btn btn-ghost', onclick: suggestMoodTechnique }, '給我一個能馬上試試看的小技巧'),
    ]),
    el('div', { id: 'moodTechniqueBody' }),
  ]);

  const cycleCard = el('div', { class: 'card', style: 'margin-bottom:0' }, [
    el('h3', {}, '🌙 生理週期（選填功能，想追蹤再填就好）'),
    el('p', { class: 'hint' }, '記錄每次月經開始的日期，系統就能大概估算你現在在哪個階段，也會讓上面的關心訊息跟趨勢分析更貼近你的狀態（不記錄完全不影響其他功能）。'),
    el('div', { id: 'cycleStatusBody' }, el('div', { class: 'empty-state' }, '載入中...')),
    el('div', { class: 'form-row', style: 'margin-top:10px' }, [
      el('input', { id: 'cycleStartDate', type: 'date', value: todayStr() }),
      el('input', { id: 'cycleEndDate', type: 'date', placeholder: '結束日 (選填)' }),
    ]),
    chipSelectEl({
      id: 'cycleTrackingFor', variant: 'segmented', value: 'self', style: 'margin-top:8px',
      options: [{ value: 'self', label: '記錄自己的' }, { value: 'partner', label: '幫另一半記錄' }],
    }),
    el('p', { class: 'hint', style: 'margin-top:4px' }, '結束日選填，多填這個之後，經期天數跟排卵期推算會更準；不填的話系統會用預設的 5 天估算。'),
    el('input', { id: 'cycleNote', placeholder: '想順便記點什麼嗎？(選填，例如：這次經痛比較明顯)', style: 'width:100%;margin-top:8px' }),
    el('button', { class: 'btn btn-ghost', style: 'margin-top:8px', onclick: saveCycleEntry }, '記錄這次月經開始'),
    el('p', { class: 'hint', style: 'margin-top:6px' }, '選「幫另一半記錄」的話，這筆資料只會拿來提醒你、不會混進你自己的心情分析，會顯示在「陪伴另一半」那個分頁裡。'),
    el('button', { class: 'btn btn-ghost', style: 'font-size:12px;margin-top:8px', onclick: toggleCycleHistory }, '查看/管理紀錄'),
    el('div', { id: 'cycleHistoryList', style: 'display:none;margin-top:8px' }),
  ]);

  // v0.65：mood-trend-mild / mood-trend-concern / mood-social-checkin 這幾種洞察，之前算出來
  // 後沒地方顯示 (首頁的「主動式提醒」區塊已經整個移除)，這裡在心情分頁最上面顯示。
  const moodInsightAlerts = el('div', { id: 'moodInsightAlerts' });

  const patternsCard = el('div', { class: 'card mood-insight-card', style: 'margin-bottom:0' }, [
    el('h3', {}, '🧩 你的長期規律'),
    el('p', { class: 'hint' }, '把你的心情、行程、記帳、日記這幾份紀錄放在一起看，累積得夠多之後，幫你找出「什麼情況下你的心情通常會變好或變差」這種你自己可能沒發現的規律。'),
    el('button', { class: 'btn btn-ghost', onclick: refreshMoodPatterns }, '重新分析'),
    el('div', { id: 'moodPatternsBody', style: 'margin-top:10px' }, el('div', { class: 'empty-state' }, '載入中...')),
  ]);

  // v0.70：心情 x 天氣關聯——天氣是使用者自己在上面「今天天氣」選單標記的 (不接氣象 API)，
  // 累積夠多筆才會顯示，避免只記錄過一兩次就下結論。
  const weatherCard = el('div', { class: 'card', style: 'margin-bottom:0' }, [
    el('h3', {}, '🌦️ 心情 x 天氣'),
    el('p', { class: 'hint' }, '把你在「今天」分頁順手標記的天氣，跟當天的心情分數放在一起看平均值，樣本太少 (少於 3 筆) 的天氣類別不會顯示，避免只記過一兩次就下結論。'),
    el('div', { id: 'moodWeatherCorrelationBody' }, el('div', { class: 'empty-state' }, '載入中...')),
  ]);

  const monthlyReviewCard = el('div', { class: 'card', style: 'margin-bottom:0' }, [
    el('h3', {}, '📅 這個月的 AI 回顧'),
    el('p', { class: 'hint' }, '把這個月記錄的心情資料交給 AI，幫你寫一段完整一點的月度回顧，像是月底的一份小總結。'),
    el('button', { class: 'btn btn-ghost', onclick: generateMoodMonthlyReview }, '產生本月回顧'),
    el('div', { id: 'moodMonthlyReviewBody' }),
  ]);

  const thoughtRecordCard = el('div', { class: 'card thought-record-card', style: 'margin-bottom:0' }, [
    el('h3', {}, '🧠 卡住的時候：換個角度想想看'),
    el('p', { class: 'hint' }, '這是一個簡單的自助練習，不是正式心理治療：先寫下讓你不舒服的念頭，再想想有什麼理由支持它、有什麼理由不支持它，最後試著寫出一個比較平衡一點的說法。不知道怎麼寫也沒關係，可以請 AI 幫忙想。'),
    el('div', { class: 'thought-record-form' }, [
      el('div', { class: 'thought-record-row2' }, [
        el('input', { id: 'trSituation', list: 'trSituationList', placeholder: '發生了什麼事？(選填)' }),
        el('input', { id: 'trEmotion', list: 'trEmotionList', placeholder: '當下的情緒是什麼？(選填，例如：焦慮)' }),
      ]),
      el('datalist', { id: 'trSituationList' }),
      el('datalist', { id: 'trEmotionList' }),
      el('textarea', { id: 'trThought', rows: 2, placeholder: '腦中冒出來的念頭是什麼？(例如：他一定討厭我了)' }),
      el('div', { class: 'thought-record-row2' }, [
        el('textarea', { id: 'trEvidenceFor', rows: 1, placeholder: '有什麼理由讓你覺得這個念頭是真的？(選填)' }),
        el('textarea', { id: 'trEvidenceAgainst', rows: 1, placeholder: '有什麼理由讓你覺得不一定是真的？(選填)' }),
      ]),
      el('div', { class: 'thought-record-row2' }, [
        el('textarea', { id: 'trReframe', rows: 2, placeholder: '比較平衡一點的說法會是什麼？(可以自己寫，也可以請 AI 幫忙)' }),
        el('div', { class: 'thought-record-intensity-row' }, [
          el('span', { class: 'hint', style: 'margin:0' }, '現在還有多相信這個念頭：'),
          el('input', { id: 'trIntensity', type: 'number', min: '1', max: '10', placeholder: '1-10', style: 'width:66px;padding:6px 4px;text-align:center' }),
        ]),
      ]),
      el('div', { style: 'display:flex;gap:8px;flex-wrap:wrap;margin-top:2px' }, [
        el('button', { class: 'btn btn-ghost', onclick: suggestThoughtReframe }, '請 AI 幫我想一句'),
        el('button', { class: 'btn btn-primary', onclick: saveThoughtRecord }, '儲存這筆記錄'),
      ]),
    ]),
    el('div', { id: 'thoughtRecordList', class: 'coping-note-list', style: 'margin-top:12px' }, el('div', { class: 'empty-state' }, '載入中...')),
  ]);

  const trendCard = el('div', { class: 'card', style: 'margin-bottom:0' }, [
    el('h3', {}, '📈 心情趨勢 (近 30 天)'),
    el('div', { id: 'moodTrendChart' }, el('div', { class: 'empty-state' }, '載入中...')),
  ]);

  const insightsCard = el('div', { class: 'card mood-insight-card', style: 'margin-bottom:0' }, [
    el('h3', {}, '🔎 心情跟行程有沒有關聯'),
    el('div', { id: 'moodInsightBody' }, el('div', { class: 'empty-state' }, '載入中...')),
  ]);

  const weeklyReviewCard = el('div', { class: 'card', style: 'margin-bottom:0' }, [
    el('h3', {}, '🗓️ 這週的 AI 回顧'),
    el('p', { class: 'hint' }, '把這週記錄的心情資料交給 AI，幫你寫一段像朋友寫給你的小卡片。'),
    el('button', { class: 'btn btn-ghost', onclick: generateMoodWeeklyReview }, '產生本週回顧'),
    el('div', { id: 'moodWeeklyReviewBody' }),
  ]);

  const toolboxCard = el('div', { class: 'card', style: 'margin-bottom:0' }, [
    el('h3', {}, '🧰 我的因應工具箱'),
    el('p', { class: 'hint' }, '根據你之前對這些技巧的回饋 (有沒有用、喜不喜歡)，整理出對你來說最有效的幾個，之後心情不好可以直接用這幾個，不用每次都重新摸索。'),
    el('div', { id: 'moodToolboxBody' }, el('div', { class: 'empty-state' }, '載入中...')),
  ]);

  const copingNotesCard = el('div', { class: 'card', style: 'margin-bottom:0' }, [
    el('h3', {}, '🍃 安心小卡'),
    el('p', { class: 'hint' }, '收藏一句對你有用的話，心情不好的時候可以回來翻一翻，提醒自己。'),
    el('div', { class: 'coping-note-add-row' }, [
      el('input', { id: 'copingNoteInput', placeholder: '寫一句想留給自己的話...', onkeydown: (ev) => { if (ev.key === 'Enter') addCopingNote(); } }),
      el('button', { class: 'btn btn-primary', onclick: addCopingNote }, '新增'),
    ]),
    el('div', { id: 'copingNoteList', class: 'coping-note-list' }, el('div', { class: 'empty-state' }, '載入中...')),
  ]);

  const chatCard = el('div', { class: 'card mood-chat-card mood-chat-companion' }, [
    el('div', { class: 'mood-chat-avatar' }, '🌱'),
    el('div', { style: 'text-align:center;margin-bottom:4px' }, [
      el('h3', { style: 'justify-content:center;margin-bottom:2px' }, 'AI 心靈對話室'),
      el('p', { class: 'hint', style: 'margin-bottom:0' }, '隨時可以來聊聊，這裡是陪伴傾聽，不是正式的心理治療；如果你正在經歷緊急的心理危機，請直接撥打 119，或聯絡安心專線 1925、生命線 1995（皆 24 小時）、張老師專線 1980（日間）。'),
    ]),
    el('div', { id: 'moodChatMessages', class: 'chat-box', style: 'margin-top:10px' }, el('div', { class: 'empty-state' }, '載入中...')),
    el('div', { class: 'form-row' }, [
      el('input', { id: 'moodChatInput', placeholder: '想說什麼都可以，按 Enter 送出', onkeydown: (ev) => { if (ev.key === 'Enter') sendMoodChatMessage(); } }),
      el('button', { class: 'btn btn-primary', onclick: sendMoodChatMessage }, '送出'),
    ]),
    el('div', { style: 'text-align:center;margin-top:8px' }, [
      el('button', { class: 'btn btn-ghost', style: 'font-size:12px', onclick: clearMoodChatHistory }, '🗑️ 清除對話'),
    ]),
  ]);

  const statsCard = el('div', { class: 'card', style: 'margin-bottom:0' }, [
    el('h3', {}, '📊 情緒健康報告'),
    el('div', { id: 'moodStatsGrid', class: 'mood-stat-grid' }, el('div', { class: 'empty-state' }, '載入中...')),
  ]);
  const diaryCard = el('div', { class: 'card', style: 'margin-bottom:0' }, [
    el('h3', {}, '📔 今天的日記'),
    el('div', { id: 'moodDiaryLink' }, el('div', { class: 'empty-state' }, '載入中...')),
  ]);

  // v0.37 調整：求助專線原本用一顆固定徽章「🚨 需要協助？」放在最上面、四個分頁籤共用，
  // 常常跟旁邊的「🔔 開啟瀏覽器提醒」擠在一起換行、看起來很擠。實際上求助資訊真正需要出現
  // 的地方是「今天」分頁的 AI 心靈對話室（使用者情緒低落、正在跟 AI 聊的當下），已經把完整
  // 專線號碼寫進那張卡片的說明文字裡了，所以這裡不用再重複佔用空間，其他分頁 (想法練習/
  // 生理週期/回顧與洞察) 也不用一直背著跟自己內容無關的求助徽章。
  c.appendChild(el('div', { class: 'mood-dash-topline' }, [
    el('div', { class: 'mood-dash-topline-title' }, [
      el('div', { id: 'moodCareBanner', class: 'mood-dash-care' }),
    ]),
    el('div', { class: 'mood-dash-topline-right' }, [
      // v0.87：已經允許或拒絕過通知的人不用一直看到這顆按鈕
      ('Notification' in window && Notification.permission === 'default')
        ? el('button', { class: 'btn btn-ghost', style: 'font-size:12px', onclick: enableMoodBrowserNotification }, '🔔 開啟瀏覽器提醒')
        : null,
    ]),
  ]));

  const moodWrap = el('div', { class: 'mood-clean-wrap' });
  moodWrap.appendChild(el('div', { class: 'task-view-tabs' }, MOOD_VIEW_TABS.map((t) =>
    el('button', { class: `task-view-tab${moodViewTab === t.key ? ' active' : ''}`, onclick: () => switchMoodViewTab(t.key) }, t.label)
  )));

  const sections = el('div', { class: 'mood-clean-sections' });
  if (moodViewTab === 'today') {
    sections.appendChild(moodInsightAlerts);
    sections.appendChild(checkinCard);
    sections.appendChild(chatCard);
    sections.appendChild(copingNotesCard);
  } else if (moodViewTab === 'thoughtwork') {
    sections.appendChild(thoughtRecordCard);
    sections.appendChild(toolboxCard);
  } else if (moodViewTab === 'cycle') {
    sections.appendChild(cycleCard);
  } else if (moodViewTab === 'review') {
    sections.appendChild(trendCard);
    sections.appendChild(statsCard);
    sections.appendChild(insightsCard);
    sections.appendChild(patternsCard);
    sections.appendChild(weatherCard);
    sections.appendChild(weeklyReviewCard);
    sections.appendChild(monthlyReviewCard);
    sections.appendChild(diaryCard);
  }
  moodWrap.appendChild(sections);
  c.appendChild(moodWrap);

  if (moodViewTab === 'today') {
    const scoreRow = $('#moodScoreRow');
    for (let i = 1; i <= 10; i++) {
      scoreRow.appendChild(el('button', { class: 'mood-score-btn', 'data-score': i, onclick: () => selectMoodScore(i) }, String(i)));
    }
    const tagRow = $('#moodTagRow');
    MOOD_TAGS.forEach((tag) => {
      tagRow.appendChild(el('button', { class: 'mood-tag-chip', 'data-tag': tag, onclick: () => toggleMoodTag(tag) }, tag));
    });
    loadMoodToday();
    loadMoodChatHistory();
    loadCopingNotes();
    loadTabInsightAlerts('moodInsightAlerts', ['mood-trend-mild', 'mood-trend-concern', 'mood-social-checkin']);
  } else if (moodViewTab === 'thoughtwork') {
    loadThoughtRecords();
    loadMoodToolbox();
  } else if (moodViewTab === 'cycle') {
    loadCycleStatus();
  } else if (moodViewTab === 'review') {
    loadMoodTrend();
    loadMoodDiaryLink();
    loadMoodInsights();
    loadMoodPatterns();
    loadMoodWeatherCorrelation();
  }
}

const MOOD_WEATHER_LABEL = { sunny: '☀️ 晴天', cloudy: '☁️ 陰天', rainy: '🌧️ 雨天', cold: '🥶 寒冷', hot: '🥵 悶熱' };
async function loadMoodWeatherCorrelation() {
  const body = $('#moodWeatherCorrelationBody');
  if (!body) return;
  try {
    const res = await api('/mood/weather-correlation');
    body.innerHTML = '';
    if (!res.hasEnoughData) {
      body.appendChild(el('div', { class: 'empty-state' }, '目前累積的天氣標記還不夠多，多記錄幾天再回來看看。'));
      return;
    }
    res.results.forEach((r) => {
      body.appendChild(el('div', { class: 'mood-signal-item' },
        `${MOOD_WEATHER_LABEL[r.weather] || r.weather}：平均 ${r.avgScore} 分（${r.count} 筆紀錄）`));
    });
  } catch (e) {
    body.innerHTML = '';
    body.appendChild(el('div', { class: 'empty-state' }, '載入失敗：' + e.message));
  }
}

// ---------- 生理週期 (選填) ----------
const CYCLE_PHASE_LABEL = { menstrual: '月經期', follicular: '濾泡期', ovulation: '排卵期', luteal: '黃體期', late: '超過預估日期', stale: '紀錄太久沒更新' };
const CYCLE_REGULARITY_LABEL = {
  regular: '規律（最近幾次的週期長度都差不多）',
  medium: '大致規律（有一點自然波動）',
  variable: '波動比較大（每次長度差異不小，預估日期參考就好）',
};
// v0.81：遲到天數 → 給「自己檢視」的分層文案。重點是把「差幾天很正常」講在前面，
// 不要讓 App 變成另一個焦慮來源；拖比較久才慢慢往「要不要驗一下/看醫生」推進，
// 而且都是「可以考慮」的語氣，決定權在使用者自己。
function cycleLateSelfCopy(daysLate) {
  if (daysLate <= 3) return '晚個幾天非常常見，壓力、睡眠、運動量的變化都會影響，先不用特別做什麼。';
  if (daysLate <= 7) return '一週內的波動仍在常見範圍。值得知道的是：焦慮本身就會讓月經更晚來，愈平常心通常愈快恢復。';
  if (daysLate <= 14) return '已經超過一週了。如果有懷孕的可能，可以考慮驗一下；沒有的話也不用太緊張，偶爾一次週期特別長是常見的，但如果連續好幾個週期都這樣，建議找婦產科聊聊。';
  return '已經超過兩週。如果還沒驗孕，建議驗一下；不論結果如何，這種長度的延遲值得找婦產科看一次，讓專業的來判斷，不要自己瞎猜。';
}
// 週期狀態顯示共用：自己 (Mood 頁) 跟另一半 (Partner Care 頁) 的呈現方式幾乎一樣，抽出來共用，
// 兩邊都能顯示「目前階段、距離下次月經天數與明確日期、易孕期範圍」，不用各寫一份。
function renderCycleStatusDetail(area, status, opts = {}) {
  // ---- 太久沒記錄：推算暫停 ----
  if (status.isStale) {
    area.appendChild(el('p', {}, `上次記錄的經期開始日已經是 ${status.daysSinceLastPeriod} 天前，超出可以合理推算的範圍，估算先暫停。`));
    area.appendChild(el('p', { class: 'hint', style: 'margin-top:4px' }, '比較可能是這段時間忘了記錄。記一次最近的經期開始日，推算就會重新開始。'));
    if (opts.extraNode) area.appendChild(opts.extraNode);
    return;
  }
  // ---- 遲到：預估日期已過，不再假裝新週期開始 ----
  if (status.isLate) {
    area.appendChild(el('p', {}, `預估的月經日期（${status.predictedNextDate}，前後約 ±${status.rangeDays} 天）已經過了 ${status.daysLate} 天，還沒有記錄新的開始日。`));
    area.appendChild(el('p', { class: 'hint', style: 'margin-top:6px;line-height:1.7' }, cycleLateSelfCopy(status.daysLate)));
    area.appendChild(el('p', { class: 'hint', style: 'margin-top:4px' }, '📍 這個週期實際比預估長，排卵日跟易孕期的推算也跟著失準了，等記錄到新的開始日之後會重新校正。'));
    if (opts.extraNode) area.appendChild(opts.extraNode);
    return;
  }
  // ---- 正常範圍 ----
  const phaseLabel = CYCLE_PHASE_LABEL[status.phase] || status.phase;
  const pmsNote = status.isPmsWindow ? '（經前觀察窗）' : '';
  const fertileNote = status.isFertileWindow ? '（目前正在估算的易孕期內）' : '';
  area.appendChild(el('p', {}, `目前估計在「${phaseLabel}」${pmsNote}${fertileNote} · 距離下次月經約 ${status.daysUntilNextPeriod} 天（預估 ${status.nextPeriodDate}，前後約 ±${status.rangeDays} 天）`));
  if (status.regularity && CYCLE_REGULARITY_LABEL[status.regularity]) {
    area.appendChild(el('p', { class: 'hint', style: 'margin-top:4px' }, `週期規律度：${CYCLE_REGULARITY_LABEL[status.regularity]}`));
  }
  if (status.fertileWindowStart && status.fertileWindowEnd) {
    area.appendChild(el('p', { class: 'hint', style: 'margin-top:4px' }, `📍 這個週期估算的易孕期：${status.fertileWindowStart} ～ ${status.fertileWindowEnd}（排卵日約 ${status.ovulationDateEstimate}，是概略估算，不是精準避孕/助孕依據）`));
  }
  if (!status.hasEnoughDataForAvg) {
    area.appendChild(el('p', { class: 'hint', style: 'margin-top:4px' }, '目前用預設 28 天週期估算，多記錄幾次會愈來愈準。'));
  }
  if (opts.extraNode) area.appendChild(opts.extraNode);
}
async function loadCycleStatus() {
  const area = $('#cycleStatusBody');
  if (!area) return;
  try {
    const status = await api('/mood/cycle/status');
    area.innerHTML = '';
    if (!status.hasData) {
      // 自己沒有紀錄，不代表「幫另一半記錄」的資料也不見了——那份資料在「陪伴另一半」分頁，
      // 這裡順便檢查一下，如果有的話給個明確的入口，避免使用者以為紀錄或推算不見了。
      try {
        const partnerStatus = await api('/mood/cycle/partner-status');
        if (partnerStatus.hasData) {
          area.appendChild(el('div', { class: 'empty-state' }, '你自己還沒有紀錄；不過有「幫另一半記錄」的資料，推算會顯示在「陪伴另一半」分頁裡。'));
          area.appendChild(el('button', { class: 'btn btn-ghost', style: 'margin-top:8px;font-size:12px', onclick: () => switchTab('partnerCare') }, '前往「陪伴另一半」查看推算'));
          return;
        }
      } catch (e) { /* 忽略，走下面的預設空狀態 */ }
      area.appendChild(el('div', { class: 'empty-state' }, '還沒有紀錄，記一次經期開始日就能開始估算'));
      return;
    }
    renderCycleStatusDetail(area, status);
  } catch (e) {
    area.innerHTML = '';
    area.appendChild(el('div', { class: 'empty-state' }, '週期資料暫時無法取得'));
  }
}
async function saveCycleEntry() {
  const date = $('#cycleStartDate').value;
  if (!date) { showToast('請選擇日期'); return; }
  const endDate = $('#cycleEndDate') ? $('#cycleEndDate').value : '';
  const trackingFor = $('#cycleTrackingFor') ? $('#cycleTrackingFor').value : 'self';
  const note = $('#cycleNote') ? $('#cycleNote').value.trim() : '';
  try {
    await api('/mood/cycle', { method: 'POST', body: { periodStartDate: date, periodEndDate: endDate || null, trackingFor, symptoms: note || null } });
    $('#cycleNote').value = '';
    if ($('#cycleEndDate')) $('#cycleEndDate').value = '';
    showToast('已記錄');
    loadCycleStatus();
    if ($('#cycleHistoryList').style.display !== 'none') loadCycleHistory();
  } catch (e) { showToast('儲存失敗：' + e.message); }
}
function toggleCycleHistory() {
  const box = $('#cycleHistoryList');
  const show = box.style.display === 'none';
  box.style.display = show ? 'block' : 'none';
  if (show) loadCycleHistory();
}
async function loadCycleHistory() {
  const box = $('#cycleHistoryList');
  box.innerHTML = '';
  try {
    const rows = await api('/mood/cycle');
    if (!rows.length) {
      box.appendChild(el('div', { class: 'empty-state' }, '還沒有紀錄'));
      return;
    }
    rows.forEach((r) => {
      box.appendChild(el('div', { class: 'coping-note-item' }, [
        el('div', { class: 'content' }, [
          el('div', {}, `${r.period_start_date}${r.tracking_for === 'partner' ? '（幫另一半記錄）' : ''}`),
          r.symptoms ? el('div', { class: 'hint', style: 'margin:2px 0 0' }, r.symptoms) : null,
        ]),
        el('button', { class: 'del-btn', onclick: () => deleteCycleEntry(r.id) }, '✕'),
      ]));
    });
  } catch (e) {
    box.appendChild(el('div', { class: 'empty-state' }, '紀錄暫時無法取得'));
  }
}
async function deleteCycleEntry(id) {
  try {
    await api(`/mood/cycle/${id}`, { method: 'DELETE' });
    loadCycleHistory();
    loadCycleStatus();
  } catch (e) { showToast('刪除失敗：' + e.message); }
}

async function loadMoodToolbox() {
  const area = $('#moodToolboxBody');
  if (!area) return;
  try {
    const rows = await api('/mood/techniques/stats');
    area.innerHTML = '';
    if (!rows.length) {
      area.appendChild(el('div', { class: 'empty-state' }, '還沒有累積技巧回饋，選標籤後點「給我一個因應技巧」，用完給個回饋，這裡就會開始累積屬於你的工具箱。'));
      return;
    }
    rows.forEach((r) => {
      area.appendChild(el('div', { class: 'mood-signal-item' }, `${r.tag}：${r.best.title}（${r.best.helped}/${r.best.total} 次覺得有幫助）`));
    });
  } catch (e) {
    area.innerHTML = '';
    area.appendChild(el('div', { class: 'empty-state' }, '工具箱資料暫時無法取得'));
  }
}

function selectMoodScore(score) {
  moodState.selectedScore = score;
  document.querySelectorAll('.mood-score-btn').forEach((b) => b.classList.toggle('selected', Number(b.dataset.score) === score));
}
function toggleMoodTag(tag) {
  if (moodState.selectedTags.has(tag)) moodState.selectedTags.delete(tag);
  else moodState.selectedTags.add(tag);
  document.querySelectorAll('.mood-tag-chip').forEach((b) => b.classList.toggle('selected', moodState.selectedTags.has(b.dataset.tag)));
}

// v0.68：改成可以回填過去幾天的心情，不再只能記錄「今天」。切換日期時要重置選取狀態
// (分數/標籤/備註)，再重新查詢那天有沒有已經記錄過的資料，不然會殘留前一個日期選到的內容。
function moodEntryDateVal() {
  const el2 = $('#moodEntryDate');
  const v = el2 && el2.value;
  return v && v <= todayStr() ? v : todayStr();
}
function onMoodEntryDateChange() {
  const date = moodEntryDateVal();
  const label = $('#moodEntryDateLabel');
  const btn = $('#moodSaveBtn');
  const isToday = date === todayStr();
  if (label) label.textContent = isToday ? '今天' : `補記錄 ${date}`;
  if (btn) btn.textContent = isToday ? '儲存今天的紀錄' : `儲存 ${date} 的紀錄`;
  moodState.selectedScore = null;
  moodState.selectedTags = new Set();
  document.querySelectorAll('.mood-score-btn').forEach((b) => b.classList.remove('selected'));
  document.querySelectorAll('.mood-tag-chip').forEach((b) => b.classList.remove('selected'));
  if ($('#moodNote')) $('#moodNote').value = '';
  if ($('#moodWeatherSelect')) $('#moodWeatherSelect').value = '';
  loadMoodToday();
}

async function loadMoodToday() {
  try {
    const date = moodEntryDateVal();
    const rows = await api(`/mood/entries?from=${date}&to=${date}`);
    if (rows.length) {
      const entry = rows[0];
      selectMoodScore(entry.score);
      (entry.tags || '').split(',').filter(Boolean).forEach((t) => { moodState.selectedTags.add(t); });
      document.querySelectorAll('.mood-tag-chip').forEach((b) => b.classList.toggle('selected', moodState.selectedTags.has(b.dataset.tag)));
      if (entry.note) $('#moodNote').value = entry.note;
      if (entry.weather && $('#moodWeatherSelect')) $('#moodWeatherSelect').value = entry.weather;
    }
  } catch (e) { /* 忽略，當作那天還沒記錄 */ }
}

async function saveMoodEntry() {
  if (!moodState.selectedScore) { showToast('先選一個 1-10 的分數'); return; }
  try {
    const date = moodEntryDateVal();
    await api(`/mood/entries/${date}`, {
      method: 'PUT',
      body: {
        score: moodState.selectedScore,
        tags: [...moodState.selectedTags],
        note: $('#moodNote').value.trim(),
        weather: ($('#moodWeatherSelect') && $('#moodWeatherSelect').value) || undefined,
      },
    });
    showToast(date === todayStr() ? '已記錄今天的心情 💗' : `已補記錄 ${date} 的心情 💗`);
    loadMoodTrend();
    // 分數偏低又有選標籤時，直接主動問要不要看技巧建議或寫想法記錄，
    // 不用讓使用者自己想到要去別的卡片找，把整個流程串起來。
    if (moodState.selectedScore <= 4 && moodState.selectedTags.size) {
      showCheckinFollowupPrompt();
    } else {
      const followup = $('#moodCheckinFollowup');
      if (followup) followup.innerHTML = '';
    }
  } catch (e) { showToast('儲存失敗：' + e.message); }
}

function showCheckinFollowupPrompt() {
  let followup = $('#moodCheckinFollowup');
  if (!followup) {
    followup = el('div', { id: 'moodCheckinFollowup', style: 'margin-top:10px' });
    $('#moodTechniqueBody').after(followup);
  }
  followup.innerHTML = '';
  followup.appendChild(el('div', { class: 'mood-technique-box' }, [
    el('div', {}, '這幾天感覺不太容易，要不要看一個可能有幫助的技巧，或寫一筆想法記錄整理一下？'),
    el('div', { style: 'display:flex;gap:8px;margin-top:8px;flex-wrap:wrap' }, [
      el('button', { class: 'btn btn-ghost', style: 'font-size:12px', onclick: () => { suggestMoodTechnique(); followup.innerHTML = ''; } }, '看技巧建議'),
      el('button', { class: 'btn btn-ghost', style: 'font-size:12px', onclick: () => { scrollMoodToolsIntoView('trThought'); followup.innerHTML = ''; } }, '寫想法記錄'),
      el('button', { class: 'btn btn-ghost', style: 'font-size:12px', onclick: () => { followup.innerHTML = ''; } }, '先不用了'),
    ]),
  ]));
}

async function loadMoodTrend() {
  const chartArea = $('#moodTrendChart');
  const statsGrid = $('#moodStatsGrid');
  if (!chartArea) return;
  try {
    const summary = await api('/mood/summary?days=30');
    if (!summary.series.length) {
      chartArea.innerHTML = '';
      chartArea.appendChild(el('div', { class: 'empty-state' }, '還沒有心情紀錄，記錄第一筆之後這裡就會出現趨勢圖'));
    } else {
      renderMoodChart(chartArea, summary.series);
    }
    if (statsGrid) renderMoodStats(statsGrid, summary);
    const banner = $('#moodCareBanner');
    if (banner) {
      banner.innerHTML = '';
      if (summary.careMessage) {
        banner.appendChild(el('div', { class: 'mood-care-banner' }, `💌 ${summary.careMessage}`));
      }
    }
  } catch (e) {
    chartArea.innerHTML = '';
    chartArea.appendChild(el('div', { class: 'empty-state' }, '心情資料暫時無法取得'));
    if (statsGrid) { statsGrid.innerHTML = ''; statsGrid.appendChild(el('div', { class: 'empty-state' }, '心情資料暫時無法取得')); }
  }
}

async function loadMoodInsights() {
  const area = $('#moodInsightBody');
  if (!area) return;
  try {
    const insight = await api('/mood/insights');
    area.innerHTML = '';
    if (!insight.available) {
      area.appendChild(el('div', { class: 'empty-state' }, insight.message));
    } else {
      area.appendChild(el('p', {}, insight.message));
    }
  } catch (e) {
    area.innerHTML = '';
    area.appendChild(el('div', { class: 'empty-state' }, '洞察資料暫時無法取得'));
  }
}

async function generateMoodWeeklyReview() {
  const area = $('#moodWeeklyReviewBody');
  if (!area) return;
  area.innerHTML = '';
  area.appendChild(el('div', { class: 'empty-state' }, '正在為你寫這週的回顧...'));
  try {
    const result = await api('/mood/weekly-review', { method: 'POST' });
    area.innerHTML = '';
    area.appendChild(el('div', { class: 'mood-weekly-review-box' }, result.reply));
  } catch (e) {
    area.innerHTML = '';
    area.appendChild(el('div', { class: 'empty-state' }, '這週回顧暫時無法產生：' + e.message));
  }
}

async function loadCopingNotes() {
  const list = $('#copingNoteList');
  if (!list) return;
  try {
    const notes = await api('/mood/coping-notes');
    list.innerHTML = '';
    if (!notes.length) {
      list.appendChild(el('div', { class: 'empty-state' }, '還沒有安心小卡，寫一句想留給自己的話吧'));
      return;
    }
    notes.forEach((n) => {
      list.appendChild(el('div', { class: 'coping-note-item' }, [
        el('div', { class: 'content' }, n.content),
        el('button', { class: 'del-btn', onclick: () => deleteCopingNote(n.id) }, '✕'),
      ]));
    });
  } catch (e) {
    list.innerHTML = '';
    list.appendChild(el('div', { class: 'empty-state' }, '小卡資料暫時無法取得'));
  }
}

async function addCopingNote() {
  const input = $('#copingNoteInput');
  const text = input.value.trim();
  if (!text) return;
  try {
    await api('/mood/coping-notes', { method: 'POST', body: { content: text } });
    input.value = '';
    loadCopingNotes();
  } catch (e) { showToast('新增失敗：' + e.message); }
}

async function deleteCopingNote(id) {
  try {
    await api(`/mood/coping-notes/${id}`, { method: 'DELETE' });
    loadCopingNotes();
  } catch (e) { showToast('刪除失敗：' + e.message); }
}

// ---------- 這個月 AI 回顧 ----------
async function generateMoodMonthlyReview() {
  const area = $('#moodMonthlyReviewBody');
  if (!area) return;
  area.innerHTML = '';
  area.appendChild(el('div', { class: 'empty-state' }, '正在為你寫這個月的回顧...'));
  try {
    const month = todayStr().slice(0, 7);
    const result = await api('/mood/monthly-review', { method: 'POST', body: { month } });
    area.innerHTML = '';
    area.appendChild(el('div', { class: 'mood-weekly-review-box' }, result.reply));
  } catch (e) {
    area.innerHTML = '';
    area.appendChild(el('div', { class: 'empty-state' }, '這個月的回顧暫時無法產生：' + e.message));
  }
}

// ---------- 會學習的因應技巧庫 ----------
async function suggestMoodTechnique() {
  const area = $('#moodTechniqueBody');
  if (!area) return;
  const tag = [...moodState.selectedTags][0];
  if (!tag) {
    showToast('先選一個標籤，AI 才知道要給哪種技巧');
    return;
  }
  area.innerHTML = '';
  area.appendChild(el('div', { class: 'empty-state' }, '載入中...'));
  try {
    const res = await api(`/mood/techniques/suggest?tag=${encodeURIComponent(tag)}`);
    const t = res.technique;
    area.innerHTML = '';
    area.appendChild(el('div', { class: 'mood-technique-box' }, [
      el('div', { class: 'mood-technique-title' }, `💡 ${t.title}`),
      el('p', { style: 'margin:6px 0 10px' }, t.text),
      el('div', { style: 'display:flex;gap:8px;align-items:center' }, [
        el('span', { class: 'hint', style: 'margin:0' }, '這個方法有幫助嗎？'),
        el('button', { class: 'btn btn-ghost', style: 'font-size:12px;padding:4px 10px', onclick: () => giveTechniqueFeedback(tag, t.key, true) }, '👍 有幫助'),
        el('button', { class: 'btn btn-ghost', style: 'font-size:12px;padding:4px 10px', onclick: () => giveTechniqueFeedback(tag, t.key, false) }, '👎 沒有幫助'),
      ]),
    ]));
  } catch (e) {
    area.innerHTML = '';
    area.appendChild(el('div', { class: 'empty-state' }, '技巧建議暫時無法取得'));
  }
}
async function giveTechniqueFeedback(tag, techniqueKey, helped) {
  try {
    await api('/mood/techniques/feedback', { method: 'POST', body: { tag, techniqueKey, helped } });
    showToast('謝謝你的回饋，下次會愈推薦愈準');
    loadMoodToolbox();
  } catch (e) { showToast('回饋送出失敗：' + e.message); }
}

// ---------- 跨模塊深層模式識別 ----------
async function loadMoodPatterns() {
  const area = $('#moodPatternsBody');
  if (!area) return;
  try {
    const res = await api('/mood/patterns');
    renderMoodPatterns(area, res);
  } catch (e) {
    area.innerHTML = '';
    area.appendChild(el('div', { class: 'empty-state' }, '模式分析資料暫時無法取得'));
  }
}
async function refreshMoodPatterns() {
  const area = $('#moodPatternsBody');
  if (!area) return;
  area.innerHTML = '';
  area.appendChild(el('div', { class: 'empty-state' }, '正在分析中，資料量比較大的話可能要幾秒鐘...'));
  try {
    const res = await api('/mood/patterns/refresh', { method: 'POST' });
    renderMoodPatterns(area, res);
  } catch (e) {
    area.innerHTML = '';
    area.appendChild(el('div', { class: 'empty-state' }, '分析暫時無法完成：' + e.message));
  }
}
function renderMoodPatterns(area, res) {
  area.innerHTML = '';
  if (!res.available) {
    area.appendChild(el('div', { class: 'empty-state' }, res.message));
    return;
  }
  area.appendChild(el('p', {}, res.insights));
  if (res.signals && res.signals.length) {
    const list = el('div', { class: 'mood-signal-list' });
    res.signals.forEach((s) => {
      list.appendChild(el('div', { class: 'mood-signal-item' }, `${s.label}：${s.groupAName} ${s.avgA} 分 vs ${s.groupBName} ${s.avgB} 分`));
    });
    area.appendChild(list);
  }
  if (res.generatedAt) {
    area.appendChild(el('p', { class: 'hint', style: 'margin-top:8px' }, `上次分析時間：${new Date(res.generatedAt).toLocaleString('zh-TW')}`));
  }
}

// ---------- CBT 式思考記錄 ----------
async function suggestThoughtReframe() {
  const thought = $('#trThought').value.trim();
  if (!thought) { showToast('先寫下腦中出現的念頭'); return; }
  try {
    const result = await api('/mood/thought-records/reframe-suggest', {
      method: 'POST',
      body: {
        situation: $('#trSituation').value.trim(),
        thought,
        evidenceFor: $('#trEvidenceFor').value.trim(),
        evidenceAgainst: $('#trEvidenceAgainst').value.trim(),
      },
    });
    $('#trReframe').value = result.reply;
  } catch (e) { showToast('建議暫時無法產生：' + e.message); }
}
async function saveThoughtRecord() {
  const thought = $('#trThought').value.trim();
  if (!thought) { showToast('先寫下腦中出現的念頭'); return; }
  try {
    await api('/mood/thought-records', {
      method: 'POST',
      body: {
        situation: $('#trSituation').value.trim(),
        thought,
        emotion: $('#trEmotion').value.trim(),
        intensity: $('#trIntensity').value ? Number($('#trIntensity').value) : null,
        evidenceFor: $('#trEvidenceFor').value.trim(),
        evidenceAgainst: $('#trEvidenceAgainst').value.trim(),
        reframe: $('#trReframe').value.trim(),
      },
    });
    ['trSituation', 'trThought', 'trEmotion', 'trIntensity', 'trEvidenceFor', 'trEvidenceAgainst', 'trReframe'].forEach((id) => { $('#' + id).value = ''; });
    showToast('已儲存這筆思考記錄');
    loadThoughtRecords();
  } catch (e) { showToast('儲存失敗：' + e.message); }
}
async function loadThoughtRecords() {
  const list = $('#thoughtRecordList');
  if (!list) return;
  try {
    const rows = await api('/mood/thought-records');
    populateThoughtRecordDatalists(rows);
    list.innerHTML = '';
    if (!rows.length) {
      list.appendChild(el('div', { class: 'empty-state' }, '還沒有紀錄，卡住的時候可以試著寫一筆'));
      return;
    }
    rows.forEach((r) => {
      const parts = [];
      if (r.situation) parts.push(el('div', { class: 'hint', style: 'margin:0' }, `情境：${r.situation}`));
      parts.push(el('div', { style: 'font-weight:600' }, `念頭：${r.thought}`));
      if (r.emotion || r.intensity) parts.push(el('div', { class: 'hint', style: 'margin:0' }, `情緒：${r.emotion || ''}${r.intensity ? ` (強度 ${r.intensity}/10)` : ''}`));
      if (r.reframe) parts.push(el('div', { style: 'margin-top:4px;color:var(--series-aqua)' }, `→ ${r.reframe}`));
      list.appendChild(el('div', { class: 'coping-note-item' }, [
        el('div', { class: 'content' }, parts),
        el('button', { class: 'del-btn', onclick: () => deleteThoughtRecord(r.id) }, '✕'),
      ]));
    });
  } catch (e) {
    list.innerHTML = '';
    list.appendChild(el('div', { class: 'empty-state' }, '思考記錄暫時無法取得'));
  }
}
// 表單自動記憶：情境/情緒欄位常常是重複的字眼，記住之前打過的就好，之後用選的比較快，也可以繼續自己打字
function populateThoughtRecordDatalists(rows) {
  const situationList = $('#trSituationList');
  const emotionList = $('#trEmotionList');
  if (situationList) {
    situationList.innerHTML = '';
    [...new Set(rows.map((r) => (r.situation || '').trim()).filter(Boolean))].slice(0, 50).forEach((v) => situationList.appendChild(el('option', { value: v })));
  }
  if (emotionList) {
    emotionList.innerHTML = '';
    [...new Set(rows.map((r) => (r.emotion || '').trim()).filter(Boolean))].slice(0, 50).forEach((v) => emotionList.appendChild(el('option', { value: v })));
  }
}
async function deleteThoughtRecord(id) {
  try {
    await api(`/mood/thought-records/${id}`, { method: 'DELETE' });
    loadThoughtRecords();
  } catch (e) { showToast('刪除失敗：' + e.message); }
}

function moodStatTile(value, label) {
  return el('div', { class: 'mood-stat-tile' }, [
    el('div', { class: 'mood-stat-value' }, value),
    el('div', { class: 'mood-stat-label' }, label),
  ]);
}

function renderMoodStats(container, summary) {
  container.innerHTML = '';
  const series = summary.series || [];
  if (!series.length) {
    container.appendChild(el('div', { class: 'empty-state' }, '還沒有資料'));
    return;
  }
  const thisMonth = todayStr().slice(0, 7);
  const monthCount = series.filter((r) => r.entry_date.startsWith(thisMonth)).length;

  // 連續記錄天數：從今天往回算，只要中間斷一天就停止
  const dateSet = new Set(series.map((r) => r.entry_date));
  let streak = 0;
  let cursor = new Date();
  while (true) {
    const ds = cursor.toISOString().slice(0, 10);
    if (!dateSet.has(ds)) break;
    streak++;
    cursor.setDate(cursor.getDate() - 1);
  }

  // 情緒穩定度：分數波動愈小，數值愈高 (僅供參考，不是精確的醫學指標)
  let stability = null;
  if (series.length >= 2 && summary.average != null) {
    const variance = series.reduce((s, r) => s + Math.pow(r.score - summary.average, 2), 0) / series.length;
    const stdev = Math.sqrt(variance);
    stability = Math.max(0, Math.round(100 - (stdev / 4.5) * 100));
  }

  container.appendChild(moodStatTile(summary.average != null ? `${summary.average} 分` : '--', '近 30 天平均分數'));
  container.appendChild(moodStatTile(String(monthCount), '本月已記錄天數'));
  container.appendChild(moodStatTile(`${streak} 天`, '連續記錄天數'));
  container.appendChild(moodStatTile(stability != null ? `${stability}%` : '--', '情緒穩定度 (僅供參考)'));
  if (summary.topTags && summary.topTags.length) {
    const tagsBox = el('div', { style: 'grid-column:1/-1;margin-top:4px' }, [
      el('div', { class: 'mood-stat-label', style: 'margin-bottom:6px' }, '常見標籤'),
      el('div', { class: 'mood-tag-row', style: 'margin:0' }, summary.topTags.map((t) => el('span', { class: 'mood-tag-chip selected' }, `${t.tag} ×${t.count}`))),
    ]);
    container.appendChild(tagsBox);
  }

  const heatmapBox = el('div', { style: 'grid-column:1/-1;margin-top:14px' }, [
    el('div', { class: 'mood-stat-label', style: 'margin-bottom:6px' }, '近 30 天一覽'),
  ]);
  const grid = el('div', { class: 'mood-heatmap' });
  const byDate = {};
  series.forEach((r) => { byDate[r.entry_date] = r.score; });
  const days = [];
  for (let i = 29; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    days.push(d.toISOString().slice(0, 10));
  }
  days.forEach((ds) => {
    const score = byDate[ds];
    const cell = el('div', { class: 'mood-heatmap-cell' });
    if (score != null) {
      cell.style.background = `color-mix(in srgb, ${cssVar('--series-magenta')} ${Math.round((score / 10) * 85 + 15)}%, var(--surface-2))`;
      cell.addEventListener('mousemove', (ev) => showTooltip(ev, `${ds}：${score} 分`));
      cell.addEventListener('mouseleave', hideTooltip);
    }
    grid.appendChild(cell);
  });
  heatmapBox.appendChild(grid);
  container.appendChild(heatmapBox);
}

function renderMoodChart(container, series) {
  container.innerHTML = '';
  const width = container.clientWidth || 460;
  const height = 180;
  const padL = 28, padR = 12, padTop = 14, padBottom = 26;
  const plotW = width - padL - padR;
  const plotH = height - padTop - padBottom;
  const svg = svgEl('svg', { width: '100%', height, viewBox: `0 0 ${width} ${height}` });

  for (const gv of [1, 4, 7, 10]) {
    const y = padTop + plotH - ((gv - 1) / 9) * plotH;
    svg.appendChild(svgEl('line', { x1: padL, x2: width - padR, y1: y, y2: y, stroke: cssVar('--grid-line'), 'stroke-width': 1 }));
    const lbl = svgEl('text', { x: 2, y: y + 4, 'font-size': 10, fill: cssVar('--text-muted') });
    lbl.textContent = String(gv);
    svg.appendChild(lbl);
  }

  const n = series.length;
  const coords = series.map((p, i) => ({
    px: padL + (n > 1 ? (i / (n - 1)) * plotW : plotW / 2),
    py: padTop + plotH - ((p.score - 1) / 9) * plotH,
  }));
  const pathD = coords.map((p, i) => `${i === 0 ? 'M' : 'L'}${p.px},${p.py}`).join(' ');

  const gradId = 'moodAreaGrad';
  const defs = svgEl('defs', {});
  const grad = svgEl('linearGradient', { id: gradId, x1: '0', y1: '0', x2: '0', y2: '1' });
  const stop1 = svgEl('stop', { offset: '0%', 'stop-color': cssVar('--series-magenta'), 'stop-opacity': '0.35' });
  const stop2 = svgEl('stop', { offset: '100%', 'stop-color': cssVar('--series-magenta'), 'stop-opacity': '0' });
  grad.appendChild(stop1); grad.appendChild(stop2); defs.appendChild(grad); svg.appendChild(defs);

  const areaD = `${pathD} L${coords[coords.length - 1].px},${padTop + plotH} L${coords[0].px},${padTop + plotH} Z`;
  svg.appendChild(svgEl('path', { d: areaD, fill: `url(#${gradId})`, stroke: 'none' }));
  svg.appendChild(svgEl('path', { d: pathD, fill: 'none', stroke: cssVar('--series-magenta'), 'stroke-width': 2, 'stroke-linecap': 'round' }));

  series.forEach((p, i) => {
    const px = padL + (n > 1 ? (i / (n - 1)) * plotW : plotW / 2);
    const py = padTop + plotH - ((p.score - 1) / 9) * plotH;
    const dot = svgEl('circle', { cx: px, cy: py, r: 3.5, fill: cssVar('--series-magenta') });
    dot.addEventListener('mousemove', (ev) => showTooltip(ev, `${p.entry_date}：${p.score} 分`));
    dot.addEventListener('mouseleave', hideTooltip);
    svg.appendChild(dot);
    if (n <= 10 || i === 0 || i === n - 1 || i % Math.ceil(n / 6) === 0) {
      const lbl = svgEl('text', { x: px, y: height - 6, 'font-size': 9, 'text-anchor': 'middle', fill: cssVar('--text-muted') });
      lbl.textContent = p.entry_date.slice(5);
      svg.appendChild(lbl);
    }
  });

  container.appendChild(svg);
}

async function loadMoodDiaryLink() {
  const area = $('#moodDiaryLink');
  if (!area) return;
  try {
    const today = todayStr();
    const entries = await api(`/diary?from=${today}&to=${today}`);
    area.innerHTML = '';
    if (!entries.length) {
      area.appendChild(el('div', { class: 'empty-state' }, '今天還沒寫日記'));
      area.appendChild(el('button', { class: 'btn btn-ghost', style: 'margin-top:8px', onclick: () => switchTab('diary') }, '前往寫日記'));
    } else {
      const snippet = (entries[0].content || '').slice(0, 80);
      area.appendChild(el('p', { style: 'font-size:13px;color:var(--text-secondary)' }, snippet + (entries[0].content.length > 80 ? '…' : '')));
      area.appendChild(el('button', { class: 'btn btn-ghost', style: 'margin-top:4px', onclick: () => switchTab('diary') }, '查看完整日記'));
    }
  } catch (e) {
    area.innerHTML = '';
    area.appendChild(el('div', { class: 'empty-state' }, '日記資料暫時無法取得'));
  }
}

async function loadMoodChatHistory() {
  try {
    moodState.chatHistory = await api('/mood/chat/history');
  } catch (e) {
    moodState.chatHistory = [];
  }
  moodState.opener = null;
  // 只有「目前沒有對話紀錄，但之前留有長期記憶摘要」時，才會拿到主動開場白，
  // 這樣使用者清過對話畫面之後，AI 還是會像記得之前聊過的內容一樣主動先開口。
  if (!moodState.chatHistory.length) {
    try {
      const opener = await api('/mood/chat/opener');
      if (opener.available) moodState.opener = opener.reply;
    } catch (e) { /* 開場白失敗不影響主要功能 */ }
  }
  renderMoodChatMessages();
}
async function clearMoodChatHistory() {
  try {
    await api('/mood/chat/history', { method: 'DELETE' });
    moodState.chatHistory = [];
    renderMoodChatMessages();
    showToast('已清除陪伴對話記錄');
  } catch (e) { showToast('清除失敗: ' + e.message); }
}
function renderMoodChatMessages() {
  const box = $('#moodChatMessages');
  if (!box) return;
  box.innerHTML = '';
  if (!moodState.chatHistory || !moodState.chatHistory.length) {
    if (moodState.opener) {
      box.appendChild(el('div', { class: 'chat-msg chat-ai' }, moodState.opener));
    } else {
      box.appendChild(el('div', { class: 'empty-state' }, '還沒有對話，想聊聊嗎？隨時都可以開始'));
    }
    return;
  }
  moodState.chatHistory.forEach((m) => {
    box.appendChild(el('div', { class: 'chat-msg ' + (m.role === 'user' ? 'chat-user' : 'chat-ai') }, m.content));
  });
  box.scrollTop = box.scrollHeight;
}
async function sendMoodChatMessage() {
  const input = $('#moodChatInput');
  const text = input.value.trim();
  if (!text) return;
  moodState.chatHistory = moodState.chatHistory || [];
  moodState.chatHistory.push({ role: 'user', content: text });
  input.value = '';
  renderMoodChatMessages();
  try {
    const res = await api('/mood/chat', { method: 'POST', body: { message: text } });
    moodState.chatHistory.push({ role: 'assistant', content: res.reply });
    renderMoodChatMessages();
  } catch (e) {
    moodState.chatHistory.push({ role: 'assistant', content: '發生錯誤: ' + e.message });
    renderMoodChatMessages();
  }
}

// ===================== 健康紀錄 (睡眠 / 服藥) =====================
function renderHealth() {
  const c = $('#tab-health');
  c.innerHTML = '';

  const sleepCard = el('div', { class: 'card' }, [
    el('h3', {}, '😴 睡眠紀錄'),
    el('p', { class: 'hint' }, '記錄每天的睡眠時數，看看這幾天/這個月平均睡多少。'),
    el('div', { class: 'form-row' }, [
      el('input', { id: 'sleepDate', type: 'date', value: todayStr() }),
      el('input', { id: 'sleepHours', type: 'number', step: '0.5', min: '0', max: '24', placeholder: '睡眠時數 (小時)' }),
    ]),
    el('input', { id: 'sleepNote', placeholder: '備註 (選填)', style: 'width:100%;margin-top:8px' }),
    el('button', { class: 'btn btn-primary', style: 'margin-top:10px', onclick: saveSleepEntry }, '儲存'),
    el('div', { id: 'sleepChart', style: 'margin-top:16px' }, el('div', { class: 'empty-state' }, '載入中...')),
  ]);

  const medsCard = el('div', { class: 'card' }, [
    el('h3', {}, '💊 服藥提醒'),
    el('p', { class: 'hint' }, '把需要每天吃的藥加進來，每天打勾記錄有沒有吃。'),
    el('div', { class: 'form-row' }, [
      el('input', { id: 'medName', placeholder: '藥品名稱' }),
      el('input', { id: 'medDose', placeholder: '劑量 (選填)' }),
      el('input', { id: 'medTime', placeholder: '服用時間 (選填，例如 08:00)' }),
    ]),
    el('button', { class: 'btn btn-primary', style: 'margin-top:8px', onclick: addMed }, '新增藥品'),
    el('div', { id: 'medTodayList', style: 'margin-top:16px' }, el('div', { class: 'empty-state' }, '載入中...')),
  ]);

  c.appendChild(el('div', { class: 'grid-2' }, [sleepCard, medsCard]));

  const insightCard = el('div', { class: 'card', style: 'margin-top:12px' }, [
    el('h3', {}, '🔎 睡眠與服藥深度分析'),
    el('div', { id: 'sleepMoodCorrelationBody' }, el('div', { class: 'empty-state' }, '載入中...')),
    el('div', { id: 'medAdherenceBody', style: 'margin-top:10px' }, el('div', { class: 'empty-state' }, '載入中...')),
  ]);
  c.appendChild(insightCard);

  loadSleepChart();
  loadMedsToday();
  loadSleepMoodCorrelation();
  loadMedAdherence();
}

// v0.68：#1 睡眠與心情關聯分析
async function loadSleepMoodCorrelation() {
  const area = $('#sleepMoodCorrelationBody');
  if (!area) return;
  try {
    const r = await api('/health-track/sleep/mood-correlation?days=60');
    area.innerHTML = '';
    area.appendChild(el('div', { class: 'hint', style: 'font-weight:600;color:var(--text-primary,inherit);margin-bottom:4px' }, '😴➜💗 睡眠與隔天心情'));
    if (!r.hasEnoughData) {
      area.appendChild(el('div', { class: 'empty-state' }, r.note));
      return;
    }
    area.appendChild(el('p', {}, `睡足 7 小時以上的隔天，平均心情 ${r.wellRestedAvgNextMood ?? '—'} 分（${r.wellRestedCount} 筆）；不足 7 小時的隔天，平均心情 ${r.shortSleepAvgNextMood ?? '—'} 分（${r.shortSleepCount} 筆）。`));
    if (r.correlation != null) area.appendChild(el('p', { class: 'hint' }, `相關係數約 ${r.correlation}（越接近 1 代表「睡越多隔天心情越好」的傾向越明顯，越接近 -1 則相反，接近 0 代表看不出明顯關聯）`));
    area.appendChild(el('p', { class: 'hint', style: 'margin-top:4px' }, r.disclaimer));
  } catch (e) {
    area.innerHTML = '';
    area.appendChild(el('div', { class: 'empty-state' }, '分析資料暫時無法取得'));
  }
}

// v0.68：#2 服藥遵從率與漏服模式分析
async function loadMedAdherence() {
  const area = $('#medAdherenceBody');
  if (!area) return;
  try {
    const r = await api('/health-track/meds/adherence?days=30');
    area.innerHTML = '';
    area.appendChild(el('div', { class: 'hint', style: 'font-weight:600;color:var(--text-primary,inherit);margin-bottom:4px' }, '💊 近 30 天服藥遵從率'));
    if (!r.meds.length) {
      area.appendChild(el('div', { class: 'empty-state' }, '目前沒有服用中的藥品'));
      return;
    }
    r.meds.forEach((m) => {
      const line = [`${m.name}：遵從率 ${m.adherenceRate ?? '—'}%（${m.takenDays}/${m.totalDays} 天）`];
      if (m.worstWeekday) line.push(`，最常漏服的是${m.worstWeekday.label}`);
      area.appendChild(el('div', { class: 'mood-signal-item' }, line.join('')));
    });
  } catch (e) {
    area.innerHTML = '';
    area.appendChild(el('div', { class: 'empty-state' }, '遵從率資料暫時無法取得'));
  }
}

async function saveSleepEntry() {
  const date = $('#sleepDate').value || todayStr();
  const hours = $('#sleepHours').value;
  if (!hours) { showToast('請填寫睡眠時數'); return; }
  try {
    await api(`/health-track/sleep/${date}`, { method: 'PUT', body: { hours: Number(hours), note: $('#sleepNote').value.trim() } });
    showToast('已儲存睡眠紀錄');
    loadSleepChart();
  } catch (e) { showToast('儲存失敗：' + e.message); }
}
async function loadSleepChart() {
  const area = $('#sleepChart');
  if (!area) return;
  try {
    const summary = await api('/health-track/sleep/summary?days=30');
    area.innerHTML = '';
    if (!summary.series.length) {
      area.appendChild(el('div', { class: 'empty-state' }, '還沒有睡眠紀錄'));
      return;
    }
    area.appendChild(el('p', { class: 'hint' }, `近 30 天平均睡眠時數：${summary.average} 小時`));
    const svg = svgEl('svg', { width: '100%', height: 140, viewBox: '0 0 460 140' });
    const padL = 28, padR = 12, padTop = 10, padBottom = 20;
    const plotW = 460 - padL - padR, plotH = 140 - padTop - padBottom;
    const n = summary.series.length;
    const maxHours = Math.max(10, ...summary.series.map((r) => r.hours));
    const coords = summary.series.map((p, i) => ({
      px: padL + (n > 1 ? (i / (n - 1)) * plotW : plotW / 2),
      py: padTop + plotH - (p.hours / maxHours) * plotH,
    }));
    const pathD = coords.map((p, i) => `${i === 0 ? 'M' : 'L'}${p.px},${p.py}`).join(' ');
    svg.appendChild(svgEl('path', { d: pathD, fill: 'none', stroke: cssVar('--series-blue'), 'stroke-width': 2, 'stroke-linecap': 'round' }));
    summary.series.forEach((p, i) => {
      const dot = svgEl('circle', { cx: coords[i].px, cy: coords[i].py, r: 3, fill: cssVar('--series-blue') });
      dot.addEventListener('mousemove', (ev) => showTooltip(ev, `${p.entry_date}：${p.hours} 小時`));
      dot.addEventListener('mouseleave', hideTooltip);
      svg.appendChild(dot);
    });
    area.appendChild(svg);
  } catch (e) {
    area.innerHTML = '';
    area.appendChild(el('div', { class: 'empty-state' }, '睡眠資料暫時無法取得'));
  }
}

async function addMed() {
  const name = $('#medName').value.trim();
  if (!name) { showToast('請填寫藥品名稱'); return; }
  try {
    await api('/health-track/meds', { method: 'POST', body: { name, dose: $('#medDose').value.trim(), scheduleTime: $('#medTime').value.trim() } });
    $('#medName').value = ''; $('#medDose').value = ''; $('#medTime').value = '';
    loadMedsToday();
  } catch (e) { showToast('新增失敗：' + e.message); }
}
async function loadMedsToday() {
  const list = $('#medTodayList');
  if (!list) return;
  try {
    const meds = await api('/health-track/meds/today');
    list.innerHTML = '';
    if (!meds.length) {
      list.appendChild(el('div', { class: 'empty-state' }, '還沒有加入任何藥品'));
      return;
    }
    meds.forEach((m) => {
      const checkbox = el('input', { type: 'checkbox', onchange: (ev) => toggleMedTaken(m.id, ev.target.checked) });
      checkbox.checked = !!m.takenToday;
      // v0.80：今天吃過 = 綠色條，還沒吃 = 中性色，跟打勾框的意思是同一件事，
      // 色條只是讓它在清單裡更容易一眼掃過，不是額外發明的新狀態。
      list.appendChild(el('div', { class: `coping-note-item ${m.takenToday ? 'rb-green' : 'rb-neutral'}` }, [
        el('label', { style: 'display:flex;align-items:center;gap:8px;flex:1;cursor:pointer' }, [
          checkbox,
          el('div', { class: 'content' }, `${m.name}${m.dose ? `（${m.dose}）` : ''}${m.schedule_time ? ` · ${m.schedule_time}` : ''}`),
        ]),
        el('button', { class: 'del-btn', onclick: () => deleteMed(m.id) }, '✕'),
      ]));
    });
  } catch (e) {
    list.innerHTML = '';
    list.appendChild(el('div', { class: 'empty-state' }, '服藥資料暫時無法取得'));
  }
}
async function toggleMedTaken(id, taken) {
  try {
    await api(`/health-track/meds/${id}/log`, { method: 'PUT', body: { taken, date: todayStr() } });
  } catch (e) { showToast('更新失敗：' + e.message); }
}
async function deleteMed(id) {
  try {
    await api(`/health-track/meds/${id}`, { method: 'DELETE' });
    loadMedsToday();
  } catch (e) { showToast('刪除失敗：' + e.message); }
}

// ===================== 帳單提醒 =====================
function renderBills() {
  const c = $('#tab-bills');
  c.innerHTML = '';

  const formCard = el('div', { class: 'card' }, [
    el('h3', {}, '🧾 新增固定帳單'),
    el('p', { class: 'hint' }, '記錄每月固定要繳的錢 (房租、保險、訂閱等)，到期前可以提醒自己還沒繳。'),
    el('div', { class: 'form-row' }, [
      el('input', { id: 'billName', placeholder: '帳單名稱' }),
      el('input', { id: 'billAmount', type: 'number', placeholder: '金額' }),
      el('input', { id: 'billDueDay', type: 'number', min: '1', max: '31', placeholder: '每月幾號到期' }),
    ]),
    el('input', { id: 'billCategory', placeholder: '分類 (選填，例如：居住、保險、訂閱)', style: 'width:100%;margin-top:8px' }),
    el('button', { class: 'btn btn-primary', style: 'margin-top:10px', onclick: addBill }, '新增帳單'),
  ]);

  const listCard = el('div', { class: 'card' }, [
    el('h3', {}, '📋 這個月的帳單'),
    el('div', { id: 'billsListArea' }, el('div', { class: 'empty-state' }, '載入中...')),
  ]);

  // v0.66：帳單金額異常偵測 (見 src/routes/insights.js 的 bill-amount-anomaly)，之前算出來後
  // 沒地方顯示，這裡在帳單分頁最上面顯示。
  c.appendChild(el('div', { id: 'billsInsightAlerts' }));
  c.appendChild(formCard);
  c.appendChild(listCard);
  loadBills();
  loadTabInsightAlerts('billsInsightAlerts', ['bill-amount-anomaly']);
}
async function addBill() {
  const name = $('#billName').value.trim();
  const amount = $('#billAmount').value;
  const dueDay = $('#billDueDay').value;
  if (!name || !amount || !dueDay) { showToast('請填寫名稱、金額、到期日'); return; }
  try {
    await api('/bills', { method: 'POST', body: { name, amount: Number(amount), dueDay: Number(dueDay), category: $('#billCategory').value.trim() } });
    $('#billName').value = ''; $('#billAmount').value = ''; $('#billDueDay').value = ''; $('#billCategory').value = '';
    showToast('已新增帳單');
    loadBills();
  } catch (e) { showToast('新增失敗：' + e.message); }
}
async function loadBills() {
  const area = $('#billsListArea');
  if (!area) return;
  try {
    const res = await api('/bills/upcoming');
    area.innerHTML = '';
    if (!res.bills.length) {
      area.appendChild(el('div', { class: 'empty-state' }, '還沒有加入任何帳單'));
      return;
    }
    area.appendChild(el('p', { class: 'hint' }, `這個月還沒繳的總金額：NT$ ${Math.round(res.totalUnpaid)}`));
    res.bills.forEach((b) => {
      const dueText = b.paid ? '已繳' : (b.daysUntilDue < 0 ? `已過期 ${Math.abs(b.daysUntilDue)} 天` : b.daysUntilDue === 0 ? '今天到期' : `還有 ${b.daysUntilDue} 天到期`);
      // v0.80：急迫度色條改用跟其他模組一致的 rb-red/rb-gold/rb-green，取代原本
      // 單獨寫死的 border-color 內聯樣式——已繳 = 綠、快到期(3 天內)或已過期 = 紅、
      // 其餘正常倒數 = 中性色。
      const ribbonClass = b.paid ? 'rb-green' : (b.daysUntilDue <= 3 ? 'rb-red' : 'rb-neutral');
      const item = el('div', { class: `coping-note-item ${ribbonClass}`, style: 'flex-direction:column;align-items:stretch;gap:6px' });
      item.appendChild(el('div', { style: 'display:flex;justify-content:space-between;align-items:center' }, [
        el('div', { class: 'content' }, [
          el('div', { style: 'font-weight:700' }, `${b.name}　NT$ ${Math.round(b.amount)}`),
          el('div', { class: 'hint', style: 'margin:2px 0 0' }, `每月 ${b.due_day} 號到期 · ${dueText}${b.category ? ` · ${b.category}` : ''}`),
        ]),
        el('div', { style: 'display:flex;gap:6px;align-items:center' }, [
          el('button', { class: 'del-btn', onclick: () => deleteBill(b.id) }, '✕'),
        ]),
      ]));
      // v0.66：標記已繳時可以順填「這次實際繳了多少」，不填就用帳單設定的金額，
      // 累積夠多筆之後才有辦法比對「這次是不是異常升高」(見上面的洞察卡片)。
      if (!b.paid) {
        item.appendChild(el('div', { class: 'form-row' }, [
          el('input', { id: `billActualAmount_${b.id}`, type: 'number', placeholder: '這次實際金額 (選填，不填就用預設金額)', style: 'flex:1' }),
          el('button', { class: 'btn btn-ghost', style: 'font-size:12px', onclick: () => toggleBillPaid(b.id, true) }, '標記已繳'),
        ]));
      } else {
        item.appendChild(el('button', { class: 'btn btn-ghost', style: 'font-size:12px;align-self:flex-start', onclick: () => toggleBillPaid(b.id, false) }, '取消已繳'));
      }
      area.appendChild(item);
    });
  } catch (e) {
    area.innerHTML = '';
    area.appendChild(el('div', { class: 'empty-state' }, '帳單資料暫時無法取得'));
  }
}
async function toggleBillPaid(id, paid) {
  try {
    const amountInput = paid ? $(`#billActualAmount_${id}`) : null;
    const body = amountInput && amountInput.value !== '' ? { amount: Number(amountInput.value) } : {};
    const r = await api(`/bills/${id}/${paid ? 'mark-paid' : 'mark-unpaid'}`, { method: 'POST', body });
    // v0.88：標記已繳會自動記一筆支出，取消標記會一起刪掉，用提示告訴使用者發生了什麼
    if (paid && r && r.recorded) showToast(r.recorded.updated ? `已更新記帳金額 NT$${Number(r.recorded.amount).toLocaleString()}` : `已繳費，並記了一筆 NT$${Number(r.recorded.amount).toLocaleString()} 支出`);
    else if (!paid && r && r.removedTx) showToast('已取消，自動記的那筆支出也刪掉了');
    loadBills();
    loadTabInsightAlerts('billsInsightAlerts', ['bill-amount-anomaly']);
  } catch (e) { showToast('更新失敗：' + e.message); }
}
async function deleteBill(id) {
  try {
    await api(`/bills/${id}`, { method: 'DELETE' });
    loadBills();
  } catch (e) { showToast('刪除失敗：' + e.message); }
}

// ===================== 待辦事項 =====================
// ---- 待辦事項頁面狀態 (編輯中的任務 id、表單進階選項是否展開、清單分頁籤/篩選/批次模式) ----
let taskEditingId = null;
let taskFormExpanded = false;
let taskViewTab = 'pending'; // 'pending' | 'done'
let taskFilterText = '';
let taskFilterPriority = '';
let taskBatchMode = false;
const taskSelectedIds = new Set();
let taskDataPending = [];
let taskDataDone = [];

function renderTasks() {
  const c = $('#tab-tasks');
  c.innerHTML = '';
  taskEditingId = null;
  taskBatchMode = false;
  taskSelectedIds.clear();

  const formCard = el('div', { class: 'card', id: 'taskFormCard' }, [
    el('h3', { id: 'taskFormTitle' }, '➕ 新增任務'),
    el('input', { id: 'taskTitle', placeholder: '要做什麼事？', style: 'width:100%' }),
    // v0.85：期限改成「今天／明天／這週末」快選 + 原本的日期欄位 (要選別天時用)；
    // 優先度改成三段式按鈕。兩者各自一行、上面有小標，不再擠在同一列。
    // v0.87：表單平常只露出一個輸入框，點進去 (或開始打字、編輯任務) 才展開期限/優先度等
    // 選項；直接按 Enter 就用預設值新增。
    el('div', { id: 'taskFormExtra', class: 'task-form-extra' }, [
    el('div', { class: 'task-form-label' }, '期限'),
    dueQuickChipsEl('taskDueDate'),
    el('div', { class: 'task-form-label' }, '優先度'),
    prioritySliderEl('taskPriority', 'medium'),
    el('span', { id: 'taskAdvancedToggle', class: 'task-advanced-toggle', onclick: toggleTaskAdvanced }, '▸ 更多選項 (精力／備註／重複／準時提醒)'),
    el('div', { id: 'taskAdvancedFields', style: 'display:none;margin-top:8px' }, [
      el('p', { class: 'hint', style: 'margin:0 0 6px' }, '⚡ 所需精力 (選填)：'),
      chipSelectEl({
        id: 'taskEnergy', value: '',
        options: [
          { value: 'low', label: '🔋 低精力' },
          { value: 'medium', label: '🔋🔋 中精力' },
          { value: 'high', label: '🔋🔋🔋 高精力' },
        ],
      }),
      el('input', { id: 'taskNote', list: 'taskNoteList', placeholder: '備註 (選填)', style: 'width:100%;margin-top:8px' }),
      el('datalist', { id: 'taskNoteList' }),
      chipSelectEl({
        id: 'taskRecurrence', value: '', style: 'margin-top:8px',
        options: [
          { value: '', label: '🔁 不重複' },
          { value: 'daily', label: '每天' },
          { value: 'weekly', label: '每週' },
          { value: 'monthly', label: '每月' },
        ],
      }),
      el('p', { class: 'hint', style: 'margin-top:4px' }, '設定重複的話，完成這筆任務時會自動照週期產生下一筆，不用重新輸入。'),
      el('div', { class: 'form-row', style: 'margin-top:8px;align-items:center' }, [
        el('select', { id: 'taskRemindQuick', onchange: applyTaskRemindQuickPick }, [
          el('option', { value: '' }, '🔔 準時提醒 (選填)'),
          el('option', { value: '300' }, '5 分鐘後'),
          el('option', { value: '900' }, '15 分鐘後'),
          el('option', { value: '1800' }, '30 分鐘後'),
          el('option', { value: '3600' }, '1 小時後'),
          el('option', { value: 'custom' }, '自訂時間…'),
        ]),
        el('input', { id: 'taskRemindAt', type: 'datetime-local', style: 'display:none' }),
      ]),
      el('p', { class: 'hint', style: 'margin-top:4px' }, '設定的話，時間一到會準時跳出背景推播通知 (需要先在「個人化設定」開啟背景推播)。'),
    ]),
    el('div', { class: 'form-row', style: 'margin-top:10px' }, [
      el('button', { class: 'btn btn-primary', id: 'taskSubmitBtn', onclick: submitTaskForm }, '新增任務'),
      el('button', { class: 'btn btn-ghost', id: 'taskCancelEditBtn', style: 'display:none', onclick: () => cancelEditTask() }, '取消編輯'),
    ]),
    ]),
  ]);
  const titleInput = formCard.querySelector('#taskTitle');
  const expandForm = () => formCard.classList.add('expanded');
  titleInput.addEventListener('focus', expandForm);
  titleInput.addEventListener('input', expandForm);
  titleInput.addEventListener('keydown', (ev) => { if (ev.key === 'Enter' && !ev.isComposing && titleInput.value.trim()) { ev.preventDefault(); submitTaskForm(); } });

  const reviewCard = el('div', { class: 'card', id: 'taskReviewCard' }, [
    el('h3', {}, '🗓️ 這週回顧'),
    el('div', { id: 'taskReviewArea' }, el('div', { class: 'empty-state' }, '載入中...')),
  ]);

  const suggestCard = el('div', { class: 'card', id: 'taskSuggestCard' }, [
    el('h3', {}, '💡 今天建議先做'),
    el('div', { id: 'taskSuggestArea' }, el('div', { class: 'empty-state' }, '載入中...')),
  ]);

  const listCard = el('div', { class: 'card' }, [
    el('div', { class: 'task-view-tabs' }, [
      el('button', { id: 'taskTabPending', class: 'task-view-tab active', onclick: () => switchTaskViewTab('pending') }, '📌 待完成'),
      el('button', { id: 'taskTabDone', class: 'task-view-tab', onclick: () => switchTaskViewTab('done') }, '✅ 已完成'),
      el('button', { id: 'taskBatchToggleBtn', class: 'btn btn-ghost', style: 'margin-left:auto;font-size:11.5px;padding:5px 10px', onclick: toggleTaskBatchMode }, '☑️ 批次'),
    ]),
    el('div', { class: 'task-filter-row' }, [
      el('input', { id: 'taskFilterText', type: 'text', placeholder: '🔍 搜尋標題／備註', oninput: (ev) => { taskFilterText = ev.target.value; renderTaskListArea(); } }),
      el('select', { id: 'taskFilterPriority', onchange: (ev) => { taskFilterPriority = ev.target.value; renderTaskListArea(); } }, [
        el('option', { value: '' }, '全部優先度'),
        el('option', { value: 'high' }, '🔴 高優先'),
        el('option', { value: 'medium' }, '🟡 中優先'),
        el('option', { value: 'low' }, '🟢 低優先'),
      ]),
    ]),
    el('div', { id: 'taskBatchBar', class: 'task-batch-bar', style: 'display:none' }, [
      el('span', { id: 'taskBatchCount' }, '已選 0 筆'),
      el('button', { class: 'btn btn-ghost', style: 'font-size:12px', onclick: () => batchCompleteTasks() }, '✅ 標記完成'),
      el('button', { class: 'btn btn-ghost', style: 'font-size:12px', onclick: () => batchDeleteTasks() }, '🗑️ 刪除'),
    ]),
    el('div', { id: 'taskListArea' }, el('div', { class: 'empty-state' }, '載入中...')),
  ]);

  const energyEfficiencyCard = el('div', { class: 'card' }, [
    el('h3', {}, '⚡ 精力等級 vs 完成效率'),
    el('div', { id: 'taskEnergyEfficiencyArea' }, el('div', { class: 'empty-state' }, '載入中...')),
  ]);

  // v0.66：任務拖延模式偵測 (見 src/routes/insights.js 的 task-procrastination)，之前算出來後
  // 沒地方顯示，這裡在待辦分頁最上面顯示。
  c.appendChild(el('div', { id: 'tasksInsightAlerts' }));
  c.appendChild(formCard);
  c.appendChild(reviewCard);
  c.appendChild(suggestCard);
  c.appendChild(listCard);
  c.appendChild(energyEfficiencyCard);
  // v0.87：回顧/分析類的卡片移到清單後面，預設收合 (點標題展開)，清單本身往上提。
  c.insertBefore(listCard, reviewCard);
  makeCardCollapsible(reviewCard, 'tasks', false);
  makeCardCollapsible(energyEfficiencyCard, 'tasks', false);
  loadTasks();
  loadTaskSuggestions();
  loadTaskReview();
  loadTabInsightAlerts('tasksInsightAlerts', ['task-procrastination']);
  loadTaskEnergyEfficiency();
}

// v0.68：#7 任務精力等級 vs 完成效率分析
async function loadTaskEnergyEfficiency() {
  const area = $('#taskEnergyEfficiencyArea');
  if (!area) return;
  try {
    const r = await api('/tasks/energy-efficiency');
    area.innerHTML = '';
    if (!r.hasEnoughData) { area.appendChild(el('div', { class: 'empty-state' }, r.note)); return; }
    const LEVEL_LABEL = { low: '🔋 低精力', medium: '🔋🔋 中精力', high: '🔋🔋🔋 高精力' };
    r.summary.forEach((s) => {
      if (!s.total) return;
      area.appendChild(el('div', { class: 'mood-signal-item' },
        `${LEVEL_LABEL[s.level]}：完成率 ${s.completionRate ?? '—'}%（${s.completed}/${s.total}）${s.avgHoursToComplete != null ? `，平均花 ${s.avgHoursToComplete} 小時完成` : ''}`
      ));
    });
    area.appendChild(el('p', { class: 'hint', style: 'margin-top:4px' }, r.disclaimer));
  } catch (e) { area.innerHTML = ''; area.appendChild(el('div', { class: 'empty-state' }, '分析資料暫時無法取得')); }
}

// 「更多選項」收合區塊：預設收合只留最常用的標題/日期/優先度，避免手機版表單一次展開太多欄位要滑很久。
function toggleTaskAdvanced(forceOpen) {
  taskFormExpanded = forceOpen === true ? true : !taskFormExpanded;
  const box = $('#taskAdvancedFields');
  const toggle = $('#taskAdvancedToggle');
  if (box) box.style.display = taskFormExpanded ? '' : 'none';
  if (toggle) toggle.textContent = taskFormExpanded ? '▾ 收合更多選項' : '▸ 更多選項 (精力／備註／重複／準時提醒)';
}

// 「準時提醒」下拉選單：選相對時間 (5分鐘後等) 就直接算出對應的 datetime-local 值填進隱藏的
// 自訂時間欄位；選「自訂時間…」則把欄位顯示出來讓使用者自己挑日期時間。
function applyTaskRemindQuickPick() {
  const quick = $('#taskRemindQuick').value;
  const input = $('#taskRemindAt');
  if (!quick) { input.style.display = 'none'; input.value = ''; return; }
  if (quick === 'custom') { input.style.display = ''; return; }
  const target = new Date(Date.now() + Number(quick) * 1000);
  // datetime-local 要的是「本地時間」字串 (無時區資訊)，用 getTimezoneOffset 校正成本地時間再切片
  const local = new Date(target.getTime() - target.getTimezoneOffset() * 60000);
  input.value = local.toISOString().slice(0, 16);
  input.style.display = '';
}

// datetime-local 輸入框給的值沒有時區資訊，瀏覽器會當作「使用者當地時區」解讀，
// new Date(value) 剛好就是照當地時區轉換，直接轉成 ISO 字串送給後端即可。
function taskRemindAtIso() {
  const val = $('#taskRemindAt').value;
  if (!val) return null;
  const d = new Date(val);
  return Number.isNaN(d.getTime()) ? null : d.toISOString();
}

function resetTaskForm() {
  const fc = $('#taskFormCard'); if (fc) fc.classList.remove('expanded');
  $('#taskTitle').value = ''; $('#taskDueDate').value = ''; $('#taskDueDate').dispatchEvent(new Event('input')); prioritySliderSet('taskPriority', 'medium');
  $('#taskEnergy').value = ''; $('#taskNote').value = ''; $('#taskRecurrence').value = '';
  $('#taskRemindQuick').value = ''; $('#taskRemindAt').value = ''; $('#taskRemindAt').style.display = 'none';
}

// 表單同時負責「新增」跟「編輯」——編輯時 taskEditingId 有值就改呼叫 PUT，其餘欄位收集邏輯完全共用，
// 這樣桌面版跟手機版不用維護兩套表單邏輯。
async function submitTaskForm() {
  const title = $('#taskTitle').value.trim();
  if (!title) { showToast('請填寫任務標題'); return; }
  const body = {
    title,
    dueDate: $('#taskDueDate').value || null,
    priority: prioritySliderGet('taskPriority'),
    energyLevel: $('#taskEnergy').value || null,
    note: $('#taskNote').value.trim(),
    recurrence: $('#taskRecurrence').value || null,
    remindAt: taskRemindAtIso(),
  };
  try {
    if (taskEditingId != null) {
      await api(`/tasks/${taskEditingId}`, { method: 'PUT', body });
      showToast('已更新任務');
      cancelEditTask();
    } else {
      await api('/tasks', { method: 'POST', body });
      showToast('已新增任務');
      resetTaskForm();
    }
    loadTasks();
    loadTaskSuggestions();
  } catch (e) { showToast('儲存失敗：' + e.message); }
}

// 點任務的「✏️ 編輯」按鈕：把表單填成這筆任務目前的內容、切換成編輯模式，並捲動到表單讓使用者看得到。
function startEditTask(t) {
  taskEditingId = t.id;
  $('#taskFormTitle').textContent = '✏️ 編輯任務';
  const fcEdit = $('#taskFormCard'); if (fcEdit) fcEdit.classList.add('expanded');
  $('#taskTitle').value = t.title || '';
  $('#taskDueDate').value = t.due_date || '';
  $('#taskDueDate').dispatchEvent(new Event('input'));
  prioritySliderSet('taskPriority', t.priority || 'medium');
  $('#taskEnergy').value = t.energy_level || '';
  $('#taskNote').value = t.note || '';
  $('#taskRecurrence').value = t.recurrence || '';
  if (t.remind_at) {
    const d = new Date(t.remind_at);
    const local = new Date(d.getTime() - d.getTimezoneOffset() * 60000);
    $('#taskRemindQuick').value = 'custom';
    $('#taskRemindAt').value = local.toISOString().slice(0, 16);
    $('#taskRemindAt').style.display = '';
  } else {
    $('#taskRemindQuick').value = '';
    $('#taskRemindAt').value = '';
    $('#taskRemindAt').style.display = 'none';
  }
  toggleTaskAdvanced(true); // 編輯時直接展開進階選項，不然使用者會以為精力/重複/提醒設定不見了
  $('#taskSubmitBtn').textContent = '更新任務';
  $('#taskCancelEditBtn').style.display = '';
  $('#taskFormCard').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function cancelEditTask() {
  taskEditingId = null;
  $('#taskFormTitle').textContent = '➕ 新增任務';
  $('#taskSubmitBtn').textContent = '新增任務';
  $('#taskCancelEditBtn').style.display = 'none';
  resetTaskForm();
}

const RECURRENCE_LABEL = { daily: '每天', weekly: '每週', monthly: '每月' };

async function loadTaskReview() {
  const area = $('#taskReviewArea');
  if (!area) return;
  try {
    const res = await api('/tasks/review/week');
    area.innerHTML = '';
    area.appendChild(el('p', { class: 'hint', style: 'margin:0 0 8px' }, `${res.rangeFrom} ～ ${res.rangeTo}，完成了 ${res.completedCount} 件，目前還有 ${res.stillPendingCount} 件待完成。`));
    if (res.longPendingTasks.length) {
      area.appendChild(el('div', { style: 'font-size:12.5px;font-weight:700;margin-bottom:4px' }, `已經過期 3 天以上、還沒完成 (${res.longPendingTasks.length})`));
      res.longPendingTasks.slice(0, 5).forEach((t) => {
        area.appendChild(el('div', { class: 'mood-signal-item' }, `${t.title}（到期：${t.due_date}）`));
      });
    }
  } catch (e) { area.innerHTML = ''; area.appendChild(el('div', { class: 'empty-state' }, '這週回顧暫時無法取得')); }
}
const PRIORITY_LABEL = { high: '🔴 高', medium: '🟡 中', low: '🟢 低' };
const PRIORITY_SLIDER_PLAIN_LABEL = { high: '高', medium: '中', low: '低' };
const ENERGY_LABEL = { low: '🔋 低精力', medium: '🔋🔋 中精力', high: '🔋🔋🔋 高精力' };

// ===== 共用「三段式優先度拉桿」元件 (v0.74) =====
// 使用者希望低/中/高這種三段選擇能像拉桿一樣「拖到哪卡到那、放開就存」，取代原本陽春的
// 下拉選單。用原生 <input type=range min=0 max=2 step=1> 實作——瀏覽器原生就支援拖曳/
// 觸控/鍵盤方向鍵操作，範圍只有 0/1/2 三個整數格，所以「拖到哪就卡到那」是瀏覽器內建
// 行為，不用自己刻拖曳吸附邏輯。
//
// 用法分兩種：
// 1.「表單模式」(不傳 opts.onChange)：用在新增/編輯表單裡，拖動只是暫存目前選到的值，
//    真正送出要等表單按「新增/儲存」。這種情境要讀值、或要用程式重設表單值，改用
//    prioritySliderGet(id) / prioritySliderSet(id, value)，不能再直接用 $('#id').value——
//    拉桿的 id 掛在 range input 上，原生 value 是 0/1/2 的索引，不是語意字串本身。
// 2.「即時模式」(有傳 opts.onChange)：用在已經存在、可以直接編輯的項目 (例如子任務優先度)，
//    放開手指/滑鼠的瞬間就直接呼叫 API 存檔，不用另外按儲存鈕，成功後標籤會短暫閃一下
//    表示「已存」。
const PRIORITY_SLIDER_LEVELS = ['low', 'medium', 'high'];

// v0.85：外觀從「藍→紅漸層拉桿」改成「低／中／高」三段式按鈕 (segmented control)。
// 使用者回饋拉桿要瞄準、顏色又跟優先度語意不完全一致；三顆按鈕一點就選、顏色只用在
// 小圓點 (低=灰、中=金、高=紅，沿用色條系統的語意)。對外介面完全不變：id 仍掛在一個
// 存 0/1/2 索引的 input 上，prioritySliderGet/Set 照舊可用，表單模式/即時模式也一樣。
function prioritySliderEl(id, value, opts = {}) {
  const labels = opts.labels || PRIORITY_SLIDER_PLAIN_LABEL;
  const idx0 = Math.max(0, PRIORITY_SLIDER_LEVELS.indexOf(value || 'medium'));
  const hidden = el('input', { type: 'hidden', id, value: String(idx0), class: 'priority-slider-range' });
  const buttons = PRIORITY_SLIDER_LEVELS.map((lv, i) => el('button', {
    type: 'button',
    class: `priority-seg-btn priority-seg-${lv}${i === idx0 ? ' active' : ''}`,
    'aria-pressed': i === idx0 ? 'true' : 'false',
  }, [el('span', { class: 'priority-seg-dot', 'aria-hidden': 'true' }), labels[lv]]));
  const sync = () => {
    const cur = Number(hidden.value);
    buttons.forEach((b, i) => { b.classList.toggle('active', i === cur); b.setAttribute('aria-pressed', i === cur ? 'true' : 'false'); });
  };
  hidden.addEventListener('input', sync);
  buttons.forEach((b, i) => {
    b.addEventListener('click', () => {
      if (Number(hidden.value) === i) return;
      hidden.value = String(i);
      sync();
      if (opts.onChange) {
        Promise.resolve(opts.onChange(PRIORITY_SLIDER_LEVELS[i])).then(() => {
          b.classList.add('priority-slider-saved-pulse');
          setTimeout(() => b.classList.remove('priority-slider-saved-pulse'), 700);
        }).catch((e) => showToast('儲存失敗：' + e.message));
      }
    });
  });
  return el('div', { class: 'priority-seg' + (opts.compact ? ' priority-slider-wrap-compact' : ''), role: 'group', 'aria-label': opts.ariaLabel || '優先度' }, [hidden, ...buttons]);
}

// v0.85：期限快選 chips。日期欄位本身 (id 不變) 保留在最後當「選日期」，所以其他地方
// 讀寫 $('#taskDueDate').value 的程式碼都不用改；這裡只是幫它多幾個一按就填好的按鈕，
// 並在值改變時同步亮起對應的 chip。
function dueQuickChipsEl(inputId) {
  const addDays = (n) => { const d = new Date(); d.setDate(d.getDate() + n); return fmtYMD(d); };
  const weekendOffset = () => { const day = new Date().getDay(); return day === 6 || day === 0 ? 0 : 6 - day; };
  const presets = [
    { label: '今天', get: () => addDays(0) },
    { label: '明天', get: () => addDays(1) },
    { label: '這週末', get: () => addDays(weekendOffset()) },
    { label: '不設', get: () => '' },
  ];
  const input = el('input', { id: inputId, type: 'date', class: 'due-quick-date', 'aria-label': '選日期' });
  const chips = presets.map((p) => el('button', { type: 'button', class: 'due-quick-chip' }, p.label));
  const sync = () => {
    const v = input.value;
    let matched = false;
    chips.forEach((c, i) => {
      const on = !matched && presets[i].get() === v;
      if (on) matched = true;
      c.classList.toggle('active', on);
      c.setAttribute('aria-pressed', on ? 'true' : 'false');
    });
  };
  chips.forEach((c, i) => c.addEventListener('click', () => { input.value = presets[i].get(); sync(); }));
  input.addEventListener('input', sync);
  input.addEventListener('change', sync);
  // 程式碼直接設定 .value 不會觸發事件，所以任務表單清空/帶入編輯值的地方會順手
  // dispatch 一次 input 事件讓 chips 同步；初始狀態在這裡先同步一次。
  setTimeout(sync, 0);
  return el('div', { class: 'due-quick' }, [...chips, input]);
}

function prioritySliderGet(id) {
  const elx = document.getElementById(id);
  if (!elx) return 'medium';
  return PRIORITY_SLIDER_LEVELS[Number(elx.value)] || 'medium';
}

function prioritySliderSet(id, value) {
  const elx = document.getElementById(id);
  if (!elx) return;
  const idx = Math.max(0, PRIORITY_SLIDER_LEVELS.indexOf(value || 'medium'));
  elx.value = String(idx);
  elx.dispatchEvent(new Event('input'));
}

async function loadTaskSuggestions() {
  const area = $('#taskSuggestArea');
  if (!area) return;
  try {
    const res = await api('/tasks/suggest-today');
    area.innerHTML = '';
    if (!res.moodLogged) {
      area.appendChild(el('p', { class: 'hint', style: 'margin:0 0 8px' }, res.note || '今天還沒記錄心情，先依優先度排序。'));
    } else {
      area.appendChild(el('p', { class: 'hint', style: 'margin:0 0 8px' }, `今天心情 ${res.todayScore} 分，${res.usedHistory ? '依你過去在類似心情下的完成狀況排序：' : '先用一般的建議順序排序 (累積更多紀錄後會更準)：'}`));
    }
    if (!res.tasks.length) {
      area.appendChild(el('div', { class: 'empty-state' }, '目前沒有待完成的任務'));
      return;
    }
    res.tasks.slice(0, 5).forEach((t) => {
      area.appendChild(el('div', { class: 'mood-signal-item' }, `${PRIORITY_LABEL[t.priority] || ''} ${t.title}${t.energy_level ? ` · ${ENERGY_LABEL[t.energy_level]}` : ''}`));
    });
  } catch (e) {
    area.innerHTML = '';
    area.appendChild(el('div', { class: 'empty-state' }, '建議清單暫時無法取得'));
  }
}
// 依到期日把待完成任務分組——「已過期／今天／本週／之後／沒有期限」，比單純依日期攤平排序更容易
// 一眼看出「今天真的該做的是哪幾件」，不用自己在一長串清單裡面找。
const TASK_GROUP_ORDER = ['overdue', 'today', 'week', 'later', 'none'];
const TASK_GROUP_LABELS = { overdue: '⚠️ 已過期', today: '📍 今天', week: '📅 本週內', later: '🗓️ 之後', none: '🗂️ 沒有設定到期日' };

function taskDueBucket(dueDate) {
  if (!dueDate) return 'none';
  const todayStr = new Date().toISOString().slice(0, 10);
  if (dueDate < todayStr) return 'overdue';
  if (dueDate === todayStr) return 'today';
  const diffDays = Math.round((new Date(dueDate + 'T00:00:00') - new Date(todayStr + 'T00:00:00')) / 86400000);
  return diffDays <= 7 ? 'week' : 'later';
}

async function loadTasks() {
  const area = $('#taskListArea');
  if (!area) return;
  try {
    const [pending, done] = await Promise.all([api('/tasks?status=pending'), api('/tasks?status=completed')]);
    taskDataPending = pending;
    taskDataDone = done;
    populateTaskNoteDatalist([...pending, ...done]);
    renderTaskListArea();
  } catch (e) {
    area.innerHTML = '';
    area.appendChild(el('div', { class: 'empty-state' }, '任務資料暫時無法取得'));
  }
}

function applyTaskFilters(rows) {
  let out = rows;
  const q = taskFilterText.trim().toLowerCase();
  if (q) out = out.filter((t) => (t.title || '').toLowerCase().includes(q) || (t.note || '').toLowerCase().includes(q));
  if (taskFilterPriority) out = out.filter((t) => t.priority === taskFilterPriority);
  return out;
}

// 分頁籤/篩選/批次模式只是「怎麼呈現已經拿到的資料」，不需要重打 API，切換時直接重畫這個函式就好，
// 手感比每次都重新 fetch 快很多。
function renderTaskListArea() {
  const area = $('#taskListArea');
  if (!area) return;
  $('#taskTabPending').classList.toggle('active', taskViewTab === 'pending');
  $('#taskTabDone').classList.toggle('active', taskViewTab === 'done');
  area.innerHTML = '';

  if (taskViewTab === 'pending') {
    const filtered = applyTaskFilters(taskDataPending);
    if (!taskDataPending.length) {
      area.appendChild(el('div', { class: 'empty-state' }, '目前沒有待完成的任務'));
    } else if (!filtered.length) {
      area.appendChild(el('div', { class: 'empty-state' }, '沒有符合篩選條件的任務'));
    } else {
      const grouped = {};
      filtered.forEach((t) => {
        const b = taskDueBucket(t.due_date);
        (grouped[b] = grouped[b] || []).push(t);
      });
      TASK_GROUP_ORDER.forEach((bucket) => {
        const rows = grouped[bucket];
        if (!rows || !rows.length) return;
        area.appendChild(el('div', { class: 'task-group-header', style: 'display:flex;align-items:center;gap:8px' }, [
          el('span', {}, `${TASK_GROUP_LABELS[bucket]} (${rows.length})`),
          // 過期任務常常一堆一堆卡在那裡沒人處理，這裡加一顆「全選」捷徑，直接把整組帶進批次模式，
          // 不用一筆一筆手動勾選才能批次完成/刪除。
          bucket === 'overdue' ? el('button', {
            class: 'btn btn-ghost', style: 'font-size:10.5px;padding:2px 8px;margin-left:auto;font-weight:600',
            onclick: () => selectOverdueForBatch(rows.map((r) => r.id)),
          }, '☑️ 全選批次處理') : null,
        ]));
        rows.forEach((t) => area.appendChild(buildTaskRow(t)));
      });
    }
  } else {
    const filtered = applyTaskFilters(taskDataDone);
    if (!taskDataDone.length) {
      area.appendChild(el('div', { class: 'empty-state' }, '還沒有完成的任務'));
    } else if (!filtered.length) {
      area.appendChild(el('div', { class: 'empty-state' }, '沒有符合篩選條件的任務'));
    } else {
      filtered.forEach((t) => {
        area.appendChild(el('div', { class: 'coping-note-item' }, [
          el('div', { class: 'content', style: 'text-decoration:line-through;opacity:0.6' }, t.title),
          el('button', { class: 'btn btn-ghost', style: 'font-size:12px', onclick: () => completeTask(t.id, false) }, '取消完成'),
        ]));
      });
    }
  }
  updateTaskBatchBar();
}

function switchTaskViewTab(tab) {
  taskViewTab = tab;
  renderTaskListArea();
}

// v0.80：優先度色條跟願望清單共用同一套 rb-blue/rb-violet/rb-red 色彩語言 (見
// WISHLIST_PRIORITY_RIBBON)，全站「優先度」只用一套顏色講一次，不是待辦自己另外
// 發明一組色碼。
// v0.87：色條跟優先度圓點同一套語意 (低=中性、中=金、高=紅)，不再用藍/紫
const TASK_PRIORITY_RIBBON = { low: 'rb-neutral', medium: 'rb-gold', high: 'rb-red' };
function buildTaskRow(t) {
  const hasSubtasks = t.totalSubtasks > 0;
  const pct = hasSubtasks ? Math.round((t.completedSubtasks / t.totalSubtasks) * 100) : 0;
  const subtaskPanel = el('div', { class: 'task-subtask-panel', style: 'display:none' });
  const bucket = taskDueBucket(t.due_date);
  const isOverdue = bucket === 'overdue';
  const ribbonClass = TASK_PRIORITY_RIBBON[t.priority] || 'rb-violet';
  const row = el('div', { class: `task-row-wrap priority-${t.priority || 'medium'}${isOverdue ? ' overdue' : ''}` }, [
    el('div', { class: `coping-note-item ${ribbonClass}` }, [
      taskBatchMode ? el('input', {
        type: 'checkbox', style: 'margin-top:3px', checked: taskSelectedIds.has(t.id),
        onchange: (ev) => { if (ev.target.checked) taskSelectedIds.add(t.id); else taskSelectedIds.delete(t.id); updateTaskBatchBar(); },
      }) : null,
      el('label', { style: 'display:flex;align-items:flex-start;gap:8px;flex:1;cursor:pointer' }, [
        el('input', { type: 'checkbox', style: 'margin-top:3px', onchange: () => completeTask(t.id, true) }),
        el('div', { class: 'content' }, [
          el('div', {}, [
            `${PRIORITY_LABEL[t.priority] || ''} ${t.title}${t.energy_level ? ` · ${ENERGY_LABEL[t.energy_level]}` : ''} `,
            t.recurrence ? el('span', { class: 'badge badge-neutral' }, `🔁 ${RECURRENCE_LABEL[t.recurrence]}`) : null,
          ]),
          el('div', { class: 'hint', style: 'margin:2px 0 0' }, [
            isOverdue
              ? el('span', { class: 'task-overdue-badge' }, `⚠️ 已過期 (${t.due_date})`)
              : (t.due_date ? `到期：${t.due_date}` : '沒有設定到期日'),
            t.note ? ` · ${t.note}` : '',
          ]),
          t.remind_at ? el('div', { class: 'hint', style: 'margin:2px 0 0' }, [
            el('span', {}, t.remind_sent_at ? `🔔 已於 ${formatDateTimeShort(t.remind_at)} 提醒過` : `🔔 將於 ${formatDateTimeShort(t.remind_at)} 提醒`),
            !t.remind_sent_at ? el('button', { class: 'btn btn-ghost', style: 'font-size:10px;padding:1px 6px;margin-left:6px', onclick: (ev) => { ev.stopPropagation(); cancelTaskReminder(t.id); } }, '取消提醒') : null,
          ]) : null,
          hasSubtasks ? el('div', { class: 'task-subtask-progress-wrap' }, [
            el('div', { class: 'task-subtask-progress-bar' }, [el('div', { class: 'task-subtask-progress-fill', style: `width:${pct}%` })]),
            el('span', { class: 'task-subtask-progress-label' }, `${t.completedSubtasks}/${t.totalSubtasks} 小任務`),
          ]) : null,
        ]),
      ]),
      // v0.87：操作按鈕原本跟標題擠在同一列，手機上標題被壓成一個字一行；改成標題底下一排。
      el('div', { class: 'task-row-actions' }, [
        isOverdue ? el('button', { class: 'btn btn-ghost', onclick: () => snoozeTaskToToday(t.id) }, '⏩ 延到今天') : null,
        el('button', { class: 'btn btn-ghost', 'aria-label': '編輯', onclick: () => startEditTask(t) }, '✏️ 編輯'),
        el('button', { class: 'btn btn-ghost', onclick: () => toggleSubtaskPanel(t.id, subtaskPanel) }, hasSubtasks ? '拆解' : '➕ 拆小任務'),
        el('button', { class: 'del-btn', 'aria-label': '刪除', onclick: () => deleteTask(t.id) }, '✕'),
      ]),
    ]),
    subtaskPanel,
  ]);
  // 重新整理清單 (例如新增/勾選小任務後) 會整個重建 DOM，這裡讓「已經展開過」的
  // 小任務面板保持展開狀態，不然每次操作完面板都會被重建成收合狀態，看起來像沒生效。
  if (expandedTaskSubtasks.has(t.id)) {
    subtaskPanel.style.display = 'block';
    renderSubtaskPanel(t.id, subtaskPanel);
  }
  return row;
}

// 過期任務不自動刪除 (過期通常只是日期沒抓準，不代表這件事不重要了，悄悄刪掉會讓使用者以為
// 資料不見)——改成兩個使用者自己按的快速處理：單筆「延到今天」直接把到期日改成今天，
// 或者下面的「全選批次處理」一次把整組過期任務帶進批次模式，自己決定要完成還是刪除。
async function snoozeTaskToToday(id) {
  try {
    await api(`/tasks/${id}`, { method: 'PUT', body: { dueDate: todayStr() } });
    showToast('已延到今天');
    loadTasks();
    loadTaskSuggestions();
  } catch (e) { showToast('延期失敗：' + e.message); }
}

function selectOverdueForBatch(ids) {
  taskBatchMode = true;
  ids.forEach((id) => taskSelectedIds.add(id));
  const btn = $('#taskBatchToggleBtn');
  if (btn) btn.classList.add('btn-primary');
  renderTaskListArea();
  showToast(`已選取 ${ids.length} 筆已過期任務，可以在下面按批次完成或刪除`);
}

function toggleTaskBatchMode() {
  taskBatchMode = !taskBatchMode;
  if (!taskBatchMode) taskSelectedIds.clear();
  const btn = $('#taskBatchToggleBtn');
  if (btn) btn.classList.toggle('btn-primary', taskBatchMode);
  renderTaskListArea();
}

function updateTaskBatchBar() {
  const bar = $('#taskBatchBar');
  if (!bar) return;
  bar.style.display = taskBatchMode && taskSelectedIds.size > 0 ? '' : 'none';
  const countEl = $('#taskBatchCount');
  if (countEl) countEl.textContent = `已選 ${taskSelectedIds.size} 筆`;
}

async function batchCompleteTasks() {
  const ids = [...taskSelectedIds];
  if (!ids.length) return;
  try {
    await Promise.all(ids.map((id) => api(`/tasks/${id}/complete`, { method: 'PUT', body: { completed: true } })));
    showToast(`已完成 ${ids.length} 筆任務`);
    taskSelectedIds.clear();
    loadTasks();
    loadTaskSuggestions();
    loadTaskReview();
  } catch (e) { showToast('批次完成失敗：' + e.message); }
}

async function batchDeleteTasks() {
  const ids = [...taskSelectedIds];
  if (!ids.length) return;
  try {
    await Promise.all(ids.map((id) => api(`/tasks/${id}`, { method: 'DELETE' })));
    showToast(`已刪除 ${ids.length} 筆任務`);
    taskSelectedIds.clear();
    loadTasks();
    loadTaskSuggestions();
  } catch (e) { showToast('批次刪除失敗：' + e.message); }
}

function populateTaskNoteDatalist(rows) {
  const list = $('#taskNoteList');
  if (!list) return;
  const notes = [...new Set(rows.map((r) => (r.note || '').trim()).filter(Boolean))];
  list.innerHTML = '';
  notes.slice(0, 50).forEach((n) => list.appendChild(el('option', { value: n })));
}

async function completeTask(id, completed) {
  try {
    const res = await api(`/tasks/${id}/complete`, { method: 'PUT', body: { completed } });
    if (res.nextTaskId) showToast('已完成，下一次的重複任務已自動建立');
    loadTasks();
    loadTaskSuggestions();
    loadTaskReview();
  } catch (e) { showToast('更新失敗：' + e.message); }
}
async function deleteTask(id) {
  try {
    await api(`/tasks/${id}`, { method: 'DELETE' });
    loadTasks();
    loadTaskSuggestions();
  } catch (e) { showToast('刪除失敗：' + e.message); }
}

// 把 ISO 時間戳記轉成「07/30 14:05」這種簡短的本地時間顯示，任務清單上的提醒時間用這個格式。
function formatDateTimeShort(iso) {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  const hh = String(d.getHours()).padStart(2, '0');
  const mi = String(d.getMinutes()).padStart(2, '0');
  return `${mm}/${dd} ${hh}:${mi}`;
}

async function cancelTaskReminder(id) {
  try {
    await api(`/tasks/${id}`, { method: 'PUT', body: { remindAt: null } });
    loadTasks();
  } catch (e) { showToast('取消提醒失敗：' + e.message); }
}

// ---- 小任務 (待辦拆解成子項目 + 進度追蹤) ----
const expandedTaskSubtasks = new Set();

async function toggleSubtaskPanel(taskId, panelEl) {
  if (expandedTaskSubtasks.has(taskId)) {
    expandedTaskSubtasks.delete(taskId);
    panelEl.style.display = 'none';
    panelEl.innerHTML = '';
    return;
  }
  expandedTaskSubtasks.add(taskId);
  panelEl.style.display = 'block';
  await renderSubtaskPanel(taskId, panelEl);
}

// v0.53：小任務可以各自設定優先度跟精準提醒時間，卡片上用小小的優先度標籤 + 🔔 提醒時間
// 顯示出來；點優先度標籤可以直接切換。
// v0.80：點 🔔 原本會跳 prompt() 問時間，改成原地展開一個 datetime-local 輸入框
// (跟主任務新增表單同一套時區換算邏輯：本地時間字串 <-> ISO)，不用再跳彈窗、也不用
// 自己手打日期格式。
let subtaskReminderOpenId = null;

function isoToDatetimeLocalValue(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '';
  const local = new Date(d.getTime() - d.getTimezoneOffset() * 60000);
  return local.toISOString().slice(0, 16);
}

async function renderSubtaskPanel(taskId, panelEl) {
  panelEl.innerHTML = '';
  panelEl.appendChild(el('div', { class: 'empty-state' }, '載入中...'));
  try {
    const subs = await api(`/tasks/${taskId}/subtasks`);
    panelEl.innerHTML = '';
    if (subs.length) {
      const list = el('div', { class: 'task-subtask-list' });
      subs.forEach((s) => {
        list.appendChild(el('div', { class: 'task-subtask-item' }, [
          el('div', { class: 'task-subtask-item-line1' }, [
            el('label', { style: 'display:flex;align-items:center;gap:6px;flex:1;cursor:pointer;min-width:0' }, [
              el('input', { type: 'checkbox', checked: !!s.completed, onchange: (ev) => toggleSubtask(s.id, ev.target.checked, taskId, panelEl) }),
              el('span', { style: (s.completed ? 'text-decoration:line-through;opacity:0.55;' : '') + 'overflow:hidden;text-overflow:ellipsis;white-space:nowrap' }, s.title),
            ]),
            el('button', {
              class: 'dash-section-action', style: 'font-size:11px;padding:2px 6px;flex-shrink:0',
              onclick: () => { subtaskReminderOpenId = subtaskReminderOpenId === s.id ? null : s.id; renderSubtaskPanel(taskId, panelEl); },
              title: s.remind_at ? `將於 ${formatDateTimeShort(s.remind_at)} 提醒` : '設定精準提醒',
            }, s.remind_at ? `🔔 ${formatDateTimeShort(s.remind_at)}` : '🔔'),
            el('button', { class: 'del-btn', onclick: () => deleteSubtask(s.id, taskId, panelEl) }, '✕'),
          ]),
          prioritySliderEl(`subtaskPriority-${s.id}`, s.priority, {
            compact: true,
            ariaLabel: '子任務優先度',
            onChange: (v) => saveSubtaskPriority(s.id, v),
          }),
          subtaskReminderOpenId === s.id
            ? el('div', { class: 'form-row', style: 'margin-top:6px;align-items:center' }, [
                el('input', { id: `subtaskReminderInput-${s.id}`, type: 'datetime-local', value: isoToDatetimeLocalValue(s.remind_at), style: 'font-size:12px' }),
                el('button', { class: 'btn btn-ghost', style: 'font-size:12px', onclick: () => saveSubtaskReminder(s.id, taskId, panelEl) }, '儲存'),
                s.remind_at ? el('button', { class: 'btn btn-ghost', style: 'font-size:12px', onclick: () => clearSubtaskReminder(s.id, taskId, panelEl) }, '清除') : null,
                el('button', { class: 'btn btn-ghost', style: 'font-size:12px', onclick: () => { subtaskReminderOpenId = null; renderSubtaskPanel(taskId, panelEl); } }, '取消'),
              ])
            : null,
        ]));
      });
      panelEl.appendChild(list);
    }
    panelEl.appendChild(el('div', { class: 'task-subtask-add-row' }, [
      el('input', { id: `subtaskInput-${taskId}`, placeholder: '新增小任務...', onkeydown: (ev) => { if (ev.key === 'Enter') addSubtask(taskId, panelEl); } }),
      el('button', { class: 'btn btn-ghost', onclick: () => addSubtask(taskId, panelEl) }, '新增'),
    ]));
  } catch (e) {
    panelEl.innerHTML = '';
    panelEl.appendChild(el('div', { class: 'empty-state' }, '小任務暫時無法取得'));
  }
}

async function addSubtask(taskId, panelEl) {
  const input = $(`#subtaskInput-${taskId}`);
  const title = input ? input.value.trim() : '';
  if (!title) return;
  try {
    await api(`/tasks/${taskId}/subtasks`, { method: 'POST', body: { title } });
    await renderSubtaskPanel(taskId, panelEl);
    loadTasks();
  } catch (e) { showToast('新增小任務失敗：' + e.message); }
}

async function toggleSubtask(subId, completed, taskId, panelEl) {
  try {
    await api(`/tasks/subtasks/${subId}`, { method: 'PUT', body: { completed } });
    await renderSubtaskPanel(taskId, panelEl);
    loadTasks();
  } catch (e) { showToast('更新失敗：' + e.message); }
}

// 子任務優先度拉桿是「即時模式」(見 prioritySliderEl 說明)：放開手指的瞬間直接存檔，
// 不用像以前的循環按鈕那樣整個小任務面板重新 render——拉桿自己的標籤文字已經會即時
// 更新，子任務清單的排序也不是依優先度排的，不需要重新抓資料。
async function saveSubtaskPriority(subId, priority) {
  await api(`/tasks/subtasks/${subId}`, { method: 'PUT', body: { priority } });
}

async function saveSubtaskReminder(subId, taskId, panelEl) {
  const input = $(`#subtaskReminderInput-${subId}`);
  const val = input ? input.value : '';
  if (!val) { showToast('請先選擇提醒時間'); return; }
  const nextIso = new Date(val).toISOString();
  try {
    await api(`/tasks/subtasks/${subId}`, { method: 'PUT', body: { remindAt: nextIso } });
    subtaskReminderOpenId = null;
    await renderSubtaskPanel(taskId, panelEl);
    showToast('已設定提醒');
  } catch (e) { showToast('更新失敗：' + e.message); }
}

async function clearSubtaskReminder(subId, taskId, panelEl) {
  try {
    await api(`/tasks/subtasks/${subId}`, { method: 'PUT', body: { remindAt: null } });
    subtaskReminderOpenId = null;
    await renderSubtaskPanel(taskId, panelEl);
    showToast('已清除提醒');
  } catch (e) { showToast('更新失敗：' + e.message); }
}

async function deleteSubtask(subId, taskId, panelEl) {
  try {
    await api(`/tasks/subtasks/${subId}`, { method: 'DELETE' });
    await renderSubtaskPanel(taskId, panelEl);
    loadTasks();
  } catch (e) { showToast('刪除失敗：' + e.message); }
}

// ===================== 人際關係 =====================
const REL_VIEW_TABS = [
  { key: 'contacts', label: '聯絡人' },
  { key: 'reminders', label: '提醒與重要日子' },
];
let relViewTab = 'contacts';
function switchRelViewTab(tab) { relViewTab = tab; renderRelationships(); }

function renderRelationships() {
  const c = $('#tab-relationships');
  c.innerHTML = '';

  const wrap = el('div', { class: 'rel-clean-wrap' });
  wrap.appendChild(el('div', { class: 'task-view-tabs' }, REL_VIEW_TABS.map((t) =>
    el('button', { class: `task-view-tab${relViewTab === t.key ? ' active' : ''}`, onclick: () => switchRelViewTab(t.key) }, t.label)
  )));

  const sections = el('div', { class: 'rel-clean-sections' });

  if (relViewTab === 'contacts') {
    sections.appendChild(el('div', { class: 'card' }, [
      el('h3', {}, '➕ 新增聯絡人'),
      el('div', { class: 'form-row' }, [
        el('input', { id: 'relName', placeholder: '姓名' }),
        el('input', { id: 'relType', list: 'relTypeList', placeholder: '關係 (選填，例如：家人、朋友)' }),
        el('datalist', { id: 'relTypeList' }, ['家人', '朋友', '同事', '其他'].map((v) => el('option', { value: v }))),
        el('input', { id: 'relBirthday', placeholder: '生日 MM-DD (選填)' }),
      ]),
      el('button', { class: 'btn btn-primary', style: 'margin-top:10px', onclick: addRelationship }, '新增'),
    ]));
    sections.appendChild(el('div', { class: 'card' }, [
      el('h3', {}, '👥 聯絡人列表'),
      el('p', { class: 'hint' }, '每位聯絡人可以記一筆互動，或設定「多久沒聯絡要提醒我」的天數 (選填，不設就不會被提醒)。'),
      el('div', { id: 'relListArea' }, el('div', { class: 'empty-state' }, '載入中...')),
    ]));
  } else if (relViewTab === 'reminders') {
    sections.appendChild(el('div', { class: 'card' }, [
      el('h3', {}, '🕰️ 好一陣子沒特別聯繫'),
      el('p', { class: 'hint' }, '只是時間上的小提醒，純參考用，要不要聯絡、什麼時候聯絡都由你自己決定；每個人可以在「聯絡人」分頁設定自己的提醒週期，或乾脆不設。'),
      el('div', { id: 'relOverdueArea' }, el('div', { class: 'empty-state' }, '載入中...')),
    ]));
    sections.appendChild(el('div', { class: 'card' }, [
      el('h3', {}, '🎂 未來 30 天內的生日'),
      el('div', { id: 'relBirthdayList' }, el('div', { class: 'empty-state' }, '載入中...')),
    ]));
    sections.appendChild(el('div', { class: 'card' }, [
      el('h3', {}, '📌 重要日期'),
      el('p', { class: 'hint' }, '不只是生日，紀念日、對方的特殊日子都可以記，每年會自動重複提醒。'),
      el('div', { class: 'form-row' }, [
        el('input', { id: 'impDateLabel', placeholder: '名稱，如：交往紀念日' }),
        el('input', { id: 'impDateMonthDay', placeholder: 'MM-DD，例如 08-15' }),
        el('select', { id: 'impDateRel' }, [el('option', { value: '' }, '不綁定聯絡人 (選填)')]),
      ]),
      el('button', { class: 'btn btn-primary', style: 'margin-top:8px', onclick: addImportantDate }, '新增日期'),
      el('div', { id: 'impDateUpcoming', style: 'margin-top:12px' }, el('div', { class: 'empty-state' }, '載入中...')),
      el('div', { id: 'impDateList', style: 'margin-top:8px' }),
    ]));
    sections.appendChild(el('div', { class: 'card' }, [
      el('h3', {}, '📅 重要日期季節聚集'),
      el('p', { class: 'hint' }, '把生日+重要日期依月份分組，看看哪幾個月特別密集，提前有個底。'),
      el('div', { id: 'relDateClustersArea' }, el('div', { class: 'empty-state' }, '載入中...')),
    ]));
  }

  wrap.appendChild(sections);
  c.appendChild(wrap);

  if (relViewTab === 'contacts') {
    loadRelationships();
  } else if (relViewTab === 'reminders') {
    loadUpcomingBirthdays();
    loadOverdueContacts();
    loadImportantDates();
    loadDateClusters();
  }
}

// v0.68：#14 人際重要日期季節聚集提醒
async function loadDateClusters() {
  const area = $('#relDateClustersArea');
  if (!area) return;
  try {
    const r = await api('/relationships/date-clusters');
    area.innerHTML = '';
    if (!r.hasEnoughData) { area.appendChild(el('div', { class: 'empty-state' }, r.note)); return; }
    if (!r.busyMonths.length) { area.appendChild(el('div', { class: 'empty-state' }, '目前還看不出特別密集的月份')); return; }
    if (r.upcomingBusyMonths.length) {
      area.appendChild(el('p', {}, `⏰ 接下來 60 天內會進入密集月份：${r.upcomingBusyMonths.map((m) => `${m.month} 月 (${m.count} 筆)`).join('、')}`));
    }
    r.busyMonths.forEach((m) => {
      area.appendChild(el('div', { class: 'mood-signal-item' }, `${m.month} 月：${m.count} 筆（${m.items.join('、')}）`));
    });
    area.appendChild(el('p', { class: 'hint', style: 'margin-top:4px' }, r.disclaimer));
  } catch (e) { area.innerHTML = ''; area.appendChild(el('div', { class: 'empty-state' }, '分析資料暫時無法取得')); }
}

async function addImportantDate() {
  const label = $('#impDateLabel').value.trim();
  const monthDay = $('#impDateMonthDay').value.trim();
  if (!label) { showToast('請填寫日期名稱'); return; }
  if (!/^\d{2}-\d{2}$/.test(monthDay)) { showToast('日期請用 MM-DD 格式，例如 08-15'); return; }
  try {
    await api('/relationships/important-dates', { method: 'POST', body: { label, monthDay, relationshipId: $('#impDateRel').value || null } });
    $('#impDateLabel').value = ''; $('#impDateMonthDay').value = '';
    loadImportantDates();
  } catch (e) { showToast('新增失敗：' + e.message); }
}
async function deleteImportantDate(id) {
  await api(`/relationships/important-dates/${id}`, { method: 'DELETE' });
  loadImportantDates();
}
async function loadImportantDates() {
  const upcomingBox = $('#impDateUpcoming');
  const listBox = $('#impDateList');
  const relSelect = $('#impDateRel');
  if (!upcomingBox) return;
  try {
    const [upcoming, all, rels] = await Promise.all([
      api('/relationships/important-dates/upcoming'),
      api('/relationships/important-dates'),
      api('/relationships'),
    ]);
    if (relSelect) {
      relSelect.innerHTML = '';
      relSelect.appendChild(el('option', { value: '' }, '不綁定聯絡人 (選填)'));
      rels.forEach((r) => relSelect.appendChild(el('option', { value: r.id }, r.name)));
    }
    upcomingBox.innerHTML = '';
    if (!upcoming.length) {
      upcomingBox.appendChild(el('div', { class: 'empty-state' }, '未來 30 天內沒有重要日期'));
    } else {
      upcoming.forEach((r) => {
        upcomingBox.appendChild(el('div', { class: 'mood-signal-item' }, `${r.label}${r.relationship_name ? `（${r.relationship_name}）` : ''} · ${r.daysUntil === 0 ? '就是今天！' : `還有 ${r.daysUntil} 天`}`));
      });
    }
    listBox.innerHTML = '';
    all.forEach((r) => {
      listBox.appendChild(el('div', { class: 'coping-note-item' }, [
        el('div', { class: 'content' }, `${r.label}${r.relationship_name ? `（${r.relationship_name}）` : ''} · ${r.month_day}`),
        el('button', { class: 'del-btn', onclick: () => deleteImportantDate(r.id) }, '✕'),
      ]));
    });
  } catch (e) { upcomingBox.innerHTML = ''; upcomingBox.appendChild(el('div', { class: 'empty-state' }, '資料暫時無法取得')); }
}
async function addRelationship() {
  const name = $('#relName').value.trim();
  if (!name) { showToast('請填寫姓名'); return; }
  const birthday = $('#relBirthday').value.trim();
  if (birthday && !/^\d{2}-\d{2}$/.test(birthday)) { showToast('生日請用 MM-DD 格式，例如 03-15'); return; }
  try {
    await api('/relationships', { method: 'POST', body: { name, relationType: $('#relType').value.trim(), birthday: birthday || null } });
    $('#relName').value = ''; $('#relType').value = ''; $('#relBirthday').value = '';
    loadRelationships();
    loadUpcomingBirthdays();
    loadOverdueContacts();
  } catch (e) { showToast('新增失敗：' + e.message); }
}
async function loadOverdueContacts() {
  const area = $('#relOverdueArea');
  if (!area) return;
  try {
    const rows = await api('/relationships/overdue');
    area.innerHTML = '';
    if (!rows.length) {
      area.appendChild(el('div', { class: 'empty-state' }, '目前沒有特別要標記的' ));
      return;
    }
    rows.forEach((r) => {
      const timeText = r.daysSinceContact == null ? '目前還沒有互動紀錄' : `距離上次記錄的互動 ${r.daysSinceContact} 天`;
      area.appendChild(el('div', { class: 'mood-signal-item' }, `${r.name}${r.relation_type ? `（${r.relation_type}）` : ''} · ${timeText}`));
    });
  } catch (e) {
    area.innerHTML = '';
    area.appendChild(el('div', { class: 'empty-state' }, '資料暫時無法取得'));
  }
}
async function loadUpcomingBirthdays() {
  const area = $('#relBirthdayList');
  if (!area) return;
  try {
    const rows = await api('/relationships/upcoming-birthdays');
    area.innerHTML = '';
    if (!rows.length) {
      area.appendChild(el('div', { class: 'empty-state' }, '未來 30 天內沒有生日'));
      return;
    }
    rows.forEach((r) => {
      area.appendChild(el('div', { class: 'mood-signal-item' }, `${r.name}${r.relation_type ? `（${r.relation_type}）` : ''} · ${r.daysUntil === 0 ? '就是今天！' : `還有 ${r.daysUntil} 天`}`));
    });
  } catch (e) {
    area.innerHTML = '';
    area.appendChild(el('div', { class: 'empty-state' }, '生日資料暫時無法取得'));
  }
}
// v0.65：互動品質標記——'positive'(正向) / 'neutral'(普通) / 'draining'(勉強/消耗)。
const REL_QUALITY_OPTIONS = [
  { value: '', label: '這次感覺 (選填)' },
  { value: 'positive', label: '😊 正向' },
  { value: 'neutral', label: '😐 普通' },
  { value: 'draining', label: '😮‍💨 有點消耗' },
];
function relQualityBadgeText(summary) {
  if (!summary) return null;
  const total = (summary.positive || 0) + (summary.neutral || 0) + (summary.draining || 0);
  if (total < 3) return null; // 樣本太少不下判斷，避免一兩筆資料就貼標籤
  if (summary.draining / total >= 0.5) return { text: '偏消耗', cls: 'rel-quality-draining' };
  if (summary.positive / total >= 0.6) return { text: '多半正向', cls: 'rel-quality-positive' };
  return null;
}
async function loadRelationships() {
  const area = $('#relListArea');
  if (!area) return;
  try {
    const [rows, qualitySummary] = await Promise.all([
      api('/relationships'),
      api('/relationships/interaction-quality-summary').catch(() => ({})),
    ]);
    area.innerHTML = '';
    if (!rows.length) {
      area.appendChild(el('div', { class: 'empty-state' }, '還沒有加入任何聯絡人'));
      return;
    }
    rows.forEach((r) => {
      const item = el('div', { class: 'coping-note-item', style: 'flex-direction:column;align-items:stretch;gap:6px' }, []);
      const badge = relQualityBadgeText(qualitySummary[r.id]);
      item.appendChild(el('div', { style: 'display:flex;justify-content:space-between;align-items:center' }, [
        el('div', { class: 'content' }, [
          `${r.name}${r.relation_type ? `（${r.relation_type}）` : ''}${r.birthday ? ` · 生日 ${r.birthday}` : ''}`,
          badge ? el('span', { class: `rel-quality-badge ${badge.cls}` }, badge.text) : null,
        ].filter(Boolean)),
        el('button', { class: 'del-btn', onclick: () => deleteRelationship(r.id) }, '✕'),
      ]));
      item.appendChild(el('input', { id: `relNote_${r.id}`, list: 'relNoteList', placeholder: '記一筆互動 (例如：一起吃了晚餐)', style: 'width:100%' }));
      item.appendChild(chipSelectEl({
        id: `relQuality_${r.id}`, value: '', style: 'margin-top:6px',
        options: REL_QUALITY_OPTIONS.filter((o) => o.value).map((o) => ({ value: o.value, label: o.label })),
      }));
      item.appendChild(el('div', { class: 'form-row', style: 'margin-top:6px' }, [
        el('button', { class: 'btn btn-ghost', style: 'font-size:12px' , onclick: () => addInteraction(r.id) }, '新增互動'),
      ]));
      item.appendChild(el('div', { class: 'form-row' }, [
        el('input', {
          id: `relInterval_${r.id}`, type: 'number', min: '0',
          placeholder: '提醒週期 (天，選填)',
          value: r.reminder_interval_days != null ? r.reminder_interval_days : '',
          style: 'flex:1',
        }),
        el('button', { class: 'btn btn-ghost', style: 'font-size:12px', onclick: () => saveReminderInterval(r) }, '儲存提醒週期'),
      ]));
      area.appendChild(item);
    });
    area.appendChild(el('datalist', { id: 'relNoteList' }));
    populateRelNoteDatalist(rows);
  } catch (e) {
    area.innerHTML = '';
    area.appendChild(el('div', { class: 'empty-state' }, '聯絡人資料暫時無法取得'));
  }
}
async function addInteraction(relId) {
  const input = $(`#relNote_${relId}`);
  const note = input.value.trim();
  if (!note) return;
  const qualitySelect = $(`#relQuality_${relId}`);
  const quality = qualitySelect && qualitySelect.value ? qualitySelect.value : null;
  try {
    await api(`/relationships/${relId}/interactions`, { method: 'POST', body: { note, quality } });
    input.value = '';
    if (qualitySelect) qualitySelect.value = '';
    showToast('已記錄這筆互動');
    loadOverdueContacts();
    loadRelationships();
  } catch (e) { showToast('新增失敗：' + e.message); }
}
async function deleteRelationship(id) {
  try {
    await api(`/relationships/${id}`, { method: 'DELETE' });
    loadRelationships();
    loadUpcomingBirthdays();
    loadOverdueContacts();
  } catch (e) { showToast('刪除失敗：' + e.message); }
}
async function saveReminderInterval(r) {
  const input = $(`#relInterval_${r.id}`);
  const val = input.value.trim();
  try {
    await api(`/relationships/${r.id}`, {
      method: 'PUT',
      body: { reminderIntervalDays: val === '' ? null : Number(val) },
    });
    showToast('已儲存提醒週期');
    loadOverdueContacts();
  } catch (e) { showToast('儲存失敗：' + e.message); }
}
// 表單自動記憶：把之前記錄過的互動內容整理成建議清單 (最多抓最近幾位聯絡人的紀錄，避免一次打太多 API)
async function populateRelNoteDatalist(rels) {
  const list = $('#relNoteList');
  if (!list || !rels.length) return;
  try {
    const results = await Promise.all(rels.slice(0, 15).map((r) => api(`/relationships/${r.id}/interactions`).catch(() => [])));
    const notes = [...new Set(results.flat().map((i) => (i.note || '').trim()).filter(Boolean))];
    list.innerHTML = '';
    notes.slice(0, 50).forEach((n) => list.appendChild(el('option', { value: n })));
  } catch (e) { /* 自動完成失敗不影響主要功能，靜默略過 */ }
}

// ===================== 陪伴另一半 =====================
// 給「幫另一半記錄生理週期」的使用者一個獨立的頁面：目前大概在哪個階段、可以怎麼體貼地陪伴，
// 以及一份簡單的紀錄日誌 (每次記錄可以順便寫一句觀察，例如「她今天說有點累」)。
// 所有描述都刻意用「有些人可能」這種保留語氣，不做斷言、不做醫療建議，把最終判斷留給使用者自己觀察。
// v0.81：每個階段的建議從單一段「注意事項」擴充成三層——
//   tip：這個階段她大概是什麼狀態 (幫你理解，不是幫你貼標籤)
//   action：今天可以做的一件具體小事 (行動比原則好執行)
//   avoid：這個階段先避免的事
// 每個人狀況不同，這些是常見傾向不是鐵律，永遠以她本人當下說的為準。
const PARTNER_PHASE_TIPS = {
  menstrual: {
    label: '月經期',
    tip: '這幾天她的身體可能比較不舒服：經痛、腰痠、疲倦感增加都很常見，有些人還會頭痛或腸胃不適。安靜地陪伴通常比講道理有幫助。',
    action: '主動把一件她平常負責的事接過來（晚餐、洗碗、倒垃圾），不用問「需要幫忙嗎」，直接做。熱飲、熱敷墊、止痛藥備著但不強推。',
    avoid: '避免約很耗體力的行程，也不要說「多喝熱水」就結束——那句話本身沒錯，但單獨講會像敷衍。',
  },
  follicular: {
    label: '濾泡期',
    tip: '月經結束後體力和心情通常會回升，是整個週期裡狀態相對好的一段。',
    action: '想約會、討論比較需要專注的事情（旅行規劃、家裡的大決定），這段時間開口成功率通常最高。',
    avoid: '沒有特別要避免的，但別因為她狀態好就把所有累積的待辦一口氣倒給她。',
  },
  ovulation: {
    label: '排卵期',
    tip: '這幾天精神通常不錯，部分人會有輕微的排卵痛或分泌物變化，屬於正常現象。',
    action: '維持平常的相處步調就好。如果你們有懷孕規劃，這段是關鍵窗口；反過來說如果還沒有規劃，避孕要更確實。',
    avoid: '沒有特別要避免的。',
  },
  luteal: {
    label: '黃體期',
    tip: '排卵後身體開始為下次月經做準備，後半段（經前）比較容易水腫、胸部脹痛、想吃甜食或重口味、情緒起伏變大。',
    action: '多觀察少評論。她說累就讓她休息，想吃什麼就一起吃，不用糾正「你不是在減肥嗎」。',
    avoid: '避免在這段時間挑起需要冷靜討論的敏感話題，能等就等到下個濾泡期。',
  },
};
const PARTNER_PMS_TIP = '這幾天正好在「經前」這個常見比較敏感的時間窗，有些人在這階段容易累、情緒起伏比較大，這是常見的生理反應，不代表她怎麼了、也不代表你們之間有什麼問題。這時候少一點講道理、多一點耐心和空間，通常會比較有幫助。如果她因為小事發脾氣，先不要急著爭對錯——很多時候她自己也知道反應大了，你不追究，這件事過得比較快。';
// 遲到期是以前完全沒有的階段：她的月經比預估晚了，這段時間「她自己通常比你更焦慮」，
// 建議按遲到天數分層，愈晚愈需要實際的陪伴而不只是嘴上安慰。
function partnerLateTip(daysLate) {
  if (daysLate <= 3) {
    return {
      tip: '晚個幾天非常常見（壓力、睡眠、運動量的變化都會影響），大部分情況下過幾天就來了。',
      action: '什麼都不用做，也什麼都不用問。照常生活就是最好的支持。',
      avoid: '不要問「來了沒？」——她比你清楚，問了只會提醒她這件事。也不要開「是不是有了」的玩笑。',
    };
  }
  if (daysLate <= 7) {
    return {
      tip: '一週內的延遲仍在常見範圍，但她自己可能已經開始在意了。值得知道：焦慮本身就會讓月經更晚來，這是個容易惡性循環的機制。',
      action: '幫她把生活壓力降一點：家事多分擔一些、少排一點行程、睡前陪她做點放鬆的事。她想聊就聽，不想聊就不追問。',
      avoid: '不要每天問進度，也不要自己先慌——你的緊張她感受得到，只會加重她的壓力。',
    };
  }
  if (daysLate <= 14) {
    return {
      tip: '超過一週了。如果你們有懷孕的可能性，這是該面對的時間點；如果沒有，偶爾一次週期特別長也還是常見的。',
      action: '找一個放鬆的時機（不是睡前、不是吵架後）溫和地問她要不要驗一下，順口說一句「不管結果怎樣我都在」。驗孕棒可以你去買，減少她的心理門檻。',
      avoid: '決定權在她。她說再等等就再等等，不要自作主張或施壓。',
    };
  }
  return {
    tip: '超過兩週了，不論是否可能懷孕，這種長度的延遲都值得給婦產科看一次——長期壓力、多囊性卵巢、甲狀腺問題都可能是原因，讓專業判斷，不要兩個人自己瞎猜。',
    action: '主動說「我陪你去看醫生」，然後把掛號、交通這些雜事包下來。看診時她若希望你進去陪就進去，希望自己來就在外面等。',
    avoid: '不要拿網路查到的病名嚇她（也嚇自己）。查資料可以，下結論交給醫生。',
  };
}
// v0.83：症狀模式提示——完全被動，讀已經記錄的症狀標籤統計出來，不需要現在多做任何事。
// 資料太少 (hasEnoughData: false) 時不顯示，避免拿樣本太小的統計誤導人。
function symptomPatternHintEl(patterns) {
  if (!patterns || !patterns.hasEnoughData || !patterns.top.length) return null;
  const list = patterns.top.map((s) => `${s.symptom}(${s.count} 次)`).join('、');
  return el('p', { class: 'hint', style: 'margin-top:8px' }, `📊 根據你記錄的 ${patterns.sampleCount} 筆資料，她過去比較常提到的狀況：${list}——這次也可能出現類似狀況，先留意一下。`);
}

// 把 tip/action/avoid 三層渲染成統一的小區塊，遲到跟一般階段共用
function partnerTipBlockEl(tips) {
  return el('div', { style: 'margin-top:10px' }, [
    el('p', { style: 'margin:0;line-height:1.7' }, tips.tip),
    tips.action ? el('p', { class: 'hint', style: 'margin:8px 0 0;line-height:1.7' }, `✅ 可以做的一件事：${tips.action}`) : null,
    tips.avoid ? el('p', { class: 'hint', style: 'margin:6px 0 0;line-height:1.7' }, `🚫 先避免：${tips.avoid}`) : null,
  ].filter(Boolean));
}

// v0.35：陪伴日誌加上症狀勾選 (取代純打字)，記久一點就比較看得出她通常在哪個階段容易怎樣，
// 存法沿用後端本來就支援的 symptoms 陣列 (逗號分隔存進同一個欄位)，不用額外動資料庫。
const PARTNER_SYMPTOM_TAGS = ['經痛', '疲倦', '情緒起伏', '頭痛', '嗜睡', '食慾改變', '腹脹', '腰痠'];
let partnerSelectedSymptoms = new Set();
function togglePartnerSymptomTag(tag) {
  if (partnerSelectedSymptoms.has(tag)) partnerSelectedSymptoms.delete(tag);
  else partnerSelectedSymptoms.add(tag);
  document.querySelectorAll('#partnerSymptomRow .mood-tag-chip').forEach((b) => b.classList.toggle('selected', partnerSelectedSymptoms.has(b.dataset.tag)));
}

function renderPartnerCare() {
  const c = $('#tab-partnerCare');
  c.innerHTML = '';

  c.appendChild(el('div', { class: 'card' }, [
    el('h3', {}, '🌷 目前狀態'),
    el('div', { id: 'partnerStatusBody' }, el('div', { class: 'empty-state' }, '載入中...')),
  ]));

  // v0.82：這整個分頁原本預設「你是那個穩定輸出支持的人」，只給任務清單，沒有一個地方
  // 問過「你自己還好嗎」——長期單向的陪伴會把人耗竭。這張卡片是給陪伴者(通常是這個模組
  // 使用情境下的男方)自己的：快速記錄今天的狀態(直接借用「心靈」分頁本來就有的心情紀錄，
  // 不重複開一份資料)、怎麼分辨她是「在氣你」還是「只是不舒服在發洩」、還有兩人可以事先
  // 講好的「暫停用語」，撐不住的時候有一句話可以說，不用臨場想措辭。
  c.appendChild(el('div', { class: 'card' }, [
    el('h3', {}, '🌱 你自己也重要'),
    el('p', { class: 'hint' }, '陪伴是雙向的，不是你一個人負責穩住。這裡是留給你自己的一小塊空間。'),
    el('div', { id: 'partnerSelfCareBody', style: 'margin-top:8px' }, el('div', { class: 'empty-state' }, '載入中...')),
  ]));

  const partnerSymptomRow = el('div', { id: 'partnerSymptomRow', class: 'mood-tag-row', style: 'margin-top:10px' });
  PARTNER_SYMPTOM_TAGS.forEach((tag) => {
    partnerSymptomRow.appendChild(el('button', { class: 'mood-tag-chip', 'data-tag': tag, onclick: () => togglePartnerSymptomTag(tag) }, tag));
  });
  c.appendChild(el('div', { class: 'card' }, [
    el('h3', {}, '📝 記一筆'),
    el('p', { class: 'hint' }, '記錄這次月經開始日，也可以順便勾選她這次比較明顯的狀況，或自己寫點觀察，會變成下面的日誌；記久一點就比較看得出她通常在哪個階段容易怎樣。'),
    el('div', { class: 'form-row' }, [
      el('input', { id: 'partnerCycleDate', type: 'date', value: todayStr() }),
      el('input', { id: 'partnerCycleEndDate', type: 'date', placeholder: '結束日 (選填)' }),
      el('button', { class: 'btn btn-primary', onclick: addPartnerCycleEntry }, '記錄這次月經開始'),
    ]),
    el('p', { class: 'hint', style: 'margin-top:4px' }, '結束日選填，多填這個之後，經期天數跟排卵期推算會更準；不填的話系統會用預設的 5 天估算。'),
    partnerSymptomRow,
    el('input', { id: 'partnerCycleNote', placeholder: '想記點什麼嗎？(選填)', style: 'width:100%;margin-top:8px' }),
  ]));

  c.appendChild(el('div', { class: 'card' }, [
    el('h3', {}, '📔 陪伴日誌'),
    el('p', { class: 'hint' }, '你幫她記錄過的經期跟觀察備註，依時間排列。'),
    el('div', { id: 'partnerLogArea' }, el('div', { class: 'empty-state' }, '載入中...')),
  ]));

  c.appendChild(el('div', { class: 'card' }, [
    el('h3', {}, '🔗 家人/伴侶共享'),
    el('p', { class: 'hint' }, '雙方都要有自己的帳號：一邊產生邀請碼給對方，對方輸入邀請碼就完成連結。連結之後可以互相「唯讀」看到彼此的行事曆跟待辦事項 (不能互相修改)，任一方隨時可以解除連結。'),
    el('div', { id: 'partnerLinkArea' }, el('div', { class: 'empty-state' }, '載入中...')),
  ]));

  // v0.85：說明文字從頁面最上面移到最下面——一打開就先讀一段免責聲明，會把真正要看的
  // 「目前狀態」往下擠；內容不變，只換位置。
  c.appendChild(el('div', { class: 'disclaimer' }, '這裡的階段推算跟提示，是根據你記錄的經期開始日做統計上的估算，僅供理解與陪伴參考，不是醫療建議，每個人狀況不同，最準確的還是直接問她的感受和需求。'));
  loadPartnerStatus();
  loadPartnerLog();
  loadPartnerLinkArea();
  loadPartnerSelfCare();
}

// v0.82：「怎麼分辨她在氣你 vs 只是不舒服在發洩」——這不是要你當下去分析她 (那樣當場講
// 出來反而更容易火上加油)，是給你事後回想、少一點自我懷疑用的。三條線索都只是常見傾向，
// 不是鐵律，畢竟最準的永遠是她自己怎麼說。
function partnerAngerVsStateContentEl() {
  // v0.85：三段文字改成可展開的線索 (原生 <details>)，預設只展開第一條——原本整段攤開很長，
  // 在手機上要滑很久才看得到下面的暫停用語。內容一字不改。
  const clue = (title, body, open) => el('details', Object.assign({ class: 'partner-clue' }, open ? { open: '' } : {}), [
    el('summary', {}, title),
    el('p', {}, body),
  ]);
  return el('div', { style: 'margin-top:10px;padding-top:10px;border-top:1px solid var(--border)' }, [
    el('div', { style: 'font-weight:700;font-size:14px' }, '💭 她在氣你，還是只是不舒服？'),
    el('p', { class: 'hint', style: 'margin-top:6px;line-height:1.7' }, '不是要你當下分析她——那樣講出來通常只會更糟。這是給你事後回想用的，幾個常見的判斷線索：'),
    clue('她能具體講出「你做了 X」', '如果她生氣的點可以具體講出「你做了 X」，而且氣消之後那件事她還是在意，通常是真的對你有意見，值得認真聽、也值得道歉或調整。', true),
    clue('怎麼回應都不太對', '如果是那種你怎麼回應都不太對、講什麼都能被挑出問題、或她事後自己也覺得「剛剛好像反應有點大」，這大多是狀態影響了情緒閾值，不完全是針對你這個人。', false),
    clue('這條線是給你自己用的', '這條線不是拿來當下反駁她的，是讓你事後可以跟自己說一句「這個大概不是真的在說我」，少一點自我懷疑。', false),
  ]);
}

// v0.82：暫停用語——兩人事先(平常心情好的時候)講好、快要撐不住時可以直接說出口的一句話，
// 比吵架當下臨時想措辭更不容易被誤解成在逃避或甩鍋。純文字存在 prefs，只有自己看得到。
function partnerPauseWordEl(currentWord) {
  const wrap = el('div', { style: 'margin-top:10px;padding-top:10px;border-top:1px solid var(--border)' });
  wrap.appendChild(el('div', { style: 'font-weight:700;font-size:13px' }, '🤍 你們的暫停用語'));
  wrap.appendChild(el('p', { class: 'hint', style: 'margin-top:6px;line-height:1.7' }, '撐不住的時候，一句事先講好的話比臨場硬撐或說錯話要好——例如「我需要十分鐘自己靜一下，等一下回來」。趁平常心情好的時候跟她一起約定一句，這裡幫你記著提醒自己。'));
  if (currentWord) {
    wrap.appendChild(el('div', { class: 'coping-note-item rb-blue', style: 'margin-top:8px;font-weight:700' }, [
      el('div', { class: 'content' }, `「${currentWord}」`),
      el('button', { class: 'btn btn-ghost', style: 'font-size:11px', onclick: () => { wrap.querySelector('.pause-word-edit-row').style.display = 'flex'; } }, '修改'),
    ]));
  }
  const editRow = el('div', { class: 'form-row pause-word-edit-row', style: `margin-top:8px;${currentWord ? 'display:none' : ''}` }, [
    el('input', { id: 'partnerPauseWordInput', placeholder: '例如：我需要十分鐘自己靜一下', value: currentWord || '', style: 'flex:1' }),
    el('button', { class: 'btn btn-primary', style: 'font-size:12px', onclick: savePartnerPauseWord }, '儲存'),
  ]);
  wrap.appendChild(editRow);
  return wrap;
}

async function savePartnerPauseWord() {
  const input = $('#partnerPauseWordInput');
  const val = input ? input.value.trim() : '';
  try {
    state.prefs = state.prefs || (await api('/prefs'));
    await api('/prefs', { method: 'PUT', body: { ...state.prefs, partnerPauseWord: val } });
    state.prefs.partnerPauseWord = val;
    showToast(val ? '已記住你們的暫停用語' : '已清除');
    loadPartnerSelfCare();
  } catch (e) { showToast('儲存失敗：' + e.message); }
}

async function loadPartnerSelfCare() {
  const box = $('#partnerSelfCareBody');
  if (!box) return;
  try {
    const [entries, prefs, reminders] = await Promise.all([
      api('/mood/entries'),
      api('/prefs'),
      api('/insights/reminders').catch(() => ({ items: [] })),
    ]);
    state.prefs = prefs;
    box.innerHTML = '';
    const today = todayStr();

    // v0.83：完全被動的自我照顧提示——不需要打分數、不需要寫任何東西，只要你有打開這個
    // 分頁就看得到，不用特地去開啟推播通知也能被接住。這裡是「首頁被動顯示」的路徑；要
    // 主動推播出去 (不用開 App 就收到) 由下面設定頁的開關決定 (見 push.js)。
    const selfCareItem = (reminders.items || []).find((i) => i.type === 'self-care');
    if (selfCareItem) {
      box.appendChild(el('div', { class: 'coping-note-item rb-green', style: 'margin-bottom:10px' }, [
        el('div', { class: 'content' }, `${selfCareItem.icon || '🌱'} ${selfCareItem.text}`),
      ]));
    }
    const todayEntry = entries.find((e) => e.entry_date === today);
    if (todayEntry) {
      box.appendChild(el('div', { style: 'display:flex;align-items:center;gap:10px;flex-wrap:wrap' }, [
        el('span', { class: 'badge badge-neutral' }, `今天記錄的心情：${todayEntry.score} 分`),
        el('button', { class: 'btn btn-ghost', style: 'font-size:12px', onclick: () => switchTab('mood') }, '看趨勢與更多工具'),
      ]));
      // v0.85：補上筆記裡的「深層工具斷層」——這裡打低分之前只是存一個數字，不像心靈分頁
      // 會接著遞上工具。現在分數 ≤ 4 時，直接在這裡把「心靈」分頁既有的安心小卡/想法練習
      // 遞過來；不要求多寫任何東西 (零記錄成本)，也不替他解讀感受，只陳述分數、給入口。
      if (todayEntry.score <= 4) await appendPartnerLowScoreFollowup(box, todayEntry.score);
    } else {
      box.appendChild(el('p', { class: 'hint' }, '今天還沒記錄自己的狀態，點一個分數就好。'));
      // v0.85：沿用心靈分頁同一套 .mood-score-btn 樣式 (5×2 大按鈕)，原本的小藍字按鈕太難點。
      const scoreWrap = el('div', { class: 'mood-score-row' });
      for (let n = 1; n <= 10; n++) {
        const btn = el('button', { class: 'mood-score-btn', 'data-score': n, 'aria-label': `今天的狀態 ${n} 分` }, String(n));
        btn.onclick = () => { savePartnerSelfScore(n); };
        scoreWrap.appendChild(btn);
      }
      box.appendChild(scoreWrap);
      box.appendChild(el('div', { class: 'mood-score-scale' }, [el('span', {}, '很累'), el('span', {}, '很好')]));
    }
    // 最近 3 天平均偏低、又碰上她正在遲到或經前觀察窗，代表兩個人可能同時都不好過，
    // 值得溫和地點出來——這是唯一一處把「他自己的狀態」跟「她的週期狀態」放在一起看的地方。
    try {
      const threeDaysAgo = (() => { const d = new Date(); d.setDate(d.getDate() - 2); return d.toISOString().slice(0, 10); })();
      const recent = entries.filter((e) => e.entry_date >= threeDaysAgo).map((e) => e.score);
      if (recent.length >= 2) {
        const avg = recent.reduce((s, v) => s + v, 0) / recent.length;
        if (avg <= 4) {
          const partnerStatus = await api('/mood/cycle/partner-status').catch(() => null);
          if (partnerStatus && (partnerStatus.isLate || partnerStatus.isPmsWindow)) {
            box.appendChild(el('p', { class: 'hint', style: 'margin-top:8px;line-height:1.7' }, '你自己最近幾天的心情分數也偏低，剛好又碰上她這段時間比較不好過——你們可能同時都在硬撐。這時候更需要留一點餘裕給自己，不一定要兩個人都靠你撐著。'));
          }
        }
      }
    } catch (e) { /* 這段是加分提示，失敗就不顯示，不影響其他內容 */ }

    // v0.84：回應「我不知道這軟體可以怎麼幫我」——被動整理出這段時間你其實有在做的事，
    // 兩個數字都是既有功能順便留下的紀錄，不需要你多做任何記錄。兩個數字都是 0 就整個不
    // 顯示 (代表這兩個功能你本來就沒在用，顯示一排 0 只會像在指責，沒有意義)。
    // v0.84 second pass：原本結尾有一句「不是要邀功，只是…」——這其實是在自我辯護，讀起來
    // 反而更用力、更像在討拍。改成單純陳述數字，不加任何自我辯解或情緒收尾，看過去就好，
    // 不需要有什麼感覺。
    try {
      const effort = await api('/insights/effort-summary');
      if (effort.moodEntriesCount > 0 || effort.partnerCycleLogsCount > 0) {
        const parts = [];
        if (effort.moodEntriesCount > 0) parts.push(`記錄了 ${effort.moodEntriesCount} 次自己的心情`);
        if (effort.partnerCycleLogsCount > 0) parts.push(`幫她記了 ${effort.partnerCycleLogsCount} 次月經開始日`);
        box.appendChild(el('div', { class: 'coping-note-item rb-neutral', style: 'margin-top:10px' }, [
          el('div', { class: 'content' }, `過去 ${effort.rangeDays} 天，你${parts.join('、')}。`),
        ]));
      }
    } catch (e) { /* 這段是加分提示，失敗就不顯示 */ }

    box.appendChild(partnerAngerVsStateContentEl());
    box.appendChild(partnerPauseWordEl(prefs.partnerPauseWord));
  } catch (e) {
    box.innerHTML = '';
    box.appendChild(el('div', { class: 'empty-state' }, '資料暫時無法取得'));
  }
}

// v0.85：陪伴分頁自我打卡分數偏低時的後續入口。安心小卡如果本來就有寫，直接隨機翻一張
// 出來 (資料是既有的，不需要新增)；按鈕直接帶到心靈分頁對應的工具。「先不用了」只在這個
// 瀏覽器當天記住，不寫進資料庫。
async function appendPartnerLowScoreFollowup(box, score) {
  const dismissKey = 'lifehub_partner_lowscore_dismissed';
  let dismissed = null;
  try { dismissed = localStorage.getItem(dismissKey); } catch (e) { /* ignore */ }
  if (dismissed === todayStr()) return;
  let notes = [];
  try { notes = await api('/mood/coping-notes'); } catch (e) { notes = []; }
  const wrap = el('div', { class: 'partner-lowscore-followup' });
  wrap.appendChild(el('div', { class: 'partner-lowscore-title' }, `今天記了 ${score} 分。想整理一下的話，這些工具都在：`));
  if (Array.isArray(notes) && notes.length) {
    const pick = notes[Math.floor(Math.random() * notes.length)];
    wrap.appendChild(el('div', { class: 'partner-lowscore-note' }, [
      el('span', { class: 'partner-lowscore-note-label' }, '🍃 你之前留給自己的一句話'),
      el('div', {}, pick.content || ''),
    ]));
  }
  wrap.appendChild(el('div', { class: 'partner-lowscore-actions' }, [
    el('button', { class: 'btn btn-primary', onclick: () => { moodViewTab = 'today'; switchTab('mood'); setTimeout(() => { const t = $('#copingNoteList'); if (t) t.scrollIntoView({ behavior: 'smooth', block: 'center' }); }, 120); } }, '翻翻安心小卡'),
    el('button', { class: 'btn btn-secondary', onclick: () => { switchTab('mood'); setTimeout(goToThoughtRecordTool, 60); } }, '寫一筆想法練習'),
    el('button', { class: 'btn btn-ghost', onclick: () => { try { localStorage.setItem(dismissKey, todayStr()); } catch (e) { /* ignore */ } wrap.remove(); } }, '先不用了'),
  ]));
  box.appendChild(wrap);
}

async function savePartnerSelfScore(score) {
  try {
    await api(`/mood/entries/${todayStr()}`, { method: 'PUT', body: { score, tags: [], note: '' } });
    showToast('已記錄今天的心情 💗');
    loadPartnerSelfCare();
  } catch (e) { showToast('儲存失敗：' + e.message); }
}

// ===================== 家人/伴侶帳號共享 (v0.33) =====================
async function loadPartnerLinkArea() {
  const area = $('#partnerLinkArea');
  if (!area) return;
  try {
    const { links } = await api('/partner-link');
    area.innerHTML = '';

    if (links.length) {
      area.appendChild(el('div', { class: 'dash-section-title', style: 'margin:0 0 8px' }, `已連結（${links.length}）`));
      links.forEach((l) => {
        area.appendChild(el('div', { class: 'coping-note-item' }, [
          el('div', { class: 'content' }, l.name),
          el('button', { class: 'del-btn', onclick: () => unlinkPartner(l.linkId) }, '解除連結'),
        ]));
      });
      area.appendChild(el('div', { style: 'margin-top:16px' }, [
        el('div', { class: 'dash-section-title', style: 'margin-bottom:8px' }, '她本人記錄的生理週期（唯讀，比猜的準）'),
        el('p', { class: 'hint', style: 'margin:0 0 8px' }, '如果對方也有在自己的心情陪伴分頁記錄真正的週期，這裡會直接顯示她本人的估算狀態，不用你再用上面「記一筆」用猜的。'),
        el('div', { id: 'partnerSharedCycleArea' }, el('div', { class: 'empty-state' }, '載入中...')),
      ]));
      area.appendChild(el('div', { style: 'margin-top:16px' }, [
        el('div', { class: 'dash-section-title', style: 'margin-bottom:8px' }, '心情 × 週期關聯（要對方自己開啟分享才看得到）'),
        el('p', { class: 'hint', style: 'margin:0 0 8px' }, '只有統計數字 (依階段分組的心情平均分數)，不包含日記原文或 AI 對話內容；這是對方自己決定要不要分享的，不是連結了就自動看得到。'),
        el('div', { id: 'partnerSharedMoodArea' }, el('div', { class: 'empty-state' }, '載入中...')),
      ]));
      area.appendChild(el('div', { style: 'margin-top:16px' }, [
        el('div', { class: 'dash-section-title', style: 'margin-bottom:8px' }, '對方的行事曆（唯讀）'),
        el('div', { id: 'partnerSharedCalendarArea' }, el('div', { class: 'empty-state' }, '載入中...')),
      ]));
      area.appendChild(el('div', { style: 'margin-top:16px' }, [
        el('div', { class: 'dash-section-title', style: 'margin-bottom:8px' }, '對方還沒完成的待辦（唯讀）'),
        el('div', { id: 'partnerSharedTasksArea' }, el('div', { class: 'empty-state' }, '載入中...')),
      ]));
      loadPartnerSharedCycleStatus();
      loadPartnerSharedMoodCorrelation();
      loadPartnerSharedCalendar();
      loadPartnerSharedTasks();
    }

    area.appendChild(el('div', { style: 'margin-top:16px;padding-top:16px;border-top:1px solid var(--grid-line)' }, [
      el('div', { class: 'dash-section-title', style: 'margin-bottom:8px' }, '邀請對方連結'),
      el('div', { id: 'partnerInviteCodeArea' }),
      el('button', { class: 'btn btn-ghost', onclick: generatePartnerInvite }, '產生邀請碼給對方'),
    ]));
    area.appendChild(el('div', { style: 'margin-top:14px' }, [
      el('div', { class: 'dash-section-title', style: 'margin-bottom:8px' }, '輸入對方給你的邀請碼'),
      el('div', { class: 'form-row' }, [
        el('input', { id: 'partnerInviteCodeInput', placeholder: '例如：A1B2C3', style: 'text-transform:uppercase' }),
        el('button', { class: 'btn btn-primary', onclick: acceptPartnerInvite }, '連結'),
      ]),
    ]));
  } catch (e) {
    area.innerHTML = '';
    area.appendChild(el('div', { class: 'empty-state' }, '共享資料暫時無法取得'));
  }
}

async function generatePartnerInvite() {
  try {
    const { code, expiresAt } = await api('/partner-link/invite', { method: 'POST' });
    const box = $('#partnerInviteCodeArea');
    if (box) {
      box.innerHTML = '';
      box.appendChild(el('div', { class: 'recovery-code-box' }, code));
      box.appendChild(el('p', { class: 'hint', style: 'margin-top:6px' }, `把這組邀請碼給對方，24 小時內有效 (到 ${new Date(expiresAt).toLocaleString('zh-TW')} 為止)，對方在自己的帳號裡輸入這組碼就會完成連結。`));
    }
  } catch (e) { showToast('產生邀請碼失敗：' + e.message); }
}

async function acceptPartnerInvite() {
  const code = $('#partnerInviteCodeInput').value.trim();
  if (!code) { showToast('請輸入邀請碼'); return; }
  try {
    const res = await api('/partner-link/accept', { method: 'POST', body: { code } });
    showToast(`已經跟「${res.linkedWith}」連結成功`);
    $('#partnerInviteCodeInput').value = '';
    loadPartnerLinkArea();
  } catch (e) { showToast('連結失敗：' + e.message); }
}

async function unlinkPartner(linkId) {
  try {
    await api(`/partner-link/${linkId}`, { method: 'DELETE' });
    showToast('已解除連結');
    loadPartnerLinkArea();
  } catch (e) { showToast('解除失敗：' + e.message); }
}

async function loadPartnerSharedCycleStatus() {
  const area = $('#partnerSharedCycleArea');
  if (!area) return;
  try {
    const { partners } = await api('/partner-link/shared-cycle-status');
    area.innerHTML = '';
    const withData = partners.filter((p) => p.status && p.status.hasData);
    if (!withData.length) {
      area.appendChild(el('div', { class: 'empty-state' }, '已連結的對象目前還沒有自己記錄週期資料，或還沒開始記錄。'));
      return;
    }
    withData.forEach((p) => {
      const s = p.status;
      const box = el('div', { class: 'coping-note-item', style: 'flex-direction:column;align-items:stretch;gap:4px' });
      box.appendChild(el('div', { style: 'font-weight:700' }, `${p.ownerLabel}（她本人的紀錄）`));
      // v0.81：對方本人紀錄的推算也支援遲到/太久沒更新狀態，不再繞回去顯示錯的階段
      if (s.isStale) {
        box.appendChild(el('div', { class: 'hint', style: 'margin:0' }, `她上次記錄已經是 ${s.daysSinceLastPeriod} 天前，推算暫停中（可能是最近沒記錄）。`));
      } else if (s.isLate) {
        box.appendChild(el('div', { class: 'hint', style: 'margin:0' }, `比預估（${s.predictedNextDate}）晚了 ${s.daysLate} 天，還沒有新紀錄。這段時間她可能比較在意，多點平常心陪伴就好。`));
      } else {
        const phaseInfo = PARTNER_PHASE_TIPS[s.phase] || { label: CYCLE_PHASE_LABEL[s.phase] || s.phase, tip: '' };
        box.appendChild(el('div', { class: 'hint', style: 'margin:0' }, `目前估計：${phaseInfo.label}${s.isPmsWindow ? '（經前觀察窗）' : ''}${s.isFertileWindow ? '（易孕期）' : ''} · 距離下次月經約 ${s.daysUntilNextPeriod} 天（預估 ${s.nextPeriodDate}，前後約 ±${s.rangeDays} 天）`));
        if (s.fertileWindowStart && s.fertileWindowEnd) {
          box.appendChild(el('div', { class: 'hint', style: 'margin:0' }, `📍 易孕期：${s.fertileWindowStart} ～ ${s.fertileWindowEnd}`));
        }
      }
      area.appendChild(box);
    });
  } catch (e) { area.innerHTML = ''; area.appendChild(el('div', { class: 'empty-state' }, '暫時無法取得對方的紀錄')); }
}

// v0.36：心情 × 週期關聯——完全由對方自己決定要不要分享，這裡只負責顯示，不做任何
// 「猜對方是不是沒開分享」之類的暗示文字，統一用中性的「還沒有可以顯示的統計資料」。
async function loadPartnerSharedMoodCorrelation() {
  const area = $('#partnerSharedMoodArea');
  if (!area) return;
  try {
    const { partners } = await api('/partner-link/shared-mood-cycle-correlation');
    area.innerHTML = '';
    if (!partners.length) {
      area.appendChild(el('div', { class: 'empty-state' }, '目前沒有已連結的對象。'));
      return;
    }
    const anyShown = partners.some((p) => p.shared && p.phaseAverages && p.phaseAverages.length);
    partners.forEach((p) => {
      if (!p.shared) return; // 對方沒開分享：不特別點名是誰，直接略過這個人
      const box = el('div', { class: 'coping-note-item', style: 'flex-direction:column;align-items:stretch;gap:4px' });
      box.appendChild(el('div', { style: 'font-weight:700' }, `${p.ownerLabel}（依她分享的統計數字）`));
      if (!p.phaseAverages || !p.phaseAverages.length) {
        box.appendChild(el('div', { class: 'hint', style: 'margin:0' }, '資料還不夠多，每個階段至少累積 3 筆紀錄才會顯示平均值。'));
      } else {
        p.phaseAverages.forEach((pa) => {
          const label = CYCLE_PHASE_LABEL[pa.phase] || pa.phase;
          box.appendChild(el('div', { class: 'hint', style: 'margin:0' }, `${label}：平均心情 ${pa.avgScore} 分（共 ${pa.count} 筆紀錄）`));
        });
      }
      area.appendChild(box);
    });
    if (!anyShown && !area.children.length) {
      area.appendChild(el('div', { class: 'empty-state' }, '已連結的對象目前還沒有開啟分享，或資料還不夠多。'));
    }
  } catch (e) { area.innerHTML = ''; area.appendChild(el('div', { class: 'empty-state' }, '暫時無法取得分享的統計資料')); }
}

async function loadPartnerSharedCalendar() {
  const area = $('#partnerSharedCalendarArea');
  if (!area) return;
  try {
    const { events } = await api('/partner-link/shared-calendar');
    area.innerHTML = '';
    if (!events.length) { area.appendChild(el('div', { class: 'empty-state' }, '對方最近沒有安排行程')); return; }
    events.slice(0, 10).forEach((ev) => {
      area.appendChild(el('div', { class: 'coping-note-item' }, [
        el('div', { class: 'content' }, [
          el('div', { style: 'font-weight:700' }, `${ev.title}（${ev.ownerLabel}）`),
          el('div', { class: 'hint', style: 'margin:2px 0 0' }, `${ev.event_date}${ev.start_time ? ' ' + ev.start_time : ''}`),
        ]),
      ]));
    });
  } catch (e) { area.innerHTML = ''; area.appendChild(el('div', { class: 'empty-state' }, '暫時無法取得對方的行事曆')); }
}

async function loadPartnerSharedTasks() {
  const area = $('#partnerSharedTasksArea');
  if (!area) return;
  try {
    const { tasks } = await api('/partner-link/shared-tasks');
    area.innerHTML = '';
    if (!tasks.length) { area.appendChild(el('div', { class: 'empty-state' }, '對方目前沒有待完成的待辦')); return; }
    tasks.slice(0, 10).forEach((t) => {
      area.appendChild(el('div', { class: 'coping-note-item' }, [
        el('div', { class: 'content' }, [
          el('div', { style: 'font-weight:700' }, `${t.title}（${t.ownerLabel}）`),
          t.due_date ? el('div', { class: 'hint', style: 'margin:2px 0 0' }, `期限：${t.due_date}`) : null,
        ]),
      ]));
    });
  } catch (e) { area.innerHTML = ''; area.appendChild(el('div', { class: 'empty-state' }, '暫時無法取得對方的待辦')); }
}

// ===================== 家庭公告欄 (v0.42) =====================
// 直接重用「陪伴另一半」頁面裡已經有的邀請碼配對系統 (/partner-link/*)，這裡的「連結家人」
// 就是同一組連結，不是另外一套。公告欄看得到的貼文 = 自己發的 + 所有已連結對象發的。
let familyPostEditingId = null;
function renderFamilyBoard() {
  const c = $('#tab-familyBoard');
  c.innerHTML = '';
  familyPostEditingId = null;

  c.appendChild(el('div', { class: 'card' }, [
    el('h3', { id: 'familyPostFormTitle' }, '📌 家庭公告欄'),
    el('p', { class: 'hint' }, '跟「陪伴另一半」用同一套邀請碼連結系統：連結後，你發的公告跟已連結對象發的公告會顯示在同一個地方，任何人都可以置頂重要公告，但只有本人能編輯/刪除自己發的內容。'),
    el('div', { class: 'form-row', style: 'align-items:flex-start' }, [
      el('textarea', { id: 'familyPostInput', placeholder: '想公告什麼呢？例如：這週六全家聚餐、垃圾車改到晚上七點…', rows: 3, style: 'flex:1;resize:vertical' }),
    ]),
    el('div', { style: 'display:flex;gap:10px;align-items:center;margin-top:8px' }, [
      el('button', { class: 'btn btn-primary', id: 'familyPostSubmitBtn', onclick: submitFamilyPost }, '發布公告'),
      el('button', { class: 'btn btn-ghost', id: 'familyPostCancelBtn', style: 'display:none', onclick: cancelEditFamilyPost }, '取消'),
    ]),
  ]));

  c.appendChild(el('div', { class: 'card' }, [
    el('h3', {}, '🗒️ 公告列表'),
    el('div', { id: 'familyPostList' }, el('div', { class: 'empty-state' }, '載入中...')),
  ]));

  c.appendChild(el('div', { class: 'card' }, [
    el('h3', {}, '🔗 連結家人'),
    el('div', { id: 'familyMembersArea' }, el('div', { class: 'empty-state' }, '載入中...')),
  ]));

  loadFamilyBoardPosts();
  loadFamilyMembersArea();
}

async function loadFamilyBoardPosts() {
  const listEl = $('#familyPostList');
  if (!listEl) return;
  try {
    const { posts, circleSize, reactionEmojis } = await api('/family-board');
    listEl.innerHTML = '';
    if (!circleSize) {
      listEl.appendChild(el('div', { class: 'empty-state' }, '你目前還沒連結任何家人，公告只有自己看得到。往下滑到「連結家人」，用邀請碼跟家人連結後，彼此的公告就會顯示在同一個地方。'));
    }
    if (!posts.length) {
      listEl.appendChild(el('div', { class: 'empty-state' }, circleSize ? '目前還沒有任何公告，上面寫第一則吧！' : '目前還沒有任何公告。'));
      return;
    }
    // v0.76：置頂公告用金色色條＋圖釘標示；自己發的貼文不用額外徽章 (authorLabel 本來就
    // 會顯示「你」)，只用極淡的底色區分，避免跟標題文字重複講兩次「這是你發的」。
    posts.forEach((p) => {
      const ribbonClass = p.pinned ? 'rb-gold' : (p.isMine ? 'rb-neutral rb-self' : 'rb-neutral');
      const row = el('div', { class: 'card', style: 'margin-bottom:10px' }, [
        el('div', { class: `ribbon-item ${ribbonClass}` }, [
          el('div', { class: 'ribbon-item-top-row' }, [
            el('div', { class: 'ribbon-item-title' }, `${p.pinned ? '📌 ' : ''}${p.authorLabel}`),
            el('div', { class: 'ribbon-item-time' }, new Date(p.createdAt).toLocaleString('zh-TW')),
          ]),
          el('div', { class: 'ribbon-item-note' }, p.content),
          // v0.84：輕量反應——不用打字也能留下一點什麼。自己發的貼文不顯示反應按鈕
          // (對自己的內容按反應沒有意義)，但如果別人已經對你的貼文留了反應，一樣會顯示出來。
          familyPostReactionRowEl(p, reactionEmojis || []),
          el('div', { class: 'ribbon-item-actions' }, [
            el('button', { onclick: () => toggleFamilyPostPin(p.id) }, p.pinned ? '取消置頂' : '置頂'),
            p.isMine ? el('button', { onclick: () => editFamilyPost(p.id, p.content) }, '編輯') : null,
            p.isMine ? el('button', { onclick: () => deleteFamilyPost(p.id) }, '刪除') : null,
          ].filter(Boolean)),
        ]),
      ]);
      listEl.appendChild(row);
    });
  } catch (e) {
    listEl.innerHTML = '';
    listEl.appendChild(el('div', { class: 'empty-state' }, '公告暫時無法取得'));
  }
}

// v0.84：家庭公告欄的輕量反應列。已存在的反應顯示為「表情 + 次數」小徽章 (自己按過的
// 那個會用實心樣式標出來)；自己的貼文不顯示可點的選項列 (isMine)，但既有反應徽章照樣顯示。
function familyPostReactionRowEl(p, reactionEmojis) {
  const existing = (p.reactions || []).map((r) => el('span', {
    class: `family-reaction-badge${r.emoji === p.myReaction ? ' family-reaction-badge-mine' : ''}`,
    style: 'display:inline-flex;align-items:center;gap:3px;font-size:12px;padding:2px 7px;border-radius:999px;background:var(--surface-2);margin-right:4px',
  }, `${r.emoji} ${r.count}`));

  if (p.isMine) {
    return el('div', { style: 'margin-top:6px' }, existing);
  }

  const picker = el('div', { style: 'display:flex;gap:4px;flex-wrap:wrap' }, reactionEmojis.map((emoji) => {
    const isMine = emoji === p.myReaction;
    const btn = el('button', {
      class: 'btn btn-ghost',
      style: `font-size:14px;padding:3px 8px;${isMine ? 'background:var(--accent-soft, var(--surface-2));border-color:var(--accent)' : ''}`,
    }, emoji);
    btn.onclick = () => (isMine ? unreactFamilyPost(p.id) : reactToFamilyPost(p.id, emoji));
    return btn;
  }));

  return el('div', { style: 'margin-top:6px;display:flex;align-items:center;gap:6px;flex-wrap:wrap' }, [...existing, picker]);
}

async function reactToFamilyPost(postId, emoji) {
  try {
    await api(`/family-board/${postId}/react`, { method: 'POST', body: { emoji } });
    loadFamilyBoardPosts();
  } catch (e) { showToast('操作失敗：' + e.message); }
}

async function unreactFamilyPost(postId) {
  try {
    await api(`/family-board/${postId}/react`, { method: 'DELETE' });
    loadFamilyBoardPosts();
  } catch (e) { showToast('操作失敗：' + e.message); }
}

async function submitFamilyPost() {
  const input = $('#familyPostInput');
  const content = input.value.trim();
  if (!content) { showToast('先寫點內容吧'); return; }
  try {
    if (familyPostEditingId) {
      await api(`/family-board/${familyPostEditingId}`, { method: 'PUT', body: { content } });
      showToast('已更新');
      cancelEditFamilyPost();
    } else {
      await api('/family-board', { method: 'POST', body: { content } });
      input.value = '';
      showToast('公告已發布');
    }
    loadFamilyBoardPosts();
  } catch (e) { showToast((familyPostEditingId ? '更新失敗：' : '發布失敗：') + e.message); }
}

// v0.77：編輯公告改成重用上面的「發布公告」表單 (跟待辦事項編輯同一套模式)，不再跳
// prompt() 彈窗——點編輯後表單帶入原內容、按鈕文字變成「儲存修改」，多一個「取消」可以
// 放棄編輯回到新增模式。
function editFamilyPost(id, oldContent) {
  familyPostEditingId = id;
  $('#familyPostFormTitle').textContent = '✏️ 編輯公告';
  $('#familyPostInput').value = oldContent;
  $('#familyPostInput').focus();
  $('#familyPostSubmitBtn').textContent = '儲存修改';
  $('#familyPostCancelBtn').style.display = '';
  window.scrollTo({ top: 0, behavior: 'smooth' });
}
function cancelEditFamilyPost() {
  familyPostEditingId = null;
  $('#familyPostFormTitle').textContent = '📌 家庭公告欄';
  $('#familyPostInput').value = '';
  $('#familyPostSubmitBtn').textContent = '發布公告';
  $('#familyPostCancelBtn').style.display = 'none';
}

async function deleteFamilyPost(id) {
  if (!confirm('確定要刪除這則公告嗎？')) return;
  try {
    await api(`/family-board/${id}`, { method: 'DELETE' });
    showToast('已刪除');
    loadFamilyBoardPosts();
  } catch (e) { showToast('刪除失敗：' + e.message); }
}

async function toggleFamilyPostPin(id) {
  try {
    await api(`/family-board/${id}/pin`, { method: 'POST' });
    loadFamilyBoardPosts();
  } catch (e) { showToast('操作失敗：' + e.message); }
}

// 「連結家人」區塊直接重用「陪伴另一半」頁面同一套邀請碼 API (/partner-link/*)，
// 不是另外做一套——這裡只顯示已連結名單 + 產生/輸入邀請碼，不重複顯示唯讀行事曆/待辦
// 這些「陪伴另一半」頁面已經有的內容，避免同樣資訊在兩個地方各顯示一次。
async function loadFamilyMembersArea() {
  const area = $('#familyMembersArea');
  if (!area) return;
  try {
    const { links } = await api('/partner-link');
    area.innerHTML = '';
    if (links.length) {
      area.appendChild(el('div', { class: 'dash-section-title', style: 'margin:0 0 8px' }, `已連結（${links.length}）`));
      links.forEach((l) => {
        area.appendChild(el('div', { class: 'coping-note-item' }, [
          el('div', { class: 'content' }, l.name),
        ]));
      });
    } else {
      area.appendChild(el('div', { class: 'empty-state' }, '目前還沒連結任何人。'));
    }
    area.appendChild(el('div', { style: 'margin-top:16px;padding-top:16px;border-top:1px solid var(--grid-line)' }, [
      el('div', { class: 'dash-section-title', style: 'margin-bottom:8px' }, '邀請家人連結'),
      el('div', { id: 'familyInviteCodeArea' }),
      el('button', { class: 'btn btn-ghost', onclick: generateFamilyInvite }, '產生邀請碼給家人'),
    ]));
    area.appendChild(el('div', { style: 'margin-top:14px' }, [
      el('div', { class: 'dash-section-title', style: 'margin-bottom:8px' }, '輸入家人給你的邀請碼'),
      el('div', { class: 'form-row' }, [
        el('input', { id: 'familyInviteCodeInput', placeholder: '例如：A1B2C3', style: 'text-transform:uppercase' }),
        el('button', { class: 'btn btn-primary', onclick: acceptFamilyInvite }, '連結'),
      ]),
    ]));
  } catch (e) {
    area.innerHTML = '';
    area.appendChild(el('div', { class: 'empty-state' }, '連結資料暫時無法取得'));
  }
}

async function generateFamilyInvite() {
  try {
    const { code, expiresAt } = await api('/partner-link/invite', { method: 'POST' });
    const box = $('#familyInviteCodeArea');
    if (box) {
      box.innerHTML = '';
      box.appendChild(el('div', { class: 'recovery-code-box' }, code));
      box.appendChild(el('p', { class: 'hint', style: 'margin-top:6px' }, `把這組邀請碼給家人，24 小時內有效 (到 ${new Date(expiresAt).toLocaleString('zh-TW')} 為止)，對方在自己的帳號裡輸入這組碼就會完成連結。`));
    }
  } catch (e) { showToast('產生邀請碼失敗：' + e.message); }
}

async function acceptFamilyInvite() {
  const code = $('#familyInviteCodeInput').value.trim();
  if (!code) { showToast('請輸入邀請碼'); return; }
  try {
    const res = await api('/partner-link/accept', { method: 'POST', body: { code } });
    showToast(`已經跟「${res.linkedWith}」連結成功`);
    $('#familyInviteCodeInput').value = '';
    loadFamilyMembersArea();
    loadFamilyBoardPosts();
  } catch (e) { showToast('連結失敗：' + e.message); }
}

// ===================== 遊戲化點數 + 獎勵兌換頁面 (v0.43) =====================
// 點數本身不能在這裡手動調整，只會在完成待辦(+2)/寫日記(+3)/記心情(+2)/記帳(+1，一天限一次)
// 這幾個既有行為時自動加點；這個頁面負責顯示點數、點數紀錄，跟管理/兌換自訂的獎勵項目。
const POINT_REASON_LABELS = { task_complete: '✅ 完成待辦', diary: '📔 寫日記', mood: '💗 記心情', finance: '💰 記帳' };
function pointReasonLabel(reason) {
  if (POINT_REASON_LABELS[reason]) return POINT_REASON_LABELS[reason];
  if (reason.startsWith('redeem:')) return `🎁 兌換：${reason.slice(7)}`;
  return reason;
}

// v0.52：獎勵項目除了自己私人設定，也可以選擇跟已連結的家人/伴侶「共同建立」——雙方看到
// 一樣的獎勵清單、都能新增/編輯/刪除，但兌換還是各自扣各自的點數。rewardPartnerLinks 存
// 目前有哪些已連結對象可以選 (沒有連結任何人的話，新增表單就不會出現「共同建立」的選項)。
let rewardPartnerLinks = [];
let rewardEditingId = null;

function renderRewards() {
  const c = $('#tab-rewards');
  c.innerHTML = '';
  rewardEditingId = null;

  c.appendChild(el('div', { class: 'card' }, [
    el('h3', {}, '🎮 我的點數'),
    el('p', { class: 'hint' }, '完成待辦 +2 點、寫日記 +3 點、記心情 +2 點、記帳 +1 點 (記帳一天最多算一次)。點數可以在下面自己設定的獎勵項目兌換。'),
    el('div', { id: 'pointsBalanceBody' }, el('div', { class: 'empty-state' }, '載入中...')),
  ]));

  c.appendChild(el('div', { class: 'card' }, [
    el('h3', { id: 'rewardFormTitle' }, '🎁 獎勵兌換'),
    el('p', { class: 'hint' }, '自己設定想用點數換的東西，例如「看一集劇：10 點」「買一杯手搖飲：30 點」。如果已經連結家人/伴侶，也可以選擇跟對方共同建立，雙方看到同一份清單，但兌換各自扣各自的點數。'),
    el('div', { class: 'form-row' }, [
      el('input', { id: 'rewardTitleInput', placeholder: '獎勵名稱，例如：看一集劇' }),
      el('input', { id: 'rewardCostInput', type: 'number', min: '1', placeholder: '花費點數', style: 'max-width:110px' }),
    ]),
    el('div', { id: 'rewardScopeRow', style: 'margin-top:8px' }),
    el('div', { style: 'margin-top:8px;display:flex;gap:10px;align-items:center' }, [
      el('button', { class: 'btn btn-primary', id: 'rewardSubmitBtn', onclick: addPointReward }, '新增獎勵'),
      el('button', { class: 'btn btn-ghost', id: 'rewardCancelBtn', style: 'display:none', onclick: cancelEditPointReward }, '取消'),
    ]),
    el('div', { id: 'rewardsList', style: 'margin-top:12px' }, el('div', { class: 'empty-state' }, '載入中...')),
  ]));

  c.appendChild(el('div', { class: 'card' }, [
    el('h3', {}, '🧾 點數紀錄'),
    el('div', { id: 'pointsHistoryBody' }, el('div', { class: 'empty-state' }, '載入中...')),
  ]));

  c.appendChild(el('div', { class: 'card' }, [
    el('h3', {}, '📜 兌換紀錄'),
    el('div', { id: 'redemptionsHistoryBody' }, el('div', { class: 'empty-state' }, '載入中...')),
  ]));

  loadPointsBalance();
  loadRewardPartnerLinks();
  loadPointRewards();
  loadRedemptionsHistory();
}

async function loadRewardPartnerLinks() {
  const row = $('#rewardScopeRow');
  if (!row) return;
  try {
    const { links } = await api('/partner-link');
    rewardPartnerLinks = links || [];
    row.innerHTML = '';
    if (!rewardPartnerLinks.length) return; // 沒有連結任何人，就不用顯示「共同建立」的選項
    row.appendChild(el('label', { class: 'hint', style: 'display:block;margin-bottom:4px' }, '這個獎勵是：'));
    row.appendChild(el('select', { id: 'rewardScopeInput' }, [
      el('option', { value: '' }, '只有我自己'),
      ...rewardPartnerLinks.map((l) => el('option', { value: String(l.linkId) }, `跟 ${l.name} 共同建立`)),
    ]));
  } catch (e) {
    // 連結資料抓不到就當作沒有連結，不影響私人獎勵的新增
    rewardPartnerLinks = [];
  }
}

async function loadPointsBalance() {
  const box = $('#pointsBalanceBody');
  if (!box) return;
  try {
    const { balance, transactions } = await api('/points');
    box.innerHTML = '';
    box.appendChild(el('div', { class: 'stat-big' }, `${balance} 點`));
    const histBox = $('#pointsHistoryBody');
    if (histBox) {
      histBox.innerHTML = '';
      if (!transactions.length) {
        histBox.appendChild(el('div', { class: 'empty-state' }, '還沒有任何點數紀錄，開始完成待辦/寫日記/記心情/記帳就會開始累積。'));
      } else {
        transactions.forEach((t) => {
          histBox.appendChild(el('div', { class: 'coping-note-item' }, [
            el('div', { class: 'content' }, [
              el('div', {}, pointReasonLabel(t.reason)),
              el('div', { class: 'hint', style: 'margin:2px 0 0' }, new Date(t.created_at).toLocaleString('zh-TW')),
            ]),
            el('div', { style: `font-weight:700;color:${t.delta >= 0 ? 'var(--good)' : 'var(--critical)'}` }, `${t.delta >= 0 ? '+' : ''}${t.delta}`),
          ]));
        });
      }
    }
  } catch (e) {
    box.innerHTML = '';
    box.appendChild(el('div', { class: 'empty-state' }, '點數資料暫時無法取得'));
  }
}

async function loadPointRewards() {
  const listEl = $('#rewardsList');
  if (!listEl) return;
  try {
    const { rewards, balance } = await api('/points/rewards');
    listEl.innerHTML = '';
    if (!rewards.length) {
      listEl.appendChild(el('div', { class: 'empty-state' }, '還沒有設定任何獎勵項目，上面新增第一個吧！'));
      return;
    }
    rewards.forEach((r) => {
      const canAfford = balance >= r.cost;
      listEl.appendChild(el('div', { class: 'coping-note-item' }, [
        el('div', { class: 'content' }, [
          el('div', { style: 'font-weight:700' }, r.title),
          el('div', { class: 'hint', style: 'margin:2px 0 0' }, `${r.cost} 點`),
          r.shared ? el('div', { class: 'hint', style: 'margin:2px 0 0;color:var(--accent)' }, `🤝 跟 ${r.partnerLabel} 共同建立 · 由${r.createdByMe ? '我' : r.creatorLabel}新增`) : null,
        ].filter(Boolean)),
        el('div', { style: 'display:flex;gap:6px;flex-wrap:wrap' }, [
          el('button', { class: 'btn btn-primary', style: canAfford ? '' : 'opacity:.45;cursor:not-allowed', onclick: () => redeemPointReward(r.id, canAfford) }, '兌換'),
          el('button', { class: 'dash-section-action', onclick: () => editPointReward(r.id, r.title, r.cost) }, '編輯'),
          el('button', { class: 'dash-section-action', onclick: () => deletePointReward(r.id) }, '刪除'),
        ]),
      ]));
    });
  } catch (e) {
    listEl.innerHTML = '';
    listEl.appendChild(el('div', { class: 'empty-state' }, '獎勵資料暫時無法取得'));
  }
}

async function addPointReward() {
  const titleInput = $('#rewardTitleInput');
  const costInput = $('#rewardCostInput');
  const scopeInput = $('#rewardScopeInput');
  const title = titleInput.value.trim();
  const cost = Number(costInput.value);
  if (!title) { showToast('請輸入獎勵名稱'); return; }
  if (!Number.isInteger(cost) || cost <= 0) { showToast('花費點數必須是大於 0 的整數'); return; }
  const linkId = scopeInput && scopeInput.value ? scopeInput.value : null;
  try {
    if (rewardEditingId) {
      await api(`/points/rewards/${rewardEditingId}`, { method: 'PUT', body: { title, cost } });
      showToast('已更新');
      cancelEditPointReward();
    } else {
      await api('/points/rewards', { method: 'POST', body: { title, cost, linkId } });
      titleInput.value = '';
      costInput.value = '';
      if (scopeInput) scopeInput.value = '';
      showToast(linkId ? '共同獎勵已新增' : '獎勵已新增');
    }
    loadPointRewards();
  } catch (e) { showToast((rewardEditingId ? '更新失敗：' : '新增失敗：') + e.message); }
}

// v0.77：編輯獎勵改成重用上面的「新增獎勵」表單，不再跳兩次 prompt() 分別問名稱跟點數。
function editPointReward(id, oldTitle, oldCost) {
  rewardEditingId = id;
  $('#rewardFormTitle').textContent = '✏️ 編輯獎勵';
  $('#rewardTitleInput').value = oldTitle;
  $('#rewardCostInput').value = String(oldCost);
  $('#rewardSubmitBtn').textContent = '儲存修改';
  $('#rewardCancelBtn').style.display = '';
  $('#rewardTitleInput').focus();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}
function cancelEditPointReward() {
  rewardEditingId = null;
  $('#rewardFormTitle').textContent = '🎁 獎勵兌換';
  $('#rewardTitleInput').value = '';
  $('#rewardCostInput').value = '';
  $('#rewardSubmitBtn').textContent = '新增獎勵';
  $('#rewardCancelBtn').style.display = 'none';
}

async function deletePointReward(id) {
  if (!confirm('確定要刪除這個獎勵項目嗎？')) return;
  try {
    await api(`/points/rewards/${id}`, { method: 'DELETE' });
    showToast('已刪除');
    loadPointRewards();
  } catch (e) { showToast('刪除失敗：' + e.message); }
}

async function redeemPointReward(id, canAfford) {
  if (!canAfford) { showToast('點數不夠，再多累積一點吧'); return; }
  if (!confirm('確定要用點數兌換這個獎勵嗎？')) return;
  try {
    const res = await api(`/points/rewards/${id}/redeem`, { method: 'POST' });
    showToast(`兌換成功！剩餘 ${res.newBalance} 點`);
    loadPointsBalance();
    loadPointRewards();
    loadRedemptionsHistory();
  } catch (e) { showToast('兌換失敗：' + e.message); }
}

async function loadRedemptionsHistory() {
  const box = $('#redemptionsHistoryBody');
  if (!box) return;
  try {
    const { redemptions } = await api('/points/redemptions');
    box.innerHTML = '';
    if (!redemptions.length) {
      box.appendChild(el('div', { class: 'empty-state' }, '還沒有兌換過任何獎勵。'));
      return;
    }
    redemptions.forEach((r) => {
      box.appendChild(el('div', { class: 'coping-note-item' }, [
        el('div', { class: 'content' }, [
          el('div', { style: 'font-weight:700' }, r.reward_title),
          el('div', { class: 'hint', style: 'margin:2px 0 0' }, new Date(r.created_at).toLocaleString('zh-TW')),
        ]),
        el('div', { style: 'font-weight:700' }, `-${r.cost} 點`),
      ]));
    });
  } catch (e) {
    box.innerHTML = '';
    box.appendChild(el('div', { class: 'empty-state' }, '兌換紀錄暫時無法取得'));
  }
}

// ===================== 讀書：閱讀/戲劇進度追蹤 (v0.44) =====================
const READING_STATUS_LABELS = { want: '想看', in_progress: '在看', done: '看完' };
const READING_TYPE_LABELS = { book: '📖 書', drama: '🎬 戲劇/影集' };
// v0.76：讀書清單左側色條用「狀態」語意 (想看=中性/在看=金色/看完=綠色)，狀態本身已經
// 在色條(一眼掃過)跟下面 meta 文字(細節)兩層講過，不再多加右上角徽章重複第三次。
const READING_STATUS_RIBBON = { want: 'rb-neutral', in_progress: 'rb-gold', done: 'rb-green' };
let readingFilter = 'all';
let readingEditingId = null;

function renderReading() {
  const c = $('#tab-reading');
  c.innerHTML = '';
  readingEditingId = null;

  c.appendChild(el('div', { class: 'card' }, [
    el('h3', { id: 'readingFormTitle' }, '📚 新增一筆'),
    chipSelectEl({
      id: 'readingTypeInput', variant: 'segmented', value: 'book',
      options: [{ value: 'book', label: '📖 書' }, { value: 'drama', label: '🎬 戲劇/影集' }],
    }),
    el('input', { id: 'readingTitleInput', placeholder: '書名/劇名', style: 'width:100%;margin-top:8px' }),
    chipSelectEl({
      id: 'readingStatusInput', value: 'want', style: 'margin-top:8px',
      options: [{ value: 'want', label: '想看' }, { value: 'in_progress', label: '在看' }, { value: 'done', label: '看完' }],
    }),
    el('input', { id: 'readingProgressInput', placeholder: '進度 (選填，例如：第 5 集 / 120 頁)', style: 'width:100%;margin-top:8px' }),
    el('div', { class: 'form-row', style: 'margin-top:8px' }, [
      el('select', { id: 'readingRatingInput' }, [
        el('option', { value: '' }, '評分 (選填)'),
        ...[1, 2, 3, 4, 5].map((n) => el('option', { value: String(n) }, '⭐'.repeat(n))),
      ]),
    ]),
    el('textarea', { id: 'readingNoteInput', placeholder: '心得 (選填)', rows: 2, style: 'width:100%;margin-top:8px;resize:vertical' }),
    el('div', { style: 'margin-top:8px;display:flex;gap:10px;align-items:center' }, [
      el('button', { class: 'btn btn-primary', id: 'readingSubmitBtn', onclick: addReadingItem }, '新增'),
      el('button', { class: 'btn btn-ghost', id: 'readingCancelBtn', style: 'display:none', onclick: cancelEditReadingItem }, '取消'),
    ]),
  ]));

  const filterRow = el('div', { class: 'form-row', style: 'margin:14px 0 4px' });
  [['all', '全部'], ['want', '想看'], ['in_progress', '在看'], ['done', '看完']].forEach(([key, label]) => {
    filterRow.appendChild(el('button', {
      class: 'dash-section-action' + (readingFilter === key ? ' active' : ''),
      style: readingFilter === key ? 'background:var(--accent-soft);border-radius:8px;padding:4px 10px' : 'padding:4px 10px',
      onclick: () => { readingFilter = key; loadReadingList(); },
    }, label));
  });
  c.appendChild(filterRow);

  c.appendChild(el('div', { id: 'readingList' }, el('div', { class: 'empty-state' }, '載入中...')));

  c.appendChild(el('div', { class: 'card', style: 'margin-top:12px' }, [
    el('h3', {}, '⏸️ 進度停滯提醒'),
    el('p', { class: 'hint' }, '「在看」狀態但超過 14 天沒更新進度的項目，也許忘記了，或可以考慮先放一放。'),
    el('div', { id: 'readingStagnantArea' }, el('div', { class: 'empty-state' }, '載入中...')),
  ]));

  loadReadingList();
  loadReadingStagnant();
}

// v0.68：#8 閱讀進度停滯偵測
async function loadReadingStagnant() {
  const area = $('#readingStagnantArea');
  if (!area) return;
  try {
    const r = await api('/reading/stagnant?days=14');
    area.innerHTML = '';
    if (!r.items.length) { area.appendChild(el('div', { class: 'empty-state' }, '目前沒有停滯超過 14 天的項目')); return; }
    r.items.forEach((item) => {
      area.appendChild(el('div', { class: 'mood-signal-item' }, `${READING_TYPE_LABELS[item.type]} ${item.title}：已經 ${item.daysSinceUpdate} 天沒更新進度了${item.progress ? `（上次進度：${item.progress}）` : ''}`));
    });
  } catch (e) { area.innerHTML = ''; area.appendChild(el('div', { class: 'empty-state' }, '分析資料暫時無法取得')); }
}

function ratingStars(rating) {
  if (!rating) return '';
  return '⭐'.repeat(rating);
}

async function loadReadingList() {
  const listEl = $('#readingList');
  if (!listEl) return;
  try {
    const query = readingFilter === 'all' ? '' : `?status=${readingFilter}`;
    const items = await api(`/reading${query}`);
    listEl.innerHTML = '';
    if (!items.length) {
      listEl.appendChild(el('div', { class: 'empty-state' }, '目前沒有紀錄，上面新增第一筆吧！'));
      return;
    }
    items.forEach((item) => {
      listEl.appendChild(el('div', { class: 'card', style: 'margin-bottom:10px' }, [
        el('div', { class: `ribbon-item ${READING_STATUS_RIBBON[item.status] || 'rb-neutral'}` }, [
          el('div', { class: 'ribbon-item-top-row' }, [
            el('div', {}, [
              el('div', { class: 'ribbon-item-title' }, item.title),
              el('div', { class: 'ribbon-item-meta' }, `${READING_TYPE_LABELS[item.type]} · ${READING_STATUS_LABELS[item.status]}${item.progress ? ' · ' + item.progress : ''}`),
            ]),
            item.rating ? el('div', { style: 'font-size:13px;flex-shrink:0' }, ratingStars(item.rating)) : null,
          ].filter(Boolean)),
          item.note ? el('div', { class: 'ribbon-item-note' }, item.note) : null,
          el('div', { class: 'ribbon-item-actions' }, [
            el('button', { onclick: () => editReadingItem(item) }, '編輯'),
            el('button', { onclick: () => deleteReadingItem(item.id) }, '刪除'),
          ]),
        ].filter(Boolean)),
      ]));
    });
  } catch (e) {
    listEl.innerHTML = '';
    listEl.appendChild(el('div', { class: 'empty-state' }, '讀書紀錄暫時無法取得'));
  }
}

async function addReadingItem() {
  const type = $('#readingTypeInput').value;
  const title = $('#readingTitleInput').value.trim();
  const status = $('#readingStatusInput').value;
  const progress = $('#readingProgressInput').value.trim();
  const ratingVal = $('#readingRatingInput').value;
  const note = $('#readingNoteInput').value.trim();
  if (!title) { showToast('請輸入書名/劇名'); return; }
  const rating = ratingVal ? Number(ratingVal) : null;
  try {
    if (readingEditingId) {
      await api(`/reading/${readingEditingId}`, { method: 'PUT', body: { type, title, status, progress, rating, note } });
      showToast('已更新');
      cancelEditReadingItem();
    } else {
      await api('/reading', { method: 'POST', body: { type, title, status, progress, rating, note } });
      $('#readingTitleInput').value = '';
      $('#readingProgressInput').value = '';
      $('#readingRatingInput').value = '';
      $('#readingNoteInput').value = '';
      showToast('已新增');
    }
    loadReadingList();
  } catch (e) { showToast((readingEditingId ? '更新失敗：' : '新增失敗：') + e.message); }
}

// v0.77：編輯改成重用上面的「新增一筆」表單，不再連續跳 5 個 prompt()——尤其狀態原本要
// 使用者自己打 want/in_progress/done 這種內部代碼，現在直接是表單裡本來就有的下拉選單。
function editReadingItem(item) {
  readingEditingId = item.id;
  $('#readingFormTitle').textContent = '✏️ 編輯這一筆';
  $('#readingTypeInput').value = item.type;
  $('#readingTitleInput').value = item.title;
  $('#readingStatusInput').value = item.status;
  $('#readingProgressInput').value = item.progress || '';
  $('#readingRatingInput').value = item.rating ? String(item.rating) : '';
  $('#readingNoteInput').value = item.note || '';
  $('#readingSubmitBtn').textContent = '儲存修改';
  $('#readingCancelBtn').style.display = '';
  $('#readingTitleInput').focus();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}
function cancelEditReadingItem() {
  readingEditingId = null;
  $('#readingFormTitle').textContent = '📚 新增一筆';
  $('#readingTypeInput').value = 'book';
  $('#readingTitleInput').value = '';
  $('#readingStatusInput').value = 'want';
  $('#readingProgressInput').value = '';
  $('#readingRatingInput').value = '';
  $('#readingNoteInput').value = '';
  $('#readingSubmitBtn').textContent = '新增';
  $('#readingCancelBtn').style.display = 'none';
}

async function deleteReadingItem(id) {
  if (!confirm('確定要刪除這筆紀錄嗎？')) return;
  try {
    await api(`/reading/${id}`, { method: 'DELETE' });
    showToast('已刪除');
    loadReadingList();
  } catch (e) { showToast('刪除失敗：' + e.message); }
}

// ===================== 習慣養成 (v0.45，v0.52 圖示改選單+本週固定排序) =====================
// iPhone 風格：一個習慣一張卡片，today 打勾/取消，顯示連續天數跟本週一到週日的打卡點。
// v0.52：圖示欄位原本是可以自由打字的文字框 (容易誤觸、留空時還會被偷偷換成跟「打卡」
// 按鈕一樣的 ✅ 勾勾，讓人搞不清楚那是圖示還是已完成狀態)，改成固定選項的下拉選單，
// 一定會有一個明確選到的 emoji，不會再意外變成 ✅。
const HABIT_ICON_OPTIONS = ['🔁', '💧', '🏃', '🧘', '📖', '🍎', '💊', '🛌', '🚭', '📵', '✍️', '🧹', '🌱', '🎯'];

let habitEditingId = null;
function renderHabits() {
  const c = $('#tab-habits');
  c.innerHTML = '';
  habitEditingId = null;

  c.appendChild(el('div', { class: 'card' }, [
    el('h3', { id: 'habitFormTitle' }, '🔁 新增習慣'),
    chipSelectEl({
      id: 'habitIconInput', variant: 'icons', value: HABIT_ICON_OPTIONS[0],
      options: HABIT_ICON_OPTIONS.map((ic) => ({ value: ic, label: ic })),
    }),
    el('input', { id: 'habitTitleInput', placeholder: '習慣名稱，例如：喝 2000ml 水', style: 'width:100%;margin-top:8px' }),
    el('div', { style: 'margin-top:8px;display:flex;gap:10px;align-items:center' }, [
      el('button', { class: 'btn btn-primary', id: 'habitSubmitBtn', onclick: addHabit }, '新增'),
      el('button', { class: 'btn btn-ghost', id: 'habitCancelBtn', style: 'display:none', onclick: cancelEditHabit }, '取消'),
    ]),
  ]));

  c.appendChild(el('div', { id: 'habitsList' }, el('div', { class: 'empty-state' }, '載入中...')));

  loadHabitsList();
}

function habitDotsRow(week) {
  const WEEKDAY_LABEL = ['日', '一', '二', '三', '四', '五', '六'];
  return el('div', { style: 'display:flex;gap:6px;margin-top:8px' }, week.map((d) => {
    const wd = WEEKDAY_LABEL[new Date(d.date + 'T00:00:00Z').getUTCDay()];
    return el('div', { style: 'display:flex;flex-direction:column;align-items:center;gap:3px' }, [
      el('div', {
        style: `width:20px;height:20px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:11px;${d.done ? 'background:var(--good);color:#fff;' : 'background:var(--surface-2);color:var(--text-muted);'}`,
      }, d.done ? '✓' : ''),
      el('div', { class: 'hint', style: 'margin:0;font-size:10px' }, wd),
    ]);
  }));
}

async function loadHabitsList() {
  const listEl = $('#habitsList');
  if (!listEl) return;
  try {
    const habits = await api('/habits');
    listEl.innerHTML = '';
    if (!habits.length) {
      listEl.appendChild(el('div', { class: 'empty-state' }, '還沒有任何習慣，上面新增第一個吧！'));
      return;
    }
    habits.forEach((h) => {
      listEl.appendChild(el('div', { class: 'card', style: 'margin-bottom:10px' }, [
        el('div', { style: 'display:flex;justify-content:space-between;align-items:center' }, [
          el('div', { style: 'display:flex;align-items:center;gap:8px' }, [
            el('span', { style: 'font-size:22px' }, h.icon),
            el('div', {}, [
              el('div', { style: 'font-weight:700' }, h.title),
              el('div', { class: 'hint', style: 'margin:2px 0 0' }, h.streak > 0 ? `🔥 連續 ${h.streak} 天` : '還沒開始連續紀錄'),
            ]),
          ]),
          el('button', {
            class: 'btn ' + (h.doneToday ? 'btn-primary' : 'btn-ghost'),
            style: 'min-width:64px',
            onclick: () => toggleHabit(h.id),
          }, h.doneToday ? '✓ 已完成' : '打卡'),
        ]),
        habitDotsRow(h.week),
        el('div', { style: 'display:flex;gap:8px;margin-top:8px' }, [
          el('button', { class: 'dash-section-action', onclick: () => editHabit(h.id, h.title, h.icon) }, '編輯'),
          el('button', { class: 'dash-section-action', onclick: () => deleteHabit(h.id) }, '刪除'),
        ]),
      ]));
    });
  } catch (e) {
    listEl.innerHTML = '';
    listEl.appendChild(el('div', { class: 'empty-state' }, '習慣資料暫時無法取得'));
  }
}

async function addHabit() {
  const icon = $('#habitIconInput').value || HABIT_ICON_OPTIONS[0];
  const title = $('#habitTitleInput').value.trim();
  if (!title) { showToast('請輸入習慣名稱'); return; }
  try {
    if (habitEditingId) {
      await api(`/habits/${habitEditingId}`, { method: 'PUT', body: { title, icon } });
      showToast('已更新');
      cancelEditHabit();
    } else {
      await api('/habits', { method: 'POST', body: { title, icon } });
      $('#habitTitleInput').value = '';
      $('#habitIconInput').value = HABIT_ICON_OPTIONS[0];
      showToast('已新增');
    }
    loadHabitsList();
  } catch (e) { showToast((habitEditingId ? '更新失敗：' : '新增失敗：') + e.message); }
}

async function toggleHabit(id) {
  try {
    await api(`/habits/${id}/toggle`, { method: 'POST' });
    loadHabitsList();
  } catch (e) { showToast('操作失敗：' + e.message); }
}

// v0.77：編輯改成重用上面的「新增習慣」表單——圖示欄本來就是下拉選單，不用再把整排 emoji
// 選項貼進 prompt() 文字裡讓使用者自己照著打一次。
function editHabit(id, oldTitle, oldIcon) {
  habitEditingId = id;
  $('#habitFormTitle').textContent = '✏️ 編輯習慣';
  $('#habitTitleInput').value = oldTitle;
  $('#habitIconInput').value = oldIcon;
  $('#habitSubmitBtn').textContent = '儲存修改';
  $('#habitCancelBtn').style.display = '';
  $('#habitTitleInput').focus();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}
function cancelEditHabit() {
  habitEditingId = null;
  $('#habitFormTitle').textContent = '🔁 新增習慣';
  $('#habitTitleInput').value = '';
  $('#habitIconInput').value = HABIT_ICON_OPTIONS[0];
  $('#habitSubmitBtn').textContent = '新增';
  $('#habitCancelBtn').style.display = 'none';
}

async function deleteHabit(id) {
  if (!confirm('確定要刪除這個習慣嗎？連同打卡紀錄一起刪除。')) return;
  try {
    await api(`/habits/${id}`, { method: 'DELETE' });
    showToast('已刪除');
    loadHabitsList();
  } catch (e) { showToast('刪除失敗：' + e.message); }
}

// ===================== 個人筆記 (v0.46，iPhone 備忘錄風格) =====================
// 清單/編輯兩種畫面切換：notesViewState 是 null (清單) 或 'new' (新增) 或筆記 id (編輯)。
let notesViewState = null;
let notesFolderFilter = '';

function renderNotes() {
  const c = $('#tab-notes');
  c.innerHTML = '';
  if (notesViewState !== null) {
    renderNoteEditor(c);
    return;
  }
  renderNotesList(c);
}

function renderNotesList(c) {
  c.appendChild(el('div', { class: 'card' }, [
    el('div', { style: 'display:flex;gap:8px;align-items:center' }, [
      el('input', {
        id: 'notesFolderFilterInput', placeholder: '依資料夾篩選 (留空看全部)', style: 'flex:1',
        value: notesFolderFilter,
        onchange: (e) => { notesFolderFilter = e.target.value.trim(); loadNotesList(); },
      }),
      el('button', { class: 'btn btn-primary', onclick: () => { notesViewState = 'new'; renderNotes(); } }, '📝 新增筆記'),
    ]),
  ]));
  c.appendChild(el('div', { id: 'notesList' }, el('div', { class: 'empty-state' }, '載入中...')));
  loadNotesList();
}

function notePreviewText(note) {
  const firstLine = String(note.content || '').split('\n').find((l) => l.trim()) || '';
  return firstLine.slice(0, 60);
}

async function loadNotesList() {
  const listEl = $('#notesList');
  if (!listEl) return;
  try {
    const qs = notesFolderFilter ? `?folder=${encodeURIComponent(notesFolderFilter)}` : '';
    const notes = await api('/notes' + qs);
    listEl.innerHTML = '';
    if (!notes.length) {
      listEl.appendChild(el('div', { class: 'empty-state' }, notesFolderFilter ? '這個資料夾裡還沒有筆記' : '還沒有任何筆記，點上面「新增筆記」開始寫吧！'));
      return;
    }
    notes.forEach((n) => {
      listEl.appendChild(el('div', {
        class: 'card', style: 'margin-bottom:10px;cursor:pointer',
        onclick: () => { notesViewState = n.id; renderNotes(); },
      }, [
        el('div', { style: 'display:flex;justify-content:space-between;align-items:flex-start;gap:8px' }, [
          el('div', { style: 'flex:1;min-width:0' }, [
            el('div', { style: 'font-weight:700;display:flex;align-items:center;gap:6px' }, [
              n.pinned ? el('span', {}, '📌') : null,
              el('span', {}, n.title || '（無標題）'),
            ].filter(Boolean)),
            n.folder ? el('div', { class: 'hint', style: 'margin:2px 0 0' }, `📁 ${n.folder}`) : null,
            el('div', { class: 'hint', style: 'margin:4px 0 0' }, notePreviewText(n)),
          ].filter(Boolean)),
          el('button', {
            class: 'icon-btn', title: n.pinned ? '取消釘選' : '釘選',
            onclick: (e) => { e.stopPropagation(); toggleNotePin(n.id); },
          }, n.pinned ? '📌' : '📍'),
        ]),
      ]));
    });
  } catch (e) {
    listEl.innerHTML = '';
    listEl.appendChild(el('div', { class: 'empty-state' }, '筆記資料暫時無法取得'));
  }
}

async function toggleNotePin(id) {
  try {
    await api(`/notes/${id}/pin`, { method: 'POST' });
    loadNotesList();
  } catch (e) { showToast('操作失敗：' + e.message); }
}

async function renderNoteEditor(c) {
  const isNew = notesViewState === 'new';
  let note = { title: '', content: '', folder: '' };
  if (!isNew) {
    try {
      note = await api(`/notes/${notesViewState}`);
    } catch (e) {
      showToast('筆記載入失敗：' + e.message);
      notesViewState = null;
      renderNotes();
      return;
    }
  }
  c.innerHTML = '';
  c.appendChild(el('div', { class: 'card' }, [
    el('div', { style: 'display:flex;justify-content:space-between;align-items:center;margin-bottom:10px' }, [
      el('button', { class: 'btn btn-ghost', onclick: () => { notesViewState = null; renderNotes(); } }, '← 返回清單'),
      isNew ? null : el('button', { class: 'btn btn-ghost', onclick: () => deleteNote(note.id) }, '🗑 刪除'),
    ].filter(Boolean)),
    el('input', { id: 'noteTitleInput', placeholder: '標題', value: note.title || '', style: 'font-weight:700;font-size:16px;margin-bottom:8px' }),
    el('input', { id: 'noteFolderInput', placeholder: '資料夾 (選填，例如：工作)', value: note.folder || '', style: 'margin-bottom:8px' }),
    el('textarea', { id: 'noteContentInput', placeholder: '在這裡輸入內容...', style: 'width:100%;min-height:240px;resize:vertical' }, note.content || ''),
    el('div', { style: 'display:flex;gap:8px;margin-top:10px' }, [
      el('button', { class: 'btn btn-primary', onclick: () => saveNote(isNew ? null : note.id) }, '儲存'),
    ]),
  ]));
}

async function saveNote(id) {
  const title = $('#noteTitleInput').value.trim();
  const content = $('#noteContentInput').value;
  const folder = $('#noteFolderInput').value.trim();
  if (!title && !content.trim()) { showToast('標題跟內容不能都是空白'); return; }
  try {
    if (id) {
      await api(`/notes/${id}`, { method: 'PUT', body: { title, content, folder } });
    } else {
      await api('/notes', { method: 'POST', body: { title, content, folder } });
    }
    showToast('已儲存');
    notesViewState = null;
    renderNotes();
  } catch (e) { showToast('儲存失敗：' + e.message); }
}

async function deleteNote(id) {
  if (!confirm('確定要刪除這篇筆記嗎？')) return;
  try {
    await api(`/notes/${id}`, { method: 'DELETE' });
    showToast('已刪除');
    notesViewState = null;
    renderNotes();
  } catch (e) { showToast('刪除失敗：' + e.message); }
}

// ===================== 塔羅占卜 (v0.70，v0.71 重做抽牌互動) =====================
// 牌卡資料跟抽牌邏輯都在後端 (src/data/tarotDeck.js、src/routes/tarot.js)，前端只負責
// 送出抽牌請求、把結果畫出來 (洗牌動畫 + 翻牌 + 依花色區分卡面樣式)，跟顯示過去的占卜紀錄。
//
// v0.71 調整 (根據使用者回饋)：
//   1. 拿掉「單張/三張」下拉選單 + 分開的「開始抽牌」按鈕——改成兩個直接可以點的抽牌動作，
//      點了就直接抽那個牌陣，不用「先選模式、再按確認」兩步。
//   2. 拿掉「想問的問題」欄位——目前完全不影響抽到哪張牌 (塔羅本來就該先問問題、再隨機抽牌、
//      拿抽到的牌對應問題解讀，不是反過來)，沒有實際作用的欄位不留著佔位置；之後如果做
//      「AI 幫你把牌義結合問題寫解讀」，會是那個新功能自己的輸入框，屆時才會真的用上。
//   3. 加上洗牌動畫 (抽牌當下顯示一疊會晃動的牌背) + 發牌動畫 (卡片從縮小/半透明滑入定位，
//      到定位後才翻面)，比原本「直接生成卡片、馬上翻面」更有抽卡的節奏感。
//   4. 卡片正面依「花色」上不同底色跟角標圖示：大阿爾克那(金紫)/權杖·火(橘紅)/聖杯·水(藍)/
//      寶劍·風(灰銀)/錢幣·土(綠金)，78 張牌不再全部長一樣。
//   5. 三張牌牌陣的卡片縮小尺寸，讓三張能在手機寬度同一行並排，不用換行堆疊。
const TAROT_SPREADS = [
  { key: 'single', icon: '🔮', title: '抽一張牌', hint: '今日/此刻的指引' },
  { key: 'three', icon: '🔮🔮🔮', title: '抽三張牌', hint: '過去 / 現在 / 未來' },
];
let tarotLastResult = null;

// 依花色決定卡面配色 class 跟角標圖示——大阿爾克那用 major，小阿爾克那從 card.key
// (格式 minor-<suit>-...) 解析花色，沒對到就退回中性樣式，不會壞掉。
const TAROT_SUIT_THEME = {
  wands: { icon: '🔥', cls: 'tarot-suit-wands' },
  cups: { icon: '💧', cls: 'tarot-suit-cups' },
  swords: { icon: '⚔️', cls: 'tarot-suit-swords' },
  pentacles: { icon: '🪙', cls: 'tarot-suit-pentacles' },
};
function tarotCardTheme(card) {
  if (card.arcana === 'major') return { icon: '🌟', cls: 'tarot-suit-major' };
  const suit = String(card.key).split('-')[1];
  return TAROT_SUIT_THEME[suit] || { icon: '🔮', cls: '' };
}

function renderTarot() {
  const c = $('#tab-tarot');
  c.innerHTML = '';

  c.appendChild(el('div', { class: 'card' }, [
    el('h3', {}, '🔮 塔羅占卜'),
    el('p', { class: 'hint' }, '78 張牌全部是內建資料，不會連到任何外部占卜或 AI 服務——單純幫你把牌抽出來、附上牌義讓你自己解讀，就像實體牌卡一樣，不是「AI 幫你算命」。'),
    el('input', {
      id: 'tarotQuestionInput',
      placeholder: '想問的問題 (選填，例如「這禮拜工作運勢如何？」)',
      style: 'width:100%;margin-bottom:10px',
    }),
    el('p', { class: 'hint', style: 'margin-top:-6px;margin-bottom:10px' }, '問題不會影響抽到哪張牌，是抽完之後可以另外請 AI 幫你把牌義結合這個問題寫成解讀用的。'),
    el('div', { class: 'tarot-spread-choice-row' }, TAROT_SPREADS.map((s) =>
      el('button', { class: 'tarot-spread-choice-btn', onclick: () => drawTarotCards(s.key) }, [
        el('div', { class: 'tarot-spread-choice-icon' }, s.icon),
        el('div', { class: 'tarot-spread-choice-title' }, s.title),
        el('div', { class: 'tarot-spread-choice-hint' }, s.hint),
      ])
    )),
    el('div', { id: 'tarotResultArea', style: 'margin-top:16px' }),
  ]));

  c.appendChild(el('div', { class: 'card' }, [
    el('h3', {}, '🗂️ 占卜卡夾'),
    el('p', { class: 'hint' }, '只保留最近 7 天內抽的牌，超過 7 天會自動永久刪除 (含心得跟 AI 解讀)，避免卡夾越疊越多。'),
    el('div', { id: 'tarotHistoryArea' }, el('div', { class: 'empty-state' }, '載入中...')),
  ]));
  loadTarotHistory();
}

function tarotCardFaceEl(card, theme) {
  return el('div', { class: `tarot-card-face tarot-card-front-face ${theme.cls}` }, [
    el('div', { class: 'tarot-card-suit-badge' }, theme.icon),
    el('div', { class: 'tarot-card-name' }, card.name),
    card.reversed ? el('div', { class: 'tarot-card-reversed-badge' }, '逆位') : null,
    el('div', { class: 'tarot-card-keyword' }, card.keyword),
  ].filter(Boolean));
}

function tarotCardEl(card, index, compact) {
  const theme = tarotCardTheme(card);
  const wrap = el('div', { class: 'tarot-card-3d' + (compact ? ' tarot-card-compact' : ''), id: `tarotCard${index}` }, [
    el('div', { class: 'tarot-card-inner' }, [
      el('div', { class: 'tarot-card-face tarot-card-back-face' }, el('div', { class: 'tarot-card-back-emblem' }, '🔮')),
      tarotCardFaceEl(card, theme),
    ]),
  ]);
  // 先「發牌」(從縮小/半透明滑入定位)，到定位後再翻面——比同時發生更有節奏感，
  // 每張牌之間也錯開一點時間，看起來像一張一張抽出來的，不是整批同時出現。
  setTimeout(() => { wrap.classList.add('is-dealt'); }, 60 + index * 180);
  setTimeout(() => { wrap.classList.add('is-flipped'); }, 420 + index * 180);
  return wrap;
}

function tarotShuffleDeckEl() {
  return el('div', { class: 'tarot-shuffle-deck' }, [
    el('div', { class: 'tarot-shuffle-stack' }, [
      el('div', { class: 'tarot-shuffle-card' }),
      el('div', { class: 'tarot-shuffle-card' }),
      el('div', { class: 'tarot-shuffle-card' }),
    ]),
    el('div', { class: 'hint', style: 'text-align:center;margin-top:12px' }, '洗牌中...'),
  ]);
}

function sleep(ms) { return new Promise((resolve) => setTimeout(resolve, ms)); }

// AI 解讀用「捲軸/信件」風格卡片呈現，跟一般白色 .card 明顯區隔開——使用者選過這個
// 顯示風格，避免跟普通卡片混在一起看不出來這段是 AI 生成的客製化解讀。
// 這張卡片不會自動消失或計時隱藏——解讀內容一直存在資料庫裡、占卜紀錄也看得到，
// 交給使用者自己決定要不要收合，不做「幫你自動關掉」這種容易漏看內容的設計。
// startExpanded：剛產生完的當下預設展開；占卜紀錄列表裡的舊解讀預設收合，避免
// 列表被一堆展開的長文字塞滿，想回顧再自己點開。
function tarotAiReadingEl(text, startExpanded) {
  const bodyId = 'tarotAiReadingBody' + Math.random().toString(36).slice(2);
  const toggleBtn = el('button', { class: 'tarot-ai-reading-scroll-toggle' }, startExpanded ? '▲ 收合' : '▼ 展開解讀');
  const body = el('div', { id: bodyId, class: 'tarot-ai-reading-scroll-body', style: startExpanded ? '' : 'display:none' }, [
    el('div', { class: 'tarot-ai-reading-scroll-text' }, text),
  ]);
  const toggle = () => {
    const expanded = body.style.display !== 'none';
    body.style.display = expanded ? 'none' : '';
    toggleBtn.textContent = expanded ? '▼ 展開解讀' : '▲ 收合';
  };
  // 按鈕點擊事件會冒泡到外層 header 的 onclick，兩邊都綁同一個 toggle 會互相抵銷
  // (點一下等於切兩次、視覺上像沒反應)，所以按鈕這邊要先 stopPropagation。
  toggleBtn.onclick = (ev) => { ev.stopPropagation(); toggle(); };
  const header = el('div', { class: 'tarot-ai-reading-scroll-header', onclick: toggle }, [
    el('div', { class: 'tarot-ai-reading-scroll-title' }, '🔮 AI 客製化解讀'),
    toggleBtn,
  ]);
  return el('div', { class: 'tarot-ai-reading-scroll' }, [
    el('div', { class: 'tarot-ai-reading-scroll-cap tarot-ai-reading-scroll-cap-top' }),
    header,
    body,
    el('div', { class: 'tarot-ai-reading-scroll-cap tarot-ai-reading-scroll-cap-bottom' }),
  ]);
}

function tarotAiReadingTriggerEl(id, containerId) {
  return el('div', { id: containerId, style: 'margin-top:10px' }, [
    el('button', { class: 'btn btn-ghost', onclick: () => generateTarotAiReading(id, containerId) }, '🔮 產生 AI 客製化解讀'),
  ]);
}

async function generateTarotAiReading(id, containerId) {
  const container = $('#' + containerId);
  if (!container) return;
  container.innerHTML = '';
  container.appendChild(el('div', { class: 'hint' }, '解讀生成中...'));
  try {
    const result = await api(`/tarot/draws/${id}/ai-reading`, { method: 'POST' });
    container.innerHTML = '';
    if (!result.isConfigured) {
      container.appendChild(el('div', { class: 'empty-state' }, result.reply));
      return;
    }
    // 剛產生完的解讀預設展開，讓使用者不用多點一下就能馬上看到結果。
    container.appendChild(tarotAiReadingEl(result.aiReading, true));
  } catch (e) {
    container.innerHTML = '';
    container.appendChild(el('div', { class: 'empty-state' }, '解讀產生失敗：' + e.message));
    container.appendChild(el('button', { class: 'btn btn-ghost', style: 'margin-top:6px', onclick: () => generateTarotAiReading(id, containerId) }, '重試'));
  }
}

async function drawTarotCards(spreadType) {
  const area = $('#tarotResultArea');
  const questionInput = $('#tarotQuestionInput');
  const question = (questionInput && questionInput.value.trim()) || '';
  area.innerHTML = '';
  area.appendChild(tarotShuffleDeckEl());
  try {
    // 洗牌動畫至少播 650ms 才進到發牌，即使伺服器回得很快也一樣——不然動畫一閃即逝，
    // 感覺不到「有在洗牌」；真的抽牌邏輯完全在後端，這裡只是讓視覺節奏更完整。
    const [result] = await Promise.all([
      api('/tarot/draw', { method: 'POST', body: { spreadType, question } }),
      sleep(650),
    ]);
    tarotLastResult = result;
    const compact = result.cards.length > 1;
    area.innerHTML = '';
    area.appendChild(el('p', { class: 'hint' }, result.spreadLabel));
    area.appendChild(el('div', { class: 'tarot-spread-grid' }, result.cards.map((card, i) => tarotCardEl(card, i, compact))));
    const meaningBox = el('div', {});
    result.cards.forEach((card) => {
      meaningBox.appendChild(el('div', { class: 'tarot-meaning-box' }, [
        el('div', { style: 'font-weight:700;margin-bottom:4px' }, `${card.name}${card.reversed ? '（逆位）' : '（正位）'} — ${card.keyword}`),
        el('div', { style: 'font-size:13px;line-height:1.6' }, card.meaning),
      ]));
    });
    area.appendChild(meaningBox);
    area.appendChild(el('div', { style: 'margin-top:10px;display:flex;gap:8px;flex-wrap:wrap' }, [
      el('input', { id: 'tarotNoteInput', placeholder: '寫下這次抽牌的心得/備註 (選填)', style: 'flex:1' }),
      el('button', { class: 'btn btn-ghost', onclick: () => saveTarotNote(result.id) }, '💾 儲存心得'),
    ]));
    area.appendChild(tarotAiReadingTriggerEl(result.id, `tarotAiReading${result.id}`));
    loadTarotHistory();
  } catch (e) {
    area.innerHTML = '';
    area.appendChild(el('div', { class: 'empty-state' }, '抽牌失敗：' + e.message));
  }
}

async function saveTarotNote(id) {
  const note = ($('#tarotNoteInput') && $('#tarotNoteInput').value.trim()) || '';
  try {
    await api(`/tarot/draws/${id}/note`, { method: 'PUT', body: { note } });
    showToast('已儲存心得');
    loadTarotHistory();
  } catch (e) { showToast('儲存失敗：' + e.message); }
}

// 依 expiresAt 算「還剩幾天會被自動刪除」，快到期 (剩 1 天內) 用比較顯眼的顏色提醒，
// 免得使用者完全不知道這筆卡夾快消失了。
function tarotExpiryBadgeEl(expiresAt) {
  if (!expiresAt) return null;
  const msLeft = new Date(expiresAt).getTime() - Date.now();
  const daysLeft = Math.max(0, Math.ceil(msLeft / (24 * 60 * 60 * 1000)));
  const label = daysLeft <= 0 ? '今天到期' : `${daysLeft} 天後刪除`;
  const soon = daysLeft <= 1;
  return el('div', { class: 'tarot-expiry-badge' + (soon ? ' tarot-expiry-badge-soon' : '') }, `⏳ ${label}`);
}

async function loadTarotHistory() {
  const area = $('#tarotHistoryArea');
  if (!area) return;
  try {
    const { items } = await api('/tarot/history?limit=50');
    area.innerHTML = '';
    if (!items.length) {
      area.appendChild(el('div', { class: 'empty-state' }, '卡夾還是空的，上面選「抽一張」或「抽三張」試試看吧！(卡夾只保留最近 7 天內抽的牌)'));
      return;
    }
    items.forEach((draw) => {
      const cardsSummary = draw.cards.map((c) => `${c.name}${c.reversed ? '(逆)' : ''}`).join('、');
      area.appendChild(el('div', { class: 'card', style: 'margin-bottom:10px' }, [
        el('div', { style: 'display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap;align-items:flex-start' }, [
          el('div', {}, [
            el('div', { style: 'font-weight:700' }, draw.spreadLabel),
            el('div', { class: 'hint' }, new Date(draw.createdAt).toLocaleString('zh-Hant-TW')),
          ]),
          tarotExpiryBadgeEl(draw.expiresAt),
        ]),
        draw.question ? el('div', { class: 'hint', style: 'margin-top:4px' }, `問題：${draw.question}`) : null,
        el('div', { style: 'margin-top:6px;font-size:13px' }, cardsSummary),
        draw.note ? el('div', { class: 'tarot-meaning-box', style: 'margin-top:8px' }, draw.note) : null,
        draw.aiReading
          ? tarotAiReadingEl(draw.aiReading, false)
          : tarotAiReadingTriggerEl(draw.id, `tarotAiReadingHist${draw.id}`),
      ].filter(Boolean)));
    });
  } catch (e) {
    area.innerHTML = '';
    area.appendChild(el('div', { class: 'empty-state' }, '載入失敗：' + e.message));
  }
}

// ===================== 願望清單 (v0.47) =====================
// v0.74：優先度文字對照表跟待辦事項共用同一份 PRIORITY_LABEL (在待辦事項那段定義)，
// 不再各自維護一份一模一樣的複製版本。

let wishlistPartnerLinks = [];

let wishlistEditingId = null;
let wishlistConvertOpenId = null;
let wishlistGoals = [];
function renderWishlist() {
  const c = $('#tab-wishlist');
  c.innerHTML = '';
  wishlistEditingId = null;
  wishlistConvertOpenId = null;
  c.appendChild(el('div', { class: 'card' }, [
    el('h3', { id: 'wishFormTitle' }, '🎀 新增願望'),
    el('div', { class: 'form-row' }, [
      el('input', { id: 'wishTitleInput', placeholder: '想要的東西', style: 'flex:1' }),
    ]),
    el('div', { class: 'form-row', style: 'margin-top:8px' }, [
      el('input', { id: 'wishPriceInput', type: 'number', min: '0', step: '0.1', placeholder: '價格 (選填)', style: 'max-width:140px' }),
      el('button', { class: 'btn btn-primary', id: 'wishSubmitBtn', onclick: addWishlistItem }, '新增'),
      el('button', { class: 'btn btn-ghost', id: 'wishCancelBtn', style: 'display:none', onclick: cancelEditWishlistItem }, '取消'),
    ]),
    el('div', { style: 'margin-top:8px' }, [
      prioritySliderEl('wishPriorityInput', 'medium'),
    ]),
    el('input', { id: 'wishLinkInput', placeholder: '連結 (選填)', style: 'margin-top:8px' }),
    el('div', { id: 'wishScopeRow', style: 'margin-top:8px' }),
  ]));
  c.appendChild(el('div', { id: 'wishlistList' }, el('div', { class: 'empty-state' }, '載入中...')));
  loadWishlistPartnerLinks();
  loadWishlistGoals();
  loadWishlistList();
}

async function loadWishlistGoals() {
  try { wishlistGoals = await api('/finance/goals'); } catch (e) { wishlistGoals = []; }
}

async function loadWishlistPartnerLinks() {
  const row = $('#wishScopeRow');
  if (!row) return;
  try {
    const { links } = await api('/partner-link');
    wishlistPartnerLinks = links || [];
    row.innerHTML = '';
    if (!wishlistPartnerLinks.length) return; // 沒有連結任何人，就不用顯示「共同建立」的選項
    row.appendChild(el('label', { class: 'hint', style: 'display:block;margin-bottom:4px' }, '這個願望是：'));
    row.appendChild(el('select', { id: 'wishScopeInput' }, [
      el('option', { value: '' }, '只有我自己'),
      ...wishlistPartnerLinks.map((l) => el('option', { value: String(l.linkId) }, `跟 ${l.name} 共同建立`)),
    ]));
  } catch (e) {
    wishlistPartnerLinks = [];
  }
}

const WISHLIST_PRIORITY_RIBBON = { low: 'rb-blue', medium: 'rb-violet', high: 'rb-red' };
const WISHLIST_PRIORITY_BADGE = { low: 'ribbon-badge-blue', medium: 'ribbon-badge-violet', high: 'ribbon-badge-red' };
function wishlistItemCard(item) {
  const priceText = item.price != null ? `NT$ ${Number(item.price).toLocaleString()}` : '';
  // v0.76：完成狀態只交給刪除線表示 (跟子任務打勾完成同一套視覺語言)，不再疊加一個
  // 「已完成」徽章重複講同一件事；打勾框也移到跟子任務一樣的「checkbox+標題」排法。
  const goalPct = (item.goalProjection && item.price)
    ? Math.max(0, Math.min(100, Math.round((item.goalProjection.goalNetSaved / item.price) * 100)))
    : null;
  return el('div', { class: 'card', style: 'margin-bottom:10px' }, [
    el('div', {
      class: `ribbon-item ${item.completed ? 'rb-blue' : (WISHLIST_PRIORITY_RIBBON[item.priority] || 'rb-violet')}`,
      style: item.completed ? 'opacity:0.6' : '',
    }, [
      el('div', { class: 'ribbon-item-top-row' }, [
        el('label', { style: 'display:flex;align-items:center;gap:8px;flex:1;min-width:0;cursor:pointer' }, [
          el('input', { type: 'checkbox', checked: !!item.completed, onchange: () => toggleWishlistItem(item.id) }),
          el('span', { class: 'ribbon-item-title' + (item.completed ? ' done' : '') }, item.title),
        ]),
        item.completed ? null : el('span', { class: `ribbon-badge ${WISHLIST_PRIORITY_BADGE[item.priority] || 'ribbon-badge-violet'}` }, PRIORITY_LABEL[item.priority] || item.priority),
      ].filter(Boolean)),
      priceText ? el('span', { class: 'ribbon-badge ribbon-badge-neutral' }, `💰 ${priceText}`) : null,
      item.shared ? el('div', { class: 'ribbon-item-meta', style: 'color:var(--accent)' }, `🤝 跟 ${item.partnerLabel} 共同建立 · 由${item.createdByMe ? '我' : item.creatorLabel}新增`) : null,
      item.link ? el('a', { href: item.link, target: '_blank', rel: 'noopener', class: 'ribbon-item-meta', style: 'display:block;color:var(--accent)' }, '🔗 連結') : null,
      item.note ? el('div', { class: 'ribbon-item-note' }, item.note) : null,
      item.reward
        ? el('div', { class: 'ribbon-item-meta', style: `color:${item.reward.canAffordNow ? 'var(--good)' : 'var(--text-muted)'}` },
            `🎯 已連結成獎勵：需要 ${item.reward.cost} 點${item.reward.canAffordNow ? '（現在點數已經夠了！）' : ''}`)
        : null,
      item.goalProjection
        ? el('div', {}, [
            el('div', { class: 'ribbon-item-meta', style: 'color:var(--accent)' }, [
              `💰 連結目標「${item.goalProjection.goalName}」：`,
              item.goalProjection.projectedAffordDate === 'reached'
                ? '照目前存款已經存夠了！'
                : item.goalProjection.projectedAffordDate
                  ? `依目前儲蓄速度，大約 ${item.goalProjection.projectedAffordDate} 存得到`
                  : '目前還沒有明顯的淨儲蓄速度，先看看目標本身的進度',
            ].join('')),
            goalPct != null ? el('div', { class: 'ribbon-goal-progress-track' }, [
              el('div', { class: 'ribbon-goal-progress-fill', style: `width:${goalPct}%` }),
            ]) : null,
            goalPct != null ? el('div', { class: 'ribbon-item-meta' }, `已存 ${goalPct}%（NT$ ${Math.round(item.goalProjection.goalNetSaved).toLocaleString()} / ${priceText || 'NT$ ' + item.price}）`) : null,
          ].filter(Boolean))
        : null,
      el('div', { class: 'ribbon-item-actions' }, [
        el('button', { onclick: () => editWishlistItem(item) }, '編輯'),
        el('button', { onclick: () => deleteWishlistItem(item.id) }, '刪除'),
        (item.reward || wishlistConvertOpenId === item.id)
          ? (item.reward ? el('button', { onclick: () => switchTab('rewards') }, '前往獎勵頁面') : null)
          : el('button', { onclick: () => { wishlistConvertOpenId = item.id; loadWishlistList(); } }, '🎁 轉換成獎勵'),
      ].filter(Boolean)),
      // v0.77：「轉換成獎勵」原本會跳 prompt() 問要花多少點數，改成點下去原地展開一個小
      // 表單 (跟看板卡片編輯同一套「原地展開」模式)，不用跳彈窗。
      (wishlistConvertOpenId === item.id && !item.reward)
        ? el('div', { class: 'ribbon-item-actions', style: 'align-items:center' }, [
            el('span', { style: 'font-size:12px;color:var(--text-muted)' }, '🎁 兌換點數'),
            el('input', { id: `wishConvertCost-${item.id}`, type: 'number', min: '1', placeholder: '點數', style: 'max-width:90px' }),
            el('button', { onclick: () => confirmConvertWishlistToReward(item.id) }, '確定'),
            el('button', { onclick: () => { wishlistConvertOpenId = null; loadWishlistList(); } }, '取消'),
          ])
        : null,
      // v0.77：連結財務目標原本要輸入數字對照清單，改成常駐一行的下拉選單 (跟看板卡片
      // 「指派」同一套「選了就存」模式)，只有已經設定過財務目標時才顯示，沒有目標的話
      // 顯示這個空欄位沒有意義。
      wishlistGoals.length
        ? el('div', { class: 'ribbon-item-actions', style: 'align-items:center' }, [
            el('span', { style: 'font-size:12px;color:var(--text-muted)' }, '🎯 財務目標'),
            el('select', {
              onchange: (ev) => saveWishlistGoalLink(item.id, ev.target.value || null),
            }, [
              el('option', { value: '' }, '不連結'),
              ...wishlistGoals.map((g) => el('option', { value: String(g.id), selected: item.goal_id === g.id }, g.name)),
            ]),
          ])
        : null,
    ].filter(Boolean)),
  ]);
}

async function saveWishlistGoalLink(itemId, goalId) {
  try {
    await api(`/wishlist/${itemId}`, { method: 'PUT', body: { goalId } });
    showToast('已更新連結');
    loadWishlistList();
  } catch (e) { showToast('更新失敗：' + e.message); }
}

async function confirmConvertWishlistToReward(id) {
  const input = $(`#wishConvertCost-${id}`);
  const cost = Number(input ? input.value : NaN);
  if (!Number.isInteger(cost) || cost <= 0) { showToast('請輸入大於 0 的整數點數'); return; }
  try {
    await api(`/wishlist/${id}/convert-to-reward`, { method: 'POST', body: { cost } });
    wishlistConvertOpenId = null;
    showToast('已轉換成獎勵，可以到「獎勵兌換」頁面看到它');
    loadWishlistList();
  } catch (e) { showToast('轉換失敗：' + e.message); }
}

async function loadWishlistList() {
  const listEl = $('#wishlistList');
  if (!listEl) return;
  try {
    const items = await api('/wishlist');
    listEl.innerHTML = '';
    if (!items.length) {
      listEl.appendChild(el('div', { class: 'empty-state' }, '還沒有任何願望，上面新增第一個吧！'));
      return;
    }
    items.forEach((item) => listEl.appendChild(wishlistItemCard(item)));
  } catch (e) {
    listEl.innerHTML = '';
    listEl.appendChild(el('div', { class: 'empty-state' }, '願望清單暫時無法取得'));
  }
}

async function addWishlistItem() {
  const title = $('#wishTitleInput').value.trim();
  const price = $('#wishPriceInput').value;
  const priority = prioritySliderGet('wishPriorityInput');
  const link = $('#wishLinkInput').value.trim();
  const scopeInput = $('#wishScopeInput');
  const linkId = scopeInput && scopeInput.value ? scopeInput.value : null;
  if (!title) { showToast('請輸入名稱'); return; }
  try {
    if (wishlistEditingId) {
      await api(`/wishlist/${wishlistEditingId}`, {
        method: 'PUT',
        body: { title, price: price || null, priority, link: link || null },
      });
      showToast('已更新');
      cancelEditWishlistItem();
    } else {
      await api('/wishlist', { method: 'POST', body: { title, price: price || null, priority, link, linkId } });
      $('#wishTitleInput').value = '';
      $('#wishPriceInput').value = '';
      $('#wishLinkInput').value = '';
      if (scopeInput) scopeInput.value = '';
      showToast(linkId ? '共同願望已新增' : '已新增');
    }
    loadWishlistList();
  } catch (e) { showToast((wishlistEditingId ? '更新失敗：' : '新增失敗：') + e.message); }
}

async function toggleWishlistItem(id) {
  try {
    await api(`/wishlist/${id}/toggle`, { method: 'POST' });
    loadWishlistList();
  } catch (e) { showToast('操作失敗：' + e.message); }
}

// v0.77：編輯改成重用上面的「新增願望」表單 (名稱/價格/優先度拉桿/連結全部帶回去)，
// 不再連續跳 3 個 prompt()。
function editWishlistItem(item) {
  wishlistEditingId = item.id;
  wishlistConvertOpenId = null;
  $('#wishFormTitle').textContent = '✏️ 編輯願望';
  $('#wishTitleInput').value = item.title;
  $('#wishPriceInput').value = item.price != null ? String(item.price) : '';
  prioritySliderSet('wishPriorityInput', item.priority || 'medium');
  $('#wishLinkInput').value = item.link || '';
  $('#wishSubmitBtn').textContent = '儲存修改';
  $('#wishCancelBtn').style.display = '';
  $('#wishTitleInput').focus();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}
function cancelEditWishlistItem() {
  wishlistEditingId = null;
  $('#wishFormTitle').textContent = '🎀 新增願望';
  $('#wishTitleInput').value = '';
  $('#wishPriceInput').value = '';
  prioritySliderSet('wishPriorityInput', 'medium');
  $('#wishLinkInput').value = '';
  $('#wishSubmitBtn').textContent = '新增';
  $('#wishCancelBtn').style.display = 'none';
}

async function deleteWishlistItem(id) {
  if (!confirm('確定要刪除這個願望嗎？')) return;
  try {
    await api(`/wishlist/${id}`, { method: 'DELETE' });
    showToast('已刪除');
    loadWishlistList();
  } catch (e) { showToast('刪除失敗：' + e.message); }
}

// ===================== 年度回顧 (v0.48) =====================
let annualReviewYear = new Date().getFullYear();

function renderAnnualReview() {
  const c = $('#tab-annualReview');
  c.innerHTML = '';
  c.appendChild(el('div', { class: 'card' }, [
    el('div', { style: 'display:flex;align-items:center;justify-content:center;gap:16px' }, [
      el('button', { class: 'btn btn-ghost', onclick: () => { annualReviewYear -= 1; renderAnnualReview(); } }, '←'),
      el('h3', { style: 'margin:0' }, `🎊 ${annualReviewYear} 年度回顧`),
      el('button', {
        class: 'btn btn-ghost',
        disabled: annualReviewYear >= new Date().getFullYear(),
        onclick: () => { annualReviewYear += 1; renderAnnualReview(); },
      }, '→'),
    ]),
  ]));
  c.appendChild(el('div', { id: 'annualReviewBody' }, el('div', { class: 'empty-state' }, '載入中...')));
  loadAnnualReview();
}

function reviewStatCard(icon, label, value, hint) {
  return el('div', { class: 'card', style: 'text-align:center' }, [
    el('div', { style: 'font-size:28px' }, icon),
    el('div', { style: 'font-size:22px;font-weight:700;margin-top:4px' }, String(value)),
    el('div', { class: 'hint', style: 'margin:2px 0 0' }, label),
    hint ? el('div', { class: 'hint', style: 'margin:2px 0 0' }, hint) : null,
  ].filter(Boolean));
}

async function loadAnnualReview() {
  const body = $('#annualReviewBody');
  if (!body) return;
  try {
    const data = await api(`/annual-review?year=${annualReviewYear}`);
    body.innerHTML = '';
    const grid = el('div', { style: 'display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:10px;margin-top:10px' }, [
      reviewStatCard('📔', '日記篇數', data.diary.entryCount),
      reviewStatCard('💗', '心情平均分數', data.mood.avgScore != null ? data.mood.avgScore : '—', data.mood.entryCount ? `共 ${data.mood.entryCount} 筆紀錄` : '尚無紀錄'),
      reviewStatCard('✅', '完成待辦', data.tasks.completedCount),
      reviewStatCard('🔁', '習慣打卡次數', data.habits.checkinCount),
      reviewStatCard('📚', '讀完本數', data.reading.doneCount),
    ]);
    body.appendChild(grid);

    body.appendChild(el('div', { class: 'card', style: 'margin-top:10px' }, [
      el('h3', {}, '💰 記帳總覽'),
      el('div', { style: 'display:flex;justify-content:space-around;text-align:center;margin-top:8px' }, [
        el('div', {}, [el('div', { style: 'font-size:20px;font-weight:700;color:var(--good)' }, `NT$ ${Math.round(data.finance.income).toLocaleString()}`), el('div', { class: 'hint' }, '總收入')]),
        el('div', {}, [el('div', { style: 'font-size:20px;font-weight:700;color:var(--critical)' }, `NT$ ${Math.round(data.finance.expense).toLocaleString()}`), el('div', { class: 'hint' }, '總支出')]),
        el('div', {}, [el('div', { style: 'font-size:20px;font-weight:700' }, `NT$ ${Math.round(data.finance.net).toLocaleString()}`), el('div', { class: 'hint' }, '淨額')]),
      ]),
      data.finance.topExpenseCategories.length
        ? el('div', { style: 'margin-top:12px' }, [
            el('div', { class: 'hint', style: 'margin-bottom:6px' }, '支出前五名分類'),
            ...data.finance.topExpenseCategories.map((cat) =>
              el('div', { style: 'display:flex;justify-content:space-between;padding:4px 0' }, [
                el('span', {}, cat.category),
                el('span', { style: 'font-weight:600' }, `NT$ ${Math.round(cat.total).toLocaleString()}`),
              ])
            ),
          ])
        : el('div', { class: 'empty-state' }, '這一年還沒有支出紀錄'),
    ]));
  } catch (e) {
    body.innerHTML = '';
    body.appendChild(el('div', { class: 'empty-state' }, '年度回顧資料暫時無法取得'));
  }
}

// ===================== 揪團分帳 (v0.49) =====================
let splitGroupsView = null; // null = 清單, 'new' = 新增群組, 數字 = 該群組的詳細畫面
let splitNewMemberCount = 2;

function renderSplitGroups() {
  const c = $('#tab-splitGroups');
  c.innerHTML = '';
  if (splitGroupsView === 'new') {
    renderSplitGroupNewForm(c);
    return;
  }
  if (typeof splitGroupsView === 'number') {
    renderSplitGroupDetail(c, splitGroupsView);
    return;
  }
  renderSplitGroupsList(c);
}

function renderSplitGroupsList(c) {
  c.appendChild(el('div', { class: 'card', style: 'display:flex;justify-content:space-between;align-items:center' }, [
    el('h3', { style: 'margin:0' }, '🧮 揪團分帳'),
    el('button', { class: 'btn btn-primary', onclick: () => { splitGroupsView = 'new'; splitNewMemberCount = 2; renderSplitGroups(); } }, '➕ 新增群組'),
  ]));
  c.appendChild(el('div', { id: 'splitGroupsList' }, el('div', { class: 'empty-state' }, '載入中...')));
  loadSplitGroupsList();
}

async function loadSplitGroupsList() {
  const listEl = $('#splitGroupsList');
  if (!listEl) return;
  try {
    const groups = await api('/split-groups');
    listEl.innerHTML = '';
    if (!groups.length) {
      listEl.appendChild(el('div', { class: 'empty-state' }, '還沒有任何分帳群組，上面新增一個開始記帳吧！'));
      return;
    }
    groups.forEach((g) => {
      listEl.appendChild(el('div', {
        class: 'card', style: 'margin-bottom:10px;cursor:pointer',
        onclick: () => { splitGroupsView = g.id; renderSplitGroups(); },
      }, [
        el('div', { style: 'font-weight:700' }, g.name),
        el('div', { class: 'hint', style: 'margin-top:4px' }, `${g.memberCount} 位成員 · 總花費 NT$ ${g.totalAmount.toLocaleString()}`),
      ]));
    });
  } catch (e) {
    listEl.innerHTML = '';
    listEl.appendChild(el('div', { class: 'empty-state' }, '分帳群組暫時無法取得'));
  }
}

function renderSplitGroupNewForm(c) {
  const memberInputs = [];
  for (let i = 0; i < splitNewMemberCount; i++) {
    memberInputs.push(el('input', { id: `splitNewMember${i}`, placeholder: `成員 ${i + 1} 名字`, style: 'margin-top:6px' }));
  }
  c.appendChild(el('div', { class: 'card' }, [
    el('button', { class: 'btn btn-ghost', onclick: () => { splitGroupsView = null; renderSplitGroups(); } }, '← 返回清單'),
    el('h3', {}, '➕ 新增分帳群組'),
    el('input', { id: 'splitNewGroupName', placeholder: '群組名稱，例如：日本旅遊' }),
    el('div', { class: 'hint', style: 'margin-top:10px' }, '成員名單 (至少 2 位)'),
    el('div', { id: 'splitNewMemberInputs' }, memberInputs),
    // 用直接操作 DOM 加一個新的 input 進去，不整個表單重新 render——不然剛剛輸入的群組名稱
    // 跟其他成員名字會因為 renderSplitGroups() 重新產生全新的空白 input 而被清空。
    el('button', {
      class: 'dash-section-action', style: 'margin-top:8px',
      onclick: () => {
        const container = $('#splitNewMemberInputs');
        const idx = splitNewMemberCount;
        splitNewMemberCount += 1;
        container.appendChild(el('input', { id: `splitNewMember${idx}`, placeholder: `成員 ${idx + 1} 名字`, style: 'margin-top:6px' }));
      },
    }, '+ 再加一位成員'),
    el('div', { style: 'margin-top:12px' }, [
      el('button', { class: 'btn btn-primary', onclick: createSplitGroup }, '建立群組'),
    ]),
  ]));
}

async function createSplitGroup() {
  const name = $('#splitNewGroupName').value.trim();
  const memberNames = [];
  for (let i = 0; i < splitNewMemberCount; i++) {
    const val = $(`#splitNewMember${i}`).value.trim();
    if (val) memberNames.push(val);
  }
  if (!name) { showToast('請輸入群組名稱'); return; }
  if (memberNames.length < 2) { showToast('至少需要 2 位成員'); return; }
  try {
    await api('/split-groups', { method: 'POST', body: { name, memberNames } });
    showToast('已建立群組');
    splitGroupsView = null;
    renderSplitGroups();
  } catch (e) { showToast('建立失敗：' + e.message); }
}

async function deleteSplitGroup(groupId) {
  if (!confirm('確定要刪除這個分帳群組嗎？所有花費紀錄都會一起刪除。')) return;
  try {
    await api(`/split-groups/${groupId}`, { method: 'DELETE' });
    showToast('已刪除');
    splitGroupsView = null;
    renderSplitGroups();
  } catch (e) { showToast('刪除失敗：' + e.message); }
}

async function renderSplitGroupDetail(c, groupId) {
  let group;
  try {
    group = await api(`/split-groups/${groupId}`);
  } catch (e) {
    showToast('群組載入失敗：' + e.message);
    splitGroupsView = null;
    renderSplitGroups();
    return;
  }
  c.innerHTML = '';

  c.appendChild(el('div', { class: 'card' }, [
    el('div', { style: 'display:flex;justify-content:space-between;align-items:center' }, [
      el('button', { class: 'btn btn-ghost', onclick: () => { splitGroupsView = null; renderSplitGroups(); } }, '← 返回清單'),
      el('button', { class: 'btn btn-ghost', onclick: () => deleteSplitGroup(group.id) }, '🗑 刪除群組'),
    ]),
    el('h3', {}, `🧮 ${group.name}`),
    el('div', { class: 'hint' }, `${group.members.length} 位成員 · 總花費 NT$ ${group.totalAmount.toLocaleString()}`),
  ]));

  // 結算：誰該付給誰多少錢
  c.appendChild(el('div', { class: 'card' }, [
    el('h3', {}, '💸 結算'),
    group.settlements.length
      ? el('div', {}, group.settlements.map((s) =>
          el('div', { style: 'display:flex;justify-content:space-between;padding:4px 0' }, [
            el('span', {}, `${s.fromName} → ${s.toName}`),
            el('span', { style: 'font-weight:700;color:var(--critical)' }, `NT$ ${s.amount.toLocaleString()}`),
          ])
        ))
      : el('div', { class: 'empty-state' }, '目前收支平衡，不需要轉帳'),
  ]));

  // 每位成員的收支狀況
  c.appendChild(el('div', { class: 'card' }, [
    el('h3', {}, '👥 成員收支'),
    ...group.balances.map((b) =>
      el('div', { style: 'display:flex;justify-content:space-between;padding:4px 0' }, [
        el('span', {}, b.name),
        el('span', {
          style: 'font-weight:700;' + (b.net > 0 ? 'color:var(--good)' : b.net < 0 ? 'color:var(--critical)' : ''),
        }, b.net > 0 ? `+NT$ ${b.net.toLocaleString()}` : b.net < 0 ? `-NT$ ${Math.abs(b.net).toLocaleString()}` : 'NT$ 0'),
      ])
    ),
  ]));

  // 新增花費
  c.appendChild(el('div', { class: 'card' }, [
    el('h3', {}, '➕ 新增花費'),
    el('input', { id: 'splitExpenseDesc', placeholder: '花費說明，例如：晚餐' }),
    el('input', { id: 'splitExpenseAmount', type: 'number', min: '0', step: '1', placeholder: '金額', style: 'margin-top:6px' }),
    el('div', { class: 'hint', style: 'margin-top:8px' }, '誰付的錢？'),
    el('select', { id: 'splitExpensePayer' }, group.members.map((m) => el('option', { value: m.id }, m.name))),
    el('button', {
      class: 'btn btn-primary', style: 'margin-top:10px',
      onclick: () => addSplitExpense(group.id),
    }, '新增花費 (全體均分)'),
  ]));

  // 花費紀錄
  c.appendChild(el('div', { id: 'splitExpensesList' }));
  const expensesBox = $('#splitExpensesList');
  if (!group.expenses.length) {
    expensesBox.appendChild(el('div', { class: 'empty-state' }, '這個群組還沒有任何花費紀錄'));
  } else {
    group.expenses.forEach((exp) => {
      const payer = group.members.find((m) => m.id === exp.paid_by_member_id);
      expensesBox.appendChild(el('div', { class: 'card', style: 'margin-bottom:10px' }, [
        el('div', { style: 'display:flex;justify-content:space-between;align-items:flex-start' }, [
          el('div', {}, [
            el('div', { style: 'font-weight:700' }, exp.description || '（無說明）'),
            el('div', { class: 'hint', style: 'margin-top:2px' }, `${payer ? payer.name : '?'} 付的 · ${exp.expense_date}`),
          ]),
          el('div', { style: 'font-weight:700' }, `NT$ ${exp.amount.toLocaleString()}`),
        ]),
        el('button', { class: 'dash-section-action', style: 'margin-top:8px', onclick: () => deleteSplitExpense(group.id, exp.id) }, '刪除'),
      ]));
    });
  }
}

async function addSplitExpense(groupId) {
  const description = $('#splitExpenseDesc').value.trim();
  const amount = $('#splitExpenseAmount').value;
  const paidByMemberId = Number($('#splitExpensePayer').value);
  if (!amount || Number(amount) <= 0) { showToast('請輸入正確的金額'); return; }
  try {
    await api(`/split-groups/${groupId}/expenses`, { method: 'POST', body: { description, amount, paidByMemberId } });
    showToast('已新增花費');
    renderSplitGroups();
  } catch (e) { showToast('新增失敗：' + e.message); }
}

async function deleteSplitExpense(groupId, expenseId) {
  if (!confirm('確定要刪除這筆花費嗎？')) return;
  try {
    await api(`/split-groups/${groupId}/expenses/${expenseId}`, { method: 'DELETE' });
    showToast('已刪除');
    renderSplitGroups();
  } catch (e) { showToast('刪除失敗：' + e.message); }
}

// ===================== 專案看板 (v0.50) =====================
// 固定三欄 (待辦/進行中/完成)。手機觸控環境下滑鼠拖曳的體驗其實不太可靠 (容易誤觸/
// 滾動衝突)，所以用「◀ ▶」按鈕移動卡片到相鄰欄位，跟這個 App 其他地方的操作方式一致、
// 手機上也更好按——不是省事，是實測後刻意的選擇。
let kanbanView = null; // null = 清單, 數字 = 該看板的詳細畫面
const KANBAN_COLUMNS = [
  { key: 'todo', label: '📋 待辦' },
  { key: 'in_progress', label: '🚧 進行中' },
  { key: 'done', label: '✅ 完成' },
];

function renderKanban() {
  const c = $('#tab-kanban');
  c.innerHTML = '';
  if (typeof kanbanView === 'number') {
    renderKanbanBoardDetail(c, kanbanView);
    return;
  }
  renderKanbanBoardsList(c);
}

function renderKanbanBoardsList(c) {
  kanbanCardEditingId = null;
  c.appendChild(el('div', { class: 'card' }, [
    el('h3', { style: 'margin:0 0 10px' }, '🗂️ 專案看板'),
    el('div', { class: 'form-row' }, [
      el('input', { id: 'kanbanNewBoardName', placeholder: '看板名稱，例如：網站改版專案', style: 'flex:1', onkeydown: (ev) => { if (ev.key === 'Enter') createKanbanBoard(); } }),
      el('button', { class: 'btn btn-primary', onclick: createKanbanBoard }, '建立看板'),
    ]),
  ]));
  c.appendChild(el('div', { id: 'kanbanBoardsList' }, el('div', { class: 'empty-state' }, '載入中...')));
  loadKanbanBoardsList();
}

async function loadKanbanBoardsList() {
  const listEl = $('#kanbanBoardsList');
  if (!listEl) return;
  try {
    const boards = await api('/kanban-boards');
    listEl.innerHTML = '';
    if (!boards.length) {
      listEl.appendChild(el('div', { class: 'empty-state' }, '還沒有任何看板，上面新增一個開始規劃專案吧！'));
      return;
    }
    boards.forEach((b) => {
      listEl.appendChild(el('div', {
        class: 'card', style: 'margin-bottom:10px;cursor:pointer',
        onclick: () => { kanbanView = b.id; renderKanban(); },
      }, [
        el('div', { style: 'font-weight:700' }, b.name),
        el('div', { class: 'hint', style: 'margin-top:4px' }, `${b.cardCount} 張卡片 · 已完成 ${b.doneCount} 張`),
      ]));
    });
  } catch (e) {
    listEl.innerHTML = '';
    listEl.appendChild(el('div', { class: 'empty-state' }, '看板暫時無法取得'));
  }
}

// v0.77：新增看板改成清單上方常駐的輸入框，不再點按鈕才跳 prompt()，跟其他模組的
// 新增表單一致。
async function createKanbanBoard() {
  const input = $('#kanbanNewBoardName');
  const name = input.value.trim();
  if (!name) { showToast('請輸入看板名稱'); return; }
  try {
    const result = await api('/kanban-boards', { method: 'POST', body: { name } });
    showToast('已建立看板');
    kanbanView = result.id;
    renderKanban();
  } catch (e) { showToast('建立失敗：' + e.message); }
}

async function deleteKanbanBoard(boardId) {
  if (!confirm('確定要刪除這個看板嗎？所有卡片都會一起刪除。')) return;
  try {
    await api(`/kanban-boards/${boardId}`, { method: 'DELETE' });
    showToast('已刪除');
    kanbanView = null;
    renderKanban();
  } catch (e) { showToast('刪除失敗：' + e.message); }
}

async function renderKanbanBoardDetail(c, boardId) {
  let board;
  try {
    board = await api(`/kanban-boards/${boardId}`);
  } catch (e) {
    showToast('看板載入失敗：' + e.message);
    kanbanView = null;
    renderKanban();
    return;
  }
  c.innerHTML = '';
  // v0.68：#9 家庭看板任務公平性——只有已經跟家人/伴侶連結過的使用者，circleMembers 才會
  // 超過 1 人 (自己)，這時才顯示「指派給誰」的選項跟公平性統計，沒連結任何人的話完全不顯示，
  // 不會讓單純自己用的看板多出用不到的欄位。
  const circleMembers = board.circleMembers || [];
  const hasCircle = circleMembers.length > 1;
  c.appendChild(el('div', { class: 'card' }, [
    el('div', { style: 'display:flex;justify-content:space-between;align-items:center' }, [
      el('button', { class: 'btn btn-ghost', onclick: () => { kanbanView = null; renderKanban(); } }, '← 返回清單'),
      el('button', { class: 'btn btn-ghost', onclick: () => deleteKanbanBoard(board.id) }, '🗑 刪除看板'),
    ]),
    el('h3', {}, `🗂️ ${board.name}`),
    el('div', { class: 'form-row', style: 'margin-top:8px' }, [
      el('input', { id: 'kanbanNewCardTitle', placeholder: '新卡片標題', style: 'flex:1' }),
      hasCircle ? el('select', { id: 'kanbanNewCardAssignee' }, [
        el('option', { value: '' }, '指派給...(選填)'),
        ...circleMembers.map((m) => el('option', { value: m.id }, m.label)),
      ]) : null,
      el('button', { class: 'btn btn-primary', onclick: () => addKanbanCard(board.id) }, '新增到待辦'),
    ].filter(Boolean)),
  ]));

  KANBAN_COLUMNS.forEach((col, colIdx) => {
    const cards = board.columns[col.key] || [];
    c.appendChild(el('div', { class: 'card', style: 'margin-top:10px' }, [
      el('h3', {}, `${col.label} (${cards.length})`),
      cards.length
        ? el('div', {}, cards.map((card) => kanbanCardEl(board.id, card, colIdx, circleMembers)))
        : el('div', { class: 'empty-state' }, '這一欄目前沒有卡片'),
    ]));
  });

  if (hasCircle) {
    const fairnessCard = el('div', { class: 'card', style: 'margin-top:10px' }, [
      el('h3', {}, '⚖️ 任務公平性'),
      el('div', { id: 'kanbanFairnessArea' }, el('div', { class: 'empty-state' }, '載入中...')),
    ]);
    c.appendChild(fairnessCard);
    loadKanbanFairness(board.id);
  }
}

let kanbanCardEditingId = null;
function kanbanCardEl(boardId, card, colIdx, circleMembers) {
  const canMoveLeft = colIdx > 0;
  const canMoveRight = colIdx < KANBAN_COLUMNS.length - 1;
  // v0.77：編輯改成卡片「原地展開」成一個小表單，不再跳 prompt() 問標題/備註。
  if (kanbanCardEditingId === card.id) {
    return el('div', { class: 'card', style: 'margin-bottom:8px;background:var(--surface-2)' }, [
      el('input', { id: `kanbanEditTitle-${card.id}`, value: card.title, style: 'margin-bottom:6px' }),
      el('textarea', { id: `kanbanEditNote-${card.id}`, rows: 2, style: 'width:100%;resize:vertical;margin-bottom:6px' }, card.note || ''),
      el('div', { style: 'display:flex;gap:10px' }, [
        el('button', { class: 'btn btn-primary', style: 'padding:6px 16px;font-size:12.5px', onclick: () => saveKanbanCard(boardId, card.id) }, '儲存'),
        el('button', { class: 'btn btn-ghost', style: 'padding:6px 16px;font-size:12.5px', onclick: () => { kanbanCardEditingId = null; renderKanban(); } }, '取消'),
      ]),
    ]);
  }
  return el('div', { class: 'card', style: 'margin-bottom:8px;background:var(--surface-2)' }, [
    el('div', { style: 'font-weight:700' }, card.title),
    card.note ? el('div', { class: 'hint', style: 'margin-top:4px' }, card.note) : null,
    el('div', { style: 'display:flex;gap:8px;margin-top:8px;align-items:center;flex-wrap:wrap' }, [
      el('button', {
        class: 'dash-section-action', disabled: !canMoveLeft,
        onclick: () => moveKanbanCard(boardId, card.id, KANBAN_COLUMNS[colIdx - 1] ? KANBAN_COLUMNS[colIdx - 1].key : null),
      }, '◀'),
      el('button', {
        class: 'dash-section-action', disabled: !canMoveRight,
        onclick: () => moveKanbanCard(boardId, card.id, KANBAN_COLUMNS[colIdx + 1] ? KANBAN_COLUMNS[colIdx + 1].key : null),
      }, '▶'),
      el('button', { class: 'dash-section-action', onclick: () => { kanbanCardEditingId = card.id; renderKanban(); } }, '編輯'),
      el('button', { class: 'dash-section-action', onclick: () => deleteKanbanCard(boardId, card.id) }, '刪除'),
    ]),
    // v0.77：指派原本跟其他按鈕擠在同一行 (要輸入數字對照名單)，改成獨立一行、用虛線分開、
    // 選了就直接存 (跟財務目標連結同一套「選了就存」模式)，只有已連結家人/伴侶才顯示。
    (circleMembers && circleMembers.length > 1) ? el('div', { class: 'kanban-assign-row' }, [
      el('span', { class: 'hint', style: 'margin:0' }, '👤 指派'),
      el('select', {
        onchange: (ev) => saveKanbanAssignee(boardId, card.id, ev.target.value || null),
      }, [
        el('option', { value: '' }, '尚未指派'),
        ...circleMembers.map((m) => el('option', { value: String(m.id), selected: card.assignee_user_id === m.id }, m.label)),
      ]),
    ]) : null,
  ].filter(Boolean));
}

async function saveKanbanAssignee(boardId, cardId, assigneeUserId) {
  try {
    await api(`/kanban-boards/${boardId}/cards/${cardId}`, { method: 'PUT', body: { assigneeUserId } });
    showToast('已更新指派');
    renderKanban();
  } catch (e) { showToast('更新失敗：' + e.message); }
}

// v0.68：#9 家庭看板任務公平性統計
async function loadKanbanFairness(boardId) {
  const area = $('#kanbanFairnessArea');
  if (!area) return;
  try {
    const r = await api(`/kanban-boards/${boardId}/fairness`);
    area.innerHTML = '';
    if (!r.stats.length) { area.appendChild(el('div', { class: 'empty-state' }, '目前還沒有卡片指派給任何人')); return; }
    r.stats.forEach((s) => {
      area.appendChild(el('div', { class: 'mood-signal-item' }, `${s.label}：${s.total} 張（完成 ${s.done} 張）· 佔已指派卡片的 ${s.sharePct}%`));
    });
    if (r.unassignedCount) area.appendChild(el('p', { class: 'hint', style: 'margin-top:4px' }, `另外還有 ${r.unassignedCount} 張卡片沒有指派給任何人`));
  } catch (e) { area.innerHTML = ''; area.appendChild(el('div', { class: 'empty-state' }, '統計資料暫時無法取得')); }
}

async function addKanbanCard(boardId) {
  const title = $('#kanbanNewCardTitle').value.trim();
  if (!title) { showToast('請輸入卡片標題'); return; }
  const assigneeSel = $('#kanbanNewCardAssignee');
  const assigneeUserId = assigneeSel && assigneeSel.value ? Number(assigneeSel.value) : undefined;
  try {
    await api(`/kanban-boards/${boardId}/cards`, { method: 'POST', body: { title, column: 'todo', assigneeUserId } });
    showToast('已新增');
    renderKanban();
  } catch (e) { showToast('新增失敗：' + e.message); }
}

async function moveKanbanCard(boardId, cardId, targetColumn) {
  if (!targetColumn) return;
  try {
    await api(`/kanban-boards/${boardId}/cards/${cardId}/move`, { method: 'POST', body: { column: targetColumn } });
    renderKanban();
  } catch (e) { showToast('移動失敗：' + e.message); }
}

async function saveKanbanCard(boardId, cardId) {
  const titleInput = $(`#kanbanEditTitle-${cardId}`);
  const noteInput = $(`#kanbanEditNote-${cardId}`);
  const title = titleInput.value.trim();
  if (!title) { showToast('標題不能空白'); return; }
  try {
    await api(`/kanban-boards/${boardId}/cards/${cardId}`, { method: 'PUT', body: { title, note: noteInput.value } });
    kanbanCardEditingId = null;
    showToast('已更新');
    renderKanban();
  } catch (e) { showToast('更新失敗：' + e.message); }
}

async function deleteKanbanCard(boardId, cardId) {
  if (!confirm('確定要刪除這張卡片嗎？')) return;
  try {
    await api(`/kanban-boards/${boardId}/cards/${cardId}`, { method: 'DELETE' });
    showToast('已刪除');
    renderKanban();
  } catch (e) { showToast('刪除失敗：' + e.message); }
}

// ===================== 固定行程模板 (v0.51) =====================
let routineTemplatesView = null; // null = 清單, 'new' = 新增範本, 數字 = 該範本的詳細畫面
let routineNewItemCount = 1;
let routineTemplatePartnerLinks = [];
let routineTemplateSplitGroups = [];

function renderRoutineTemplates() {
  const c = $('#tab-routineTemplates');
  c.innerHTML = '';
  if (routineTemplatesView === 'new') {
    renderRoutineTemplateNewForm(c);
    return;
  }
  if (typeof routineTemplatesView === 'number') {
    renderRoutineTemplateDetail(c, routineTemplatesView);
    return;
  }
  renderRoutineTemplatesList(c);
}

function renderRoutineTemplatesList(c) {
  c.appendChild(el('div', { class: 'card', style: 'display:flex;justify-content:space-between;align-items:center' }, [
    el('h3', { style: 'margin:0' }, '🗓️ 固定行程模板'),
    el('button', { class: 'btn btn-primary', onclick: () => { routineTemplatesView = 'new'; routineNewItemCount = 1; renderRoutineTemplates(); } }, '➕ 新增範本'),
  ]));
  c.appendChild(el('div', { id: 'routineTemplatesList' }, el('div', { class: 'empty-state' }, '載入中...')));
  loadRoutineTemplatesList();
}

async function loadRoutineTemplatesList() {
  const listEl = $('#routineTemplatesList');
  if (!listEl) return;
  try {
    const templates = await api('/routine-templates');
    listEl.innerHTML = '';
    if (!templates.length) {
      listEl.appendChild(el('div', { class: 'empty-state' }, '還沒有任何範本，上面新增一個，例如「出差打包清單」或「新專案啟動」！'));
      return;
    }
    templates.forEach((t) => {
      listEl.appendChild(el('div', {
        class: 'card', style: 'margin-bottom:10px;cursor:pointer',
        onclick: () => { routineTemplatesView = t.id; renderRoutineTemplates(); },
      }, [
        el('div', { style: 'font-weight:700' }, t.name),
        el('div', { class: 'hint', style: 'margin-top:4px' }, [
          `${t.itemCount} 個項目`,
          t.hasSplitGroup ? ' · 🧾 已連結分帳群組' : '',
        ].join('')),
        t.shared ? el('div', { class: 'hint', style: 'margin-top:4px;color:var(--accent)' }, `🤝 跟 ${t.partnerLabel} 共同建立`) : null,
      ].filter(Boolean)));
    });
  } catch (e) {
    listEl.innerHTML = '';
    listEl.appendChild(el('div', { class: 'empty-state' }, '範本暫時無法取得'));
  }
}

async function loadRoutineTemplateFormOptions() {
  try {
    const { links } = await api('/partner-link');
    routineTemplatePartnerLinks = links || [];
  } catch (e) { routineTemplatePartnerLinks = []; }
  try {
    routineTemplateSplitGroups = await api('/split-groups');
  } catch (e) { routineTemplateSplitGroups = []; }
  const scopeRow = $('#routineNewScopeRow');
  if (scopeRow && routineTemplatePartnerLinks.length) {
    scopeRow.innerHTML = '';
    scopeRow.appendChild(el('label', { class: 'hint', style: 'display:block;margin-bottom:4px' }, '這個範本是：'));
    scopeRow.appendChild(el('select', { id: 'routineNewScopeInput' }, [
      el('option', { value: '' }, '只有我自己'),
      ...routineTemplatePartnerLinks.map((l) => el('option', { value: String(l.linkId) }, `跟 ${l.name} 共同建立`)),
    ]));
  }
  const splitRow = $('#routineNewSplitGroupRow');
  if (splitRow && routineTemplateSplitGroups.length) {
    splitRow.innerHTML = '';
    splitRow.appendChild(el('label', { class: 'hint', style: 'display:block;margin-bottom:4px' }, '連結分帳群組 (選填，牽涉到花費的範本可以直接連過去)：'));
    splitRow.appendChild(el('select', { id: 'routineNewSplitGroupInput' }, [
      el('option', { value: '' }, '不連結'),
      ...routineTemplateSplitGroups.map((g) => el('option', { value: String(g.id) }, g.name)),
    ]));
  }
}

// v0.53：每個大項底下可以掛「小項目」，各自有自己的優先度/提醒時間，用巢狀的資料結構追蹤
// 目前有幾個大項、每個大項底下又有幾個小項目——跟揪團分帳/固定行程模板原本就有的教訓一樣，
// 「+再加一個」一律用直接插入新 row 的方式，不整個表單重新 render，避免清空已輸入的內容。
let routineNewItemSubCount = {}; // { [itemIdx]: 目前這個大項底下有幾個小項目 row }

function routineSubItemRow(itemIdx, subIdx) {
  return el('div', { style: 'display:flex;flex-direction:column;gap:6px;margin-top:6px' }, [
    el('input', { id: `routineNewSubTitle${itemIdx}_${subIdx}`, placeholder: '小項目標題，例如：帶牙刷' }),
    el('div', { style: 'display:flex;gap:6px;align-items:center' }, [
      prioritySliderEl(`routineNewSubPriority${itemIdx}_${subIdx}`, 'medium', { compact: true }),
      el('input', { id: `routineNewSubRemindTime${itemIdx}_${subIdx}`, type: 'time', style: 'max-width:110px;flex:0 0 auto', title: '這個小項目自己的提醒時間 (可留白)' }),
    ]),
  ]);
}

function addRoutineSubItemRow(itemIdx) {
  const container = $(`#routineNewSubRows${itemIdx}`);
  if (!container) return;
  const subIdx = routineNewItemSubCount[itemIdx] || 0;
  routineNewItemSubCount[itemIdx] = subIdx + 1;
  container.appendChild(routineSubItemRow(itemIdx, subIdx));
}

// 「統一設時間」：把目前這個大項底下所有已經存在的小項目提醒時間，一次填成同一個值；
// 填完之後每個小項目的時間欄位還是各自獨立的輸入框，使用者要再改成不同時間也完全沒問題，
// 這只是省得一個一個點的批次填入捷徑，不是綁死彼此連動的設定。
function applyRoutineBulkSubTime(itemIdx) {
  const bulkInput = $(`#routineNewBulkTime${itemIdx}`);
  const time = bulkInput ? bulkInput.value : '';
  if (!time) { showToast('請先選一個時間'); return; }
  const count = routineNewItemSubCount[itemIdx] || 0;
  for (let s = 0; s < count; s++) {
    const input = $(`#routineNewSubRemindTime${itemIdx}_${s}`);
    if (input) input.value = time;
  }
  showToast('已套用到全部小項目，還是可以個別再調整');
}

function toggleRoutineItemRemind(itemIdx) {
  const checkbox = $(`#routineNewItemRemindToggle${itemIdx}`);
  const timeInput = $(`#routineNewItemRemindTime${itemIdx}`);
  if (timeInput) timeInput.style.display = checkbox && checkbox.checked ? '' : 'none';
}

function routineItemBlock(idx) {
  routineNewItemSubCount[idx] = 0;
  return el('div', { class: 'card', style: 'margin-top:10px;background:var(--surface-2)' }, [
    el('div', { class: 'hint' }, `大項 ${idx + 1}`),
    el('input', { id: `routineNewItemTitle${idx}`, placeholder: '大項標題，例如：出門', style: 'margin-top:4px' }),
    el('div', { class: 'form-row', style: 'margin-top:6px' }, [
      el('input', { id: `routineNewItemOffset${idx}`, type: 'number', step: '1', placeholder: '第幾天 (0=當天)', value: '0', style: 'max-width:140px' }),
      el('input', { id: `routineNewItemNote${idx}`, placeholder: '備註 (可留白)', style: 'flex:1' }),
    ]),
    el('label', { style: 'display:flex;align-items:center;gap:6px;margin-top:8px;cursor:pointer' }, [
      el('input', { id: `routineNewItemRemindToggle${idx}`, type: 'checkbox', onchange: () => toggleRoutineItemRemind(idx) }),
      el('span', { class: 'hint', style: 'margin:0' }, '這個大項本身要精準提醒'),
    ]),
    el('input', { id: `routineNewItemRemindTime${idx}`, type: 'time', style: 'display:none;margin-top:4px;max-width:140px' }),
    el('div', { class: 'hint', style: 'margin-top:10px' }, '小項目 (可選填，例如「帶牙刷」「帶牙膏」，各自可以設定優先度跟提醒時間)'),
    el('div', { id: `routineNewSubRows${idx}` }),
    el('div', { style: 'display:flex;gap:8px;flex-wrap:wrap;margin-top:6px;align-items:center' }, [
      el('button', { class: 'dash-section-action', onclick: () => addRoutineSubItemRow(idx) }, '+ 再加一個小項目'),
      el('input', { id: `routineNewBulkTime${idx}`, type: 'time', style: 'max-width:110px' }),
      el('button', { class: 'dash-section-action', onclick: () => applyRoutineBulkSubTime(idx) }, '統一設定小項目提醒時間'),
    ]),
  ]);
}

function renderRoutineTemplateNewForm(c) {
  const itemBlocks = [];
  for (let i = 0; i < routineNewItemCount; i++) {
    itemBlocks.push(routineItemBlock(i));
  }
  c.appendChild(el('div', { class: 'card' }, [
    el('button', { class: 'btn btn-ghost', onclick: () => { routineTemplatesView = null; renderRoutineTemplates(); } }, '← 返回清單'),
    el('h3', {}, '➕ 新增範本'),
    el('input', { id: 'routineNewTemplateName', placeholder: '範本名稱，例如：出差打包清單' }),
    el('div', { id: 'routineNewScopeRow', style: 'margin-top:8px' }),
    el('div', { id: 'routineNewSplitGroupRow', style: 'margin-top:8px' }),
    el('div', { class: 'hint', style: 'margin-top:10px' }, '大項清單 (「第幾天」是相對套用日期的天數，0 = 當天)'),
    el('div', { id: 'routineNewItemRows' }, itemBlocks),
    el('button', {
      class: 'dash-section-action', style: 'margin-top:10px',
      onclick: () => {
        const container = $('#routineNewItemRows');
        const idx = routineNewItemCount;
        routineNewItemCount += 1;
        container.appendChild(routineItemBlock(idx));
      },
    }, '+ 再加一個大項'),
    el('div', { style: 'margin-top:12px' }, [
      el('button', { class: 'btn btn-primary', onclick: createRoutineTemplate }, '建立範本'),
    ]),
  ]));
  loadRoutineTemplateFormOptions();
}

async function createRoutineTemplate() {
  const name = $('#routineNewTemplateName').value.trim();
  const scopeInput = $('#routineNewScopeInput');
  const linkId = scopeInput && scopeInput.value ? scopeInput.value : null;
  const splitGroupInput = $('#routineNewSplitGroupInput');
  const splitGroupId = splitGroupInput && splitGroupInput.value ? splitGroupInput.value : null;
  const items = [];
  for (let i = 0; i < routineNewItemCount; i++) {
    const titleInput = $(`#routineNewItemTitle${i}`);
    if (!titleInput) continue;
    const title = titleInput.value.trim();
    if (!title) continue;
    const offsetInput = $(`#routineNewItemOffset${i}`);
    const noteInput = $(`#routineNewItemNote${i}`);
    const remindToggle = $(`#routineNewItemRemindToggle${i}`);
    const remindTimeInput = $(`#routineNewItemRemindTime${i}`);
    const remindTime = remindToggle && remindToggle.checked ? (remindTimeInput.value || null) : null;

    const subItems = [];
    const subCount = routineNewItemSubCount[i] || 0;
    for (let s = 0; s < subCount; s++) {
      const subTitleInput = $(`#routineNewSubTitle${i}_${s}`);
      if (!subTitleInput) continue;
      const subTitle = subTitleInput.value.trim();
      if (!subTitle) continue;
      const subRemindInput = $(`#routineNewSubRemindTime${i}_${s}`);
      subItems.push({
        title: subTitle,
        priority: prioritySliderGet(`routineNewSubPriority${i}_${s}`),
        remindTime: (subRemindInput && subRemindInput.value) || null,
      });
    }

    items.push({ title, dayOffset: Number(offsetInput.value) || 0, note: noteInput.value.trim(), remindTime, subItems });
  }
  if (!name) { showToast('請輸入範本名稱'); return; }
  if (!items.length) { showToast('至少需要一個大項'); return; }
  try {
    await api('/routine-templates', { method: 'POST', body: { name, items, linkId, splitGroupId } });
    showToast(linkId ? '共同範本已建立' : '已建立範本');
    routineTemplatesView = null;
    renderRoutineTemplates();
  } catch (e) { showToast('建立失敗：' + e.message); }
}

async function deleteRoutineTemplate(templateId) {
  if (!confirm('確定要刪除這個範本嗎？')) return;
  try {
    await api(`/routine-templates/${templateId}`, { method: 'DELETE' });
    showToast('已刪除');
    routineTemplatesView = null;
    renderRoutineTemplates();
  } catch (e) { showToast('刪除失敗：' + e.message); }
}

let routineApplyOpenId = null;

async function renderRoutineTemplateDetail(c, templateId) {
  let template;
  try {
    template = await api(`/routine-templates/${templateId}`);
  } catch (e) {
    showToast('範本載入失敗：' + e.message);
    routineTemplatesView = null;
    renderRoutineTemplates();
    return;
  }
  c.innerHTML = '';
  c.appendChild(el('div', { class: 'card' }, [
    el('div', { style: 'display:flex;justify-content:space-between;align-items:center' }, [
      el('button', { class: 'btn btn-ghost', onclick: () => { routineTemplatesView = null; renderRoutineTemplates(); } }, '← 返回清單'),
      el('button', { class: 'btn btn-ghost', onclick: () => deleteRoutineTemplate(template.id) }, '🗑 刪除範本'),
    ]),
    el('h3', {}, `🗓️ ${template.name}`),
    template.shared ? el('div', { class: 'hint', style: 'color:var(--accent)' }, `🤝 跟 ${template.partnerLabel} 共同建立 · 由${template.createdByMe ? '我' : template.creatorLabel}新增`) : null,
    routineApplyOpenId === template.id
      ? el('div', { class: 'form-row', style: 'margin-top:8px;align-items:center' }, [
          el('input', { id: `routineApplyDate-${template.id}`, type: 'date', style: 'font-size:13px' }),
          el('span', { class: 'hint', style: 'margin:0' }, '留空表示今天'),
          el('button', { class: 'btn btn-primary', style: 'font-size:12px', onclick: () => submitApplyRoutineTemplate(template.id, c) }, '確定套用'),
          el('button', { class: 'btn btn-ghost', style: 'font-size:12px', onclick: () => { routineApplyOpenId = null; renderRoutineTemplateDetail(c, template.id); } }, '取消'),
        ])
      : el('button', { class: 'btn btn-primary', style: 'margin-top:8px', onclick: () => { routineApplyOpenId = template.id; renderRoutineTemplateDetail(c, template.id); } }, '✅ 一鍵套用成待辦事項'),
  ].filter(Boolean)));

  c.appendChild(el('div', { class: 'card', style: 'margin-top:12px' }, [
    el('h3', { style: 'margin:0 0 8px' }, '🧾 分帳群組'),
    template.splitGroup
      ? el('div', {}, [
          el('div', {}, [
            el('span', { style: 'font-weight:700' }, template.splitGroup.name),
            el('span', { class: 'hint' }, ` · ${template.splitGroup.memberCount} 人 · 目前結算 ${template.splitGroup.totalAmount}`),
          ]),
          el('div', { style: 'display:flex;gap:8px;margin-top:8px;flex-wrap:wrap' }, [
            el('button', { class: 'dash-section-action', onclick: () => { splitGroupsView = template.splitGroup.id; switchTab('splitGroups'); } }, '前往分帳群組'),
            el('button', { class: 'dash-section-action', onclick: () => unlinkRoutineTemplateSplitGroup(template.id) }, '取消連結'),
          ]),
        ])
      : el('div', {}, [
          el('div', { class: 'hint' }, '這個範本還沒連結分帳群組。牽涉到花費的範本 (例如出差、旅行) 可以連結一個，之後套用時方便直接跳去記帳。'),
          el('div', { id: 'routineDetailSplitGroupLinkRow', style: 'margin-top:8px' }),
        ]),
  ]));
  if (!template.splitGroup) loadRoutineTemplateDetailSplitGroupOptions(template.id);

  c.appendChild(el('div', { style: 'margin-top:12px' }, [
    el('h3', { style: 'margin:0 0 10px' }, `📋 大項清單 (${template.items.length})`),
    ...template.items.map((item) => routineItemDetailCard(item)),
  ]));
}

async function loadRoutineTemplateDetailSplitGroupOptions(templateId) {
  const row = $('#routineDetailSplitGroupLinkRow');
  if (!row) return;
  try {
    const groups = await api('/split-groups');
    if (!groups.length) return;
    row.innerHTML = '';
    row.appendChild(el('select', { id: 'routineDetailSplitGroupInput' }, [
      el('option', { value: '' }, '選擇分帳群組...'),
      ...groups.map((g) => el('option', { value: String(g.id) }, g.name)),
    ]));
    row.appendChild(el('button', {
      class: 'dash-section-action', style: 'margin-left:8px',
      onclick: () => linkRoutineTemplateSplitGroup(templateId),
    }, '連結'));
  } catch (e) { /* 抓不到就不顯示，不影響其他功能 */ }
}

async function linkRoutineTemplateSplitGroup(templateId) {
  const input = $('#routineDetailSplitGroupInput');
  const splitGroupId = input && input.value ? input.value : null;
  if (!splitGroupId) { showToast('請先選一個分帳群組'); return; }
  try {
    await api(`/routine-templates/${templateId}/split-group`, { method: 'PUT', body: { splitGroupId } });
    showToast('已連結分帳群組');
    renderRoutineTemplates();
  } catch (e) { showToast('連結失敗：' + e.message); }
}

async function unlinkRoutineTemplateSplitGroup(templateId) {
  try {
    await api(`/routine-templates/${templateId}/split-group`, { method: 'PUT', body: { splitGroupId: null } });
    showToast('已取消連結');
    renderRoutineTemplates();
  } catch (e) { showToast('取消失敗：' + e.message); }
}

function routineDayOffsetLabel(dayOffset) {
  return dayOffset === 0 ? '當天' : dayOffset > 0 ? `第 ${dayOffset + 1} 天` : `提前 ${Math.abs(dayOffset)} 天`;
}

// 每個大項自成一張卡片、跟卡片之間留足夠間距，小項目再往內縮一層並保留自己的留白，
// 資訊雖然比 v0.51 多了不少 (備註/提醒/小項目/優先度)，但版面上還是希望維持舒適的空間感，
// 不會擠成一團看不清楚。
function routineItemDetailCard(item) {
  return el('div', { class: 'card', style: 'margin-bottom:14px' }, [
    el('div', { style: 'display:flex;justify-content:space-between;align-items:flex-start;gap:10px' }, [
      el('div', { style: 'font-weight:700;font-size:15px' }, item.title),
      el('span', { class: 'hint', style: 'white-space:nowrap' }, routineDayOffsetLabel(item.day_offset)),
    ]),
    item.note ? el('div', { class: 'hint', style: 'margin-top:6px' }, `📝 ${item.note}`) : null,
    item.remind_time ? el('div', { class: 'hint', style: 'margin-top:6px;color:var(--accent)' }, `🔔 這個大項會在當天 ${item.remind_time} 提醒`) : null,
    item.subItems && item.subItems.length
      ? el('div', { style: 'margin-top:12px;padding-top:10px;border-top:1px solid var(--border)' }, [
          el('div', { class: 'hint', style: 'margin-bottom:8px' }, `小項目 (${item.subItems.length})`),
          ...item.subItems.map((s) =>
            el('div', { style: 'display:flex;align-items:center;gap:8px;padding:5px 0 5px 14px' }, [
              el('span', { style: 'flex:1' }, s.title),
              el('span', { class: 'hint' }, PRIORITY_LABEL[s.priority] || PRIORITY_LABEL.medium),
              s.remind_time ? el('span', { class: 'hint', style: 'color:var(--accent)' }, `🔔 ${s.remind_time}`) : null,
            ].filter(Boolean))
          ),
        ])
      : null,
  ].filter(Boolean));
}

async function submitApplyRoutineTemplate(templateId, c) {
  const input = $(`#routineApplyDate-${templateId}`);
  const trimmed = input ? input.value.trim() : '';
  try {
    const result = await api(`/routine-templates/${templateId}/apply`, { method: 'POST', body: trimmed ? { startDate: trimmed } : {} });
    routineApplyOpenId = null;
    showToast(`已建立 ${result.createdCount} 筆待辦事項`);
    if (c) renderRoutineTemplateDetail(c, templateId);
  } catch (e) { showToast('套用失敗：' + e.message); }
}

// v0.81：一鍵記錄「她月經來了」。遲到狀態下最需要的就是快速把實際開始日記進去讓推算
// 重新校正，不該還要捲去下面的表單手動挑日期。點一下先原地變成確認列 (避免誤觸)，
// 確認後以「今天」為開始日記錄一筆。
function quickLogPartnerPeriodBtn() {
  const wrap = el('div', { style: 'margin-top:10px' });
  const btn = el('button', { class: 'btn btn-primary', style: 'font-size:13px' }, '🌷 她月經來了（記錄今天）');
  btn.onclick = () => {
    wrap.innerHTML = '';
    wrap.appendChild(el('div', { class: 'form-row', style: 'align-items:center' }, [
      el('span', { class: 'hint', style: 'margin:0' }, `以今天（${todayStr()}）為開始日記錄一筆？`),
      el('button', { class: 'btn btn-primary', style: 'font-size:12px', onclick: async () => {
        try {
          await api('/mood/cycle', { method: 'POST', body: { periodStartDate: todayStr(), trackingFor: 'partner' } });
          showToast('已記錄，推算已重新校正 🌷');
          loadPartnerStatus();
          loadPartnerLog();
        } catch (e) { showToast('記錄失敗：' + e.message); }
      } }, '確定記錄'),
      el('button', { class: 'btn btn-ghost', style: 'font-size:12px', onclick: () => { wrap.innerHTML = ''; wrap.appendChild(btn); } }, '取消'),
    ]));
  };
  wrap.appendChild(btn);
  return wrap;
}

async function loadPartnerStatus() {
  const box = $('#partnerStatusBody');
  if (!box) return;
  try {
    const status = await api('/mood/cycle/partner-status');
    box.innerHTML = '';
    if (!status.hasData) {
      box.appendChild(el('div', { class: 'empty-state' }, '還沒有幫她記錄過經期，記一次開始日就能開始估算階段。'));
      return;
    }
    // ---- v0.81：太久沒記錄，推算暫停 ----
    if (status.isStale) {
      box.appendChild(el('p', {}, `上次幫她記錄的經期開始日已經是 ${status.daysSinceLastPeriod} 天前，超出可以合理推算的範圍，估算先暫停。`));
      box.appendChild(el('p', { class: 'hint', style: 'margin-top:4px' }, '比較可能是這段時間忘了記。用下面的「記一筆」補上最近一次的開始日，推算就會重新開始。'));
      box.appendChild(quickLogPartnerPeriodBtn());
      return;
    }
    // ---- v0.81：遲到狀態——以前會錯誤地繞回去顯示「月經期」，現在誠實顯示遲到幾天，
    // 並且給男方分層的具體建議 (她這時通常比你更焦慮，重點是別再加壓) ----
    if (status.isLate) {
      box.appendChild(el('div', { style: 'display:flex;align-items:center;gap:10px;flex-wrap:wrap' }, [
        el('span', { class: 'badge', style: 'background:color-mix(in srgb, var(--warning) 18%, transparent);color:var(--warning)' }, `比預估晚了 ${status.daysLate} 天`),
        el('span', { class: 'hint', style: 'margin:0' }, `原本預估 ${status.predictedNextDate}（前後約 ±${status.rangeDays} 天）`),
      ]));
      box.appendChild(partnerTipBlockEl(partnerLateTip(status.daysLate)));
      box.appendChild(el('p', { class: 'hint', style: 'margin-top:8px' }, '📍 這個週期實際比預估長，排卵日跟易孕期的推算也跟著失準了，等記錄到新的開始日之後會重新校正。'));
      const lateSymptomHint = symptomPatternHintEl(status.symptomPatterns);
      if (lateSymptomHint) box.appendChild(lateSymptomHint);
      box.appendChild(quickLogPartnerPeriodBtn());
      return;
    }
    // ---- 正常範圍 ----
    const phaseInfo = PARTNER_PHASE_TIPS[status.phase] || { label: status.phase, tip: '' };
    box.appendChild(el('div', { style: 'display:flex;align-items:center;gap:10px;flex-wrap:wrap' }, [
      el('span', { class: 'badge badge-neutral' }, `目前估計：${phaseInfo.label}`),
      status.isPmsWindow ? el('span', { class: 'badge', style: 'background:color-mix(in srgb, var(--warning) 18%, transparent);color:var(--warning)' }, '經前觀察窗') : null,
      status.isFertileWindow ? el('span', { class: 'badge', style: 'background:color-mix(in srgb, var(--series-magenta) 18%, transparent);color:var(--series-magenta)' }, '易孕期') : null,
      el('span', { class: 'hint', style: 'margin:0' }, `距離下次月經約 ${status.daysUntilNextPeriod} 天（預估 ${status.nextPeriodDate}，前後約 ±${status.rangeDays} 天）`),
    ]));
    if (status.regularity && CYCLE_REGULARITY_LABEL[status.regularity]) {
      box.appendChild(el('p', { class: 'hint', style: 'margin-top:6px' }, `她的週期規律度：${CYCLE_REGULARITY_LABEL[status.regularity]}`));
    }
    // v0.83：完全被動的認可——不需要任何人多做什麼，純粹從已經記錄的資料算出來上一段
    // 週期比平常長了不少，只在這次月經剛開始的頭幾天顯示。
    // v0.84：原本結尾有「那陣子的等待不容易」這句——這是在替他斷言感受，猜對猜錯都一樣是
    // 猜。改成只講算出來的事實 (長了幾天、新週期開始了)，不附加任何情緒解讀，語氣放輕。
    if (status.justEndedLongCycle) {
      box.appendChild(el('div', { class: 'coping-note-item rb-neutral', style: 'margin-top:8px' }, [
        el('div', { class: 'content' }, `上次週期比平常長了約 ${status.justEndedLongCycleDays} 天，新的週期已經開始了。`),
      ]));
    }
    if (status.isPmsWindow) {
      box.appendChild(el('p', { style: 'margin-top:10px;line-height:1.7' }, PARTNER_PMS_TIP));
      box.appendChild(partnerTipBlockEl({ tip: '', action: phaseInfo.action, avoid: phaseInfo.avoid }));
    } else {
      box.appendChild(partnerTipBlockEl(phaseInfo));
    }
    const symptomHint = symptomPatternHintEl(status.symptomPatterns);
    if (symptomHint) box.appendChild(symptomHint);
    if (status.fertileWindowStart && status.fertileWindowEnd) {
      box.appendChild(el('p', { class: 'hint', style: 'margin-top:6px' }, `📍 這個週期估算的易孕期：${status.fertileWindowStart} ～ ${status.fertileWindowEnd}（排卵日約 ${status.ovulationDateEstimate}，概略估算僅供參考，不是精準避孕/助孕依據）`));
    }
    // 快來的前幾天也先把一鍵記錄放出來，來了當下點一下就好，不用捲去下面的表單
    if (status.daysUntilNextPeriod !== undefined && status.daysUntilNextPeriod <= 3) {
      box.appendChild(quickLogPartnerPeriodBtn());
    }
    if (!status.hasEnoughDataForAvg) {
      box.appendChild(el('p', { class: 'hint', style: 'margin-top:6px' }, '目前用預設 28 天週期估算，多記錄幾次會愈來愈準。'));
    }
  } catch (e) {
    box.innerHTML = '';
    box.appendChild(el('div', { class: 'empty-state' }, '狀態資料暫時無法取得'));
  }
}

async function addPartnerCycleEntry() {
  const date = $('#partnerCycleDate').value;
  if (!date) { showToast('請選擇日期'); return; }
  const endDate = $('#partnerCycleEndDate') ? $('#partnerCycleEndDate').value : '';
  const note = $('#partnerCycleNote').value.trim();
  const symptoms = [...partnerSelectedSymptoms, note].filter(Boolean); // 勾選的症狀標籤 + 自己打的備註合併成一個陣列，後端本來就支援陣列 (逗號分隔存進同一欄位)
  try {
    await api('/mood/cycle', { method: 'POST', body: { periodStartDate: date, periodEndDate: endDate || null, trackingFor: 'partner', symptoms: symptoms.length ? symptoms : null } });
    $('#partnerCycleNote').value = '';
    if ($('#partnerCycleEndDate')) $('#partnerCycleEndDate').value = '';
    partnerSelectedSymptoms.clear();
    document.querySelectorAll('#partnerSymptomRow .mood-tag-chip').forEach((b) => b.classList.remove('selected'));
    showToast('已記錄');
    loadPartnerStatus();
    loadPartnerLog();
  } catch (e) { showToast('儲存失敗：' + e.message); }
}

async function loadPartnerLog() {
  const area = $('#partnerLogArea');
  if (!area) return;
  try {
    const rows = (await api('/mood/cycle')).filter((r) => r.tracking_for === 'partner');
    area.innerHTML = '';
    if (!rows.length) { area.appendChild(el('div', { class: 'empty-state' }, '還沒有紀錄')); return; }
    rows.forEach((r) => {
      area.appendChild(el('div', { class: 'coping-note-item' }, [
        el('div', { class: 'content' }, [
          el('div', { style: 'font-weight:700' }, r.period_start_date),
          r.symptoms ? el('div', { class: 'hint', style: 'margin:2px 0 0' }, r.symptoms) : null,
        ]),
        el('button', { class: 'del-btn', onclick: () => deletePartnerCycleEntry(r.id) }, '✕'),
      ]));
    });
  } catch (e) {
    area.innerHTML = '';
    area.appendChild(el('div', { class: 'empty-state' }, '日誌暫時無法取得'));
  }
}
async function deletePartnerCycleEntry(id) {
  try {
    await api(`/mood/cycle/${id}`, { method: 'DELETE' });
    loadPartnerStatus();
    loadPartnerLog();
  } catch (e) { showToast('刪除失敗：' + e.message); }
}

// ===================== 個人化設定 =====================
// v0.68：#10 通知有效性回饋迴圈
const NOTIFICATION_TYPE_LABEL = {
  'bill-amount-anomaly': '🧾 帳單金額異常', 'task-procrastination': '📌 任務拖延提醒',
  'mood-trend-mild': '💗 心情趨勢 (輕度)', 'mood-trend-concern': '💗 心情趨勢 (需留意)',
  'mood-social-checkin': '🫂 心情+聯絡提醒', 'relationship-checkin': '👥 該聯絡的人',
  'emotional-spending-pattern': '💸 情緒化消費', 'other': '其他',
};
async function loadNotificationEffectiveness() {
  const area = $('#notificationEffectivenessArea');
  if (!area) return;
  try {
    const r = await api('/push/effectiveness');
    area.innerHTML = '';
    if (!r.hasEnoughData) { area.appendChild(el('div', { class: 'empty-state' }, r.note || '目前還沒有足夠的推播紀錄可以分析')); return; }
    r.results.forEach((item) => {
      area.appendChild(el('div', { class: 'mood-signal-item' }, [
        `${NOTIFICATION_TYPE_LABEL[item.type] || item.type}：送出 ${item.sendCount} 次，${item.effectivenessRate}% 在 24 小時內有對應行動`,
        // v0.70：自動降頻——累積夠多次、卻完全沒有對應行動的類型，會自動降低被推播出去的
        // 優先度，這裡加個小標籤讓使用者知道「不是提醒消失了，只是系統判斷這對你沒什麼用」。
        item.autoThrottled ? el('span', { style: 'margin-left:6px;font-size:11px;padding:1px 6px;border-radius:999px;background:rgba(217,119,6,0.14);color:#b45309' }, '已自動降頻') : null,
      ].filter(Boolean)));
    });
    area.appendChild(el('p', { class: 'hint', style: 'margin-top:4px' }, r.disclaimer));
    if (r.autoThrottleNote) area.appendChild(el('p', { class: 'hint' }, r.autoThrottleNote));
  } catch (e) { area.innerHTML = ''; area.appendChild(el('div', { class: 'empty-state' }, '分析資料暫時無法取得')); }
}

// ===================== v0.87 可收合的卡片 =====================
// 手機上很多分頁 (設定、待辦的分析) 一次攤開十幾張卡片，要滑很久才找到要的東西。
// 這個共用函式讓卡片標題 (h3) 可以點一下收合/展開，開合狀態記在這台裝置上
// (localStorage，壞掉或沒有也不影響功能，只是回到預設狀態)。
function makeCardCollapsible(card, storeKey, defaultOpen = false) {
  const h = card && card.querySelector(':scope > h3');
  if (!h || card.dataset.fold) return;
  card.dataset.fold = '1';
  card.classList.add('lh-fold');
  const key = `lh_fold_${storeKey}_${h.textContent.trim()}`;
  let open = defaultOpen;
  try { const v = localStorage.getItem(key); if (v !== null) open = v === '1'; } catch (e) { /* ignore */ }
  card.classList.toggle('collapsed', !open);
  h.setAttribute('role', 'button');
  h.setAttribute('tabindex', '0');
  h.setAttribute('aria-expanded', open ? 'true' : 'false');
  const toggle = () => {
    const nowOpen = card.classList.toggle('collapsed') === false;
    h.setAttribute('aria-expanded', nowOpen ? 'true' : 'false');
    try { localStorage.setItem(key, nowOpen ? '1' : '0'); } catch (e) { /* ignore */ }
  };
  h.addEventListener('click', toggle);
  h.addEventListener('keydown', (ev) => { if (ev.key === 'Enter' || ev.key === ' ') { ev.preventDefault(); toggle(); } });
}

function makeCardsCollapsible(container, storeKey, defaultOpen = false) {
  if (!container) return;
  container.querySelectorAll('.card').forEach((card) => makeCardCollapsible(card, storeKey, defaultOpen));
}

function renderSettings() {
  const c = $('#tab-settings');
  c.innerHTML = '';
  // 跟首頁小工具拼貼 (手機版) / 星系版面 (桌面版) 共用同一份 enabledModules 設定，
  // 這裡列出全部可以自訂的項目，不只是原本的 4 個 (有些人比較常用的功能，另一些人完全用不到)。
  const labels = { finance: '💰 記帳', tasks: '✅ 待辦事項', mood: '💗 心情陪伴', bills: '🧾 帳單提醒', calendar: '📅 行事曆' };
  const modules = Object.keys(labels);
  const enabled = (state.prefs && state.prefs.enabledModules) || {};

  const rows = modules.map((m) => el('div', { class: 'module-toggle-row' }, [
    el('span', {}, labels[m]),
    el('label', { class: 'switch' }, [
      el('input', { type: 'checkbox', checked: enabled[m] !== false, onchange: (ev) => toggleModule(m, ev.target.checked) }),
      el('span', { class: 'slider' }),
    ]),
  ]));
  const themePref = (state.prefs && state.prefs.theme) || 'auto';
  const THEME_OPTIONS = [
    { key: 'light', label: '☀️ 淺色' },
    { key: 'dark', label: '🌙 深色' },
    { key: 'auto', label: '🖥️ 自動 (跟系統)' },
  ];
  c.appendChild(el('div', { class: 'card' }, [
    el('h3', {}, '📱 底部導覽列'),
    el('p', { class: 'hint' }, `目前釘在底部的是：${bottomNavPinnedTabs().map((k) => (ALL_NAV_ITEMS.find((i) => i.tab === k) || {}).label).filter(Boolean).join('、') || '（沒有釘選）'}。「首頁」固定不能移除，其餘最多可以再挑 3 個常用功能釘在底部，方便一鍵切換。`),
    el('button', { class: 'btn btn-primary', onclick: () => openBottomNavCustomizeSheet() }, '自訂底部導覽列'),
  ]));

  c.appendChild(el('div', { class: 'card' }, [
    el('h3', {}, '🎨 外觀'),
    el('p', { class: 'hint' }, '選「自動」的話，會跟著手機/電腦目前的深色模式設定即時切換；選淺色或深色則固定用那個模式，不受系統設定影響。'),
    el('div', { class: 'feedback-cat-row' }, THEME_OPTIONS.map((t) =>
      el('button', {
        class: 'feedback-cat-btn' + (t.key === themePref ? ' active' : ''),
        onclick: () => setThemePref(t.key),
      }, t.label)
    )),
  ]));

  c.appendChild(el('div', { class: 'card' }, [
    el('h3', {}, '首頁模組顯示設定'),
    el('p', { class: 'hint' }, '關閉的項目仍可從選單/底部導覽進入，只是不會出現在首頁摘要或小工具拼貼裡；在首頁按「✏️ 自訂」也可以調整同一份設定。'),
    ...rows,
  ]));

  c.appendChild(el('div', { class: 'card' }, [
    el('h3', {}, '🔔 背景推播通知'),
    el('p', { class: 'hint' }, '開啟後，帳單快到期、預算超支、待辦逾期、好幾天沒記心情、該聯絡的人這幾類提醒，就算螢幕熄滅或 App 沒開著也能收到系統通知 (跟前面「開啟瀏覽器提醒」的差異：那個只有分頁開著時才有用)。iPhone 需要先把這個網站「加入主畫面」變成 App，且系統版本 iOS 16.4 以上才支援。'),
    el('p', { class: 'hint' }, '為了避免同一天被推播轟炸：短時間內累積的多筆非緊急提醒會自動合併成一則，而且一天最多推播 6 次非緊急通知；達到上限後首頁還是看得到，只是不會再跳系統通知。使用者自己設定精準時間的待辦/服藥提醒不受這個限制。'),
    el('p', { id: 'pushStatusText', class: 'hint' }, '檢查中...'),
    el('div', { style: 'display:flex;gap:8px;flex-wrap:wrap' }, [
      el('button', { id: 'pushToggleBtn', class: 'btn btn-primary', onclick: togglePushSubscription }, '開啟背景推播通知'),
      el('button', { id: 'pushTestBtn', class: 'btn btn-ghost', style: 'display:none', onclick: sendTestPush }, '📨 傳送測試通知'),
    ]),
    el('div', { class: 'module-toggle-row', style: 'margin-top:14px;padding-top:14px;border-top:1px solid var(--grid-line)' }, [
      el('div', { class: 'module-toggle-row-text' }, [
        el('div', { class: 'module-toggle-row-title' }, '🎂 生日也要推播提醒'),
        el('div', { class: 'module-toggle-row-hint' }, '預設只會顯示在首頁，不會主動推播'),
      ]),
      el('label', { class: 'switch module-toggle-row-switch' }, [
        el('input', {
          type: 'checkbox',
          checked: !!(state.prefs && state.prefs.pushBirthdayReminders),
          onchange: (ev) => togglePushBirthdayPref(ev.target.checked),
        }),
        el('span', { class: 'slider' }),
      ]),
    ]),
    el('div', { class: 'module-toggle-row', style: 'margin-top:10px;padding-top:10px;border-top:1px solid var(--grid-line)' }, [
      el('div', { class: 'module-toggle-row-text' }, [
        el('div', { class: 'module-toggle-row-title' }, '🌷 另一半的生理週期也要推播提醒'),
        el('div', { class: 'module-toggle-row-hint' }, '快來月經了/經前觀察窗，預設只顯示在首頁'),
      ]),
      el('label', { class: 'switch module-toggle-row-switch' }, [
        el('input', {
          type: 'checkbox',
          checked: !!(state.prefs && state.prefs.pushPartnerCycleReminders),
          onchange: (ev) => togglePushPartnerCyclePref(ev.target.checked),
        }),
        el('span', { class: 'slider' }),
      ]),
    ]),
    el('div', { class: 'module-toggle-row', style: 'margin-top:10px;padding-top:10px;border-top:1px solid var(--grid-line)' }, [
      el('div', { class: 'module-toggle-row-text' }, [
        el('div', { class: 'module-toggle-row-title' }, '🫂 心情持續偏低時，也要推播提醒去聯絡該聯絡的人'),
        el('div', { class: 'module-toggle-row-hint' }, '預設只顯示在首頁；推播內容會直接寫出「心情比較低落」，考慮到鎖定畫面可能被別人看到，預設關閉'),
      ]),
      el('label', { class: 'switch module-toggle-row-switch' }, [
        el('input', {
          type: 'checkbox',
          checked: !!(state.prefs && state.prefs.pushMoodSocialReminders),
          onchange: (ev) => togglePushMoodSocialPref(ev.target.checked),
        }),
        el('span', { class: 'slider' }),
      ]),
    ]),
    el('div', { class: 'module-toggle-row', style: 'margin-top:10px;padding-top:10px;border-top:1px solid var(--grid-line)' }, [
      el('div', { class: 'module-toggle-row-text' }, [
        el('div', { class: 'module-toggle-row-title' }, '🌱 自我照顧提醒 (陪伴者自己)'),
        el('div', { class: 'module-toggle-row-hint' }, '她的經前觀察窗/月經遲到期間，主動推一句給你自己的話，完全不用記錄任何東西，開了才會推播'),
      ]),
      el('label', { class: 'switch module-toggle-row-switch' }, [
        el('input', {
          type: 'checkbox',
          checked: !!(state.prefs && state.prefs.pushSelfCareReminders),
          onchange: (ev) => togglePushSelfCarePref(ev.target.checked),
        }),
        el('span', { class: 'slider' }),
      ]),
    ]),
    el('div', { class: 'module-toggle-row', style: 'margin-top:10px;padding-top:10px;border-top:1px solid var(--grid-line)' }, [
      el('div', { class: 'module-toggle-row-text' }, [
        el('div', { class: 'module-toggle-row-title' }, '📌 家庭公告欄有新內容時推播'),
        el('div', { class: 'module-toggle-row-hint' }, '連結的家人在公告欄寫了新東西、你還沒給反應時提醒你，開了才會推播'),
      ]),
      el('label', { class: 'switch module-toggle-row-switch' }, [
        el('input', {
          type: 'checkbox',
          checked: !!(state.prefs && state.prefs.pushFamilyBoardReminders),
          onchange: (ev) => togglePushFamilyBoardPref(ev.target.checked),
        }),
        el('span', { class: 'slider' }),
      ]),
    ]),
    // v0.87：早安摘要推播 (今天到期的待辦、快到期的帳單、今天的行程)，預設關閉。
    el('div', { class: 'module-toggle-row', style: 'margin-top:10px;padding-top:10px;border-top:1px solid var(--grid-line)' }, [
      el('div', { class: 'module-toggle-row-text' }, [
        el('div', { class: 'module-toggle-row-title' }, '☀️ 每天早上推一則「今天」摘要'),
        el('div', { class: 'module-toggle-row-hint', id: 'morningBriefHint' }, '靜音時段結束時推播今天到期的待辦、快到期的帳單、今天的行程；那天什麼都沒有就不推'),
      ]),
      el('label', { class: 'switch module-toggle-row-switch' }, [
        el('input', { type: 'checkbox', id: 'morningBriefToggle', onchange: (ev) => toggleMorningBrief(ev.target.checked) }),
        el('span', { class: 'slider' }),
      ]),
    ]),
    el('div', { id: 'morningBriefPreview', class: 'morning-brief-preview', style: 'display:none' }),
    el('div', { style: 'margin-top:14px;padding-top:14px;border-top:1px solid var(--grid-line)' }, [
      el('div', {}, '🌙 靜音時段'),
      el('p', { class: 'hint', style: 'margin-top:2px' }, '這段時間內的一般提醒 (帳單/待辦逾期/心情/生日等) 不會推播，隔天打開 App 首頁一樣看得到；服藥提醒跟自己設定的精準提醒時間不受這個限制，一律準時推播。'),
      el('div', { style: 'display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-top:8px' }, [
        el('input', {
          id: 'quietHoursStartInput',
          type: 'time',
          value: (state.prefs && state.prefs.quietHoursStart) || '23:00',
        }),
        el('span', { class: 'hint' }, '到'),
        el('input', {
          id: 'quietHoursEndInput',
          type: 'time',
          value: (state.prefs && state.prefs.quietHoursEnd) || '10:00',
        }),
        el('button', { class: 'btn btn-ghost', onclick: saveQuietHours }, '儲存'),
      ]),
    ]),
  ]));
  updatePushStatusUI();

  c.appendChild(el('div', { class: 'card' }, [
    el('h3', {}, '📈 通知有效性'),
    el('p', { class: 'hint' }, '過去 30 天，每種提醒送出後 24 小時內，有沒有真的做了對應的動作 (例如任務提醒後完成任務)，只是粗略的行為觀察，不是精確分析。'),
    el('div', { id: 'notificationEffectivenessArea' }, el('div', { class: 'empty-state' }, '載入中...')),
  ]));
  loadNotificationEffectiveness();

  c.appendChild(el('div', { class: 'card' }, [
    el('h3', {}, '🔒 家人/伴侶共享設定'),
    el('p', { class: 'hint' }, '每一項都是你自己單方面決定要不要分享，不需要對方同意，對方要不要分享給你看也是他自己那邊決定，兩邊互不影響。'),
    partnerShareToggleRow('📅', '行事曆', '讓對方看到我未來的行程', 'shareCalendarWithPartner', !(state.prefs && state.prefs.shareCalendarWithPartner === false)),
    partnerShareToggleRow('✅', '待辦事項', '讓對方看到我還沒完成的待辦', 'shareTasksWithPartner', !(state.prefs && state.prefs.shareTasksWithPartner === false)),
    partnerShareToggleRow('🌙', '生理週期狀態', '讓對方看到我目前估算在哪個階段', 'shareCycleWithPartner', !(state.prefs && state.prefs.shareCycleWithPartner === false)),
    partnerShareToggleRow('💗', '心情 × 週期關聯統計', '只有階段平均分數 (例如「黃體期平均 5.2 分」)，每個階段至少累積 3 筆紀錄才會顯示；日記原文跟 AI 對話內容無論如何都不會分享，這是寫死的保護，不受這個開關影響。預設關閉，因為這項資料比較敏感。', 'shareMoodWithPartner', !!(state.prefs && state.prefs.shareMoodWithPartner)),
  ]));

  c.appendChild(el('div', { class: 'card' }, [
    el('h3', {}, '📅 訂閱到手機原生行事曆'),
    el('p', { class: 'hint' }, '產生一組專屬網址，貼到 iPhone「行事曆」App (設定 → 帳號 → 新增訂閱的行事曆) 或 Google 日曆 (透過網址新增)，之後在 LifeHub 新增的行程會自動同步過去，不用兩邊各記一次。'),
    el('p', { class: 'hint' }, '同步範圍包含帳單到期日、待辦截止日、人際關係重要日子。這組網址知道的人就能看到你的行程標題，請不要分享給不信任的人；想收回就按「停用」重新產生一組新的。'),
    el('div', { id: 'icsUrlBox', class: 'hint' }, '檢查中...'),
    el('div', { style: 'display:flex;gap:8px;flex-wrap:wrap;margin-top:8px' }, [
      el('button', { id: 'icsGenBtn', class: 'btn btn-primary', onclick: generateIcsToken }, '產生訂閱網址'),
      el('button', { id: 'icsCopyBtn', class: 'btn btn-ghost', style: 'display:none', onclick: copyIcsUrl }, '📋 複製網址'),
      el('button', { id: 'icsRevokeBtn', class: 'btn btn-ghost', style: 'display:none', onclick: revokeIcsToken }, '停用'),
    ]),
  ]));
  loadIcsTokenStatus();

  c.appendChild(el('div', { class: 'card' }, [
    el('h3', {}, '🔑 帳號安全'),
    el('p', { class: 'hint' }, '忘記密碼時可以用 email + 備用重設碼自己重設密碼，不用等人幫忙。如果是這次更新之前就註冊的帳號，或是重設碼已經用掉／忘記存在哪，按下面按鈕就能拿到一組新的 (舊的會失效)。'),
    el('button', { class: 'btn btn-primary', onclick: regenerateRecoveryCode }, '重新產生備用重設碼'),
    // v0.85：「登出」從每一頁右上角搬到這裡——一個很少用、按錯又要重新登入的動作，不需要
    // 常駐在每個畫面最顯眼的位置 (原本還是全站唯一的藍色文字)。
    el('div', { style: 'margin-top:14px;padding-top:14px;border-top:1px solid var(--grid-line);display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap' }, [
      el('span', { class: 'hint', style: 'margin:0' }, state.user ? `目前登入：${state.user.email || state.user.name || ''}` : ''),
      el('button', { class: 'btn btn-secondary', onclick: doLogout }, '登出'),
    ]),
  ]));

  // v0.86：異地備份 (只有管理者看得到；備份包含所有使用者的資料)
  if (state.user && state.user.isAdmin) {
    c.appendChild(el('div', { class: 'card' }, [
      el('h3', {}, '☁️ 異地備份'),
      el('p', { class: 'hint' }, '每天台北時間凌晨 4 點後，把整個資料庫加密後存到 Google Cloud Storage，跟這台主機分開放。每日備份留 30 天、每月備份留 12 個月。'),
      el('div', { id: 'offsiteBackupStatus' }, el('p', { class: 'hint' }, '載入中...')),
    ]));
    loadOffsiteBackupStatus();
  }

  c.appendChild(el('div', { class: 'card' }, [
    el('h3', {}, '📦 資料匯出／備份'),
    el('p', { class: 'hint' }, '把日記、記帳、行事曆、心情陪伴（含安心小卡、思考記錄）等全部模組的資料，打包成一份 JSON 檔下載下來，可以自己留一份備份，或之後想搬到別的地方使用。'),
    el('button', { class: 'btn btn-primary', onclick: exportAllData }, '匯出全部資料'),
    // v0.67：伺服器每個月會自動幫每個使用者存一份完整備份 (不需要自己記得手動匯出)，
    // 這裡列出「之前自動存過哪幾份」，可以直接下載，只保留最近 6 個月。
    el('div', { style: 'margin-top:14px;padding-top:14px;border-top:1px solid var(--grid-line)' }, [
      el('div', { style: 'font-weight:700;font-size:13px;margin-bottom:4px' }, '🗓️ 自動備份紀錄'),
      el('p', { class: 'hint' }, '伺服器每個月會自動存一份完整備份，不需要自己記得按「匯出全部資料」；只保留最近 6 個月。'),
      el('div', { id: 'autoBackupList' }, el('p', { class: 'hint' }, '載入中...')),
    ]),
  ]));
  loadAutoBackupList();
  loadMorningBriefSetting();
  // v0.87：設定頁的卡片預設全部收合，只看到一排標題，點了才展開。
  makeCardsCollapsible(c, 'settings', false);

  // v0.69：管理者專屬的卡片搬到獨立的「管理者後台」分頁 (renderAdmin())，不再放在這裡——
  // 使用者反映要滑到設定頁最下面才看得到，改成從頂欄/側欄直接一鍵進入，不用捲動。
}

// v0.86：異地備份狀態卡片
async function loadOffsiteBackupStatus() {
  const box = $('#offsiteBackupStatus');
  if (!box) return;
  let st;
  try { st = await api('/backup/offsite/status'); } catch (e) { box.innerHTML = ''; box.appendChild(el('p', { class: 'hint' }, '狀態暫時無法取得')); return; }
  box.innerHTML = '';
  const fmt = (iso) => { try { return new Date(iso).toLocaleString('zh-TW', { hour12: false, month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' }); } catch (e) { return iso; } };
  // v0.89：兩列狀態——「上次備份」(有沒有上傳成功) 跟「上次還原驗證」(下載回來打不打得開)。
  // 綠色/紅色膠囊屬於「有狀態語意」的顏色，其他維持中性色。
  const pill = (ok, text) => el('span', { class: `backup-pill ${ok ? 'backup-pill-ok' : 'backup-pill-bad'}` }, text);
  const statusRow = (label, when, badge) => el('div', { class: 'backup-row' }, [
    el('div', {}, [el('div', { class: 'backup-row-label' }, label), el('div', { class: 'backup-row-when' }, when)]),
    badge,
  ]);
  if (st.notOnGce) {
    box.appendChild(el('p', { class: 'hint', style: 'margin:0 0 4px' }, '這台伺服器不在 Google Cloud 上，不會執行異地備份。'));
  } else {
    const uploadFailed = st.lastErrorAt && (!st.lastSuccessAt || st.lastErrorAt > st.lastSuccessAt);
    const panel = el('div', { class: 'backup-panel' });
    if (uploadFailed) panel.appendChild(statusRow('上次備份', fmt(st.lastErrorAt), pill(false, '失敗')));
    else if (st.lastSuccessAt) panel.appendChild(statusRow('上次備份', fmt(st.lastSuccessAt), pill(true, '成功')));
    else panel.appendChild(statusRow('上次備份', '還沒有執行過', el('span')));
    if (uploadFailed) panel.appendChild(el('p', { class: 'backup-detail' }, st.lastErrorHint || st.lastError || '未知錯誤'));
    if (st.lastVerifyAt) {
      panel.appendChild(statusRow('上次還原驗證', fmt(st.lastVerifyAt), pill(st.lastVerifyOk, st.lastVerifyOk ? '可還原' : '無法還原')));
      if (st.lastVerifyOk && st.lastVerifyCounts) {
        const c = st.lastVerifyCounts;
        panel.appendChild(el('p', { class: 'backup-detail' }, `從雲端下載回來、解密、檢查資料庫完整：待辦 ${c.tasks.toLocaleString()} 筆、記帳 ${c.finance.toLocaleString()} 筆、日記 ${c.diary.toLocaleString()} 篇，跟備份當下一致。`));
      } else if (!st.lastVerifyOk) {
        panel.appendChild(el('p', { class: 'backup-detail' }, `${st.lastVerifyError || '原因不明'}。舊的可還原備份不會被刪除，3 小時後會自動再試。`));
      }
    }
    box.appendChild(panel);
    const facts = [];
    if (st.cloudDaily != null) facts.push(`雲端目前有：每日 ${st.cloudDaily} 份、每月 ${st.cloudMonthly} 份`);
    if (st.lastSizeBytes) facts.push(`大小：${(st.lastSizeBytes / 1024).toFixed(0)} KB (加密壓縮後)`);
    if (st.bucket) facts.push(`位置：gs://${st.bucket}/`);
    facts.forEach((t) => box.appendChild(el('p', { class: 'hint', style: 'margin:0 0 4px' }, t)));
  }
  const keyArea = el('div', { style: 'margin-top:8px' });
  box.appendChild(el('div', { style: 'display:flex;gap:8px;flex-wrap:wrap;margin-top:10px' }, [
    el('button', { class: 'btn btn-primary', onclick: async (ev) => {
      ev.target.disabled = true; ev.target.textContent = '備份並驗證中...';
      try {
        const r = await api('/backup/offsite/run', { method: 'POST' });
        showToast(r.ok ? '備份完成，還原驗證通過' : (r.uploaded ? '已上傳，但還原驗證沒過' : '備份失敗，請看下方說明'));
      } catch (e) { showToast('備份失敗：' + e.message); }
      loadOffsiteBackupStatus();
    } }, '立即備份並驗證'),
    el('button', { class: 'btn btn-secondary', onclick: async () => {
      try {
        const { key } = await api('/backup/offsite/key', { method: 'POST' });
        keyArea.innerHTML = '';
        keyArea.appendChild(el('p', { class: 'hint', style: 'margin:0 0 6px' }, '這把金鑰用來解開雲端上的備份。請存到密碼管理器或其他安全的地方；主機整台不見時，沒有它就打不開備份。'));
        keyArea.appendChild(el('input', { value: key, readonly: true, onclick: (ev) => ev.target.select(), style: 'font-family:monospace;font-size:12px' }));
      } catch (e) { showToast('無法取得金鑰：' + e.message); }
    } }, '顯示加密金鑰'),
  ]));
  box.appendChild(keyArea);
}

// v0.69：管理者後台，獨立分頁 (見側欄「🛠️ 管理者後台」/頂欄 🛠️ 按鈕，只有管理者帳號
// (見 src/services/admin.js 的 ADMIN_EMAIL) 登入時才看得到入口)。內容是從「個人化設定」
// 頁最下面搬過來的三張卡片 (意見回饋/使用狀況統計/登入紀錄)，另外加一張「快速摘要」卡片。
function renderAdmin() {
  const c = $('#tab-admin');
  c.innerHTML = '';
  if (!(state.user && state.user.isAdmin)) {
    c.appendChild(el('div', { class: 'card' }, [
      el('div', { class: 'empty-state' }, '沒有權限查看這個頁面。'),
    ]));
    return;
  }

  const summaryCard = el('div', { class: 'card' }, [
    el('h3', {}, '🛠️ 管理者後台'),
    el('p', { class: 'hint' }, '只有這個帳號看得到的內部資訊，一般使用者連入口都看不到。'),
    el('div', { id: 'adminSummaryArea' }, el('p', { class: 'hint' }, '載入中...')),
  ]);
  c.appendChild(summaryCard);
  loadAdminSummary();

  const feedbackCard = el('div', { class: 'card' }, [
    el('h3', {}, '📨 所有回饋'),
    el('p', { class: 'hint' }, '使用者從右上角 💬 按鈕送出的意見回饋，只有這個帳號看得到。'),
    el('div', { id: 'adminFeedbackList' }, el('p', { class: 'hint' }, '載入中...')),
  ]);
  c.appendChild(feedbackCard);
  loadAdminFeedbackList();

  // v0.64：登入紀錄清單一筆一筆看看不出「這個 App 到底有沒有人在用、用的頻率有沒有在
  // 下降」這種趨勢，這裡用 login_events (v0.64 新增) 算最近 12 週的週活躍使用者數，畫成
  // 簡單的長條圖。
  const usageStatsCard = el('div', { class: 'card' }, [
    el('h3', {}, '📊 使用狀況統計'),
    el('p', { class: 'hint' }, '最近 12 週的「週活躍使用者數」(以每天為基準往回算 7 天一組的滾動視窗，不是曆法上的週一到週日)，用來看這個 App 實際有沒有人在用、頻率有沒有變化。'),
    el('div', { id: 'adminUsageStats' }, el('p', { class: 'hint' }, '載入中...')),
  ]);
  c.appendChild(usageStatsCard);
  loadAdminUsageStats();

  // v0.63：使用者問「最近有誰開過這個 App」才發現系統沒記錄登入時間，加了 last_login_at
  // 之後 (見 migrations/050)，這裡讓管理者能直接查看，只有從這個功能上線之後的登入才查得到，
  // 之前的沒辦法回溯 (見 GET /admin/users 的說明)。
  const usersCard = el('div', { class: 'card' }, [
    el('h3', {}, '👤 使用者登入紀錄'),
    el('p', { class: 'hint' }, '只有這個功能上線 (v0.63) 之後的登入才查得到，之前的沒有資料。'),
    el('div', { id: 'adminUsersList' }, el('p', { class: 'hint' }, '載入中...')),
  ]);
  c.appendChild(usersCard);
  loadAdminUsersList();

  // v0.70：錯誤日誌摘要——直接從 app_logs 抓最近幾筆 error，不用再另外開 /api/debug
  // 貼 Token 才看得到。
  const errorLogsCard = el('div', { class: 'card' }, [
    el('h3', {}, '🚨 錯誤日誌摘要'),
    el('p', { class: 'hint' }, '最近 20 筆系統記錄下來的錯誤 (level = error)，跟 /api/debug 看到的是同一份資料，只是不用再另外貼 Token。'),
    el('div', { id: 'adminErrorLogsArea' }, el('p', { class: 'hint' }, '載入中...')),
  ]);
  c.appendChild(errorLogsCard);
  loadAdminErrorLogs();

  // v0.70：這週熱門功能——統計最近 7 天各分頁被切換的次數/人數，看得出哪些功能做了卻
  // 幾乎沒人用、哪些是大家常用的核心功能。
  const featureUsageCard = el('div', { class: 'card' }, [
    el('h3', {}, '📈 這週熱門功能'),
    el('p', { class: 'hint' }, '最近 7 天各分頁被切換的次數跟不同使用者人數，由多到少排序；只是粗略的使用行為統計，不記錄分頁裡實際做了什麼操作。'),
    el('div', { id: 'adminFeatureUsageArea' }, el('p', { class: 'hint' }, '載入中...')),
  ]);
  c.appendChild(featureUsageCard);
  loadAdminFeatureUsage();
}

async function loadAdminErrorLogs() {
  const area = $('#adminErrorLogsArea');
  if (!area) return;
  try {
    const { items } = await api('/admin/error-logs');
    area.innerHTML = '';
    if (!items.length) {
      area.appendChild(el('div', { class: 'empty-state' }, '目前沒有錯誤紀錄，很好！'));
      return;
    }
    items.forEach((log) => {
      area.appendChild(el('div', { style: 'padding:8px 0;border-bottom:1px solid var(--grid-line)' }, [
        el('div', { class: 'hint' }, new Date(log.created_at).toLocaleString('zh-Hant-TW')),
        el('div', { style: 'font-size:13px;margin-top:2px' }, log.message),
        log.meta_json ? el('div', { class: 'hint', style: 'margin-top:2px;word-break:break-all' }, log.meta_json) : null,
      ].filter(Boolean)));
    });
  } catch (e) {
    area.innerHTML = '';
    area.appendChild(el('div', { class: 'empty-state' }, '載入失敗：' + e.message));
  }
}

async function loadAdminFeatureUsage() {
  const area = $('#adminFeatureUsageArea');
  if (!area) return;
  try {
    const { items } = await api('/admin/feature-usage');
    area.innerHTML = '';
    if (!items.length) {
      area.appendChild(el('div', { class: 'empty-state' }, '最近 7 天還沒有分頁切換紀錄。'));
      return;
    }
    const max = Math.max(1, ...items.map((i) => i.totalSwitches));
    items.forEach((item) => {
      // dashboard/settings/admin 這幾個不在 ALL_NAV_ITEMS (那份清單只收「可自訂釘選」的
      // 分頁)，另外補一份簡單的對照，沒對到的就直接顯示原始分頁代碼，不會壞掉。
      const EXTRA_TAB_LABELS = { dashboard: '🏠 我的首頁', settings: '⚙️ 個人化設定', admin: '🛠️ 管理者後台' };
      const navItem = ALL_NAV_ITEMS.find((n) => n.tab === item.tab);
      const label = navItem ? `${navItem.icon} ${navItem.label}` : (EXTRA_TAB_LABELS[item.tab] || item.tab);
      const pct = Math.round((item.totalSwitches / max) * 100);
      area.appendChild(el('div', { style: 'margin-bottom:8px' }, [
        el('div', { style: 'display:flex;justify-content:space-between;font-size:12.5px;margin-bottom:3px' }, [
          el('span', {}, label),
          el('span', { class: 'hint' }, `${item.totalSwitches} 次 · ${item.uniqueUsers} 人`),
        ]),
        el('div', { style: 'background:var(--grid-line);border-radius:999px;height:6px;overflow:hidden' }, [
          el('div', { style: `width:${pct}%;height:100%;background:var(--series-blue);border-radius:999px` }),
        ]),
      ]));
    });
  } catch (e) {
    area.innerHTML = '';
    area.appendChild(el('div', { class: 'empty-state' }, '載入失敗：' + e.message));
  }
}

async function loadAdminSummary() {
  const holder = $('#adminSummaryArea');
  if (!holder) return;
  try {
    const s = await api('/admin/summary');
    holder.innerHTML = '';
    const tiles = [
      { label: '帳號總數', value: s.totalUsers },
      { label: '最近 7 天活躍', value: s.activeUsersLast7Days },
      { label: '最近 7 天新註冊', value: s.newUsersLast7Days },
      { label: '累積回饋數', value: s.totalFeedback },
      { label: '問題回報 (bug)', value: s.bugReports },
    ];
    holder.appendChild(el('div', { style: 'display:flex;flex-wrap:wrap;gap:10px' },
      tiles.map((t) => el('div', { style: 'flex:1;min-width:100px;background:var(--card-alt-bg,rgba(127,127,127,0.08));border-radius:10px;padding:10px 12px' }, [
        el('div', { style: 'font-size:22px;font-weight:700' }, String(t.value)),
        el('div', { class: 'hint', style: 'margin-top:2px' }, t.label),
      ]))
    ));
  } catch (e) {
    holder.innerHTML = '';
    holder.appendChild(el('p', { class: 'hint' }, '載入失敗：' + e.message));
  }
}
async function loadAdminUsageStats() {
  const holder = $('#adminUsageStats');
  if (!holder) return;
  try {
    const { weeks, totalUsers, loggedInEver } = await api('/admin/usage-stats');
    holder.innerHTML = '';
    holder.appendChild(el('p', { class: 'hint', style: 'margin-bottom:10px' },
      `目前共 ${totalUsers} 個帳號，其中 ${loggedInEver} 個至少登入過一次 (v0.63 上線後才開始記錄)。`));
    const max = Math.max(1, ...weeks.map((w) => w.activeUsers));
    const barW = 22;
    const gap = 6;
    const chartH = 120;
    const width = weeks.length * (barW + gap) + gap;
    const svgNs = 'http://www.w3.org/2000/svg';
    const svg = document.createElementNS(svgNs, 'svg');
    svg.setAttribute('viewBox', `0 0 ${width} ${chartH + 34}`);
    svg.setAttribute('width', '100%');
    svg.setAttribute('style', 'max-width:100%;height:auto;display:block');
    weeks.forEach((w, i) => {
      const h = Math.round((w.activeUsers / max) * (chartH - 12));
      const x = gap + i * (barW + gap);
      const y = chartH - h;
      const rect = document.createElementNS(svgNs, 'rect');
      rect.setAttribute('x', x);
      rect.setAttribute('y', y);
      rect.setAttribute('width', barW);
      rect.setAttribute('height', Math.max(h, 2));
      rect.setAttribute('rx', 4);
      rect.setAttribute('fill', 'var(--series-blue)');
      const title = document.createElementNS(svgNs, 'title');
      const d = new Date(w.weekEndingAt);
      title.textContent = `${d.getMonth() + 1}/${d.getDate()} 為止的 7 天內：${w.activeUsers} 位活躍使用者`;
      rect.appendChild(title);
      svg.appendChild(rect);

      if (w.activeUsers > 0) {
        const label = document.createElementNS(svgNs, 'text');
        label.setAttribute('x', x + barW / 2);
        label.setAttribute('y', y - 4);
        label.setAttribute('text-anchor', 'middle');
        label.setAttribute('font-size', '10');
        label.setAttribute('fill', 'var(--text-muted)');
        label.textContent = String(w.activeUsers);
        svg.appendChild(label);
      }
      if (i === weeks.length - 1 || i === 0 || i === Math.floor(weeks.length / 2)) {
        const dLabel = document.createElementNS(svgNs, 'text');
        dLabel.setAttribute('x', x + barW / 2);
        dLabel.setAttribute('y', chartH + 16);
        dLabel.setAttribute('text-anchor', 'middle');
        dLabel.setAttribute('font-size', '9');
        dLabel.setAttribute('fill', 'var(--text-muted)');
        dLabel.textContent = `${d.getMonth() + 1}/${d.getDate()}`;
        svg.appendChild(dLabel);
      }
    });
    const wrap = el('div', { style: 'overflow-x:auto' });
    wrap.appendChild(svg);
    holder.appendChild(wrap);
  } catch (e) {
    holder.innerHTML = '';
    holder.appendChild(el('p', { class: 'hint' }, '載入失敗：' + e.message));
  }
}
async function loadAdminUsersList() {
  const listEl = $('#adminUsersList');
  if (!listEl) return;
  try {
    const { items } = await api('/admin/users');
    listEl.innerHTML = '';
    if (!items.length) {
      listEl.appendChild(el('p', { class: 'hint' }, '目前還沒有任何使用者。'));
      return;
    }
    items.forEach((u) => {
      const label = u.last_login_at
        ? new Date(u.last_login_at).toLocaleString('zh-Hant-TW')
        : '從沒登入過 (或這個功能上線前的舊登入)';
      listEl.appendChild(el('div', { class: 'feedback-item' }, [
        el('div', { class: 'feedback-item-meta' }, [
          el('span', { class: 'feedback-item-user' }, `${u.name || '(未設定名稱)'} (${u.email})`),
          el('span', { class: 'feedback-item-time' }, `上次登入：${label}`),
        ]),
      ]));
    });
  } catch (e) {
    listEl.innerHTML = '';
    listEl.appendChild(el('p', { class: 'hint' }, '載入失敗：' + e.message));
  }
}
async function loadAdminFeedbackList() {
  const listEl = $('#adminFeedbackList');
  if (!listEl) return;
  try {
    const { items } = await api('/feedback');
    listEl.innerHTML = '';
    if (!items.length) {
      listEl.appendChild(el('p', { class: 'hint' }, '目前還沒有人送出回饋。'));
      return;
    }
    const catLabels = { bug: '🐛 問題回報', suggestion: '💡 建議', other: '💬 其他' };
    items.forEach((f) => {
      const t = new Date(f.created_at);
      const timeLabel = isNaN(t.getTime()) ? f.created_at : t.toLocaleString('zh-Hant-TW');
      listEl.appendChild(el('div', { class: 'feedback-item' }, [
        el('div', { class: 'feedback-item-meta' }, [
          el('span', { class: 'feedback-item-cat' }, catLabels[f.category] || f.category),
          el('span', { class: 'feedback-item-user' }, `${f.user_name} (${f.user_email})`),
          el('span', { class: 'feedback-item-time' }, timeLabel),
          el('button', { class: 'feedback-item-del', title: '刪除這筆回饋', onclick: () => deleteFeedbackItem(f.id) }, '🗑'),
        ]),
        el('div', { class: 'feedback-item-msg' }, f.message),
      ]));
    });
  } catch (e) {
    listEl.innerHTML = '';
    listEl.appendChild(el('p', { class: 'hint' }, '載入回饋失敗：' + e.message));
  }
}
async function deleteFeedbackItem(id) {
  try {
    await api(`/feedback/${id}`, { method: 'DELETE' });
    showToast('已刪除這筆回饋');
    loadAdminFeedbackList();
  } catch (e) {
    showToast('刪除失敗：' + e.message);
  }
}
function exportAllData() {
  window.open('/api/export/all', '_blank');
}
// v0.67：伺服器自動備份的清單，跟上面「匯出全部資料」共用同一個下載方式 (直接開新分頁，
// 瀏覽器會依 content-disposition 自動下載)，只是資料來源是伺服器上存好的檔案，不用重新查詢。
async function loadAutoBackupList() {
  const listEl = $('#autoBackupList');
  if (!listEl) return;
  try {
    const { items } = await api('/export/backups');
    listEl.innerHTML = '';
    if (!items.length) {
      listEl.appendChild(el('p', { class: 'hint' }, '目前還沒有自動備份紀錄，每個月會自動產生一份。'));
      return;
    }
    items.forEach((b) => {
      listEl.appendChild(el('div', { style: 'display:flex;justify-content:space-between;align-items:center;padding:6px 0' }, [
        el('span', {}, `${b.period}　(${Math.round(b.sizeBytes / 1024)} KB)`),
        el('button', { class: 'btn btn-ghost', style: 'font-size:12px', onclick: () => window.open(`/api/export/backups/${b.period}`, '_blank') }, '下載'),
      ]));
    });
  } catch (e) {
    listEl.innerHTML = '';
    listEl.appendChild(el('p', { class: 'hint' }, '載入失敗：' + e.message));
  }
}
async function regenerateRecoveryCode() {
  try {
    const { recoveryCode } = await api('/auth/recovery-code', { method: 'POST' });
    showRecoveryCodeModal(recoveryCode, false);
  } catch (e) { showToast(e.message || '產生失敗'); }
}
async function toggleModule(name, val) {
  state.prefs.enabledModules = { ...(state.prefs.enabledModules || {}), [name]: val };
  await api('/prefs', { method: 'PUT', body: state.prefs });
  showToast('已更新設定');
}

async function togglePushBirthdayPref(val) {
  state.prefs = state.prefs || {};
  state.prefs.pushBirthdayReminders = val;
  try {
    await api('/prefs', { method: 'PUT', body: state.prefs });
    showToast(val ? '生日提醒會推播了 🎂' : '生日提醒改回只顯示在首頁');
  } catch (e) { showToast('儲存失敗：' + e.message); }
}

async function togglePushPartnerCyclePref(val) {
  state.prefs = state.prefs || {};
  state.prefs.pushPartnerCycleReminders = val;
  try {
    await api('/prefs', { method: 'PUT', body: state.prefs });
    showToast(val ? '另一半的生理週期提醒會推播了 🌷' : '這個提醒改回只顯示在首頁');
  } catch (e) { showToast('儲存失敗：' + e.message); }
}

// v0.63：「心情持續偏低+該聯絡的人」這則提醒比較敏感 (推播內容會直接寫出「心情比較低落」)，
// 比照生日/另一半週期提醒同一套「預設關閉、使用者自己決定」的開關做法。
// v0.83：完全被動、不需要使用者自己記錄任何東西的「自我照顧」提醒——比照其他推播開關
// 同一套「預設關閉、使用者自己決定」的做法。
async function togglePushSelfCarePref(val) {
  state.prefs = state.prefs || {};
  state.prefs.pushSelfCareReminders = val;
  try {
    await api('/prefs', { method: 'PUT', body: state.prefs });
    showToast(val ? '自我照顧提醒開啟了 🌱' : '這個提醒改回只顯示在首頁');
  } catch (e) { showToast('儲存失敗：' + e.message); }
}

// v0.87：早安摘要推播開關 + 預覽 (讓人開之前就知道會收到什麼)
async function loadMorningBriefSetting() {
  const toggle = $('#morningBriefToggle'), hint = $('#morningBriefHint'), pv = $('#morningBriefPreview');
  if (!toggle) return;
  try {
    const d = await api('/morning-brief');
    toggle.checked = !!d.enabled;
    if (hint) hint.textContent = `每天 ${d.sendAt} (靜音時段結束時) 推播今天到期的待辦、快到期的帳單、今天的行程；那天什麼都沒有就不推`;
    if (pv) {
      pv.innerHTML = '';
      pv.style.display = '';
      pv.appendChild(el('div', { class: 'morning-brief-preview-label' }, '如果現在推播，內容會是：'));
      if (d.preview && d.preview.length) d.preview.forEach((t) => pv.appendChild(el('div', {}, t)));
      else pv.appendChild(el('div', {}, '(今天沒有到期的待辦、帳單或行程，不會推播)'));
    }
  } catch (e) { /* 舊版伺服器沒有這支 API 時維持預設文字 */ }
}

async function toggleMorningBrief(val) {
  try {
    await api('/morning-brief', { method: 'PUT', body: { enabled: val } });
    showToast(val ? '早安摘要開啟了 ☀️' : '早安摘要關掉了');
  } catch (e) { showToast('儲存失敗：' + e.message); }
}

// v0.84：家庭公告欄有新內容 (且你還沒給反應) 的推播開關，同一套「預設關閉、使用者自己
// 決定」的做法。
async function togglePushFamilyBoardPref(val) {
  state.prefs = state.prefs || {};
  state.prefs.pushFamilyBoardReminders = val;
  try {
    await api('/prefs', { method: 'PUT', body: state.prefs });
    showToast(val ? '家庭公告欄提醒開啟了 📌' : '這個提醒改回只顯示在首頁');
  } catch (e) { showToast('儲存失敗：' + e.message); }
}

async function togglePushMoodSocialPref(val) {
  state.prefs = state.prefs || {};
  state.prefs.pushMoodSocialReminders = val;
  try {
    await api('/prefs', { method: 'PUT', body: state.prefs });
    showToast(val ? '心情持續偏低時會推播提醒了 🫂' : '這個提醒改回只顯示在首頁');
  } catch (e) { showToast('儲存失敗：' + e.message); }
}

// v0.58：靜音時段起訖時間現在可以自己調整 (原本寫死在後端是晚上 11 點到早上 10 點)。
// 起訖時間相同視為「沒有設定靜音時段」(後端 isQuietHoursNow 的邏輯)，這裡先跟使用者
// 確認一次，避免不小心設成同一個時間，誤以為關掉了靜音、其實是「整天都不會靜音」。
async function saveQuietHours() {
  const startEl = $('#quietHoursStartInput');
  const endEl = $('#quietHoursEndInput');
  const start = startEl && startEl.value;
  const end = endEl && endEl.value;
  if (!start || !end) { showToast('請完整選擇起訖時間'); return; }
  if (start === end) {
    if (!confirm('起訖時間一樣，代表「不設定靜音時段」(隨時都會推播一般提醒)，確定嗎？')) return;
  }
  state.prefs = state.prefs || {};
  state.prefs.quietHoursStart = start;
  state.prefs.quietHoursEnd = end;
  try {
    await api('/prefs', { method: 'PUT', body: state.prefs });
    showToast(start === end ? '已關閉靜音時段' : `靜音時段已更新為 ${start} - ${end}`);
  } catch (e) { showToast('儲存失敗：' + e.message); }
}

// v0.40 修正：四個分享開關原本各自用不同的元素結構寫 (有的整句塞進一個 <span>、有的拆成
// 標題+說明兩層)，長文字換行的方式不一致，開關本身的垂直位置也就跟著每一列的行數上下亂跳，
// 看起來擠、位置也不統一。改成統一用這個 helper 產生每一列：固定「短標題 (單行，不太會換
// 行) + 下面一行小字說明」的兩層結構，開關固定貼齊在標題那一行的高度 (見 CSS 的
// align-items:flex-start 搭配 .module-toggle-row-switch 的位置)，四列版面就會整齊劃一。
function partnerShareToggleRow(icon, title, hint, prefKey, checked) {
  return el('div', { class: 'module-toggle-row' }, [
    el('div', { class: 'module-toggle-row-text' }, [
      el('div', { class: 'module-toggle-row-title' }, `${icon} ${title}`),
      el('div', { class: 'module-toggle-row-hint' }, hint),
    ]),
    el('label', { class: 'switch module-toggle-row-switch' }, [
      el('input', { type: 'checkbox', checked, onchange: (ev) => togglePartnerShare(prefKey, ev.target.checked) }),
      el('span', { class: 'slider' }),
    ]),
  ]);
}

// 家人/伴侶共享設定：四個開關 (行事曆/待辦/生理週期/心情關聯) 共用同一個儲存邏輯，
// 只差在 prefs 的欄位名稱跟 toast 文字。行事曆/待辦/生理週期預設是 true (維持原本「連結
// 就看得到」的行為，不會因為這次改版而讓舊使用者原本能看到的東西突然消失)；心情關聯維持
// 原本預設 false (資料比較敏感，刻意要使用者自己主動打開)。
const PARTNER_SHARE_TOASTS = {
  shareCalendarWithPartner: ['已分享行事曆給已連結的對象 📅', '已停止分享行事曆'],
  shareTasksWithPartner: ['已分享待辦事項給已連結的對象 ✅', '已停止分享待辦事項'],
  shareCycleWithPartner: ['已分享生理週期狀態給已連結的對象 🌙', '已停止分享生理週期狀態'],
  shareMoodWithPartner: ['已開啟分享心情統計 🔓', '已關閉分享，對方不會再看到'],
};
async function togglePartnerShare(prefKey, val) {
  state.prefs = state.prefs || {};
  state.prefs[prefKey] = val;
  try {
    await api('/prefs', { method: 'PUT', body: state.prefs });
    const toasts = PARTNER_SHARE_TOASTS[prefKey] || ['已儲存', '已關閉'];
    showToast(val ? toasts[0] : toasts[1]);
  } catch (e) { showToast('儲存失敗：' + e.message); }
}

// ===================== Debug 面板 =====================
async function showDebug() {
  const token = prompt('輸入 Debug Token (見伺服器 .env 的 DEBUG_TOKEN)：');
  if (token == null) return;
  try {
    const res = await fetch('/api/debug', { headers: { 'X-Debug-Token': token } });
    const data = await res.json();
    if (!res.ok) { showToast(data.error || '驗證失敗'); return; }
    alert(JSON.stringify(data, null, 2).slice(0, 4000));
  } catch (e) { showToast('取得系統狀態失敗'); }
}

// ===================== 啟動 =====================
(async function boot() {
  try {
    const { user } = await api('/auth/me');
    if (user) onAuthed(user);
    else {
      const health = await api('/health');
      $('#appVersion').textContent = health.version;
    }
  } catch (e) {}
})();

// ===================== v0.87 長說明文字自動收合 =====================
// 很多卡片最上面有一大段說明 (規則、資料來源、注意事項)，在手機上常常佔掉半個畫面。
// 卡片裡超過 70 個字的說明 (.card p.hint) 預設只顯示兩行，旁邊一個「展開說明」可以看全文。
// 用 MutationObserver 統一處理，各分頁的程式碼都不用改。
(function setupHintClamp() {
  const LIMIT = 70;
  const process = (root) => {
    // 次分頁太多要橫向滑動時，把目前選中的那一個捲到看得見的位置
    root.querySelectorAll('.subnav').forEach((nav) => {
      const a = nav.querySelector('.subnav-item.active');
      if (a && nav.dataset.scrolledTo !== a.textContent) {
        nav.dataset.scrolledTo = a.textContent;
        nav.scrollLeft = Math.max(0, a.offsetLeft - (nav.clientWidth - a.offsetWidth) / 2);
      }
    });
    root.querySelectorAll('.card p.hint:not([data-clamp])').forEach((p) => {
      p.dataset.clamp = '1';
      if ((p.textContent || '').trim().length <= LIMIT) return;
      if (p.closest('.partner-lowscore-followup, .morning-brief-preview')) return;
      p.classList.add('hint-clamp');
      const more = el('button', { type: 'button', class: 'hint-more' }, '展開說明');
      more.addEventListener('click', () => {
        const open = p.classList.toggle('open');
        more.textContent = open ? '收起' : '展開說明';
      });
      p.after(more);
    });
  };
  const main = document.querySelector('.main');
  if (!main || !('MutationObserver' in window)) return;
  let scheduled = false;
  new MutationObserver(() => {
    if (scheduled) return;
    scheduled = true;
    requestAnimationFrame(() => { scheduled = false; process(main); });
  }).observe(main, { childList: true, subtree: true });
  process(main);
})();
