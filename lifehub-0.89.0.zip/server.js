const path = require('path');

// ===== 自我更新：每次開機都從同目錄的 lifehub-prototype.zip 還原/覆蓋一次專案檔案 =====
// (常見情況：透過網頁手動上傳到 GitHub 時，瀏覽器沒有把子資料夾一起送出。)
// 純粹用 Node.js 內建模組實作 (fs / zlib)，不依賴任何外部套件或系統指令，
// 符合這個專案「零外部依賴」的原則。整段邏輯內嵌在 server.js 裡。
// 刻意設計成「只要 zip 檔存在就一定執行」而不是只在缺檔案時才執行，
// 這樣以後要更新畫面/功能，只需要換掉這個 zip 檔重新部署，
// 不用再手動一個一個資料夾上傳、也不用再改 server.js。
(function ensureExtracted(rootDir) {
  const fs = require('fs');
  const zlib = require('zlib');

  function findZipFile() {
    const zipNames = fs.readdirSync(rootDir).filter((name) => name.toLowerCase().endsWith('.zip'));
    if (zipNames.length === 0) return null;
    if (zipNames.length > 1) {
      // 根目錄有一個以上的 zip 檔時，沒辦法安全地判斷哪個才是「最新」的
      // (git checkout 後檔案的修改時間不可靠)，寧可不做事也不要猜錯、部署到舊版本。
      console.error(
        `[bootstrap-extract] 偵測到 ${zipNames.length} 個 zip 檔 (${zipNames.join(', ')})，` +
          '為避免用錯版本，這次不會自動解壓縮。請確認專案根目錄只留「一個」zip 檔案。'
      );
      return null;
    }
    return path.join(rootDir, zipNames[0]);
  }

  function readEocd(buf) {
    const SIG = 0x06054b50;
    for (let i = buf.length - 22; i >= 0; i--) {
      if (buf.readUInt32LE(i) === SIG) {
        return { entryCount: buf.readUInt16LE(i + 10), cdOffset: buf.readUInt32LE(i + 16) };
      }
    }
    throw new Error('找不到 ZIP 的 End Of Central Directory，檔案可能不完整或已損毀');
  }

  function extractZip(zipPath, destDir) {
    const buf = fs.readFileSync(zipPath);
    const { entryCount, cdOffset } = readEocd(buf);
    let offset = cdOffset;
    for (let i = 0; i < entryCount; i++) {
      if (buf.readUInt32LE(offset) !== 0x02014b50) {
        throw new Error(`ZIP central directory 格式異常 (entry ${i})`);
      }
      const compressionMethod = buf.readUInt16LE(offset + 10);
      const compressedSize = buf.readUInt32LE(offset + 20);
      const nameLen = buf.readUInt16LE(offset + 28);
      const extraLen = buf.readUInt16LE(offset + 30);
      const commentLen = buf.readUInt16LE(offset + 32);
      const localHeaderOffset = buf.readUInt32LE(offset + 42);
      const nameStart = offset + 46;
      const fileName = buf.toString('utf8', nameStart, nameStart + nameLen);

      const localNameLen = buf.readUInt16LE(localHeaderOffset + 26);
      const localExtraLen = buf.readUInt16LE(localHeaderOffset + 28);
      const dataStart = localHeaderOffset + 30 + localNameLen + localExtraLen;
      const compressedData = buf.subarray(dataStart, dataStart + compressedSize);

      const targetPath = path.join(destDir, fileName);
      if (!path.resolve(targetPath).startsWith(path.resolve(destDir) + path.sep)) {
        throw new Error(`ZIP 內有不安全的路徑：${fileName}`);
      }
      if (fileName.endsWith('/')) {
        fs.mkdirSync(targetPath, { recursive: true });
      } else {
        fs.mkdirSync(path.dirname(targetPath), { recursive: true });
        const data = compressionMethod === 0 ? compressedData : zlib.inflateRawSync(compressedData);
        fs.writeFileSync(targetPath, data);
      }
      offset = nameStart + nameLen + extraLen + commentLen;
    }
  }

  // ===== v0.88：更新失敗自動退回上一版 =====
  // 狀態存在 .bootstrap/state.json：{ hash, status: 'trying'|'ok'|'bad', boots, goodHash }
  // - 換了新的 zip (hash 不同) 時，先把「這次會被覆蓋的檔案」備份到 .bootstrap/previous/
  //   (只在上一版已確認可正常運作 status=ok 時才更新備份，確保備份的永遠是好的版本)。
  // - 新版啟動成功、自我健康檢查通過後 (約 30 秒) 標記 ok。
  // - 新版連續 2 次開機都沒走到 ok (例如一啟動就當掉，systemd 一直重啟)，第 3 次開機時
  //   把備份還原回去並把這個 zip 標記 bad，之後不再解壓它，直到換上新的 zip。
  const crypto = require('crypto');
  const stateDir = path.join(rootDir, '.bootstrap');
  const stateFile = path.join(stateDir, 'state.json');
  const prevDir = path.join(stateDir, 'previous');
  const MAX_TRY_BOOTS = 2;

  function readState() {
    try { return JSON.parse(fs.readFileSync(stateFile, 'utf8')); } catch (e) { return null; }
  }
  function writeState(st) {
    try {
      fs.mkdirSync(stateDir, { recursive: true });
      fs.writeFileSync(stateFile, JSON.stringify({ ...st, updatedAt: new Date().toISOString() }, null, 2));
    } catch (e) {
      console.error('[bootstrap-extract] 無法寫入狀態檔：' + e.message);
    }
  }
  function zipFileNames(zipPath) {
    const buf = fs.readFileSync(zipPath);
    const { entryCount, cdOffset } = readEocd(buf);
    const names = [];
    let offset = cdOffset;
    for (let i = 0; i < entryCount; i++) {
      const nameLen = buf.readUInt16LE(offset + 28);
      const extraLen = buf.readUInt16LE(offset + 30);
      const commentLen = buf.readUInt16LE(offset + 32);
      const name = buf.toString('utf8', offset + 46, offset + 46 + nameLen);
      if (!name.endsWith('/')) names.push(name);
      offset = offset + 46 + nameLen + extraLen + commentLen;
    }
    return names;
  }
  function backupCurrent(zipPath) {
    fs.rmSync(prevDir, { recursive: true, force: true });
    fs.mkdirSync(prevDir, { recursive: true });
    const saved = [];
    for (const name of zipFileNames(zipPath)) {
      const src = path.join(rootDir, name);
      if (!fs.existsSync(src) || !fs.statSync(src).isFile()) continue;
      const dest = path.join(prevDir, name);
      fs.mkdirSync(path.dirname(dest), { recursive: true });
      fs.copyFileSync(src, dest);
      saved.push(name);
    }
    fs.writeFileSync(path.join(prevDir, '.manifest.json'), JSON.stringify(saved));
    return saved.length;
  }
  function restorePrevious() {
    let saved;
    try { saved = JSON.parse(fs.readFileSync(path.join(prevDir, '.manifest.json'), 'utf8')); } catch (e) { return false; }
    for (const name of saved) {
      const dest = path.join(rootDir, name);
      fs.mkdirSync(path.dirname(dest), { recursive: true });
      fs.copyFileSync(path.join(prevDir, name), dest);
    }
    return true;
  }

  const zipPath = findZipFile();
  if (!zipPath) {
    const srcDir = path.join(rootDir, 'src');
    if (!fs.existsSync(srcDir)) {
      console.error('[bootstrap-extract] 缺少 src/ 資料夾，且找不到 lifehub-prototype.zip 可以還原。');
    }
    return; // 沒有 zip：假設專案本身已經是完整的 (例如本機開發)，不用做任何事
  }

  const hash = crypto.createHash('sha256').update(fs.readFileSync(zipPath)).digest('hex');
  const prev = readState();
  let st;
  if (prev && prev.hash === hash) {
    st = { ...prev };
    if (st.status === 'bad') {
      console.error(`[bootstrap-extract] ${path.basename(zipPath)} 之前被判定為無法正常啟動，維持上一版，不解壓縮。請換一個新的 zip。`);
      process.__lifehubBootstrap = { state: st, markOk() {} };
      return;
    }
    if (st.status === 'trying') {
      st.boots = (st.boots || 0) + 1;
      if (st.boots > MAX_TRY_BOOTS) {
        const restored = fs.existsSync(prevDir) && restorePrevious();
        if (restored) {
          st.status = 'bad';
          writeState(st);
          console.error(`[bootstrap-extract] ${path.basename(zipPath)} 連續 ${MAX_TRY_BOOTS} 次開機都沒有成功，已自動退回上一版。`);
          process.__lifehubBootstrap = { state: st, markOk() {} };
          return;
        }
        console.error('[bootstrap-extract] 新版一直啟動失敗，但沒有上一版的備份可以退回。');
      }
    }
  } else {
    // 新的 zip：上一版已確認正常 (或第一次啟用這個機制) 才更新備份
    if (!prev || prev.status === 'ok' || !fs.existsSync(prevDir)) {
      try {
        const n = backupCurrent(zipPath);
        console.log(`[bootstrap-extract] 已備份目前版本 ${n} 個檔案，新版啟動失敗時會自動退回。`);
      } catch (e) {
        console.error('[bootstrap-extract] 備份目前版本失敗：' + e.message);
      }
    }
    st = { hash, zip: path.basename(zipPath), status: 'trying', boots: 1, previousHash: prev ? (prev.status === 'ok' ? prev.hash : prev.previousHash) : null };
  }
  writeState(st);

  console.log(`[bootstrap-extract] 正在從 ${path.basename(zipPath)} 還原/更新專案檔案...`);
  try {
    extractZip(zipPath, rootDir);
  } catch (e) {
    // zip 壞掉 (例如上傳不完整)：直接退回上一版
    console.error('[bootstrap-extract] 解壓縮失敗：' + e.message);
    if (fs.existsSync(prevDir) && restorePrevious()) {
      st.status = 'bad';
      writeState(st);
      console.error('[bootstrap-extract] 已退回上一版。');
    }
    process.__lifehubBootstrap = { state: st, markOk() {} };
    return;
  }
  console.log('[bootstrap-extract] 還原完成。');
  process.__lifehubBootstrap = {
    state: st,
    markOk() {
      if (st.status === 'ok') return;
      st.status = 'ok';
      st.okAt = new Date().toISOString();
      writeState(st);
      console.log('[bootstrap-extract] 新版運作正常，已確認。');
    },
  };
})(__dirname);

const { loadEnv } = require('./src/services/env');
loadEnv();

const { createApp } = require('./src/mini-http');
const logger = require('./src/services/logger');
const { getDb } = require('./src/services/db');

// 啟動時先初始化 DB + 套用 migrations，任何一步失敗就直接讓程式退出，
// 避免「資料庫結構跟程式版本對不上」卻還繼續服務請求。
getDb();

// 開機時印出 AI 助理目前偵測到哪個供應商 (不印出金鑰內容，只印出「有沒有偵測到」+ 長度)，
// 方便直接從部署 log 確認 GEMINI_API_KEY / ANTHROPIC_API_KEY 有沒有真的被容器讀到，
// 不用等使用者實際點進 AI 助理頁面聊天才發現「金鑰設定了卻沒作用」。
const assistantService = require('./src/services/assistant');
const health = assistantService.healthcheck();
if (health.ok) {
  const keyLen = (process.env.GEMINI_API_KEY || process.env.ANTHROPIC_API_KEY || '').length;
  logger.info(`[assistant] 已偵測到 AI 供應商: ${health.provider} (金鑰長度: ${keyLen})`);
} else {
  logger.info(`[assistant] 尚未偵測到 AI 供應商設定 (${health.reason})`);
}

const app = createApp();

app.setSession({
  name: 'lifehub_session',
  secret: process.env.SESSION_SECRET || 'dev-secret-change-me',
  maxAge: 30 * 24 * 60 * 60 * 1000,
});

app.mount('/api/auth', require('./src/routes/auth'));
app.mount('/api/prefs', require('./src/routes/prefs'));
app.mount('/api/diary', require('./src/routes/diary'));
app.mount('/api/finance', require('./src/routes/finance'));
app.mount('/api/travel', require('./src/routes/travel'));
app.mount('/api/calendar', require('./src/routes/calendar'));
app.mount('/api/assistant', require('./src/routes/assistant'));
app.mount('/api/mood', require('./src/routes/mood'));
app.mount('/api/export', require('./src/routes/export'));
app.mount('/api/health-track', require('./src/routes/health'));
app.mount('/api/bills', require('./src/routes/bills'));
app.mount('/api/relationships', require('./src/routes/relationships'));
app.mount('/api/tasks', require('./src/routes/tasks'));
app.mount('/api', require('./src/routes/debug'));

app.setStatic(path.join(__dirname, 'public'));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  logger.info(`LifeHub 伺服器已啟動: http://localhost:${PORT} (版本 ${require('./package.json').version})`);
  // v0.88：啟動 30 秒後自己打一次 /api/health，通過才算「新版運作正常」(見最上面的 bootstrap)。
  if (process.__lifehubBootstrap && process.__lifehubBootstrap.state && process.__lifehubBootstrap.state.status === 'trying') {
    const t = setTimeout(() => {
      require('http').get({ host: '127.0.0.1', port: PORT, path: '/api/health', timeout: 10000 }, (res) => {
        res.resume();
        if (res.statusCode === 200) process.__lifehubBootstrap.markOk();
        else logger.error(`[bootstrap] 自我健康檢查失敗 (HTTP ${res.statusCode})`, {});
      }).on('error', (e) => logger.error('[bootstrap] 自我健康檢查失敗', { message: e.message }));
    }, Number(process.env.LIFEHUB_BOOT_OK_DELAY_MS || 30000));
    t.unref();
  }
});

process.on('unhandledRejection', (err) => {
  logger.error('未處理的 Promise rejection', { message: err && err.message, stack: err && err.stack });
});
process.on('uncaughtException', (err) => {
  logger.error('未捕捉的例外', { message: err.message, stack: err.stack });
});
