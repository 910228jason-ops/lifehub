const { Router } = require('../mini-http');
const { getDb } = require('../services/db');
const { requireAuth } = require('../middleware/auth');

const router = Router();

// v0.89：「今天」一律用台灣時間 (UTC+8) 判斷。原本用 toISOString() 拿 UTC 日期，台灣早上 8 點前
// 會算成前一天，生日倒數就多一天。
function taipeiTodayUTC() {
  const ymd = new Date(Date.now() + 8 * 3600 * 1000).toISOString().slice(0, 10);
  return new Date(ymd + 'T00:00:00Z');
}

// MM-DD 每年重複的日期，離「台灣的今天」還有幾天 (今天 = 0，今年已過就算明年)。
// 02-29 在非閏年用 03-01 (Date.UTC 自動進位)，不會整年消失。
function daysUntilMonthDay(monthDay) {
  const today = taipeiTodayUTC();
  const [mm, dd] = String(monthDay).split('-').map(Number);
  if (!mm || !dd) return null;
  const y = today.getUTCFullYear();
  let next = new Date(Date.UTC(y, mm - 1, dd));
  if (next < today) next = new Date(Date.UTC(y + 1, mm - 1, dd));
  return Math.round((next - today) / 86400000);
}

router.get('/', requireAuth, (req, res) => {
  const db = getDb();
  const rows = db.prepare('SELECT * FROM relationships WHERE user_id = ? ORDER BY name ASC').all(req.session.userId);
  res.json(rows);
});

router.post('/', requireAuth, (req, res) => {
  const { name, relationType, birthday, note } = req.body || {};
  if (!name || !String(name).trim()) return res.status(400).json({ error: '請提供姓名' });
  if (birthday && !/^\d{2}-\d{2}$/.test(birthday)) return res.status(400).json({ error: '生日請用 MM-DD 格式 (例如 03-15)' });
  const db = getDb();
  const now = new Date().toISOString();
  const result = db.prepare('INSERT INTO relationships (user_id, name, relation_type, birthday, note, created_at) VALUES (?, ?, ?, ?, ?, ?)').run(
    req.session.userId, String(name).trim(), relationType || null, birthday || null, note || null, now
  );
  res.json({ id: result.lastInsertRowid, ok: true });
});

router.delete('/:id', requireAuth, (req, res) => {
  const db = getDb();
  db.prepare('DELETE FROM relationships WHERE id = ? AND user_id = ?').run(req.params.id, req.session.userId);
  res.json({ ok: true });
});

router.put('/:id', requireAuth, (req, res) => {
  const { name, relationType, birthday, note, reminderIntervalDays } = req.body || {};
  const db = getDb();
  const existing = db.prepare('SELECT * FROM relationships WHERE id = ? AND user_id = ?').get(req.params.id, req.session.userId);
  if (!existing) return res.status(404).json({ error: '找不到這個人' });
  if (birthday && !/^\d{2}-\d{2}$/.test(birthday)) return res.status(400).json({ error: '生日請用 MM-DD 格式 (例如 03-15)' });
  db.prepare(
    'UPDATE relationships SET name = ?, relation_type = ?, birthday = ?, note = ?, reminder_interval_days = ? WHERE id = ? AND user_id = ?'
  ).run(
    name !== undefined && String(name).trim() ? String(name).trim() : existing.name,
    relationType !== undefined ? (relationType || null) : existing.relation_type,
    birthday !== undefined ? (birthday || null) : existing.birthday,
    note !== undefined ? (note || null) : existing.note,
    reminderIntervalDays !== undefined ? (reminderIntervalDays === null ? null : Number(reminderIntervalDays)) : existing.reminder_interval_days,
    req.params.id,
    req.session.userId
  );
  res.json({ ok: true });
});

router.get('/:id/interactions', requireAuth, (req, res) => {
  const db = getDb();
  const rows = db.prepare('SELECT * FROM relationship_interactions WHERE relationship_id = ? AND user_id = ? ORDER BY interaction_date DESC').all(req.params.id, req.session.userId);
  res.json(rows);
});

const VALID_QUALITIES = new Set(['positive', 'neutral', 'draining']);

router.post('/:id/interactions', requireAuth, (req, res) => {
  const { note, date, quality } = req.body || {};
  if (!note || !String(note).trim()) return res.status(400).json({ error: '請填寫互動內容' });
  if (quality !== undefined && quality !== null && !VALID_QUALITIES.has(quality)) {
    return res.status(400).json({ error: '互動感覺的值不合法' });
  }
  const db = getDb();
  const rel = db.prepare('SELECT id FROM relationships WHERE id = ? AND user_id = ?').get(req.params.id, req.session.userId);
  if (!rel) return res.status(404).json({ error: '找不到這個人' });
  const now = new Date().toISOString();
  const result = db.prepare('INSERT INTO relationship_interactions (user_id, relationship_id, interaction_date, note, quality, created_at) VALUES (?, ?, ?, ?, ?, ?)').run(
    req.session.userId, req.params.id, date || now.slice(0, 10), String(note).trim(), quality || null, now
  );
  res.json({ id: result.lastInsertRowid, ok: true });
});

// v0.65：互動品質摘要——依關係人分組統計每一種「互動感覺」被記錄過幾次，只算有填寫過
// quality 的紀錄 (沒填的不算進分母，避免舊資料全部被當成「普通」)。前端用這個資料在
// 關係人卡片上顯示一個簡單的品質徽章 (例如「多半正向」「偏消耗」)，不強迫使用者解讀。
router.get('/interaction-quality-summary', requireAuth, (req, res) => {
  const db = getDb();
  const rows = db
    .prepare(
      `SELECT relationship_id, quality, COUNT(*) as c
       FROM relationship_interactions
       WHERE user_id = ? AND quality IS NOT NULL
       GROUP BY relationship_id, quality`
    )
    .all(req.session.userId);
  const byRelationship = {};
  rows.forEach((r) => {
    if (!byRelationship[r.relationship_id]) byRelationship[r.relationship_id] = { positive: 0, neutral: 0, draining: 0 };
    byRelationship[r.relationship_id][r.quality] = r.c;
  });
  res.json(byRelationship);
});

// 未來 30 天內的生日 (跨年也算，例如現在 12 月、生日 1 月)
router.get('/upcoming-birthdays', requireAuth, (req, res) => {
  const db = getDb();
  const rows = db.prepare("SELECT id, name, relation_type, birthday FROM relationships WHERE user_id = ? AND birthday IS NOT NULL").all(req.session.userId);
  const withDays = rows.map((r) => ({ ...r, daysUntil: daysUntilMonthDay(r.birthday) }));

  res.json(withDays.filter((r) => r.daysUntil <= 30).sort((a, b) => a.daysUntil - b.daysUntil));
});

// v0.89：首頁「即將到來」——生日 + 重要日期合在一起，依天數排序。
// ?days=14 (1~60) 只取這幾天內的，?limit=3 (1~20) 最多幾筆。
router.get('/upcoming-dates', requireAuth, (req, res) => {
  const db = getDb();
  const uid = req.session.userId;
  const days = Math.min(60, Math.max(1, parseInt(req.query.days, 10) || 14));
  const limit = Math.min(20, Math.max(1, parseInt(req.query.limit, 10) || 3));
  const birthdays = db.prepare('SELECT id, name, birthday FROM relationships WHERE user_id = ? AND birthday IS NOT NULL').all(uid)
    .map((r) => ({ kind: 'birthday', relationshipId: r.id, label: `${r.name}的生日`, monthDay: r.birthday }));
  const dates = db
    .prepare('SELECT d.id, d.label, d.month_day, d.relationship_id FROM important_dates d WHERE d.user_id = ?')
    .all(uid)
    .map((d) => ({ kind: 'date', relationshipId: d.relationship_id, label: d.label, monthDay: d.month_day }));
  const out = [...birthdays, ...dates]
    .map((x) => ({ ...x, daysUntil: daysUntilMonthDay(x.monthDay) }))
    .filter((x) => x.daysUntil != null && x.daysUntil <= days)
    .sort((a, b) => a.daysUntil - b.daysUntil || a.label.localeCompare(b.label, 'zh-Hant'))
    .slice(0, limit);
  res.json(out);
});

// 依關係類型給預設的「間隔提醒」天數 (使用者可在個別聯絡人上覆寫)
const DEFAULT_INTERVAL_BY_TYPE = { family: 30, friend: 45, colleague: 60, other: 60 };

// 這裡刻意不用「好久沒聯絡」這種帶壓力的詞，只是單純的時間資訊，
// 給不給提醒、要不要聯絡，決定權都在使用者身上。
router.get('/overdue', requireAuth, (req, res) => {
  const db = getDb();
  const rels = db.prepare('SELECT * FROM relationships WHERE user_id = ?').all(req.session.userId);
  const lastRows = db
    .prepare(
      `SELECT relationship_id, MAX(interaction_date) as last_date FROM relationship_interactions WHERE user_id = ? GROUP BY relationship_id`
    )
    .all(req.session.userId);
  const lastByRel = {};
  lastRows.forEach((r) => { lastByRel[r.relationship_id] = r.last_date; });

  const todayStr = new Date().toISOString().slice(0, 10);
  const today = new Date(todayStr + 'T00:00:00Z');

  const results = rels.map((r) => {
    const lastDate = lastByRel[r.id] || null;
    const intervalDays = r.reminder_interval_days || DEFAULT_INTERVAL_BY_TYPE[r.relation_type] || DEFAULT_INTERVAL_BY_TYPE.other;
    let daysSinceContact = null;
    if (lastDate) {
      daysSinceContact = Math.round((today - new Date(lastDate + 'T00:00:00Z')) / (1000 * 60 * 60 * 24));
    }
    const dueForContact = daysSinceContact == null || daysSinceContact >= intervalDays;
    return { ...r, lastInteractionDate: lastDate, daysSinceContact, intervalDays, dueForContact };
  });

  res.json(results.filter((r) => r.dueForContact).sort((a, b) => (b.daysSinceContact || 9999) - (a.daysSinceContact || 9999)));
});

// ---------- 重要日期 (比生日更通用：紀念日、對方特殊的日子，可以不綁定聯絡人) ----------
router.get('/important-dates', requireAuth, (req, res) => {
  const db = getDb();
  const rows = db
    .prepare(
      `SELECT d.*, r.name as relationship_name FROM important_dates d
       LEFT JOIN relationships r ON r.id = d.relationship_id
       WHERE d.user_id = ? ORDER BY d.month_day ASC`
    )
    .all(req.session.userId);
  res.json(rows);
});

router.post('/important-dates', requireAuth, (req, res) => {
  const { label, monthDay, relationshipId, note } = req.body || {};
  if (!label || !String(label).trim()) return res.status(400).json({ error: '請提供日期名稱' });
  if (!monthDay || !/^\d{2}-\d{2}$/.test(monthDay)) return res.status(400).json({ error: '日期請用 MM-DD 格式 (例如 03-15)' });
  const db = getDb();
  const now = new Date().toISOString();
  const result = db.prepare('INSERT INTO important_dates (user_id, relationship_id, label, month_day, note, created_at) VALUES (?, ?, ?, ?, ?, ?)').run(
    req.session.userId, relationshipId || null, String(label).trim(), monthDay, note || null, now
  );
  res.json({ id: result.lastInsertRowid, ok: true });
});

router.delete('/important-dates/:id', requireAuth, (req, res) => {
  const db = getDb();
  db.prepare('DELETE FROM important_dates WHERE id = ? AND user_id = ?').run(req.params.id, req.session.userId);
  res.json({ ok: true });
});

// 未來 30 天內的重要日期 (跟生日用同一套跨年邏輯)
router.get('/important-dates/upcoming', requireAuth, (req, res) => {
  const db = getDb();
  const rows = db
    .prepare(
      `SELECT d.*, r.name as relationship_name FROM important_dates d
       LEFT JOIN relationships r ON r.id = d.relationship_id
       WHERE d.user_id = ?`
    )
    .all(req.session.userId);
  const withDays = rows.map((r) => ({ ...r, daysUntil: daysUntilMonthDay(r.month_day) }));

  res.json(withDays.filter((r) => r.daysUntil <= 30).sort((a, b) => a.daysUntil - b.daysUntil));
});

// v0.68：#14 人際重要日期季節聚集提醒——把生日 + 重要日期依「月份」分組，找出哪幾個月
// 特別密集 (次數 >= 平均的 1.5 倍，且至少 2 筆才有意義)，並標出「接下來 60 天內」有沒有
// 剛好進入某個密集月份，提前提醒使用者那個月可能要多留意人情往來 (禮物/聚餐等)。
router.get('/date-clusters', requireAuth, (req, res) => {
  const db = getDb();
  const userId = req.session.userId;
  const birthdays = db.prepare("SELECT name, birthday as month_day FROM relationships WHERE user_id = ? AND birthday IS NOT NULL").all(userId);
  const importantDates = db
    .prepare(`SELECT label, month_day, relationship_id FROM important_dates WHERE user_id = ?`)
    .all(userId);

  const all = [
    ...birthdays.map((b) => ({ label: `${b.name}的生日`, monthDay: b.month_day })),
    ...importantDates.map((d) => ({ label: d.label, monthDay: d.month_day })),
  ];

  if (all.length < 3) {
    return res.json({ hasEnoughData: false, note: '目前記錄的生日/重要日期還不夠多 (至少需要 3 筆)。' });
  }

  const countByMonth = Array(12).fill(0);
  const itemsByMonth = Array.from({ length: 12 }, () => []);
  all.forEach((d) => {
    const month = Number(d.monthDay.split('-')[0]) - 1;
    if (month < 0 || month > 11) return;
    countByMonth[month]++;
    itemsByMonth[month].push(d.label);
  });
  const avg = all.length / 12;
  const busyMonths = countByMonth
    .map((count, idx) => ({ month: idx + 1, count, items: itemsByMonth[idx] }))
    .filter((m) => m.count >= 2 && m.count >= avg * 1.5)
    .sort((a, b) => b.count - a.count);

  // 接下來 60 天內，會不會進入某個密集月份
  const today = new Date();
  const upcomingBusyMonths = [];
  for (let i = 0; i <= 60; i += 30) {
    const d = new Date(today); d.setDate(d.getDate() + i);
    const m = d.getMonth() + 1;
    const match = busyMonths.find((bm) => bm.month === m);
    if (match && !upcomingBusyMonths.find((u) => u.month === m)) upcomingBusyMonths.push(match);
  }

  res.json({ hasEnoughData: true, busyMonths, upcomingBusyMonths, disclaimer: '依你目前記錄的生日/重要日期做簡單分組統計，記錄越完整參考價值越高。' });
});

module.exports = router;
