const { Router } = require('../mini-http');
const { getDb } = require('../services/db');
const { requireAuth } = require('../middleware/auth');

const router = Router();

function currentPeriod() { return new Date(Date.now() + 8 * 3600 * 1000).toISOString().slice(0, 7); } // YYYY-MM (台灣時間，v0.88)

router.get('/', requireAuth, (req, res) => {
  const db = getDb();
  const rows = db.prepare('SELECT * FROM bills WHERE user_id = ? AND active = 1 ORDER BY due_day ASC').all(req.session.userId);
  res.json(rows);
});

router.post('/', requireAuth, (req, res) => {
  const { name, amount, dueDay, category, note } = req.body || {};
  const amountNum = Number(amount);
  const dueDayNum = Number(dueDay);
  if (!name || !String(name).trim() || Number.isNaN(amountNum) || amountNum <= 0 || !Number.isInteger(dueDayNum) || dueDayNum < 1 || dueDayNum > 31) {
    return res.status(400).json({ error: '請提供名稱、有效金額、1-31 的到期日' });
  }
  const db = getDb();
  const now = new Date().toISOString();
  const result = db.prepare('INSERT INTO bills (user_id, name, amount, due_day, category, note, active, created_at) VALUES (?, ?, ?, ?, ?, ?, 1, ?)').run(
    req.session.userId, String(name).trim(), amountNum, dueDayNum, category || null, note || null, now
  );
  res.json({ id: result.lastInsertRowid, ok: true });
});

router.delete('/:id', requireAuth, (req, res) => {
  const db = getDb();
  db.prepare('UPDATE bills SET active = 0 WHERE id = ? AND user_id = ?').run(req.params.id, req.session.userId);
  res.json({ ok: true });
});

// 這個月是否已繳：用 (bill_id, paid_period) 當 key
// v0.88：標記已繳時自動記一筆支出 (帳單已經知道金額和名稱，不用再去記帳頁重打一次)。
// 對應的記帳 id 存在 bill_payments.finance_tx_id；取消標記時只刪這一筆自動記的，
// 使用者自己手動記的帳不會被動到。重複標記同一期只會更新金額，不會記兩筆。
const FINANCE_CATEGORIES = ['餐飲', '交通', '娛樂', '購物', '居家', '醫療', '教育', '其他'];
function billFinanceCategory(cat) {
  if (cat && FINANCE_CATEGORIES.includes(cat)) return cat;
  if (/電|水|瓦斯|房租|管理費|網路|電話|手機/.test(cat || '')) return '居家';
  if (/保險|醫/.test(cat || '')) return '醫療';
  if (/訂閱|netflix|spotify|youtube/i.test(cat || '')) return '娛樂';
  return '居家';
}
function twToday() { return new Date(Date.now() + 8 * 3600 * 1000).toISOString().slice(0, 10); }

router.post('/:id/mark-paid', requireAuth, (req, res) => {
  const db = getDb();
  const bill = db.prepare('SELECT id, name, amount, category FROM bills WHERE id = ? AND user_id = ?').get(req.params.id, req.session.userId);
  if (!bill) return res.status(404).json({ error: '找不到這筆帳單' });
  const period = (req.body && req.body.period) || currentPeriod();
  const now = new Date().toISOString();
  // v0.66：標記已繳時可以順便填「這次實際繳了多少錢」(選填，不填就當作跟帳單設定的金額
  // 一樣)，用來累積歷史金額，之後才有辦法比對「這次是不是異常升高」(見 GET /:id/amount-check)。
  const amount = req.body && req.body.amount !== undefined && req.body.amount !== null && req.body.amount !== ''
    ? Number(req.body.amount)
    : bill.amount;
  const autoRecord = !(req.body && req.body.autoRecord === false);
  db.prepare(
    `INSERT INTO bill_payments (user_id, bill_id, paid_period, paid_at, amount) VALUES (?, ?, ?, ?, ?)
     ON CONFLICT(bill_id, paid_period) DO UPDATE SET paid_at = excluded.paid_at, amount = excluded.amount`
  ).run(req.session.userId, req.params.id, period, now, amount);
  let recorded = null;
  if (autoRecord && amount > 0) {
    try {
      const pay = db.prepare('SELECT id, finance_tx_id FROM bill_payments WHERE bill_id = ? AND paid_period = ?').get(req.params.id, period);
      const existing = pay && pay.finance_tx_id
        ? db.prepare('SELECT id FROM finance_transactions WHERE id = ? AND user_id = ?').get(pay.finance_tx_id, req.session.userId)
        : null;
      if (existing) {
        db.prepare('UPDATE finance_transactions SET amount = ? WHERE id = ?').run(amount, existing.id);
        recorded = { id: existing.id, amount, updated: true };
      } else {
        const category = billFinanceCategory(bill.category);
        const info = db.prepare(
          'INSERT INTO finance_transactions (user_id, tx_date, type, category, amount, note, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)'
        ).run(req.session.userId, twToday(), 'expense', category, amount, `帳單：${bill.name}`, now);
        db.prepare('UPDATE bill_payments SET finance_tx_id = ? WHERE id = ?').run(info.lastInsertRowid, pay.id);
        recorded = { id: info.lastInsertRowid, amount, category };
      }
    } catch (e) { /* migration 還沒套用時就只標記已繳，不影響原本功能 */ }
  }
  res.json({ ok: true, recorded });
});

router.post('/:id/mark-unpaid', requireAuth, (req, res) => {
  const db = getDb();
  const period = (req.body && req.body.period) || currentPeriod();
  let removedTx = false;
  try {
    const pay = db.prepare('SELECT finance_tx_id FROM bill_payments WHERE bill_id = ? AND user_id = ? AND paid_period = ?').get(req.params.id, req.session.userId, period);
    if (pay && pay.finance_tx_id) {
      removedTx = db.prepare('DELETE FROM finance_transactions WHERE id = ? AND user_id = ?').run(pay.finance_tx_id, req.session.userId).changes > 0;
    }
  } catch (e) { /* ignore */ }
  db.prepare('DELETE FROM bill_payments WHERE bill_id = ? AND user_id = ? AND paid_period = ?').run(req.params.id, req.session.userId, period);
  res.json({ ok: true, removedTx });
});

// 這個月的帳單總覽：每筆帳單附上「這個月繳了沒」、「距離到期還有幾天 (負數代表已過期)」
router.get('/upcoming', requireAuth, (req, res) => {
  const db = getDb();
  const period = req.query.period || currentPeriod();
  const bills = db.prepare('SELECT * FROM bills WHERE user_id = ? AND active = 1 ORDER BY due_day ASC').all(req.session.userId);
  const payments = db.prepare('SELECT bill_id FROM bill_payments WHERE user_id = ? AND paid_period = ?').all(req.session.userId, period);
  const paidSet = new Set(payments.map((p) => p.bill_id));

  const today = new Date();
  const todayDay = today.getUTCDate();

  const result = bills.map((b) => ({
    ...b,
    paid: paidSet.has(b.id),
    daysUntilDue: b.due_day - todayDay,
  }));
  const totalUnpaid = result.filter((b) => !b.paid).reduce((s, b) => s + b.amount, 0);
  res.json({ period, bills: result, totalUnpaid });
});

module.exports = router;
