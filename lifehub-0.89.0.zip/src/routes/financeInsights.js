// v0.87：記帳頁頂端的「事實摘要」——把已經記過的帳自動整理成一兩句看得懂的結論。
// 不需要多記錄任何東西 (零記錄成本)，只講數字、不評論花得好不好 (只講事實)。
// 比較基準是「上個月同一段期間」(例如今天 29 號，就比 1~29 號)，月初跟月底比才公平。
const { Router } = require('../mini-http');
const { getDb } = require('../services/db');
const { requireAuth } = require('../middleware/auth');

const router = Router();

function twToday() {
  const t = new Date(Date.now() + 8 * 60 * 60 * 1000);
  return { y: t.getUTCFullYear(), m: t.getUTCMonth() + 1, d: t.getUTCDate() };
}
const pad = (n) => String(n).padStart(2, '0');
const fmt = (n) => 'NT$' + Math.round(n).toLocaleString('en-US');

function buildInsights(rowsThis, rowsLast) {
  const sum = (rows) => rows.reduce((s, r) => s + r.amount, 0);
  const byCat = (rows) => rows.reduce((m, r) => { m[r.category] = (m[r.category] || 0) + r.amount; return m; }, {});
  const lines = [];
  if (rowsThis.length < 3) return lines;
  const totalThis = sum(rowsThis), totalLast = sum(rowsLast);
  if (rowsLast.length) {
    const diff = totalThis - totalLast;
    if (Math.abs(diff) < 1) lines.push(`這個月到今天支出 ${fmt(totalThis)}，跟上個月同期差不多`);
    else lines.push(`這個月到今天支出 ${fmt(totalThis)}，比上個月同期${diff > 0 ? '多' : '少'} ${fmt(Math.abs(diff))}`);
    const ct = byCat(rowsThis), cl = byCat(rowsLast);
    let best = null;
    Object.keys(ct).forEach((c) => { const inc = ct[c] - (cl[c] || 0); if (inc > 0 && (!best || inc > best.inc)) best = { c, inc }; });
    if (best && best.inc >= 100) lines.push(`增加最多的是「${best.c}」，多了 ${fmt(best.inc)}`);
  } else {
    lines.push(`這個月到今天支出 ${fmt(totalThis)}`);
  }
  const ct = byCat(rowsThis);
  const top = Object.entries(ct).sort((a, b) => b[1] - a[1])[0];
  if (top && totalThis > 0) lines.push(`最大的支出分類是「${top[0]}」，佔 ${Math.round((top[1] / totalThis) * 100)}%`);
  return lines.slice(0, 3);
}

router.get('/finance-insights', requireAuth, (req, res) => {
  const db = getDb();
  const t = twToday();
  const thisFrom = `${t.y}-${pad(t.m)}-01`, thisTo = `${t.y}-${pad(t.m)}-${pad(t.d)}`;
  const lm = t.m === 1 ? { y: t.y - 1, m: 12 } : { y: t.y, m: t.m - 1 };
  const lastDays = new Date(Date.UTC(lm.y, lm.m, 0)).getUTCDate();
  const lastFrom = `${lm.y}-${pad(lm.m)}-01`, lastTo = `${lm.y}-${pad(lm.m)}-${pad(Math.min(t.d, lastDays))}`;
  const q = db.prepare("SELECT category, amount FROM finance_transactions WHERE user_id = ? AND type = 'expense' AND tx_date BETWEEN ? AND ?");
  const lines = buildInsights(q.all(req.session.userId, thisFrom, thisTo), q.all(req.session.userId, lastFrom, lastTo));
  res.json({ lines });
});

module.exports = router;
module.exports.buildInsights = buildInsights;
