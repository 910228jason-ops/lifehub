// v0.87：早安摘要推播的開關與預覽。由 src/routes/debug.js 併進 /api (不動 server.js)，
// 被 require 時順便啟動排程 (見 src/services/morningBrief.js)。
const { Router } = require('../mini-http');
const { getDb } = require('../services/db');
const { requireAuth } = require('../middleware/auth');
const brief = require('../services/morningBrief');

const router = Router();

router.get('/morning-brief', requireAuth, (req, res) => {
  const db = getDb();
  let row = null;
  try { row = db.prepare('SELECT push_morning_brief, quiet_hours_end FROM user_prefs WHERE user_id = ?').get(req.session.userId); } catch (e) { /* ignore */ }
  res.json({
    enabled: !!(row && row.push_morning_brief),
    sendAt: (row && row.quiet_hours_end) || '10:00',
    preview: brief.computeBrief(db, req.session.userId),
  });
});

router.put('/morning-brief', requireAuth, (req, res) => {
  const enabled = !!(req.body && req.body.enabled);
  try {
    getDb().prepare('UPDATE user_prefs SET push_morning_brief = ? WHERE user_id = ?').run(enabled ? 1 : 0, req.session.userId);
  } catch (e) { return res.status(500).json({ error: '儲存失敗' }); }
  res.json({ ok: true, enabled });
});

module.exports = router;
