// v0.87：每天早上一則「今天」摘要推播 (預設關閉，設定頁開啟)。
//
// 內容只講事實、不解讀 (設計原則 2)，而且全部來自已經存在的資料 (原則 1：零記錄成本)：
//   今天到期/已逾期的待辦、3 天內要繳但還沒標記繳過的帳單、今天的行程。
// 什麼都沒有的那天就不推 (不送「今天沒有事」這種空通知)。
// 推播時間 = 使用者自己設定的「靜音時段結束時間」(預設 10:00，台灣時間)，靜音時段的設定
// 本來就是「這個時間之後才可以打擾我」，不另外再多一個時間設定。
// 這個檔案由 src/routes/morningBrief.js 被 require 時啟動排程，不動 server.js。

const { getDb } = require('./db');
const logger = require('./logger');
const { sendNotification } = require('./webpush');

const CHECK_INTERVAL_MS = 5 * 60 * 1000;
const LATEST_HOUR_TW = 14; // 伺服器剛好停機錯過的話，下午 2 點以後就不補送了

function twNow(d = new Date()) {
  const t = new Date(d.getTime() + 8 * 60 * 60 * 1000);
  return { ymd: t.toISOString().slice(0, 10), ym: t.toISOString().slice(0, 7), day: t.getUTCDate(), minutes: t.getUTCHours() * 60 + t.getUTCMinutes(), hour: t.getUTCHours() };
}
function addDaysYmd(ymd, n) {
  return new Date(Date.parse(ymd + 'T00:00:00Z') + n * 86400000).toISOString().slice(0, 10);
}
function hhmmToMin(s, fb) {
  const m = typeof s === 'string' && s.match(/^(\d{1,2}):(\d{2})$/);
  return m ? Number(m[1]) * 60 + Number(m[2]) : fb;
}

function computeBrief(db, userId, today = twNow()) {
  const lines = [];
  let dueToday = [], overdue = 0;
  try {
    dueToday = db.prepare('SELECT title FROM tasks WHERE user_id = ? AND completed = 0 AND due_date = ? ORDER BY CASE priority WHEN \'high\' THEN 0 WHEN \'medium\' THEN 1 ELSE 2 END').all(userId, today.ymd);
    overdue = db.prepare('SELECT COUNT(*) AS c FROM tasks WHERE user_id = ? AND completed = 0 AND due_date IS NOT NULL AND due_date < ?').get(userId, today.ymd).c;
  } catch (e) { /* 表不存在就略過 */ }
  if (dueToday.length || overdue) {
    const parts = [];
    if (dueToday.length) parts.push(`今天到期 ${dueToday.length} 件 (${dueToday.slice(0, 2).map((t) => t.title).join('、')}${dueToday.length > 2 ? '…' : ''})`);
    if (overdue) parts.push(`已逾期 ${overdue} 件`);
    lines.push('✅ 待辦：' + parts.join('，'));
  }
  try {
    const bills = db.prepare('SELECT id, name, amount, due_day FROM bills WHERE user_id = ? AND active = 1').all(userId);
    const paid = new Set(db.prepare('SELECT bill_id FROM bill_payments WHERE user_id = ? AND paid_period = ?').all(userId, today.ym).map((r) => r.bill_id));
    const soon = bills.filter((b) => !paid.has(b.id) && b.due_day >= today.day && b.due_day - today.day <= 3);
    if (soon.length) {
      lines.push('🧾 帳單：' + soon.slice(0, 2).map((b) => `${b.name} ${b.due_day === today.day ? '今天' : `${b.due_day - today.day} 天後`}到期`).join('、') + (soon.length > 2 ? ` 等 ${soon.length} 筆` : ''));
    }
  } catch (e) { /* ignore */ }
  try {
    const events = db.prepare('SELECT title, start_time FROM calendar_events WHERE user_id = ? AND event_date = ? ORDER BY COALESCE(start_time, \'99:99\')').all(userId, today.ymd);
    if (events.length) {
      const first = events[0];
      lines.push(`📅 行程：今天 ${events.length} 個${first.start_time ? `，第一個 ${first.start_time} ${first.title}` : `：${first.title}`}`);
    }
  } catch (e) { /* ignore */ }
  return lines;
}

async function runForUser(db, row, now) {
  const lines = computeBrief(db, row.user_id, now);
  db.prepare('UPDATE user_prefs SET morning_brief_last_date = ? WHERE user_id = ?').run(now.ymd, row.user_id);
  if (!lines.length) return 0;
  const subs = db.prepare('SELECT * FROM push_subscriptions WHERE user_id = ?').all(row.user_id);
  let sent = 0;
  for (const sub of subs) {
    try {
      const r = await sendNotification(db, sub, { title: '今天', body: lines.join('\n') });
      if (r && r.ok) sent++;
      else if (r && (r.status === 404 || r.status === 410)) db.prepare('DELETE FROM push_subscriptions WHERE id = ?').run(sub.id);
    } catch (e) { /* 單一裝置失敗不影響其他裝置 */ }
  }
  return sent;
}

async function tick() {
  const db = getDb();
  const now = twNow();
  if (now.hour >= LATEST_HOUR_TW) return;
  let rows = [];
  try {
    rows = db.prepare('SELECT user_id, quiet_hours_end, morning_brief_last_date FROM user_prefs WHERE push_morning_brief = 1').all();
  } catch (e) { return; } // migration 還沒套用
  for (const row of rows) {
    if (row.morning_brief_last_date === now.ymd) continue;
    if (now.minutes < hhmmToMin(row.quiet_hours_end, 10 * 60)) continue;
    try { await runForUser(db, row, now); } catch (e) { logger.error('[morningBrief] 推播失敗', { userId: row.user_id, message: e.message }); }
  }
}

if (!process.env.LIFEHUB_DISABLE_SCHEDULERS) {
  const timer = setInterval(() => tick().catch(() => {}), CHECK_INTERVAL_MS);
  timer.unref();
}

module.exports = { computeBrief, twNow, tick };
