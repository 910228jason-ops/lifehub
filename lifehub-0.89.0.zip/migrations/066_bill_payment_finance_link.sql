-- v0.88.0：帳單標記「已繳」時自動記一筆支出，這裡記下對應的記帳紀錄 id，
-- 取消標記時才能把同一筆自動記的支出一起刪掉 (不會動到使用者自己手動記的帳)。
ALTER TABLE bill_payments ADD COLUMN finance_tx_id INTEGER;
