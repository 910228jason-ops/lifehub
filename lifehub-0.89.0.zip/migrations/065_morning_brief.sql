-- v0.87.0：每天早上「今天」摘要推播。跟其他敏感/非必要推播一樣「預設關閉、使用者自己決定」。
-- morning_brief_last_date 記錄 (台北時間) 哪一天已經送過，避免同一天重複推播。
ALTER TABLE user_prefs ADD COLUMN push_morning_brief INTEGER NOT NULL DEFAULT 0;
ALTER TABLE user_prefs ADD COLUMN morning_brief_last_date TEXT;
