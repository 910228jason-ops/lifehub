#!/usr/bin/env node
// v0.89：發版前的自動檢查。只用 Node 內建模組，不需要 npm 套件、不需要瀏覽器。
//
// 用法 (在專案根目錄，或在「把要出的 zip 解壓出來的全新資料夾」裡)：
//   node scripts/smoke-test.js
//
// 會做的事：
// 1. `node --check` 所有後端 .js，並把前端 app.js / sw.js 當成 script 編譯一次 (抓語法錯誤)。
// 2. 用暫存資料庫在隨機 port 啟動一份伺服器 (不碰 data/app.db、不跑異地備份)，註冊一個測試帳號。
// 3. 從 src/routes/*.js 自動找出所有「不帶參數」的 GET API，逐一打一次：不能回 5xx、要能解析成 JSON。
//    需要外部網路的 (交通、旅遊、AI、地點) 回 5xx 只列為警告，因為本機可能沒有金鑰或網路。
// 4. 首頁、app.js、style.css、sw.js、manifest.json 要能拿到；/api/health 的版本號要等於 package.json。
// 5. 功能檢查：生日倒數用台灣時間算 (今天 = 0)、異地備份的「還原驗證」能抓出被竄改的檔案。
//
// 全部通過 exit code 0；有任何失敗 exit code 1，最後列出失敗清單。
'use strict';
const fs = require('fs');
const os = require('os');
const path = require('path');
const vm = require('vm');
const zlib = require('zlib');
const crypto = require('crypto');
const { spawn, spawnSync } = require('child_process');

const ROOT = path.join(__dirname, '..');
const PKG = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
// 會連外部服務的 API：本機沒有金鑰/網路時 5xx 是正常的，只警告不算失敗。
const EXTERNAL_PREFIXES = ['/api/travel', '/api/assistant', '/api/places', '/api/transit', '/api/tdx', '/api/flights', '/api/tarot/ai'];
// 會改資料或觸發外部動作的 GET (少數舊 API 用 GET 做事)，不要打。
const SKIP_PATHS = new Set(['/api/auth/logout']);

const failures = [];
const warnings = [];
let passed = 0;
function ok(msg) { passed++; console.log(`  ✓ ${msg}`); }
function fail(msg) { failures.push(msg); console.log(`  ✗ ${msg}`); }
function warn(msg) { warnings.push(msg); console.log(`  ! ${msg}`); }

function listJs(dir) {
  const out = [];
  for (const ent of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, ent.name);
    if (ent.isDirectory()) { if (ent.name !== 'node_modules') out.push(...listJs(p)); } else if (ent.name.endsWith('.js')) out.push(p);
  }
  return out;
}

// ---------- 1. 語法 ----------
function checkSyntax() {
  console.log('\n[1] 語法檢查');
  const files = [path.join(ROOT, 'server.js'), ...listJs(path.join(ROOT, 'src')), ...listJs(path.join(ROOT, 'scripts'))];
  let bad = 0;
  for (const f of files) {
    const r = spawnSync(process.execPath, ['--check', f], { encoding: 'utf8' });
    if (r.status !== 0) { bad++; fail(`node --check ${path.relative(ROOT, f)}\n${r.stderr.trim()}`); }
  }
  if (!bad) ok(`後端 ${files.length} 個 .js 語法正確`);
  for (const rel of ['public/js/app.js', 'public/sw.js']) {
    try { new vm.Script(fs.readFileSync(path.join(ROOT, rel), 'utf8'), { filename: rel }); ok(`${rel} 可以編譯`); } catch (e) { fail(`${rel} 編譯失敗：${e.message}`); }
  }
}

// ---------- 從原始碼找出所有 GET 路由 ----------
function collectGetRoutes() {
  const serverSrc = fs.readFileSync(path.join(ROOT, 'server.js'), 'utf8');
  const prefixByFile = {};
  for (const m of serverSrc.matchAll(/app\.mount\('([^']+)',\s*require\('\.\/src\/routes\/([\w-]+)'\)\)/g)) prefixByFile[m[2]] = m[1];
  // debug.js 把其他 routes 檔併進 /api (require('./xxx').routes.forEach...)
  const debugSrc = fs.readFileSync(path.join(ROOT, 'src/routes/debug.js'), 'utf8');
  const apiPrefix = prefixByFile.debug || '/api';
  for (const m of debugSrc.matchAll(/require\('\.\/([\w-]+)'\)\.routes\.forEach/g)) prefixByFile[m[1]] = apiPrefix;
  const routes = [];
  for (const [file, prefix] of Object.entries(prefixByFile)) {
    const f = path.join(ROOT, 'src/routes', `${file}.js`);
    if (!fs.existsSync(f)) continue;
    const src = fs.readFileSync(f, 'utf8');
    for (const m of src.matchAll(/router\.get\(\s*'([^']+)'/g)) {
      if (m[1].includes(':') || m[1].includes('*')) continue;
      const p = (prefix + (m[1] === '/' ? '' : m[1])) || '/';
      if (!SKIP_PATHS.has(p)) routes.push(p);
    }
  }
  return [...new Set(routes)].sort();
}

// ---------- 啟動測試伺服器 ----------
function freePort() {
  return new Promise((resolve) => {
    const s = require('net').createServer();
    s.listen(0, '127.0.0.1', () => { const { port } = s.address(); s.close(() => resolve(port)); });
  });
}

async function startServer(tmpDir) {
  const port = await freePort();
  const logFile = path.join(tmpDir, 'server.log');
  const log = fs.openSync(logFile, 'w');
  const child = spawn(process.execPath, ['server.js'], {
    cwd: ROOT,
    env: {
      ...process.env,
      PORT: String(port),
      DB_PATH: path.join(tmpDir, 'app.db'),
      SESSION_SECRET: 'smoke-test',
      LIFEHUB_DISABLE_OFFSITE_BACKUP: '1',
      LIFEHUB_BOOT_OK_DELAY_MS: String(24 * 3600 * 1000), // 不要寫 .bootstrap 狀態
      GEMINI_API_KEY: '', ANTHROPIC_API_KEY: '',
    },
    stdio: ['ignore', log, log],
  });
  const base = `http://127.0.0.1:${port}`;
  for (let i = 0; i < 60; i++) {
    if (child.exitCode != null) break;
    try { const r = await fetch(base + '/api/health'); if (r.ok) return { child, base, logFile }; } catch (e) { /* 還沒好 */ }
    await new Promise((r) => setTimeout(r, 250));
  }
  child.kill();
  throw new Error(`伺服器 15 秒內沒有啟動，log：\n${fs.readFileSync(logFile, 'utf8').slice(-2000)}`);
}

function makeClient(base) {
  let cookie = '';
  return async function req(method, p, body) {
    const r = await fetch(base + p, {
      method,
      headers: { ...(cookie ? { Cookie: cookie } : {}), ...(body ? { 'Content-Type': 'application/json' } : {}) },
      body: body ? JSON.stringify(body) : undefined,
      signal: AbortSignal.timeout(10000),
    });
    const set = r.headers.getSetCookie ? r.headers.getSetCookie() : [];
    if (set.length) cookie = set.map((c) => c.split(';')[0]).join('; ');
    const text = await r.text();
    let json = null;
    try { json = text ? JSON.parse(text) : null; } catch (e) { /* 不是 JSON */ }
    return { status: r.status, text, json, type: r.headers.get('content-type') || '' };
  };
}

function taipeiMonthDay(offsetDays) {
  const d = new Date(Date.now() + 8 * 3600 * 1000 + offsetDays * 86400000);
  return d.toISOString().slice(5, 10);
}

async function checkServer() {
  console.log('\n[2] 啟動測試伺服器');
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'lifehub-smoke-'));
  const { child, base, logFile } = await startServer(tmpDir);
  ok(`伺服器在 ${base} 啟動 (暫存資料庫 ${tmpDir})`);
  const req = makeClient(base);
  try {
    const h = await req('GET', '/api/health');
    if (h.json && h.json.version === PKG.version) ok(`/api/health 版本 ${h.json.version} = package.json`);
    else fail(`/api/health 版本 ${h.json && h.json.version} ≠ package.json ${PKG.version}`);

    console.log('\n[3] 靜態檔案');
    for (const p of ['/', '/js/app.js', '/css/style.css', '/sw.js', '/manifest.json']) {
      const r = await req('GET', p);
      if (r.status === 200 && r.text.length > 0) ok(`${p} (${r.text.length} 字元)`); else fail(`${p} 回 ${r.status}`);
    }

    const email = `smoke-${Date.now()}@example.test`;
    const reg = await req('POST', '/api/auth/register', { email, password: 'smoke-test-123', name: '測試' });
    if (reg.status >= 400) throw new Error(`註冊測試帳號失敗：${reg.status} ${reg.text.slice(0, 200)}`);
    await req('POST', '/api/auth/login', { email, password: 'smoke-test-123' });
    const me = await req('GET', '/api/auth/me');
    if (me.status !== 200) throw new Error(`登入後 /api/auth/me 回 ${me.status}`);
    ok('註冊並登入測試帳號');

    console.log('\n[4] 所有不帶參數的 GET API');
    const routes = collectGetRoutes();
    for (const p of routes) {
      let r;
      try { r = await req('GET', p); } catch (e) { r = { status: 0, text: e.message, type: '' }; }
      const external = EXTERNAL_PREFIXES.some((x) => p.startsWith(x));
      if (r.status >= 500 || r.status === 0) {
        (external ? warn : fail)(`${p} 回 ${r.status || '逾時'}${external ? ' (需要外部服務)' : ''}：${r.text.slice(0, 120)}`);
      } else if (r.type.includes('application/json') && r.json === null && r.text) {
        fail(`${p} 宣稱是 JSON 但解析失敗`);
      }
    }
    ok(`打過 ${routes.length} 個 GET API`);

    console.log('\n[5] 生日倒數 (台灣時間)');
    await req('POST', '/api/relationships', { name: '今天壽星', birthday: taipeiMonthDay(0) });
    await req('POST', '/api/relationships', { name: '五天後', birthday: taipeiMonthDay(5) });
    await req('POST', '/api/relationships', { name: '一個月後', birthday: taipeiMonthDay(30) });
    const up = await req('GET', '/api/relationships/upcoming-dates?days=14&limit=3');
    const got = (up.json || []).map((x) => `${x.label}:${x.daysUntil}`).join(', ');
    if (got === '今天壽星的生日:0, 五天後的生日:5') ok(`upcoming-dates → ${got}`);
    else fail(`upcoming-dates 預期「今天壽星的生日:0, 五天後的生日:5」，實際「${got}」`);

    const serverErrors = fs.readFileSync(logFile, 'utf8').split('\n').filter((l) => /TypeError|ReferenceError|SyntaxError|Unhandled/.test(l));
    if (serverErrors.length) fail(`伺服器 log 有程式錯誤：\n    ${serverErrors.slice(0, 5).join('\n    ')}`);
    else ok('伺服器 log 沒有程式錯誤');
  } finally {
    child.kill();
  }
  return tmpDir;
}

// ---------- 異地備份的還原驗證 (不連 GCS，只測加解密跟檢查邏輯) ----------
function checkBackupVerify(tmpDir) {
  console.log('\n[6] 異地備份還原驗證');
  process.env.DB_PATH = path.join(tmpDir, 'app.db');
  process.env.LIFEHUB_DISABLE_OFFSITE_BACKUP = '1';
  process.env.BACKUP_KEY = crypto.randomBytes(32).toString('base64');
  const offsite = require(path.join(ROOT, 'src/services/offsiteBackup'));
  const { DatabaseSync } = require('node:sqlite');
  const key = Buffer.from(process.env.BACKUP_KEY, 'base64');
  const dbFile = path.join(tmpDir, 'app.db');
  const db = new DatabaseSync(dbFile);
  const counts = offsite.tableCounts(db);
  db.close();
  const payload = offsite.encrypt(zlib.gzipSync(fs.readFileSync(dbFile)), key);
  try { offsite.verifyRestorable(payload, payload, key, counts); ok(`正常備份可以還原 (${Object.keys(counts).length} 張資料表筆數一致)`); } catch (e) { fail(`正常備份驗證失敗：${e.message}`); }
  const tampered = Buffer.from(payload); tampered[tampered.length - 1] ^= 1;
  try { offsite.verifyRestorable(tampered, payload, key, counts); fail('被竄改的檔案沒有被抓到'); } catch (e) { ok(`抓到被竄改的檔案：${e.message}`); }
  try { offsite.verifyRestorable(payload, payload, crypto.randomBytes(32), counts); fail('錯的金鑰沒有被抓到'); } catch (e) { ok(`抓到錯的金鑰：${e.message}`); }
  const wrongCounts = { ...counts, tasks: (counts.tasks || 0) + 1 };
  try { offsite.verifyRestorable(payload, payload, key, wrongCounts); fail('筆數不一致沒有被抓到'); } catch (e) { ok(`抓到筆數不一致：${e.message}`); }
}

(async () => {
  console.log(`LifeHub ${PKG.version} 發版前檢查 (Node ${process.version})`);
  checkSyntax();
  let tmpDir = null;
  try { tmpDir = await checkServer(); } catch (e) { fail(e.message); }
  if (tmpDir) { try { checkBackupVerify(tmpDir); } catch (e) { fail(`還原驗證檢查無法執行：${e.message}`); } }
  console.log(`\n結果：${passed} 項通過、${failures.length} 項失敗、${warnings.length} 項警告`);
  if (failures.length) { console.log('\n失敗：'); failures.forEach((f) => console.log(`  - ${f.split('\n')[0]}`)); }
  if (tmpDir) fs.rmSync(tmpDir, { recursive: true, force: true });
  process.exit(failures.length ? 1 : 0);
})();
