// /api/debug 與 /api/health
// 目的：讓「以後持續推出版本更新」時，你或未來的工程團隊可以快速確認：
//   1. 現在跑的是哪個版本 (package.json version + migration 版本)
//   2. 外部資料源 (證交所 / TDX / 機票 Provider) 現在連得上嗎
//   3. 最近有沒有錯誤日誌
// /api/debug 需要帶 Header: X-Debug-Token，值需與 .env 的 DEBUG_TOKEN 相同，
// 避免任何人都能看到系統內部狀態。

const { Router } = require('../mini-http');
const pkg = require('../../package.json');
const { getDb } = require('../services/db');
const twse = require('../services/twse');
const tdx = require('../services/tdx');
const flights = require('../services/flights');
const marketExtras = require('../services/marketExtras');
const assistant = require('../services/assistant');

const router = Router();

// 意見回饋 (/api/feedback) 的路由定義在獨立檔案 src/routes/feedback.js，
// 但因為部署流程刻意不去動 server.js (不會多加一行 app.mount)，這裡直接把
// 它的 routes 併進這個已經掛在 /api 的 router，效果等同於單獨掛載在 /api/feedback。
require('./feedback').routes.forEach((route) => router.routes.push(route));

// 跨模組洞察／主動式提醒 (/api/insights) 比照上面 feedback 的做法，同樣不新增 app.mount()。
require('./insights').routes.forEach((route) => router.routes.push(route));

// 家人/伴侶帳號連結 (/api/partner-link) 同樣比照辦理，不新增 app.mount()。
require('./partnerLink').routes.forEach((route) => router.routes.push(route));

// 背景推播通知 (/api/push) 同樣比照辦理；這支檔案被 require 時也會順便啟動背景排程。
require('./push').routes.forEach((route) => router.routes.push(route));

// 家庭公告欄 (/api/family-board) 同樣比照辦理，不新增 app.mount()。
require('./familyBoard').routes.forEach((route) => router.routes.push(route));

// 遊戲化點數 + 獎勵兌換 (/api/points) 同樣比照辦理，不新增 app.mount()。
require('./points').routes.forEach((route) => router.routes.push(route));

// 讀書：閱讀/戲劇進度追蹤 (/api/reading) 同樣比照辦理，不新增 app.mount()。
require('./reading').routes.forEach((route) => router.routes.push(route));

// 習慣養成 (/api/habits) 同樣比照辦理，不新增 app.mount()。
require('./habits').routes.forEach((route) => router.routes.push(route));

// 個人筆記 (/api/notes) 同樣比照辦理，不新增 app.mount()。
require('./notes').routes.forEach((route) => router.routes.push(route));

// 願望清單 (/api/wishlist) 同樣比照辦理，不新增 app.mount()。
require('./wishlist').routes.forEach((route) => router.routes.push(route));

// 年度回顧 (/api/annual-review) 同樣比照辦理，不新增 app.mount()。
require('./annualReview').routes.forEach((route) => router.routes.push(route));

// 揪團分帳 (/api/split-groups) 同樣比照辦理，不新增 app.mount()。
require('./splitGroups').routes.forEach((route) => router.routes.push(route));

// 專案看板 (/api/kanban-boards) 同樣比照辦理，不新增 app.mount()。
require('./kanban').routes.forEach((route) => router.routes.push(route));

router.get('/health', (req, res) => {
  res.json({ status: 'ok', version: pkg.version, uptimeSec: Math.round(process.uptime()) });
});

router.get('/debug', async (req, res) => {
  const token = req.headers['x-debug-token'];
  if (!process.env.DEBUG_TOKEN || token !== process.env.DEBUG_TOKEN) {
    return res.status(403).json({ error: '缺少或錯誤的 X-Debug-Token' });
  }

  const db = getDb();
  const counts = {
    users: db.prepare('SELECT COUNT(*) c FROM users').get().c,
    diary_entries: db.prepare('SELECT COUNT(*) c FROM diary_entries').get().c,
    finance_transactions: db.prepare('SELECT COUNT(*) c FROM finance_transactions').get().c,
    calendar_events: db.prepare('SELECT COUNT(*) c FROM calendar_events').get().c,
    favorite_trains: db.prepare('SELECT COUNT(*) c FROM favorite_trains').get().c,
  };
  const migrations = db.prepare('SELECT version, applied_at FROM schema_migrations ORDER BY version').all();
  const recentLogs = db
    .prepare('SELECT level, message, meta_json, created_at FROM app_logs ORDER BY id DESC LIMIT 30')
    .all();

  const [twseHealth, tdxHealth, marketExtrasHealth] = await Promise.all([
    twse.healthcheck(),
    tdx.healthcheck(),
    marketExtras.healthcheck(),
  ]);

  res.json({
    version: pkg.version,
    nodeEnv: process.env.NODE_ENV || 'development',
    uptimeSec: Math.round(process.uptime()),
    dbCounts: counts,
    migrationsApplied: migrations,
    externalDataSources: {
      twse: twseHealth,
      tdx: tdxHealth,
      flights: flights.healthcheck(),
      marketExtras: marketExtrasHealth,
      assistant: assistant.healthcheck(),
    },
    recentLogs,
  });
});

module.exports = router;
