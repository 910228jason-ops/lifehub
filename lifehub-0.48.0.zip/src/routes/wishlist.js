// 願望清單 (v0.47)。個人清單 (不像家庭公告欄共用圈子)：想要的東西、優先度、價格、連結，
// 完成 (買到/實現了) 就打勾，不會被刪除、只是排到清單最後面方便回顧。

const { Router } = require('../mini-http');
const { getDb } = require('../services/db');
const { requireAuth } = require('../middleware/auth');

const router = Router();

const VALID_PRIORITIES = new Set(['low', 'medium', 'high']);
const PRIORITY_RANK = { high: 0, medium: 1, low: 2 };

router.get('/wishlist', requireAuth, (req, res) => {
  const db = getDb();
  const rows = db
    .prepare('SELECT * FROM wishlist_items WHERE user_id = ? ORDER BY completed ASC, updated_at DESC')
    .all(req.session.userId);
  // 優先度排序 (high > medium > low) 在 JS 這邊做，SQL 用文字排序會是字母序 (high, low, medium)，不對。
  rows.sort((a, b) => {
    if (a.completed !== b.completed) return a.completed - b.completed;
    const pr = (PRIORITY_RANK[a.priority] ?? 1) - (PRIORITY_RANK[b.priority] ?? 1);
    if (pr !== 0) return pr;
    return (b.updated_at || '').localeCompare(a.updated_at || '');
  });
  res.json(rows);
});

router.get('/wishlist/:id', requireAuth, (req, res) => {
  const db = getDb();
  const item = db.prepare('SELECT * FROM wishlist_items WHERE id = ? AND user_id = ?').get(req.params.id, req.session.userId);
  if (!item) return res.status(404).json({ error: '找不到這個願望' });
  res.json(item);
});

router.post('/wishlist', requireAuth, (req, res) => {
  const { title, note, link, price, priority } = req.body || {};
  const trimmedTitle = String(title || '').trim();
  if (!trimmedTitle) return res.status(400).json({ error: '請輸入名稱' });
  const finalPriority = VALID_PRIORITIES.has(priority) ? priority : 'medium';
  let finalPrice = null;
  if (price !== undefined && price !== null && String(price).trim() !== '') {
    const n = Number(price);
    if (Number.isNaN(n) || n < 0) return res.status(400).json({ error: '價格格式不正確' });
    finalPrice = n;
  }
  const db = getDb();
  const now = new Date().toISOString();
  const result = db
    .prepare('INSERT INTO wishlist_items (user_id, title, note, link, price, priority, completed, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, 0, ?, ?)')
    .run(req.session.userId, trimmedTitle, note || '', (link || '').trim() || null, finalPrice, finalPriority, now, now);
  res.json({ id: result.lastInsertRowid });
});

router.put('/wishlist/:id', requireAuth, (req, res) => {
  const db = getDb();
  const item = db.prepare('SELECT * FROM wishlist_items WHERE id = ? AND user_id = ?').get(req.params.id, req.session.userId);
  if (!item) return res.status(404).json({ error: '找不到這個願望' });
  const { title, note, link, price, priority } = req.body || {};
  const trimmedTitle = title != null ? String(title).trim() : item.title;
  if (!trimmedTitle) return res.status(400).json({ error: '請輸入名稱' });
  const finalPriority = priority != null ? (VALID_PRIORITIES.has(priority) ? priority : item.priority) : item.priority;
  let finalPrice = item.price;
  if (price !== undefined) {
    if (price === null || String(price).trim() === '') {
      finalPrice = null;
    } else {
      const n = Number(price);
      if (Number.isNaN(n) || n < 0) return res.status(400).json({ error: '價格格式不正確' });
      finalPrice = n;
    }
  }
  db.prepare('UPDATE wishlist_items SET title = ?, note = ?, link = ?, price = ?, priority = ?, updated_at = ? WHERE id = ?').run(
    trimmedTitle,
    note != null ? note : item.note,
    link != null ? ((link || '').trim() || null) : item.link,
    finalPrice,
    finalPriority,
    new Date().toISOString(),
    item.id
  );
  res.json({ ok: true });
});

router.delete('/wishlist/:id', requireAuth, (req, res) => {
  const db = getDb();
  db.prepare('DELETE FROM wishlist_items WHERE id = ? AND user_id = ?').run(req.params.id, req.session.userId);
  res.json({ ok: true });
});

router.post('/wishlist/:id/toggle', requireAuth, (req, res) => {
  const db = getDb();
  const item = db.prepare('SELECT * FROM wishlist_items WHERE id = ? AND user_id = ?').get(req.params.id, req.session.userId);
  if (!item) return res.status(404).json({ error: '找不到這個願望' });
  const nextCompleted = item.completed ? 0 : 1;
  db.prepare('UPDATE wishlist_items SET completed = ?, updated_at = ? WHERE id = ?').run(nextCompleted, new Date().toISOString(), item.id);
  res.json({ ok: true, completed: !!nextCompleted });
});

module.exports = router;
