const { Router } = require('../mini-http');
const { getDb } = require('../services/db');
const { requireAuth } = require('../middleware/auth');

const router = Router();

router.get('/', requireAuth, (req, res) => {
  const db = getDb();
  const { status } = req.query; // 'pending' | 'completed' | undefined (全部)
  let rows;
  if (status === 'pending') {
    rows = db.prepare('SELECT * FROM tasks WHERE user_id = ? AND completed = 0 ORDER BY (due_date IS NULL), due_date ASC, CASE priority WHEN \'high\' THEN 0 WHEN \'medium\' THEN 1 ELSE 2 END ASC').all(req.session.userId);
  } else if (status === 'completed') {
    rows = db.prepare('SELECT * FROM tasks WHERE user_id = ? AND completed = 1 ORDER BY completed_at DESC LIMIT 100').all(req.session.userId);
  } else {
    rows = db.prepare('SELECT * FROM tasks WHERE user_id = ? ORDER BY completed ASC, (due_date IS NULL), due_date ASC').all(req.session.userId);
  }
  res.json(rows);
});

router.post('/', requireAuth, (req, res) => {
  const { title, note, dueDate, priority } = req.body || {};
  if (!title || !String(title).trim()) return res.status(400).json({ error: '請提供任務標題' });
  const p = ['low', 'medium', 'high'].includes(priority) ? priority : 'medium';
  const db = getDb();
  const now = new Date().toISOString();
  const result = db.prepare('INSERT INTO tasks (user_id, title, note, due_date, priority, completed, created_at) VALUES (?, ?, ?, ?, ?, 0, ?)').run(
    req.session.userId, String(title).trim(), note || null, dueDate || null, p, now
  );
  res.json({ id: result.lastInsertRowid, ok: true });
});

router.put('/:id', requireAuth, (req, res) => {
  const { title, note, dueDate, priority } = req.body || {};
  const db = getDb();
  const task = db.prepare('SELECT * FROM tasks WHERE id = ? AND user_id = ?').get(req.params.id, req.session.userId);
  if (!task) return res.status(404).json({ error: '找不到這筆任務' });
  db.prepare('UPDATE tasks SET title = ?, note = ?, due_date = ?, priority = ? WHERE id = ?').run(
    title != null ? String(title).trim() : task.title,
    note != null ? note : task.note,
    dueDate !== undefined ? dueDate : task.due_date,
    ['low', 'medium', 'high'].includes(priority) ? priority : task.priority,
    req.params.id
  );
  res.json({ ok: true });
});

router.put('/:id/complete', requireAuth, (req, res) => {
  const db = getDb();
  const completed = req.body && req.body.completed != null ? !!req.body.completed : true;
  db.prepare('UPDATE tasks SET completed = ?, completed_at = ? WHERE id = ? AND user_id = ?').run(
    completed ? 1 : 0,
    completed ? new Date().toISOString() : null,
    req.params.id,
    req.session.userId
  );
  res.json({ ok: true });
});

router.delete('/:id', requireAuth, (req, res) => {
  const db = getDb();
  db.prepare('DELETE FROM tasks WHERE id = ? AND user_id = ?').run(req.params.id, req.session.userId);
  res.json({ ok: true });
});

module.exports = router;
