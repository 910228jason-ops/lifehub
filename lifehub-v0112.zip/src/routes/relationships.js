const { Router } = require('../mini-http');
const { getDb } = require('../services/db');
const { requireAuth } = require('../middleware/auth');

const router = Router();

router.get('/', requireAuth, (req, res) => {
  const db = getDb();
  const rows = db.prepare('SELECT * FROM relationships WHERE user_id = ? ORDER BY name ASC').all(req.session.userId);
  res.json(rows);
});

router.post('/', requireAuth, (req, res) => {
  const { name, relationType, birthday, note } = req.body || {};
  if (!name || !String(name).trim()) return res.status(400).json({ error: '請提供姓名' });
  if (birthday && !/^\d{2}-\d{2}$/.test(birthday)) return res.status(400).json({ error: '生日請用 MM-DD 格式 (例如 03-15)' });
  const db = getDb();
  const now = new Date().toISOString();
  const result = db.prepare('INSERT INTO relationships (user_id, name, relation_type, birthday, note, created_at) VALUES (?, ?, ?, ?, ?, ?)').run(
    req.session.userId, String(name).trim(), relationType || null, birthday || null, note || null, now
  );
  res.json({ id: result.lastInsertRowid, ok: true });
});

router.delete('/:id', requireAuth, (req, res) => {
  const db = getDb();
  db.prepare('DELETE FROM relationships WHERE id = ? AND user_id = ?').run(req.params.id, req.session.userId);
  res.json({ ok: true });
});

router.get('/:id/interactions', requireAuth, (req, res) => {
  const db = getDb();
  const rows = db.prepare('SELECT * FROM relationship_interactions WHERE relationship_id = ? AND user_id = ? ORDER BY interaction_date DESC').all(req.params.id, req.session.userId);
  res.json(rows);
});

router.post('/:id/interactions', requireAuth, (req, res) => {
  const { note, date } = req.body || {};
  if (!note || !String(note).trim()) return res.status(400).json({ error: '請填寫互動內容' });
  const db = getDb();
  const rel = db.prepare('SELECT id FROM relationships WHERE id = ? AND user_id = ?').get(req.params.id, req.session.userId);
  if (!rel) return res.status(404).json({ error: '找不到這個人' });
  const now = new Date().toISOString();
  const result = db.prepare('INSERT INTO relationship_interactions (user_id, relationship_id, interaction_date, note, created_at) VALUES (?, ?, ?, ?, ?)').run(
    req.session.userId, req.params.id, date || now.slice(0, 10), String(note).trim(), now
  );
  res.json({ id: result.lastInsertRowid, ok: true });
});

// 未來 30 天內的生日 (跨年也算，例如現在 12 月、生日 1 月)
router.get('/upcoming-birthdays', requireAuth, (req, res) => {
  const db = getDb();
  const rows = db.prepare("SELECT id, name, relation_type, birthday FROM relationships WHERE user_id = ? AND birthday IS NOT NULL").all(req.session.userId);
  const todayStr = new Date().toISOString().slice(0, 10);
  const todayUTC = new Date(todayStr + 'T00:00:00Z');
  const thisYear = todayUTC.getUTCFullYear();

  const withDays = rows.map((r) => {
    const [mm, dd] = r.birthday.split('-').map(Number);
    let next = new Date(Date.UTC(thisYear, mm - 1, dd));
    if (next < todayUTC) next = new Date(Date.UTC(thisYear + 1, mm - 1, dd));
    const daysUntil = Math.round((next - todayUTC) / (1000 * 60 * 60 * 24));
    return { ...r, daysUntil };
  });

  res.json(withDays.filter((r) => r.daysUntil <= 30).sort((a, b) => a.daysUntil - b.daysUntil));
});

module.exports = router;
