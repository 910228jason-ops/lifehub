// 跨模塊深層模式識別。
//
// 分兩層做 (詳細原因跟使用者討論過)：
//   第一層：純程式計算每天的結構化特徵 + 幾組平均數對比，不靠 AI，數字準確、不會腦補。
//   第二層：只把「算出來的統計訊號」(數字，不是日記原文) 交給 AI，請它組織成一段人話，
//           並提醒這只是初步觀察、不是絕對因果關係，避免使用者被下定論嚇到或誤信。
//
// 因為需要一定的資料量才有意義，這個分析不是每次開頁面就重算，而是由 route 決定何時觸發、
// 存進 mood_patterns 表當快取。

const assistant = require('./assistant');
const cycle = require('./cycle');

const MIN_MOOD_ENTRIES = 20;

function buildDailyFeatures(db, userId, sinceStr) {
  const moodRows = db
    .prepare('SELECT entry_date, score, tags FROM mood_entries WHERE user_id = ? AND entry_date >= ?')
    .all(userId, sinceStr);

  const eventRows = db
    .prepare('SELECT event_date, COUNT(*) as cnt FROM calendar_events WHERE user_id = ? AND event_date >= ? GROUP BY event_date')
    .all(userId, sinceStr);
  const eventsByDate = {};
  eventRows.forEach((r) => { eventsByDate[r.event_date] = r.cnt; });

  const txRows = db
    .prepare("SELECT tx_date, SUM(amount) as total FROM finance_transactions WHERE user_id = ? AND tx_date >= ? AND type = 'expense' GROUP BY tx_date")
    .all(userId, sinceStr);
  const spendByDate = {};
  txRows.forEach((r) => { spendByDate[r.tx_date] = r.total; });

  const diaryRows = db
    .prepare('SELECT entry_date, LENGTH(content) as len FROM diary_entries WHERE user_id = ? AND entry_date >= ?')
    .all(userId, sinceStr);
  const diaryLenByDate = {};
  diaryRows.forEach((r) => { diaryLenByDate[r.entry_date] = r.len; });

  // 生理週期是選填功能，沒有記錄的話這裡就是空陣列，phaseForDate 會回傳 null，
  // 下面的 computeSignals 看到全部都是 null 就不會產生這組訊號，不影響其他分析。
  const cycleEntries = db
    .prepare('SELECT period_start_date, period_end_date FROM cycle_entries WHERE user_id = ? ORDER BY period_start_date ASC')
    .all(userId);

  return moodRows.map((r) => {
    const d = new Date(r.entry_date + 'T00:00:00Z');
    const dayOfMonth = d.getUTCDate();
    const dayOfWeek = d.getUTCDay(); // 0=Sun, 6=Sat
    return {
      date: r.entry_date,
      score: r.score,
      tags: (r.tags || '').split(',').filter(Boolean),
      isMonthEnd: dayOfMonth >= 25,
      isWeekend: dayOfWeek === 0 || dayOfWeek === 6,
      eventCount: eventsByDate[r.entry_date] || 0,
      spend: spendByDate[r.entry_date] || 0,
      diaryLen: diaryLenByDate[r.entry_date] || 0,
      cyclePhase: cycle.phaseForDate(cycleEntries, r.entry_date),
    };
  });
}

function avg(arr) {
  if (!arr.length) return null;
  return Math.round((arr.reduce((s, v) => s + v, 0) / arr.length) * 10) / 10;
}

// 每一組對比都需要兩邊都至少有幾筆資料，太少沒有代表性就跳過。
const MIN_GROUP_SIZE = 4;

function computeSignals(features) {
  const signals = [];

  function pushComparison(label, groupAName, groupA, groupBName, groupB) {
    if (groupA.length < MIN_GROUP_SIZE || groupB.length < MIN_GROUP_SIZE) return;
    const avgA = avg(groupA.map((f) => f.score));
    const avgB = avg(groupB.map((f) => f.score));
    const diff = Math.round((avgA - avgB) * 10) / 10;
    if (Math.abs(diff) < 0.8) return; // 差異太小，不算是有意義的訊號
    signals.push({ label, groupAName, avgA, countA: groupA.length, groupBName, avgB, countB: groupB.length, diff });
  }

  pushComparison('月底 vs 非月底', '月底 (25 號後)', features.filter((f) => f.isMonthEnd), '非月底', features.filter((f) => !f.isMonthEnd));
  pushComparison('週末 vs 平日', '週末', features.filter((f) => f.isWeekend), '平日', features.filter((f) => !f.isWeekend));

  const spendValues = features.map((f) => f.spend).filter((v) => v > 0);
  if (spendValues.length >= MIN_GROUP_SIZE * 2) {
    const sorted = [...spendValues].sort((a, b) => a - b);
    const median = sorted[Math.floor(sorted.length / 2)];
    pushComparison('高支出日 vs 一般日', '支出偏高的日子', features.filter((f) => f.spend > median), '其他日子', features.filter((f) => f.spend <= median));
  }

  const eventCounts = features.map((f) => f.eventCount);
  if (eventCounts.some((c) => c > 0)) {
    pushComparison('行程滿 vs 行程鬆', '當天 3 件事以上', features.filter((f) => f.eventCount >= 3), '當天少於 3 件事', features.filter((f) => f.eventCount < 3));
  }

  pushComparison('有寫日記 vs 沒寫日記', '當天有寫日記', features.filter((f) => f.diaryLen > 0), '當天沒寫日記', features.filter((f) => f.diaryLen === 0));

  // 只有使用者自己有記錄生理週期，才會有 cyclePhase 不是 null 的資料
  if (features.some((f) => f.cyclePhase)) {
    pushComparison('經前(黃體期後段) vs 其他階段', '經前階段', features.filter((f) => f.cyclePhase === 'luteal'), '其他階段', features.filter((f) => f.cyclePhase !== 'luteal' && f.cyclePhase != null));
  }

  // 標籤相關：每個常見標籤出現的那幾天 vs 沒出現的那幾天
  const tagCounts = {};
  features.forEach((f) => f.tags.forEach((t) => { tagCounts[t] = (tagCounts[t] || 0) + 1; }));
  Object.keys(tagCounts)
    .filter((t) => tagCounts[t] >= MIN_GROUP_SIZE)
    .forEach((tag) => {
      pushComparison(`標籤「${tag}」出現的日子`, `有「${tag}」`, features.filter((f) => f.tags.includes(tag)), `沒有「${tag}」`, features.filter((f) => !f.tags.includes(tag)));
    });

  return signals;
}

const PATTERN_SYSTEM_PROMPT = `你是 LifeHub 的心情陪伴 AI。使用者的系統幫他統計了幾組「心情分數」跟其他生活面向 (行程、記帳、日記、標籤) 的平均數對比資料，
請你把這些數字訊號組織成 2-4 句自然的觀察，語氣溫和、像朋友在跟他分享觀察到的事，不要條列式、不要說教。
非常重要：這些只是平均數的對比，不是嚴謹的統計檢定，更不是因果關係，請在文字中很自然地帶到「這只是初步的觀察，不代表絕對如此」這樣的提醒，
但不要講得太生硬、公式化。如果訊號很少或很平淡，就誠實說目前還看不出明顯的規律，鼓勵使用者繼續累積紀錄。
請一律用繁體中文回覆。`;

async function generatePatternInsights(signals) {
  if (!signals.length) {
    return { isConfigured: true, reply: '目前資料量還看不出明顯的規律，再累積多一點心情紀錄，這裡會幫你抓出屬於你自己的模式。' };
  }
  const lines = signals.map((s) => `${s.label}：${s.groupAName} 平均 ${s.avgA} 分 (n=${s.countA})，${s.groupBName} 平均 ${s.avgB} 分 (n=${s.countB})，差 ${s.diff} 分`);
  const prompt = `這是系統統計出來的心情關聯訊號：\n${lines.join('\n')}\n請幫我寫成觀察文字。`;
  return assistant.chat([{ role: 'user', content: prompt }], { systemPrompt: PATTERN_SYSTEM_PROMPT });
}

module.exports = { MIN_MOOD_ENTRIES, buildDailyFeatures, computeSignals, generatePatternInsights };
