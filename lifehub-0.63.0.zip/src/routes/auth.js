const { Router } = require('../mini-http');
const { hashPassword, verifyPassword, generateRecoveryCode } = require('../services/passwords');
const { getDb } = require('../services/db');
const logger = require('../services/logger');
const { isAdminEmail } = require('../services/admin');
const { requireAuth } = require('../middleware/auth');

const router = Router();

router.post('/register', (req, res) => {
  const { email, password, name } = req.body || {};
  if (!email || !password) return res.status(400).json({ error: '請輸入 email 與密碼' });
  if (String(password).length < 6) return res.status(400).json({ error: '密碼至少需 6 碼' });

  const db = getDb();
  const exists = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
  if (exists) return res.status(409).json({ error: '此 email 已被註冊' });

  const hash = hashPassword(password);
  // 這個專案沒有接寄信服務，忘記密碼時沒辦法「寄重設連結到信箱」，改用這組只顯示這一次的
  // 備用重設碼——存的是雜湊值，明碼只在這次註冊回應裡出現一次，前端要提醒使用者截圖/記下來。
  const recoveryCode = generateRecoveryCode();
  const recoveryCodeHash = hashPassword(recoveryCode);
  const now = new Date().toISOString();
  const info = db
    .prepare('INSERT INTO users (email, password_hash, name, created_at, recovery_code_hash) VALUES (?, ?, ?, ?, ?)')
    .run(email, hash, name || email.split('@')[0], now, recoveryCodeHash);

  // 新帳號的深色模式偏好預設用「自動 (跟系統)」，比固定寫死淺色更貼近使用者第一次打開的體感；
  // 這個更新之前就存在的舊帳號會維持資料庫欄位原本的 'light' 預設值，不會被這裡影響。
  db.prepare('INSERT INTO user_prefs (user_id, theme) VALUES (?, ?)').run(info.lastInsertRowid, 'auto');

  req.session.userId = info.lastInsertRowid;
  logger.info('新使用者註冊', { userId: info.lastInsertRowid });
  res.json({
    id: info.lastInsertRowid,
    email,
    name: name || email.split('@')[0],
    isAdmin: isAdminEmail(email),
    recoveryCode,
  });
});

router.post('/login', (req, res) => {
  const { email, password } = req.body || {};
  const db = getDb();
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  if (!user || !verifyPassword(password || '', user.password_hash)) {
    return res.status(401).json({ error: 'email 或密碼錯誤' });
  }
  req.session.userId = user.id;
  // v0.63：記錄「上次登入時間」，之前這個系統完全沒有追蹤過這件事，有人問「最近誰開過這個
  // App」都答不出來。用 try/catch 包起來——寫入失敗 (例如 migration 還沒套用) 也不該擋掉
  // 正常登入流程。
  try {
    db.prepare('UPDATE users SET last_login_at = ? WHERE id = ?').run(new Date().toISOString(), user.id);
  } catch (e) { /* ignore */ }
  res.json({ id: user.id, email: user.email, name: user.name, isAdmin: isAdminEmail(user.email) });
});

router.post('/logout', (req, res) => {
  req.session = null;
  res.json({ ok: true });
});

router.get('/me', (req, res) => {
  if (!req.session || !req.session.userId) return res.json({ user: null });
  const db = getDb();
  const user = db.prepare('SELECT id, email, name FROM users WHERE id = ?').get(req.session.userId);
  if (!user) return res.json({ user: null });
  res.json({ user: { ...user, isAdmin: isAdminEmail(user.email) } });
});

// 忘記密碼：email + 備用重設碼 + 新密碼，三個都對才能重設。
// 用跟登入錯誤一樣的錯誤訊息 (不特別說「email 不存在」還是「重設碼錯誤」)，避免被拿來
// 反查哪些 email 有註冊過。成功重設後，這組重設碼就失效 (改成 null)，逼使用者登入後
// 再去設定頁重新產生一組新的——避免重設碼被看過一次之後可以無限次重複使用。
router.post('/forgot-password', (req, res) => {
  const { email, recoveryCode, newPassword } = req.body || {};
  if (!email || !recoveryCode || !newPassword) {
    return res.status(400).json({ error: '請填寫 email、備用重設碼與新密碼' });
  }
  if (String(newPassword).length < 6) return res.status(400).json({ error: '新密碼至少需 6 碼' });

  const db = getDb();
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  const codeOk = user && verifyPassword(String(recoveryCode).trim(), user.recovery_code_hash);
  if (!codeOk) return res.status(401).json({ error: 'email 或備用重設碼不正確' });

  db.prepare('UPDATE users SET password_hash = ?, recovery_code_hash = NULL WHERE id = ?').run(
    hashPassword(newPassword),
    user.id
  );
  logger.info('使用者用備用重設碼重設密碼', { userId: user.id });
  res.json({ ok: true });
});

// 重新產生備用重設碼：給已經登入的使用者用 (包含「這次更新之前就註冊過、還沒有重設碼」的舊帳號)。
// 舊碼會直接被新碼取代，明碼只在這次回應出現一次。
router.post('/recovery-code', requireAuth, (req, res) => {
  const db = getDb();
  const recoveryCode = generateRecoveryCode();
  db.prepare('UPDATE users SET recovery_code_hash = ? WHERE id = ?').run(hashPassword(recoveryCode), req.session.userId);
  res.json({ recoveryCode });
});

module.exports = router;
