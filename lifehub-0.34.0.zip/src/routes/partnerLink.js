// 家人/伴侶帳號連結 (v0.33)：把原本只能「幫另一半代填生理週期」這種單向資料代填，擴充成
// 兩個各自有帳號的人可以互相連結、唯讀分享彼此的行事曆跟待辦事項，方便家人/伴侶互相掌握
// 彼此的行程與待辦，不用開共用試算表或互傳截圖。
//
// 設計刻意保守：
//   - 只有「唯讀查看」，沒有互相編輯對方資料的權限，避免誤刪/誤改對方的東西。
//   - 用邀請碼建立連結 (類似很多 App 的「加好友」流程)，不是直接輸入對方帳密。
//   - 任一方隨時可以解除連結，解除後對方立刻看不到你的分享內容。
//
// 注意：這支路由沒有在 server.js 用 app.mount() 單獨掛載，是被 debug.js (已掛載在 /api)
// 合併進去的，理由跟 feedback.js/insights.js/push.js 一樣：部署流程刻意不去動 server.js。

const crypto = require('crypto');
const { Router } = require('../mini-http');
const { getDb } = require('../services/db');
const { requireAuth } = require('../middleware/auth');

const router = Router();
const INVITE_TTL_MS = 24 * 60 * 60 * 1000; // 邀請碼 24 小時內有效，過期要重新產生

function genCode() {
  // 6 碼英數字，容易口頭唸給對方或截圖傳過去，不用長長一串亂碼。
  return crypto.randomBytes(4).toString('hex').slice(0, 6).toUpperCase();
}

// 取得「我」跟哪些人有連結 (雙向對稱，不管當初是我發的邀請還是我用邀請碼加入的)。
function getLinkedUserIds(db, userId) {
  const rows = db
    .prepare('SELECT id, user_a_id, user_b_id, created_at FROM partner_links WHERE user_a_id = ? OR user_b_id = ?')
    .all(userId, userId);
  return rows.map((r) => ({
    linkId: r.id,
    partnerUserId: r.user_a_id === userId ? r.user_b_id : r.user_a_id,
    createdAt: r.created_at,
  }));
}

router.get('/partner-link', requireAuth, (req, res) => {
  const db = getDb();
  const links = getLinkedUserIds(db, req.session.userId);
  const partners = links.map((l) => {
    const u = db.prepare('SELECT id, name, email FROM users WHERE id = ?').get(l.partnerUserId);
    return { linkId: l.linkId, userId: l.partnerUserId, name: (u && u.name) || (u && u.email) || '（帳號已刪除）', createdAt: l.createdAt };
  });
  res.json({ links: partners });
});

router.post('/partner-link/invite', requireAuth, (req, res) => {
  const db = getDb();
  const now = new Date();
  const code = genCode();
  const expiresAt = new Date(now.getTime() + INVITE_TTL_MS).toISOString();
  db.prepare('INSERT INTO partner_link_invites (inviter_user_id, code, created_at, expires_at) VALUES (?, ?, ?, ?)').run(
    req.session.userId, code, now.toISOString(), expiresAt
  );
  res.json({ code, expiresAt });
});

router.post('/partner-link/accept', requireAuth, (req, res) => {
  const { code } = req.body || {};
  const trimmed = String(code || '').trim().toUpperCase();
  if (!trimmed) return res.status(400).json({ error: '請輸入邀請碼' });
  const db = getDb();
  const invite = db.prepare('SELECT * FROM partner_link_invites WHERE code = ?').get(trimmed);
  if (!invite) return res.status(404).json({ error: '找不到這組邀請碼，請確認有沒有打錯' });
  if (invite.used_by_user_id) return res.status(400).json({ error: '這組邀請碼已經被使用過了' });
  if (new Date(invite.expires_at).getTime() < Date.now()) return res.status(400).json({ error: '這組邀請碼已經過期，請對方重新產生一組' });
  if (invite.inviter_user_id === req.session.userId) return res.status(400).json({ error: '不能加入自己產生的邀請碼' });

  const a = Math.min(invite.inviter_user_id, req.session.userId);
  const b = Math.max(invite.inviter_user_id, req.session.userId);
  const existing = db.prepare('SELECT id FROM partner_links WHERE user_a_id = ? AND user_b_id = ?').get(a, b);
  const now = new Date().toISOString();
  if (!existing) {
    db.prepare('INSERT INTO partner_links (user_a_id, user_b_id, created_at) VALUES (?, ?, ?)').run(a, b, now);
  }
  db.prepare('UPDATE partner_link_invites SET used_by_user_id = ?, used_at = ? WHERE id = ?').run(req.session.userId, now, invite.id);

  const inviterUser = db.prepare('SELECT name, email FROM users WHERE id = ?').get(invite.inviter_user_id);
  res.json({ ok: true, linkedWith: (inviterUser && (inviterUser.name || inviterUser.email)) || '對方' });
});

router.delete('/partner-link/:linkId', requireAuth, (req, res) => {
  const db = getDb();
  const link = db.prepare('SELECT * FROM partner_links WHERE id = ?').get(req.params.linkId);
  if (!link || (link.user_a_id !== req.session.userId && link.user_b_id !== req.session.userId)) {
    return res.status(404).json({ error: '找不到這個連結' });
  }
  db.prepare('DELETE FROM partner_links WHERE id = ?').run(req.params.linkId);
  res.json({ ok: true });
});

// 唯讀：把所有已連結對象「未來的」行事曆事項抓出來，各自標上是誰的，方便一次看到全家的行程。
router.get('/partner-link/shared-calendar', requireAuth, (req, res) => {
  const db = getDb();
  const links = getLinkedUserIds(db, req.session.userId);
  if (!links.length) return res.json({ events: [] });
  const today = new Date().toISOString().slice(0, 10);
  const events = [];
  links.forEach((l) => {
    const u = db.prepare('SELECT name, email FROM users WHERE id = ?').get(l.partnerUserId);
    const ownerLabel = (u && (u.name || u.email)) || '對方';
    const rows = db
      .prepare('SELECT id, event_date, start_time, title, note FROM calendar_events WHERE user_id = ? AND event_date >= ? ORDER BY event_date ASC, start_time ASC LIMIT 30')
      .all(l.partnerUserId, today);
    rows.forEach((r) => events.push({ ...r, ownerUserId: l.partnerUserId, ownerLabel }));
  });
  events.sort((a, b) => (a.event_date + (a.start_time || '')).localeCompare(b.event_date + (b.start_time || '')));
  res.json({ events });
});

// 唯讀：把所有已連結對象「還沒完成的」待辦事項抓出來，一樣各自標上是誰的。
router.get('/partner-link/shared-tasks', requireAuth, (req, res) => {
  const db = getDb();
  const links = getLinkedUserIds(db, req.session.userId);
  if (!links.length) return res.json({ tasks: [] });
  const tasks = [];
  links.forEach((l) => {
    const u = db.prepare('SELECT name, email FROM users WHERE id = ?').get(l.partnerUserId);
    const ownerLabel = (u && (u.name || u.email)) || '對方';
    const rows = db
      .prepare("SELECT id, title, due_date, priority FROM tasks WHERE user_id = ? AND completed = 0 ORDER BY (due_date IS NULL), due_date ASC LIMIT 30")
      .all(l.partnerUserId);
    rows.forEach((r) => tasks.push({ ...r, ownerUserId: l.partnerUserId, ownerLabel }));
  });
  tasks.sort((a, b) => {
    if (!a.due_date && !b.due_date) return 0;
    if (!a.due_date) return 1;
    if (!b.due_date) return -1;
    return a.due_date.localeCompare(b.due_date);
  });
  res.json({ tasks });
});

module.exports = router;
