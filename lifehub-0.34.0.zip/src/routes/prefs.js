const { Router } = require('../mini-http');
const { getDb } = require('../services/db');
const { requireAuth } = require('../middleware/auth');

const router = Router();

const TASK_WIDGET_STYLES = ['grouped', 'progress', 'focus'];

router.get('/', requireAuth, (req, res) => {
  const db = getDb();
  const row = db.prepare('SELECT * FROM user_prefs WHERE user_id = ?').get(req.session.userId);
  if (!row) return res.json({ moduleOrder: ['stocks', 'travel', 'diary', 'finance'], enabledModules: {}, watchlist: [], taskWidgetStyle: 'progress', moreNavOrder: [], pushBirthdayReminders: false, bottomNavPinned: [] });
  res.json({
    moduleOrder: JSON.parse(row.module_order_json),
    enabledModules: JSON.parse(row.enabled_modules_json),
    watchlist: JSON.parse(row.watchlist_json),
    theme: row.theme,
    taskWidgetStyle: row.task_widget_style || 'progress',
    // more_nav_order_json 是 v0.29.0 才加的欄位，舊資料列 (024 migration 套用前建立的帳號)
    // 這欄一律有 DEFAULT '[]'，所以這裡不需要额外防呆，但保留 try/catch 以防萬一資料異常。
    moreNavOrder: (() => { try { return JSON.parse(row.more_nav_order_json || '[]'); } catch (e) { return []; } })(),
    pushBirthdayReminders: !!row.push_birthday_reminders,
    // bottom_nav_pinned_json 是 v0.32.0 才加的欄位，同樣有 DEFAULT '[]'；空陣列時前端會
    // 自己退回預設的「股票/記帳/待辦」三項 (見 app.js 的 bottomNavPinnedTabs())。
    bottomNavPinned: (() => { try { return JSON.parse(row.bottom_nav_pinned_json || '[]'); } catch (e) { return []; } })(),
  });
});

router.put('/', requireAuth, (req, res) => {
  const { moduleOrder, enabledModules, watchlist, theme, taskWidgetStyle, moreNavOrder, pushBirthdayReminders, bottomNavPinned } = req.body || {};
  const db = getDb();
  db.prepare(
    `UPDATE user_prefs SET module_order_json = ?, enabled_modules_json = ?, watchlist_json = ?, theme = ?, task_widget_style = ?, more_nav_order_json = ?, push_birthday_reminders = ?, bottom_nav_pinned_json = ? WHERE user_id = ?`
  ).run(
    JSON.stringify(moduleOrder || []),
    JSON.stringify(enabledModules || {}),
    JSON.stringify(watchlist || []),
    theme || 'light',
    TASK_WIDGET_STYLES.includes(taskWidgetStyle) ? taskWidgetStyle : 'progress',
    JSON.stringify(Array.isArray(moreNavOrder) ? moreNavOrder : []),
    pushBirthdayReminders ? 1 : 0,
    JSON.stringify(Array.isArray(bottomNavPinned) ? bottomNavPinned : []),
    req.session.userId
  );
  res.json({ ok: true });
});

module.exports = router;
