// ===================== 共用工具 =====================
const state = { user: null, prefs: null, watchlist: ['2330', '2317', '0050'] };

// ===================== 側欄收合 =====================
function toggleSidebar() {
  const sb = $('#sidebar');
  const collapsed = sb.classList.toggle('collapsed');
  $('#sidebarToggle').textContent = collapsed ? '▸' : '◂';
  try { localStorage.setItem('lifehub_sidebar_collapsed', collapsed ? '1' : '0'); } catch (e) {}
}
function restoreSidebarState() {
  try {
    if (localStorage.getItem('lifehub_sidebar_collapsed') === '1') {
      $('#sidebar').classList.add('collapsed');
      $('#sidebarToggle').textContent = '▸';
    }
  } catch (e) {}
}

// ===================== 星空背景 =====================
function initStarfield() {
  const canvas = $('#starfield');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  let stars = [];
  function resize() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    const count = Math.round((canvas.width * canvas.height) / 9000);
    stars = Array.from({ length: count }, () => ({
      x: Math.random() * canvas.width,
      y: Math.random() * canvas.height,
      r: Math.random() * 1.3 + 0.3,
      base: Math.random() * 0.5 + 0.25,
      speed: Math.random() * 0.015 + 0.004,
      phase: Math.random() * Math.PI * 2,
    }));
  }
  function draw(t) {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = '#eaf0fb';
    stars.forEach((s) => {
      const twinkle = reduceMotion ? s.base : s.base + Math.sin(t * s.speed + s.phase) * 0.35;
      ctx.globalAlpha = Math.max(0.08, Math.min(1, twinkle));
      ctx.beginPath();
      ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
      ctx.fill();
    });
    ctx.globalAlpha = 1;
    if (!reduceMotion) requestAnimationFrame(draw);
  }
  window.addEventListener('resize', resize);
  resize();
  draw(0);
}

function $(sel) { return document.querySelector(sel); }
function el(tag, attrs = {}, children = []) {
  const e = document.createElement(tag);
  // 像 checked/selected/disabled 這種布林屬性，HTML 只看「有沒有這個屬性」不看值，
  // 所以 setAttribute(k, false) 還是會被瀏覽器當成「有設定」而顯示成 checked/selected/disabled，
  // 這裡特別處理：值是 false 就整個不設定，值是 true 就設成空字串。
  const BOOLEAN_ATTRS = new Set(['checked', 'selected', 'disabled', 'readonly', 'required', 'multiple']);
  Object.entries(attrs).forEach(([k, v]) => {
    if (k === 'html') e.innerHTML = v;
    else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else if (BOOLEAN_ATTRS.has(k)) { if (v) e.setAttribute(k, ''); }
    else e.setAttribute(k, v);
  });
  // 防呆：children 只要不是「已經是 DOM Node」的東西 (例如不小心直接塞了數字、布林值)，
  // 一律轉成文字節點，不要讓 appendChild 直接炸掉 (之前選股工具的漲跌欄位就是踩到這個)。
  (Array.isArray(children) ? children : [children]).forEach((c) => {
    if (c == null) return;
    e.appendChild(c instanceof Node ? c : document.createTextNode(String(c)));
  });
  return e;
}
function showToast(msg) {
  const t = $('#toast');
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 2200);
}
async function api(path, opts = {}) {
  const res = await fetch('/api' + path, {
    headers: { 'content-type': 'application/json' },
    ...opts,
    body: opts.body ? JSON.stringify(opts.body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
  return data;
}
function fmtNum(n) { return Number(n || 0).toLocaleString('zh-Hant-TW'); }
function fmtMoney(n) { return 'NT$ ' + Number(n || 0).toLocaleString('zh-Hant-TW'); }
// 旅遊分帳可能不是台幣計價 (例如整趟旅程用日圓結算)，這裡不能寫死 NT$，要照旅程的 base_currency 顯示
function fmtCurrency(n, currency) { return `${currency || 'TWD'} ${Number(n || 0).toLocaleString('zh-Hant-TW')}`; }

// ===================== Auth =====================
function toggleAuth(showRegister) {
  $('#loginForm').style.display = showRegister ? 'none' : 'block';
  $('#registerForm').style.display = showRegister ? 'block' : 'none';
}

async function doLogin() {
  try {
    const user = await api('/auth/login', {
      method: 'POST',
      body: { email: $('#loginEmail').value.trim(), password: $('#loginPassword').value },
    });
    onAuthed(user);
  } catch (e) { $('#loginError').textContent = e.message; }
}
async function doRegister() {
  try {
    const user = await api('/auth/register', {
      method: 'POST',
      body: { name: $('#regName').value.trim(), email: $('#regEmail').value.trim(), password: $('#regPassword').value },
    });
    onAuthed(user);
  } catch (e) { $('#regError').textContent = e.message; }
}
async function doLogout() {
  await api('/auth/logout', { method: 'POST' });
  state.user = null;
  $('#shell').style.display = 'none';
  $('#authScreen').style.display = 'flex';
}
function onAuthed(user) {
  state.user = user;
  $('#authScreen').style.display = 'none';
  $('#shell').style.display = 'flex';
  $('#userName').textContent = user.name;
  $('#userAvatar').textContent = (user.name || '?').slice(0, 1).toUpperCase();
  restoreSidebarState();
  loadPrefsAndBoot();
}
initStarfield();

async function loadPrefsAndBoot() {
  try {
    state.prefs = await api('/prefs');
    if (state.prefs.watchlist && state.prefs.watchlist.length) state.watchlist = state.prefs.watchlist;
  } catch (e) { /* 忽略，用預設值 */ }
  renderDashboard();
  switchTab('dashboard');
  try {
    const health = await api('/health');
    $('#appVersion').textContent = health.version;
  } catch (e) {}
  checkMoodReminder();
}

// ---------- 站內提醒強化 ----------
// 除了首頁/心情頁面上的關心 banner，這裡再加兩層：
//   1) 側邊欄「心情陪伴」旁邊的小紅點，不管現在在哪個分頁都看得到，不用特地點進心情頁才知道。
//   2) 瀏覽器原生通知 (需要使用者自己按同意)，一天最多提醒一次，避免打擾。
async function checkMoodReminder() {
  try {
    const summary = await api('/mood/summary?days=7');
    const navItem = $('#navMoodItem');
    if (navItem) {
      const existingDot = navItem.querySelector('.nav-alert-dot');
      if (summary.careMessage) {
        if (!existingDot) navItem.appendChild(el('span', { class: 'nav-alert-dot' }));
      } else if (existingDot) {
        existingDot.remove();
      }
    }
    if (summary.careMessage && 'Notification' in window && Notification.permission === 'granted') {
      const lastNotified = localStorage.getItem('lifehub_mood_reminder_date');
      const today = todayStr();
      if (lastNotified !== today) {
        new Notification('LifeHub 心情陪伴', { body: summary.careMessage, icon: undefined });
        localStorage.setItem('lifehub_mood_reminder_date', today);
      }
    }
  } catch (e) { /* 提醒功能失敗不影響主要功能，安靜跳過 */ }
}

async function enableMoodBrowserNotification() {
  if (!('Notification' in window)) { showToast('這個瀏覽器不支援通知功能'); return; }
  const perm = await Notification.requestPermission();
  if (perm === 'granted') {
    showToast('已開啟瀏覽器通知，心情需要關心時會提醒你');
    checkMoodReminder();
  } else {
    showToast('沒有開啟通知權限，之後可以在瀏覽器設定裡再打開');
  }
}

// ===================== Tab 切換 =====================
const TAB_TITLES = { dashboard: '我的首頁', stocks: '股票', travel: '交通與旅遊', diary: '日記', mood: '心情陪伴', finance: '記帳', bills: '帳單提醒', calendar: '行事曆', tasks: '待辦事項', health: '健康紀錄', relationships: '人際關係', partnerCare: '陪伴另一半', assistant: 'AI 助理', settings: '個人化設定' };
function switchTab(tab) {
  document.querySelectorAll('.nav-item').forEach((n) => n.classList.toggle('active', n.dataset.tab === tab));
  document.querySelectorAll('.bn-item').forEach((n) => n.classList.toggle('active', n.dataset.tab === tab));
  document.querySelectorAll('.tab-panel').forEach((p) => (p.style.display = 'none'));
  closeSheet(); // 切換分頁時，如果「更多」選單還開著就一起收起來
  // 心情頁是鎖住視窗高度的固定版面 (flex column)，其他頁維持一般區塊排版。
  $(`#tab-${tab}`).style.display = tab === 'mood' ? 'flex' : 'block';
  $('#pageTitle').textContent = TAB_TITLES[tab];
  if (tab === 'stocks') renderStocks();
  if (tab === 'travel') renderTravel();
  if (tab === 'diary') renderDiary();
  if (tab === 'mood') renderMood();
  if (tab === 'finance') renderFinance();
  if (tab === 'bills') renderBills();
  if (tab === 'calendar') renderCalendar();
  if (tab === 'tasks') renderTasks();
  if (tab === 'health') renderHealth();
  if (tab === 'relationships') renderRelationships();
  if (tab === 'partnerCare') renderPartnerCare();
  if (tab === 'assistant') renderAssistant();
  if (tab === 'settings') renderSettings();
}

// ===================== 手機底部導覽：更多選單 / 首頁自訂 (共用同一個底部彈出面板) =====================
// 側欄選單放不進手機底部，這裡把「首頁、股票、記帳、待辦」留在底部常駐，其餘 10 個分頁
// 收進「更多」彈出選單；同一個面板也拿來給首頁小工具拼貼的「自訂」用，不用另外做兩套殼。
const MORE_NAV_ITEMS = [
  { icon: '🚄', label: '交通與旅遊', tab: 'travel' },
  { icon: '📔', label: '日記', tab: 'diary' },
  { icon: '💗', label: '心情陪伴', tab: 'mood' },
  { icon: '🧾', label: '帳單提醒', tab: 'bills' },
  { icon: '📅', label: '行事曆', tab: 'calendar' },
  { icon: '🩺', label: '健康紀錄', tab: 'health' },
  { icon: '🤝', label: '人際關係', tab: 'relationships' },
  { icon: '🌷', label: '陪伴另一半', tab: 'partnerCare' },
  { icon: '🤖', label: 'AI 助理', tab: 'assistant' },
  { icon: '⚙️', label: '個人化設定', tab: 'settings' },
];

function openSheet(title, bodyBuilder) {
  $('#sheetTitle').textContent = title;
  const body = $('#sheetBody');
  body.innerHTML = '';
  body.appendChild(bodyBuilder());
  $('#sheetOverlay').classList.add('show');
}
function closeSheet(ev) {
  if (ev && ev.target !== ev.currentTarget) return; // 點面板內容不應該關閉，只有點背景遮罩或明確呼叫才關
  const overlay = $('#sheetOverlay');
  if (overlay) overlay.classList.remove('show');
}
function toggleMoreSheet() {
  const overlay = $('#sheetOverlay');
  if (overlay && overlay.classList.contains('show')) { closeSheet(); return; }
  openSheet('更多功能', () => {
    const grid = el('div', { class: 'widget-grid shortcuts' });
    MORE_NAV_ITEMS.forEach((s) => {
      grid.appendChild(el('div', { class: 'widget wshort light shortcut', onclick: () => switchTab(s.tab) }, [
        el('div', { class: 'ic' }, s.icon),
        el('div', { class: 'lb' }, s.label),
      ]));
    });
    return grid;
  });
}

// ===================== SVG 圖表小工具 =====================
// 依 dataviz 規範：細線條、圓角端點、2px 間距、淺色 gridline、tooltip 互動
function svgEl(tag, attrs) {
  const e = document.createElementNS('http://www.w3.org/2000/svg', tag);
  Object.entries(attrs).forEach(([k, v]) => e.setAttribute(k, v));
  return e;
}

// 水平長條圖 (用於記帳分類金額) — 類別色依固定順序指派
const CATEGORICAL = ['--series-blue', '--series-orange', '--series-aqua', '--series-yellow', '--series-magenta', '--series-green', '--series-violet', '--series-red'];
function cssVar(name) { return getComputedStyle(document.documentElement).getPropertyValue(name).trim(); }

function renderBarChart(container, data, opts = {}) {
  // data: [{label, value}]
  container.innerHTML = '';
  if (!data.length) { container.appendChild(el('div', { class: 'empty-state' }, opts.emptyText || '目前沒有資料')); return; }
  const width = container.clientWidth || 400;
  const rowH = 30;
  const height = data.length * rowH + 10;
  const max = Math.max(...data.map((d) => d.value), 1);
  const svg = svgEl('svg', { width: '100%', height, viewBox: `0 0 ${width} ${height}` });

  data.forEach((d, i) => {
    const y = i * rowH + 6;
    // 預留右側 90px 給數值標籤，避免最大值那一列的長條把標籤擠出容器外
    const barW = Math.max(4, (d.value / max) * (width - 140 - 90));
    const color = cssVar(CATEGORICAL[i % CATEGORICAL.length]);
    svg.appendChild(svgEl('rect', { x: 110, y, width: barW, height: 14, rx: 4, fill: color }));
    const label = svgEl('text', { x: 0, y: y + 11, 'font-size': 12, fill: cssVar('--text-secondary') });
    label.textContent = d.label.length > 10 ? d.label.slice(0, 10) + '…' : d.label;
    svg.appendChild(label);
    const val = svgEl('text', { x: 110 + barW + 8, y: y + 11, 'font-size': 12, fill: cssVar('--text-primary') });
    val.textContent = opts.money ? fmtMoney(d.value) : fmtNum(d.value);
    svg.appendChild(val);

    const hit = svgEl('rect', { x: 110, y, width: Math.max(barW, 4), height: 14, fill: 'transparent' });
    hit.addEventListener('mousemove', (ev) => showTooltip(ev, `${d.label}: ${opts.money ? fmtMoney(d.value) : fmtNum(d.value)}`));
    hit.addEventListener('mouseleave', hideTooltip);
    svg.appendChild(hit);
  });
  container.appendChild(svg);
}

// 發散長條圖 (法人買賣超: 正值買超=blue, 負值賣超=red, 0軸=灰色基準線)
function renderDivergingChart(container, data) {
  container.innerHTML = '';
  if (!data.length) { container.appendChild(el('div', { class: 'empty-state' }, '目前沒有可用的法人買賣超資料')); return; }
  const width = container.clientWidth || 500;
  const height = 180;
  const padL = 10, padR = 10, padTop = 10, padBottom = 24;
  const plotW = width - padL - padR;
  const plotH = height - padTop - padBottom;
  const max = Math.max(...data.map((d) => Math.abs(d.netBuySell)), 1);
  const barW = Math.max(6, plotW / data.length - 6);
  const midY = padTop + plotH / 2;

  const svg = svgEl('svg', { width: '100%', height, viewBox: `0 0 ${width} ${height}` });
  svg.appendChild(svgEl('line', { x1: padL, x2: width - padR, y1: midY, y2: midY, stroke: cssVar('--baseline'), 'stroke-width': 1 }));

  data.forEach((d, i) => {
    const x = padL + i * (plotW / data.length) + (plotW / data.length - barW) / 2;
    const h = (Math.abs(d.netBuySell) / max) * (plotH / 2 - 4);
    const isBuy = d.netBuySell >= 0;
    const y = isBuy ? midY - h : midY;
    const color = isBuy ? cssVar('--series-blue') : cssVar('--series-red');
    svg.appendChild(svgEl('rect', { x, y, width: barW, height: Math.max(h, 1), rx: 3, fill: color }));

    const hit = svgEl('rect', { x, y: padTop, width: barW, height: plotH, fill: 'transparent' });
    hit.addEventListener('mousemove', (ev) => showTooltip(ev, `${d.date}: ${isBuy ? '買超' : '賣超'} ${fmtNum(Math.abs(d.netBuySell))} 股`));
    hit.addEventListener('mouseleave', hideTooltip);
    svg.appendChild(hit);

    if (i % Math.ceil(data.length / 6 || 1) === 0) {
      const lbl = svgEl('text', { x: x + barW / 2, y: height - 6, 'font-size': 10, 'text-anchor': 'middle', fill: cssVar('--text-muted') });
      lbl.textContent = (d.date || '').slice(4);
      svg.appendChild(lbl);
    }
  });
  container.appendChild(svg);
  container.appendChild(el('div', { class: 'legend' }, [
    el('div', { class: 'legend-item' }, [el('div', { class: 'legend-dot', style: `background:${cssVar('--series-blue')}` }), '買超 (法人淨買進)']),
    el('div', { class: 'legend-item' }, [el('div', { class: 'legend-dot', style: `background:${cssVar('--series-red')}` }), '賣超 (法人淨賣出)']),
  ]));
}

// 折線圖 (記帳月趨勢: 收入 vs 支出 兩條線)
function renderLineChart(container, series) {
  // series: [{name, color, points:[{x,y}]}]
  container.innerHTML = '';
  const allPoints = series.flatMap((s) => s.points);
  if (!allPoints.length) { container.appendChild(el('div', { class: 'empty-state' }, '目前沒有可用的趨勢資料')); return; }
  const width = container.clientWidth || 500;
  const height = 200;
  const padL = 40, padR = 16, padTop = 16, padBottom = 26;
  const plotW = width - padL - padR;
  const plotH = height - padTop - padBottom;
  const xs = [...new Set(allPoints.map((p) => p.x))];
  // 支援負值 (例如淨資產累計結餘可能是負的)：用實際的 min/max 範圍縮放，不假設一定從 0 開始
  const rawMin = Math.min(...allPoints.map((p) => p.y), 0);
  const rawMax = Math.max(...allPoints.map((p) => p.y), 0);
  const span = rawMax - rawMin || Math.abs(rawMax) * 0.2 || 1;
  // 全部都是非負值時維持原本「從 0 開始」的畫法，只有真的出現負值時才往下留白，
  // 不然本來就從 0 起跳的圖表 (例如收支金額) 會無緣無故變成從負數開始
  const yMin = rawMin < 0 ? rawMin - span * 0.05 : 0;
  const yMax = rawMax + span * 0.05;
  const yAt = (v) => padTop + plotH - ((v - yMin) / (yMax - yMin)) * plotH;

  const svg = svgEl('svg', { width: '100%', height, viewBox: `0 0 ${width} ${height}` });
  for (let g = 0; g <= 4; g++) {
    const y = padTop + (plotH / 4) * g;
    const v = yMax - ((yMax - yMin) / 4) * g;
    svg.appendChild(svgEl('line', { x1: padL, x2: width - padR, y1: y, y2: y, stroke: cssVar('--grid-line'), 'stroke-width': 1 }));
    const val = svgEl('text', { x: 4, y: y + 4, 'font-size': 10, fill: cssVar('--text-muted') });
    val.textContent = fmtNum(Math.round(v));
    svg.appendChild(val);
  }
  // 0 這條基準線如果落在圖表範圍內，特別標出來，負值時比較看得出「虧」跟「賺」的分界
  if (yMin < 0 && yMax > 0) {
    const zeroY = yAt(0);
    svg.appendChild(svgEl('line', { x1: padL, x2: width - padR, y1: zeroY, y2: zeroY, stroke: cssVar('--text-muted'), 'stroke-width': 1, 'stroke-dasharray': '3,3' }));
  }

  series.forEach((s) => {
    const pts = xs.map((x) => {
      const p = s.points.find((pt) => pt.x === x);
      return { x, y: p ? p.y : 0 };
    });
    const path = pts.map((p, i) => {
      const px = padL + (xs.indexOf(p.x) / Math.max(xs.length - 1, 1)) * plotW;
      const py = yAt(p.y);
      return `${i === 0 ? 'M' : 'L'}${px},${py}`;
    }).join(' ');
    svg.appendChild(svgEl('path', { d: path, fill: 'none', stroke: s.color, 'stroke-width': 2, 'stroke-linecap': 'round' }));

    pts.forEach((p) => {
      const px = padL + (xs.indexOf(p.x) / Math.max(xs.length - 1, 1)) * plotW;
      const py = yAt(p.y);
      const dot = svgEl('circle', { cx: px, cy: py, r: 4, fill: s.color });
      dot.addEventListener('mousemove', (ev) => showTooltip(ev, `${s.name} ${p.x}: ${fmtMoney(p.y)}`));
      dot.addEventListener('mouseleave', hideTooltip);
      svg.appendChild(dot);
    });
  });

  xs.forEach((x, i) => {
    const px = padL + (i / Math.max(xs.length - 1, 1)) * plotW;
    const lbl = svgEl('text', { x: px, y: height - 6, 'font-size': 10, 'text-anchor': 'middle', fill: cssVar('--text-muted') });
    lbl.textContent = x;
    svg.appendChild(lbl);
  });

  container.appendChild(svg);
  container.appendChild(el('div', { class: 'legend' }, series.map((s) =>
    el('div', { class: 'legend-item' }, [el('div', { class: 'legend-dot', style: `background:${s.color}` }), s.name])
  )));
}

// 股價走勢圖 (收盤價 + MA5 + MA20)：y 軸依價格範圍縮放 (不從 0 開始，股價圖慣例)
function renderPriceChart(container, points) {
  container.innerHTML = '';
  if (!points || points.length < 2) { container.appendChild(el('div', { class: 'empty-state' }, '歷史資料不足，無法繪製走勢圖')); return; }
  const width = container.clientWidth || 600;
  const height = 220;
  const padL = 48, padR = 14, padTop = 12, padBottom = 26;
  const plotW = width - padL - padR, plotH = height - padTop - padBottom;
  const vals = points.flatMap((p) => [p.close, p.ma5, p.ma20]).filter((v) => v != null);
  const vMin = Math.min(...vals), vMax = Math.max(...vals);
  const span = vMax - vMin || vMax * 0.02 || 1;
  const lo = vMin - span * 0.08, hi = vMax + span * 0.08;
  const xAt = (i) => padL + (i / Math.max(points.length - 1, 1)) * plotW;
  const yAt = (v) => padTop + plotH - ((v - lo) / (hi - lo)) * plotH;

  const svg = svgEl('svg', { width: '100%', height, viewBox: `0 0 ${width} ${height}` });
  for (let g = 0; g <= 4; g++) {
    const y = padTop + (plotH / 4) * g;
    const v = hi - ((hi - lo) / 4) * g;
    svg.appendChild(svgEl('line', { x1: padL, x2: width - padR, y1: y, y2: y, stroke: cssVar('--grid-line'), 'stroke-width': 1 }));
    const lbl = svgEl('text', { x: 4, y: y + 4, 'font-size': 10, fill: cssVar('--text-muted') });
    lbl.textContent = v >= 1000 ? Math.round(v).toLocaleString() : v.toFixed(1);
    svg.appendChild(lbl);
  }

  const series = [
    { key: 'close', name: '收盤價', color: cssVar('--series-blue'), w: 2 },
    { key: 'ma5', name: 'MA5', color: cssVar('--series-orange'), w: 1.5 },
    { key: 'ma20', name: 'MA20', color: cssVar('--series-aqua'), w: 1.5 },
  ];
  series.forEach((s) => {
    let d = '';
    points.forEach((p, i) => {
      const v = p[s.key];
      if (v == null) return;
      d += `${d ? 'L' : 'M'}${xAt(i).toFixed(1)},${yAt(v).toFixed(1)} `;
    });
    if (d) svg.appendChild(svgEl('path', { d: d.trim(), fill: 'none', stroke: s.color, 'stroke-width': s.w, 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }));
  });

  const colW = plotW / points.length;
  points.forEach((p, i) => {
    const hit = svgEl('rect', { x: xAt(i) - colW / 2, y: padTop, width: colW, height: plotH, fill: 'transparent' });
    hit.addEventListener('mousemove', (ev) => showTooltip(ev,
      `${p.date} 收盤 ${p.close}${p.ma5 != null ? ' · MA5 ' + p.ma5 : ''}${p.ma20 != null ? ' · MA20 ' + p.ma20 : ''}`));
    hit.addEventListener('mouseleave', hideTooltip);
    svg.appendChild(hit);
  });

  const step = Math.max(1, Math.ceil(points.length / 5));
  points.forEach((p, i) => {
    if (i % step !== 0 && i !== points.length - 1) return;
    const lbl = svgEl('text', { x: xAt(i), y: height - 6, 'font-size': 10, 'text-anchor': 'middle', fill: cssVar('--text-muted') });
    lbl.textContent = String(p.date || '').slice(-5);
    svg.appendChild(lbl);
  });

  container.appendChild(svg);
  container.appendChild(el('div', { class: 'legend' }, series.map((s) =>
    el('div', { class: 'legend-item' }, [el('div', { class: 'legend-dot', style: `background:${s.color}` }), s.name])
  )));
}

function showTooltip(ev, text) {
  const tip = $('#tooltip');
  tip.textContent = text;
  tip.style.left = ev.pageX + 12 + 'px';
  tip.style.top = ev.pageY + 12 + 'px';
  tip.style.opacity = '1';
}
function hideTooltip() { $('#tooltip').style.opacity = '0'; }

// ===================== Dashboard =====================
// 首頁的樣貌會依當下時段變化 (早晨/午後/傍晚/深夜)，不會永遠都是「晨間簡報」那一種形式，
// 每個時段有自己的徽章文字、問候語、跟摘要按鈕的語氣。
const DASH_PERIODS = {
  morning: {
    icon: '☀️', label: '晨間', badgeSuffix: '晨間時光',
    greetings: [
      '新的一天，先深呼吸一口再開始 🌿',
      '不用急，先把自己準備好就好 ✨',
      '今天想做的事，先做一件小小的就好 🌤️',
    ],
    briefBtn: '產生晨間摘要',
  },
  afternoon: {
    icon: '🌤️', label: '午後', badgeSuffix: '午後時光',
    greetings: [
      '午後了，休息一下再繼續也可以 🍃',
      '不管上午過得如何，下半天重新開始就好 💫',
      '喝口水、動一動，替下午充個電 ☕',
    ],
    briefBtn: '產生午後摘要',
  },
  evening: {
    icon: '🌇', label: '傍晚', badgeSuffix: '傍晚時光',
    greetings: [
      '今天也辛苦了，慢慢收尾就好 🌿',
      '不管今天過得如何，你都做得很好 ✨',
      '晚餐前，先鬆口氣吧 🌆',
    ],
    briefBtn: '產生傍晚摘要',
  },
  night: {
    icon: '🌙', label: '深夜', badgeSuffix: '深夜時光',
    greetings: [
      '累的時候，休息也是一種前進 🍃',
      '慢慢來也沒關係，你的步調就是最好的步調 🌙',
      '有你在乎的事情，本身就是一件很棒的事 💫',
    ],
    briefBtn: '產生深夜摘要',
  },
};

function getDayPeriod() {
  const h = new Date().getHours();
  if (h >= 5 && h < 11) return 'morning';
  if (h >= 11 && h < 17) return 'afternoon';
  if (h >= 17 && h < 21) return 'evening';
  return 'night';
}

function renderDashboard() {
  const c = $('#tab-dashboard');
  c.innerHTML = '';
  const period = getDayPeriod();
  const meta = DASH_PERIODS[period];
  const greeting = meta.greetings[Math.floor(Math.random() * meta.greetings.length)];

  const WEEKDAY_LABEL = ['日', '一', '二', '三', '四', '五', '六'];
  const now = new Date();
  const dateLabel = `${now.getMonth() + 1}月${now.getDate()}日 星期${WEEKDAY_LABEL[now.getDay()]}`;

  const orbCard = el('div', { class: `dash-orb-card dash-period-${period}` }, [
    el('div', { class: 'dash-sunrise-badge' }, `${meta.icon} ${meta.badgeSuffix} · ${dateLabel}`),
    el('div', { class: 'dash-orb-visual' }, [
      el('div', { class: 'dash-orb-ring' }),
      el('div', { class: 'dash-orb-core' }),
    ]),
    el('div', { class: 'hello' }, `哈囉，${state.user ? state.user.name : ''} 👋`),
    el('div', { class: 'sub' }, greeting),
    el('div', { class: 'dash-orb-input' }, [
      el('input', { id: 'dashAskInput', placeholder: '想問 AI 什麼呢？', onkeydown: (ev) => { if (ev.key === 'Enter') dashAskAI(); } }),
      el('button', { class: 'btn btn-primary', onclick: () => dashAskAI() }, '送出'),
    ]),
    el('div', { class: 'dash-orb-hint' }, '按 Enter 直接與 AI 助理對話，資料與對話記錄都會同步保存'),
    el('div', { class: 'dash-brief-box' }, [
      el('button', { class: 'btn btn-ghost dash-brief-btn', onclick: () => generateDashBriefing(period) }, `📋 ${meta.briefBtn}`),
      el('div', { id: 'dashBriefResult', class: 'dash-brief-result', style: 'display:none' }),
    ]),
  ]);

  // 哪些首頁小工具要顯示，使用者可以在首頁按「自訂」自己調整 (不是每個人都常用股票)，
  // 設定存在 prefs.enabledModules，桌面版跟手機版拼貼共用同一份設定，維持一致。
  const enabled = (state.prefs && state.prefs.enabledModules) || {};
  const isOn = (key) => enabled[key] !== false;

  const leftCol = el('div', { class: 'dash-col' }, [
    isOn('stocks') ? dashCard('📈', '股市摘要', 'stocksSummaryBody', () => switchTab('stocks')) : null,
    isOn('calendar') ? dashCard('📅', '行事曆行程', 'calendarSummaryBody', () => switchTab('calendar')) : null,
    isOn('tasks') ? dashCard('✅', '待辦事項', 'tasksSummaryBody', () => switchTab('tasks')) : null,
    dashCard('🚄', '交通與旅遊', null, () => switchTab('travel'), '台鐵/高鐵時刻、機票訂房連結、智慧行程規劃，點卡片前往'),
  ].filter(Boolean));
  const rightCol = el('div', { class: 'dash-col' }, [
    isOn('mood') ? dashCard('💗', '心情陪伴', 'moodSummaryBody', () => switchTab('mood')) : null,
    isOn('finance') ? dashCard('💰', '記帳流水', 'financeSummaryBody', () => switchTab('finance')) : null,
    isOn('bills') ? dashCard('🧾', '帳單提醒', 'billsSummaryBody', () => switchTab('bills')) : null,
    dashCard('📔', '日記隨筆', 'diarySummaryBody', () => switchTab('diary')),
  ].filter(Boolean));

  c.appendChild(el('div', { class: 'dash-grid' }, [
    leftCol,
    el('div', { class: 'dash-orb-col' }, [orbCard]),
    rightCol,
  ]));

  if (isOn('stocks')) loadDashStockSummary();
  if (isOn('calendar')) loadDashCalendarSummary();
  if (isOn('finance')) loadDashFinanceSummary();
  loadDashDiarySummary();
  if (isOn('tasks')) loadDashTasksSummary();
  if (isOn('bills')) loadDashBillsSummary();
  if (isOn('mood')) loadDashMoodSummary();

  // ---- 手機版首頁：小工具拼貼 (窄螢幕才顯示，見 CSS @media 760px) ----
  c.appendChild(buildMobileDashboard(period, meta, dateLabel));
}

// ===================== 手機版首頁：小工具拼貼 =====================
// 每個小工具對應一個 enabledModules 的 key，跟桌面版首頁卡片共用同一份「自訂」設定。
const MOBILE_WIDGETS = [
  { key: 'stocks', label: '📈 股票', color: 'emerald', size: 'w2x2', bodyId: 'wStockBody', tab: 'stocks', loader: () => loadMobileStockWidget() },
  { key: 'tasks', label: '✅ 待辦', color: 'amber', size: 'w1x1', bodyId: 'wTasksBody', tab: 'tasks', loader: () => loadMobileTasksWidget() },
  { key: 'mood', label: '💗 心情', color: 'sky', size: 'w1x1', bodyId: 'wMoodBody', tab: 'mood', loader: () => loadMobileMoodWidget() },
  { key: 'finance', label: '💰 記帳', color: 'indigo', size: 'w4x1', bodyId: 'wFinanceBody', tab: 'finance', loader: () => loadMobileFinanceWidget() },
  { key: 'bills', label: '🧾 帳單提醒', color: 'light', size: 'w2x2', bodyId: 'wBillsBody', tab: 'bills', loader: () => loadMobileBillsWidget() },
  { key: 'calendar', label: '📅 行事曆', color: 'rose', size: 'w2x2', bodyId: 'wCalendarBody', tab: 'calendar', loader: () => loadMobileCalendarWidget() },
];

function buildMobileDashboard(period, meta, dateLabel) {
  const enabled = (state.prefs && state.prefs.enabledModules) || {};
  const isOn = (key) => enabled[key] !== false;
  const wrap = el('div', { class: 'dash-mobile-widgets' });

  wrap.appendChild(el('div', { class: 'dash-mobile-topline' }, [
    el('div', { class: 'dash-mobile-greet' }, [
      el('div', { class: 'hi' }, `${meta.icon} ${dateLabel}`),
      el('div', { class: 'name' }, `哈囉，${state.user ? state.user.name : ''}`),
    ]),
    el('button', { class: 'dash-customize-btn', onclick: openCustomizeSheet }, '✏️ 自訂'),
  ]));

  const activeWidgets = MOBILE_WIDGETS.filter((w) => isOn(w.key));
  if (activeWidgets.length) {
    const grid = el('div', { class: 'widget-grid' });
    activeWidgets.forEach((w) => {
      grid.appendChild(el('div', { class: `widget ${w.size} ${w.color}`, onclick: () => switchTab(w.tab) }, [
        el('div', { class: 'wt' }, w.label),
        el('div', { id: w.bodyId }, el('div', { class: 'w-sub' }, '載入中...')),
      ]));
    });
    wrap.appendChild(grid);
  } else {
    wrap.appendChild(el('div', { class: 'empty-state' }, '首頁小工具都關掉了，按右上角「自訂」重新打開'));
  }

  wrap.appendChild(el('div', { class: 'section-label' }, '全部功能'));
  const shortcutGrid = el('div', { class: 'widget-grid shortcuts' });
  MORE_NAV_ITEMS.forEach((s) => {
    shortcutGrid.appendChild(el('div', { class: 'widget wshort light shortcut', onclick: () => switchTab(s.tab) }, [
      el('div', { class: 'ic' }, s.icon),
      el('div', { class: 'lb' }, s.label),
    ]));
  });
  wrap.appendChild(shortcutGrid);

  // 小工具的資料要等元素真的插入 DOM 之後才抓，不然找不到對應的 #wXxxBody
  activeWidgets.forEach((w) => w.loader());
  return wrap;
}

function openCustomizeSheet() {
  openSheet('自訂首頁小工具', () => {
    const wrap = el('div', {});
    wrap.appendChild(el('p', { class: 'hint', style: 'margin:0 0 12px' }, '關掉的項目暫時不會出現在首頁，隨時可以再打開；一般選單裡還是找得到，資料也不會被刪除。'));
    const enabled = (state.prefs && state.prefs.enabledModules) || {};
    MOBILE_WIDGETS.forEach((w) => {
      wrap.appendChild(el('div', { class: 'module-toggle-row' }, [
        el('span', {}, w.label),
        el('label', { class: 'switch' }, [
          el('input', { type: 'checkbox', checked: enabled[w.key] !== false, onchange: (ev) => toggleDashWidget(w.key, ev.target.checked) }),
          el('span', { class: 'slider' }),
        ]),
      ]));
    });
    return wrap;
  });
}

async function toggleDashWidget(key, val) {
  state.prefs.enabledModules = { ...(state.prefs.enabledModules || {}), [key]: val };
  try {
    await api('/prefs', { method: 'PUT', body: state.prefs });
  } catch (e) { showToast('儲存失敗：' + e.message); }
  renderDashboard();
  // 首頁重新畫過之後，把「自訂」面板重新打開、停在同一個畫面，這樣連續關好幾個小工具不用一直重新點「自訂」
  openCustomizeSheet();
}

async function loadMobileStockWidget() {
  const body = $('#wStockBody');
  if (!body) return;
  try {
    const t = await api('/stocks/index/taiex');
    body.innerHTML = '';
    const changeColor = t.change > 0 ? 'delta-up' : t.change < 0 ? 'delta-down' : '';
    body.appendChild(el('div', { class: 'wv' }, t.index != null ? Number(t.index).toLocaleString('zh-Hant-TW', { maximumFractionDigits: 0 }) : '--'));
    body.appendChild(el('div', { class: `w-sub ${changeColor}` }, t.change != null ? `${t.change > 0 ? '▲+' : t.change < 0 ? '▼' : ''}${t.change} · 加權指數` : '加權指數'));
  } catch (e) {
    body.innerHTML = '';
    body.appendChild(el('div', { class: 'w-sub' }, '暫時無法取得'));
  }
}
async function loadMobileTasksWidget() {
  const body = $('#wTasksBody');
  if (!body) return;
  try {
    const pending = await api('/tasks?status=pending');
    body.innerHTML = '';
    const overdue = pending.filter((t) => t.due_date && t.due_date < todayStr()).length;
    body.appendChild(el('div', { class: 'wv small' }, `${pending.length} 件`));
    body.appendChild(el('div', { class: 'w-sub' }, overdue ? `${overdue} 件已過期` : '待完成'));
  } catch (e) {
    body.innerHTML = '';
    body.appendChild(el('div', { class: 'w-sub' }, '暫時無法取得'));
  }
}
async function loadMobileMoodWidget() {
  const body = $('#wMoodBody');
  if (!body) return;
  try {
    const today = todayStr();
    const rows = await api(`/mood/entries?from=${today}&to=${today}`);
    body.innerHTML = '';
    if (rows.length) {
      body.appendChild(el('div', { class: 'wv small' }, `${rows[0].score} 分`));
      body.appendChild(el('div', { class: 'w-sub' }, '今天已記錄'));
    } else {
      body.appendChild(el('div', { class: 'wv small' }, '😊'));
      body.appendChild(el('div', { class: 'w-sub' }, '點擊記錄心情'));
    }
  } catch (e) {
    body.innerHTML = '';
    body.appendChild(el('div', { class: 'w-sub' }, '暫時無法取得'));
  }
}
async function loadMobileFinanceWidget() {
  const body = $('#wFinanceBody');
  if (!body) return;
  try {
    const summary = await api('/finance/summary');
    const expense = (summary.totals || []).find((t) => t.type === 'expense')?.total || 0;
    body.innerHTML = '';
    body.appendChild(el('div', { class: 'wv' }, fmtMoney(expense)));
    body.appendChild(el('div', { class: 'w-sub' }, '本月支出'));
  } catch (e) {
    body.innerHTML = '';
    body.appendChild(el('div', { class: 'w-sub' }, '暫時無法取得'));
  }
}
async function loadMobileBillsWidget() {
  const body = $('#wBillsBody');
  if (!body) return;
  try {
    const res = await api('/bills/upcoming');
    const unpaid = res.bills.filter((b) => !b.paid);
    body.innerHTML = '';
    if (!res.bills.length) {
      body.appendChild(el('div', { class: 'wv small' }, '尚未加入'));
      body.appendChild(el('div', { class: 'w-sub' }, '點擊新增帳單'));
    } else if (!unpaid.length) {
      body.appendChild(el('div', { class: 'wv small' }, '都繳完了 🎉'));
    } else {
      body.appendChild(el('div', { class: 'wv small' }, unpaid[0].name));
      body.appendChild(el('div', { class: 'w-sub' }, `每月${unpaid[0].due_day}號・還有${unpaid.length}筆`));
    }
  } catch (e) {
    body.innerHTML = '';
    body.appendChild(el('div', { class: 'w-sub' }, '暫時無法取得'));
  }
}
async function loadMobileCalendarWidget() {
  const body = $('#wCalendarBody');
  if (!body) return;
  try {
    const today = new Date();
    const from = today.toISOString().slice(0, 10);
    const toD = new Date(today); toD.setDate(toD.getDate() + 14);
    const to = toD.toISOString().slice(0, 10);
    const events = await api(`/calendar?from=${from}&to=${to}`);
    body.innerHTML = '';
    if (!events.length) {
      body.appendChild(el('div', { class: 'wv small' }, '沒有排程'));
      body.appendChild(el('div', { class: 'w-sub' }, '接下來兩週'));
    } else {
      body.appendChild(el('div', { class: 'wv small' }, events[0].title.length > 8 ? events[0].title.slice(0, 8) + '…' : events[0].title));
      body.appendChild(el('div', { class: 'w-sub' }, `${events[0].event_date}${events.length > 1 ? ` 等${events.length}項` : ''}`));
    }
  } catch (e) {
    body.innerHTML = '';
    body.appendChild(el('div', { class: 'w-sub' }, '暫時無法取得'));
  }
}

function dashCard(icon, title, bodyId, onClick, staticHint) {
  const children = [el('h3', {}, [el('div', { class: 'hex-badge' }, icon), title])];
  if (staticHint) {
    children.push(el('p', { class: 'hint', style: 'margin-bottom:0' }, staticHint));
  } else if (bodyId) {
    children.push(el('div', { id: bodyId }, el('p', { class: 'hint', style: 'margin-bottom:0' }, '載入中...')));
  }
  return el('div', { class: `card dash-card${onClick ? ' clickable' : ''}`, onclick: onClick || undefined }, children);
}

// 首頁快速心情打卡：有些人比較懶，不想特地點進心情頁才能記錄，
// 所以直接在首頁的卡片裡放一列小分數按鈕 + 選填備註，點兩下就能存。
// 注意這裡的每個互動元件都要 stopPropagation()，不然點下去會被外層卡片的
// onclick 攔截、直接跳轉到心情頁而不是選分數。
let dashMoodQuickScore = null;

async function loadDashMoodSummary() {
  const body = $('#moodSummaryBody');
  if (!body) return;
  try {
    const today = todayStr();
    const [todayRows, summary] = await Promise.all([
      api(`/mood/entries?from=${today}&to=${today}`),
      api('/mood/summary?days=7'),
    ]);
    body.innerHTML = '';
    dashMoodQuickScore = todayRows.length ? todayRows[0].score : null;

    if (summary.careMessage) {
      body.appendChild(el('div', { class: 'dash-care-banner' }, `💌 ${summary.careMessage}`));
    }
    if (todayRows.length) {
      body.appendChild(el('div', { class: 'stat-big' }, `${todayRows[0].score} 分`));
      body.appendChild(el('p', { class: 'hint', style: 'margin:4px 0 8px' }, `今天已記錄 · 近 7 天平均 ${summary.average != null ? summary.average : '--'} 分`));
    } else {
      body.appendChild(el('p', { class: 'hint', style: 'margin:0 0 6px' }, '今天還沒記錄，點個分數快速記一下：'));
    }

    const quickRow = el('div', { class: 'mood-score-row sm', id: 'dashMoodQuickRow' });
    for (let i = 1; i <= 10; i++) {
      quickRow.appendChild(el('button', {
        class: 'mood-score-btn sm' + (dashMoodQuickScore === i ? ' selected' : ''),
        'data-score': i,
        onclick: (ev) => { ev.stopPropagation(); dashQuickMoodPick(i); },
      }, String(i)));
    }
    body.appendChild(quickRow);

    body.appendChild(el('div', { class: 'dash-mood-quick-note', id: 'dashMoodQuickNoteRow', style: todayRows.length ? 'display:none' : 'display:flex' }, [
      el('input', { id: 'dashMoodQuickNote', placeholder: '想補充一句嗎？(選填)', value: todayRows.length ? (todayRows[0].note || '') : '', onclick: (ev) => ev.stopPropagation(), onkeydown: (ev) => ev.stopPropagation() }),
      el('button', { class: 'btn btn-primary', style: 'font-size:12px;padding:6px 10px', onclick: (ev) => { ev.stopPropagation(); saveDashQuickMood(); } }, '儲存'),
    ]));
  } catch (e) {
    body.innerHTML = '';
    body.appendChild(el('p', { class: 'hint', style: 'margin-bottom:0' }, '心情資料暫時無法取得'));
  }
}

function dashQuickMoodPick(score) {
  dashMoodQuickScore = score;
  document.querySelectorAll('#dashMoodQuickRow .mood-score-btn').forEach((b) => b.classList.toggle('selected', Number(b.dataset.score) === score));
  const noteRow = $('#dashMoodQuickNoteRow');
  if (noteRow) noteRow.style.display = 'flex';
}

async function saveDashQuickMood() {
  if (!dashMoodQuickScore) { showToast('先選一個 1-10 的分數'); return; }
  try {
    const noteEl = $('#dashMoodQuickNote');
    await api(`/mood/entries/${todayStr()}`, {
      method: 'PUT',
      body: { score: dashMoodQuickScore, tags: [], note: noteEl ? noteEl.value.trim() : '' },
    });
    showToast('已記錄今天的心情 💗');
    loadDashMoodSummary();
  } catch (e) { showToast('儲存失敗：' + e.message); }
}

async function loadDashStockSummary() {
  const body = $('#stocksSummaryBody');
  if (!body) return;
  try {
    const t = await api('/stocks/index/taiex');
    body.innerHTML = '';
    const changeColor = t.change > 0 ? 'delta-up' : t.change < 0 ? 'delta-down' : '';
    body.appendChild(el('div', { class: 'stat-big' }, [
      t.index != null ? Number(t.index).toLocaleString('zh-Hant-TW', { maximumFractionDigits: 2 }) : '--',
      el('span', { class: changeColor, style: 'font-size:13px;margin-left:8px' }, t.change != null ? `${t.change > 0 ? '▲+' : t.change < 0 ? '▼' : ''}${t.change}` : ''),
    ]));
    body.appendChild(el('p', { class: 'hint', style: 'margin:6px 0 0' }, `加權指數 · 台灣證交所公開資料`));
    if (state.watchlist.length) {
      const list = el('ul', { class: 'dash-mini-list' });
      state.watchlist.slice(0, 4).forEach((code) => {
        list.appendChild(el('li', {}, [el('span', { class: 'lbl' }, code), el('span', {}, '點卡片查看報價')]));
      });
      body.appendChild(list);
      if (state.watchlist.length > 4) body.appendChild(el('p', { class: 'hint', style: 'margin:6px 0 0' }, `還有 ${state.watchlist.length - 4} 檔自選股`));
    } else {
      body.appendChild(el('p', { class: 'hint', style: 'margin:6px 0 0' }, '還沒有加入自選股，點卡片前往設定'));
    }
  } catch (e) {
    body.innerHTML = '';
    body.appendChild(el('p', { class: 'hint', style: 'margin-bottom:0' }, '股市資料暫時無法取得'));
  }
}

async function loadDashCalendarSummary() {
  const body = $('#calendarSummaryBody');
  if (!body) return;
  try {
    const today = new Date();
    const from = today.toISOString().slice(0, 10);
    const toDate = new Date(today); toDate.setDate(toDate.getDate() + 14);
    const to = toDate.toISOString().slice(0, 10);
    const events = await api(`/calendar?from=${from}&to=${to}`);
    body.innerHTML = '';
    if (!events.length) {
      body.appendChild(el('p', { class: 'hint', style: 'margin-bottom:0' }, '接下來兩週沒有安排的行程'));
    } else {
      const list = el('ul', { style: 'list-style:none;padding:0;margin:0;display:flex;flex-direction:column;gap:6px' });
      events.slice(0, 3).forEach((ev) => {
        list.appendChild(el('li', { style: 'font-size:12.5px;color:var(--text-secondary)' }, `${ev.event_date}${ev.start_time ? ' ' + ev.start_time : ''} · ${ev.title}`));
      });
      body.appendChild(list);
      if (events.length > 3) body.appendChild(el('p', { class: 'hint', style: 'margin:6px 0 0' }, `還有 ${events.length - 3} 項行程，點卡片查看完整行事曆`));
    }
  } catch (e) {
    body.innerHTML = '';
    body.appendChild(el('p', { class: 'hint', style: 'margin-bottom:0' }, '行事曆資料暫時無法取得'));
  }
}

async function loadDashFinanceSummary() {
  const body = $('#financeSummaryBody');
  if (!body) return;
  try {
    const summary = await api('/finance/summary');
    const income = (summary.totals || []).find((t) => t.type === 'income')?.total || 0;
    const expense = (summary.totals || []).find((t) => t.type === 'expense')?.total || 0;
    body.innerHTML = '';
    body.appendChild(el('div', { class: 'stat-big' }, fmtMoney(expense)));
    body.appendChild(el('p', { class: 'hint', style: 'margin:4px 0 0' }, `本月支出 · 收入 ${fmtMoney(income)}`));
    const byExpense = (summary.byCategory || []).filter((c) => c.type === 'expense').slice(0, 4);
    if (byExpense.length) {
      const list = el('ul', { class: 'dash-mini-list' });
      byExpense.forEach((c) => {
        list.appendChild(el('li', {}, [el('span', { class: 'lbl' }, c.category), el('span', {}, fmtMoney(c.total))]));
      });
      body.appendChild(list);
    } else {
      body.appendChild(el('p', { class: 'hint', style: 'margin:8px 0 0' }, '本月還沒有記帳紀錄，點卡片新增一筆'));
    }
  } catch (e) {
    body.innerHTML = '';
    body.appendChild(el('p', { class: 'hint', style: 'margin-bottom:0' }, '記帳資料暫時無法取得'));
  }
}

async function loadDashDiarySummary() {
  const body = $('#diarySummaryBody');
  if (!body) return;
  try {
    const entries = await api('/diary?from=0001-01-01&to=9999-12-31');
    body.innerHTML = '';
    if (!entries.length) {
      body.appendChild(el('p', { class: 'hint', style: 'margin-bottom:0' }, '還沒有日記，點卡片開始寫下今天'));
    } else {
      body.appendChild(el('p', { class: 'hint', style: 'margin-bottom:8px' }, `共 ${entries.length} 篇日記，最近寫的：`));
      const list = el('div', { style: 'display:flex;flex-direction:column;gap:10px' });
      entries.slice(0, 3).forEach((entry) => {
        const snippet = (entry.content || '').slice(0, 34);
        list.appendChild(el('div', {}, [
          el('div', { style: 'font-size:11.5px;color:var(--text-muted)' }, entry.entry_date),
          el('div', { style: 'font-size:12.5px;color:var(--text-secondary)' }, snippet + (entry.content && entry.content.length > 34 ? '…' : '')),
        ]));
      });
      body.appendChild(list);
    }
  } catch (e) {
    body.innerHTML = '';
    body.appendChild(el('p', { class: 'hint', style: 'margin-bottom:0' }, '日記資料暫時無法取得'));
  }
}

async function loadDashTasksSummary() {
  const body = $('#tasksSummaryBody');
  if (!body) return;
  try {
    const pending = await api('/tasks?status=pending');
    body.innerHTML = '';
    if (!pending.length) {
      body.appendChild(el('p', { class: 'hint', style: 'margin-bottom:0' }, '目前沒有待完成的任務'));
    } else {
      const overdue = pending.filter((t) => t.due_date && t.due_date < todayStr()).length;
      body.appendChild(el('p', { class: 'hint', style: 'margin-bottom:8px' }, `${pending.length} 件待完成${overdue ? `，其中 ${overdue} 件已過期` : ''}`));
      const list = el('div', { class: 'dash-mini-list' });
      pending.slice(0, 3).forEach((t) => list.appendChild(el('div', {}, `${PRIORITY_LABEL[t.priority] || ''} ${t.title}`)));
      body.appendChild(list);
    }
  } catch (e) {
    body.innerHTML = '';
    body.appendChild(el('p', { class: 'hint', style: 'margin-bottom:0' }, '待辦資料暫時無法取得'));
  }
}

async function loadDashBillsSummary() {
  const body = $('#billsSummaryBody');
  if (!body) return;
  try {
    const res = await api('/bills/upcoming');
    body.innerHTML = '';
    const unpaid = res.bills.filter((b) => !b.paid);
    if (!res.bills.length) {
      body.appendChild(el('p', { class: 'hint', style: 'margin-bottom:0' }, '還沒有加入任何帳單'));
    } else if (!unpaid.length) {
      body.appendChild(el('p', { class: 'hint', style: 'margin-bottom:0' }, '這個月的帳單都繳完了 🎉'));
    } else {
      body.appendChild(el('p', { class: 'hint', style: 'margin-bottom:8px' }, `這個月還有 ${unpaid.length} 筆未繳，共 NT$ ${Math.round(res.totalUnpaid)}`));
      const list = el('div', { class: 'dash-mini-list' });
      unpaid.slice(0, 3).forEach((b) => list.appendChild(el('div', {}, `${b.name}（每月 ${b.due_day} 號）`)));
      body.appendChild(list);
    }
  } catch (e) {
    body.innerHTML = '';
    body.appendChild(el('p', { class: 'hint', style: 'margin-bottom:0' }, '帳單資料暫時無法取得'));
  }
}

function dashAskAI() {
  const input = $('#dashAskInput');
  const text = input ? input.value.trim() : '';
  if (!text) { switchTab('assistant'); return; }
  switchTab('assistant');
  state.assistantHistory = state.assistantHistory || [];
  const target = $('#assistantInput');
  if (target) { target.value = text; sendAssistantMessage(); }
}

// 手動觸發首頁摘要 (不是每次載入首頁就自動打 AI，避免不必要的 API 用量)
async function generateDashBriefing(period) {
  const box = $('#dashBriefResult');
  const btn = document.querySelector('.dash-brief-btn');
  if (!box) return;
  box.style.display = 'block';
  box.innerHTML = '';
  box.appendChild(el('p', { class: 'hint', style: 'margin:0' }, '整理中...'));
  if (btn) btn.disabled = true;
  try {
    const result = await api('/assistant/briefing', { method: 'POST', body: { period } });
    box.innerHTML = '';
    box.appendChild(el('p', { style: 'margin:0;white-space:pre-wrap' }, result.reply || '目前沒有特別的內容'));
  } catch (e) {
    box.innerHTML = '';
    box.appendChild(el('p', { class: 'hint', style: 'margin:0' }, '摘要暫時無法產生：' + e.message));
  } finally {
    if (btn) btn.disabled = false;
  }
}

// ===================== 股票 =====================
const STOCK_SUB_TABS = [
  { key: 'watchlist', label: '⭐ 自選股' },
  { key: 'portfolio', label: '💼 我的持股' },
  { key: 'alerts', label: '🔔 到價提醒' },
  { key: 'screener', label: '🔍 選股工具' },
];
let stockSubTab = 'watchlist';
function switchStockSub(key) {
  stockSubTab = key;
  renderStocks();
}

async function renderStocks() {
  const c = $('#tab-stocks');
  c.innerHTML = '';
  c.appendChild(el('div', { class: 'disclaimer' }, '股票資訊來自台灣證券交易所公開資料 (每日盤後更新)，所有技術指標、選股工具皆為統計描述/資料整理，SOX 指數為非官方資料源，均不構成任何投資建議，買賣決策請自行判斷並留意風險。'));

  c.appendChild(el('div', { class: 'grid-2', style: 'margin-bottom:16px' }, [
    el('div', { class: 'card', id: 'taiexCard', style: 'margin-bottom:0' }, [el('div', {}, '台股加權指數載入中...')]),
    el('div', { class: 'card', id: 'soxCard', style: 'margin-bottom:0' }, [el('div', {}, '費半指數 (SOX) 載入中...')]),
  ]));
  loadTaiexCard();
  loadSoxCard();

  c.appendChild(el('div', { class: 'subnav' }, STOCK_SUB_TABS.map((t) =>
    el('div', { class: `subnav-item${stockSubTab === t.key ? ' active' : ''}`, onclick: () => switchStockSub(t.key) }, t.label)
  )));
  const panel = (key, children) => el('div', { class: `subpanel${stockSubTab === key ? ' active' : ''}` }, children);

  if (stockSubTab === 'watchlist') {
    if (stockDetailCode && state.watchlist.includes(stockDetailCode)) {
      // ---- 個股詳細頁 (master-detail)：點列表進來看單一個股的完整資料，不用整頁滑很長 ----
      const detailWrap = el('div', { id: 'watchlistArea' });
      c.appendChild(panel('watchlist', [detailWrap]));
      loadStockDetail(stockDetailCode, detailWrap);
    } else {
      const watchCard = el('div', { class: 'card' }, [
        el('h3', {}, '自選股'),
        el('p', { class: 'hint' }, '點股票列查看該股完整資訊 (估值、均線、KD/RSI/MACD、法人動向、新聞)；按 📌 可同時釘選多檔只看關鍵數字比較。'),
        el('div', { class: 'form-row' }, [
          el('input', { id: 'newStockCode', placeholder: '輸入股票代號或公司名稱，如 2330 或 台積電' }),
          el('button', { class: 'btn btn-primary', onclick: addWatchStock }, '加入自選'),
        ]),
        el('div', { id: 'watchlistArea' }),
      ]);
      c.appendChild(panel('watchlist', [watchCard]));
      await renderWatchlist();
    }
  } else if (stockSubTab === 'portfolio') {
    c.appendChild(panel('portfolio', [renderPortfolioPanel()]));
    loadPortfolio();
  } else if (stockSubTab === 'alerts') {
    c.appendChild(panel('alerts', [renderAlertsPanel()]));
    loadAlerts();
  } else if (stockSubTab === 'screener') {
    c.appendChild(panel('screener', [renderScreenerPanel()]));
  }
}

function indexCardContent(name, value, change, badgeText, extraLabel) {
  const changeColor = change > 0 ? 'delta-up' : change < 0 ? 'delta-down' : '';
  return el('div', { class: 'index-card' }, [
    el('div', {}, [
      el('div', { class: 'idx-name' }, name),
      el('div', { class: 'stat-tile' }, [
        el('span', { class: 'value' }, value != null ? Number(value).toLocaleString('zh-Hant-TW', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : '--'),
        el('span', { class: changeColor, style: 'margin-left:8px' }, change != null ? `${change > 0 ? '▲+' : change < 0 ? '▼' : ''}${change}` : ''),
      ]),
      extraLabel ? el('div', { class: 'label' }, extraLabel) : null,
    ]),
    el('span', { class: 'badge badge-neutral' }, badgeText),
  ]);
}

async function loadTaiexCard() {
  const card = $('#taiexCard');
  try {
    const t = await api('/stocks/index/taiex');
    card.innerHTML = '';
    card.appendChild(indexCardContent(t.symbol, t.index, t.change, '證交所官方資料',
      t.tradeValue != null ? `資料日期 ${t.date || '--'} · 成交金額 ${fmtNum(Math.round(t.tradeValue / 100000000))} 億` : `資料日期 ${t.date || '--'}`));
  } catch (e) {
    card.innerHTML = '';
    card.appendChild(el('div', { style: 'font-size:12px;color:var(--text-muted)' }, `加權指數暫時無法取得 (${e.message})`));
  }
}

async function loadSoxCard() {
  const card = $('#soxCard');
  try {
    const sox = await api('/stocks/index/sox');
    card.innerHTML = '';
    card.appendChild(indexCardContent(sox.symbol, sox.price, sox.change, '非官方資料源', null));
  } catch (e) {
    card.innerHTML = '';
    card.appendChild(el('div', { style: 'font-size:12px;color:var(--text-muted)' }, `費半指數暫時無法取得 (${e.message})`));
  }
}

async function addWatchStock() {
  const raw = $('#newStockCode').value.trim();
  if (!raw) return;
  try {
    const resolved = await api(`/stocks/resolve/${encodeURIComponent(raw)}`);
    if (!state.watchlist.includes(resolved.code)) state.watchlist.push(resolved.code);
    $('#newStockCode').value = '';
    await savePrefsWatchlist();
    renderWatchlist();
    showToast(`已加入 ${resolved.name} (${resolved.code})`);
  } catch (e) {
    showToast(`加入失敗：${e.message}`);
  }
}
async function removeWatchStock(code) {
  state.watchlist = state.watchlist.filter((c) => c !== code);
  await savePrefsWatchlist();
  pinnedStocks.delete(code);
  if (stockDetailCode === code) stockDetailCode = null;
  if (stockDetailCode) renderStocks(); else renderWatchlist();
}
async function savePrefsWatchlist() {
  try {
    await api('/prefs', { method: 'PUT', body: { ...state.prefs, watchlist: state.watchlist } });
  } catch (e) {}
}

// ---- Master-detail 導覽狀態：點列表跳轉到單一個股的詳細頁，而不是原地展開一長串 ----
let stockDetailCode = null;
const pinnedStocks = new Set(); // 同時釘選多檔時，只顯示精簡數字比較，不用一次攤開全部細節

function openStockDetail(code) {
  stockDetailCode = code;
  renderStocks();
}
function closeStockDetail() {
  stockDetailCode = null;
  renderStocks();
}
function togglePinStock(code, ev) {
  if (ev) ev.stopPropagation();
  if (pinnedStocks.has(code)) pinnedStocks.delete(code);
  else pinnedStocks.add(code);
  renderWatchlist();
}

function sectionTitle(text) {
  return el('div', { style: 'font-size:12.5px;font-weight:700;color:var(--text-secondary);margin-bottom:8px' }, text);
}

function miniStat(label, value) {
  return el('span', { class: 'mini-stat' }, [label + ' ', el('b', {}, value)]);
}
function miniBadge(tone, text) {
  const cls = tone === 'positive' ? 'badge-positive' : tone === 'negative' ? 'badge-negative' : 'badge-neutral';
  return el('span', { class: `badge ${cls}`, style: 'font-size:11px;padding:2px 8px' }, text);
}

async function renderWatchlist() {
  const area = $('#watchlistArea');
  area.innerHTML = '';
  if (!state.watchlist.length) { area.appendChild(el('div', { class: 'empty-state' }, '尚未加入自選股')); return; }

  // ---- 釘選比較區：同時釘選多檔時，只顯示精簡數字，不用整排都攤開 ----
  const pinned = state.watchlist.filter((c) => pinnedStocks.has(c));
  if (pinned.length) {
    const compareGrid = el('div', { class: 'stock-compare-grid' });
    area.appendChild(el('div', { style: 'margin-bottom:14px' }, [
      sectionTitle(`📌 已釘選比較 (${pinned.length})`),
      compareGrid,
    ]));
    pinned.forEach((code) => {
      const cardBox = el('div', { class: 'stock-compare-card' }, [el('div', { class: 'label' }, `載入 ${code} 中...`)]);
      compareGrid.appendChild(cardBox);
      loadCompareCard(code, cardBox);
    });
  }

  const listBox = el('div', { class: 'stock-row-list' });
  area.appendChild(listBox);
  for (const code of state.watchlist) {
    const row = el('div', { class: 'stock-row' }, [el('div', { class: 'label' }, `載入 ${code} 中...`)]);
    listBox.appendChild(row);
    loadWatchlistRow(code, row);
  }
}

async function loadCompareCard(code, box) {
  try {
    const [quote, valuation] = await Promise.all([
      api(`/stocks/quote/${code}`).catch((e) => ({ error: e.message })),
      api(`/stocks/valuation/${code}`).catch((e) => ({ error: e.message })),
    ]);
    box.innerHTML = '';
    if (quote.error) {
      box.appendChild(el('div', { class: 'label' }, `${code} — ${quote.error}`));
      return;
    }
    const changeColor = quote.change > 0 ? 'delta-up' : quote.change < 0 ? 'delta-down' : '';
    box.appendChild(el('div', { style: 'display:flex;justify-content:space-between;align-items:flex-start' }, [
      el('div', { style: 'font-weight:800;font-size:13.5px;cursor:pointer', onclick: () => openStockDetail(code) }, `${quote.name || code} (${code})`),
      el('span', { style: 'cursor:pointer;font-size:13px', onclick: (ev) => togglePinStock(code, ev), title: '取消釘選' }, '📌'),
    ]));
    box.appendChild(el('div', { class: 'stat-tile', style: 'margin-top:4px' }, [
      el('span', { class: 'value', style: 'font-size:16px' }, quote.closingPrice != null ? quote.closingPrice.toFixed(2) : '--'),
      el('span', { class: changeColor, style: 'margin-left:6px;font-size:12px' }, `${quote.change > 0 ? '▲+' : quote.change < 0 ? '▼' : ''}${quote.change}`),
    ]));
    if (!valuation.error && valuation) {
      box.appendChild(el('div', { style: 'margin-top:6px;display:flex;flex-wrap:wrap;gap:6px' }, [
        valuation.peRatio != null ? miniStat('本益比', valuation.peRatio.toFixed(2)) : null,
        valuation.dividendYield != null ? miniStat('殖利率', valuation.dividendYield.toFixed(2) + '%') : null,
      ]));
    }
  } catch (e) {
    box.innerHTML = '';
    box.appendChild(el('div', { class: 'label' }, `${code} 載入失敗`));
  }
}

async function loadWatchlistRow(code, row) {
  try {
    const [quote, inst, indicatorRes, valuation, technicals] = await Promise.all([
      api(`/stocks/quote/${code}`).catch((e) => ({ error: e.message })),
      api(`/stocks/institutional/${code}?days=15`).catch((e) => ({ error: e.message })),
      api(`/stocks/indicator/${code}`).catch((e) => ({ error: e.message })),
      api(`/stocks/valuation/${code}`).catch((e) => ({ error: e.message })),
      api(`/stocks/technicals/${code}`).catch((e) => ({ error: e.message })),
    ]);
    row.innerHTML = '';
    if (quote.error) {
      row.appendChild(el('div', { style: 'display:flex;justify-content:space-between;align-items:center' }, [
        el('div', {}, [el('b', {}, code), ` — ${quote.error}`]),
        el('button', { class: 'btn btn-ghost', onclick: () => removeWatchStock(code) }, '移除'),
      ]));
      return;
    }
    const changeColor = quote.change > 0 ? 'delta-up' : quote.change < 0 ? 'delta-down' : '';
    const prevClose = quote.closingPrice != null ? quote.closingPrice - quote.change : null;
    const changePct = prevClose ? (quote.change / prevClose) * 100 : null;

    // ---- 精簡數字列：只看這排就好，點列進入詳細頁，不用原地展開一長串 ----
    const summaryChips = [];
    if (!valuation.error && valuation && valuation.peRatio != null) summaryChips.push(miniStat('本益比', valuation.peRatio.toFixed(2)));
    if (!valuation.error && valuation && valuation.dividendYield != null) summaryChips.push(miniStat('殖利率', valuation.dividendYield.toFixed(2) + '%'));
    if (!indicatorRes.error && indicatorRes.indicator && indicatorRes.indicator.available) {
      summaryChips.push(miniBadge(indicatorRes.indicator.tone, `均線 ${indicatorRes.indicator.label}`));
    }
    if (!inst.error && inst.signal) summaryChips.push(miniBadge(inst.signal.tone, `法人 ${inst.signal.label}`));
    if (!technicals.error && technicals.kd && technicals.kd.available) summaryChips.push(miniBadge(technicals.kd.tone, `KD ${technicals.kd.k}`));

    row.className = 'stock-row';
    row.onclick = () => openStockDetail(code);
    row.appendChild(el('div', { class: 'stock-row-left' }, [
      el('div', { style: 'font-weight:800;font-size:15px' }, `${quote.name || code} (${code})`),
      summaryChips.length ? el('div', { class: 'stock-summary-chips' }, summaryChips) : el('div', { class: 'label', style: 'margin-top:4px' }, `收盤日期 ${quote.date || '--'}`),
    ]));
    row.appendChild(el('div', { class: 'stock-row-right' }, [
      el('div', { class: 'stat-tile' }, [
        el('span', { class: 'value', style: 'font-size:18px' }, quote.closingPrice != null ? quote.closingPrice.toFixed(2) : '--'),
        el('span', { class: changeColor, style: 'margin-left:6px;font-size:12.5px' },
          `${quote.change > 0 ? '▲+' : quote.change < 0 ? '▼' : ''}${quote.change}${changePct != null ? ` (${changePct > 0 ? '+' : ''}${changePct.toFixed(2)}%)` : ''}`),
      ]),
      el('span', {
        class: `stock-pin-btn${pinnedStocks.has(code) ? ' active' : ''}`,
        title: pinnedStocks.has(code) ? '取消釘選比較' : '釘選比較 (數字檢視)',
        onclick: (ev) => togglePinStock(code, ev),
      }, '📌'),
      el('button', {
        class: 'btn btn-ghost',
        style: 'padding:5px 10px;font-size:12px',
        onclick: (ev) => { ev.stopPropagation(); removeWatchStock(code); },
      }, '移除'),
    ]));
  } catch (e) {
    row.innerHTML = '';
    row.appendChild(el('div', {}, `${code} 載入失敗: ${e.message}`));
  }
}

async function loadStockDetail(code, box) {
  try {
    const [quote, inst, indicatorRes, newsRes, valuation, historyRes, technicals, instVolTrend] = await Promise.all([
      api(`/stocks/quote/${code}`).catch((e) => ({ error: e.message })),
      api(`/stocks/institutional/${code}?days=15`).catch((e) => ({ error: e.message })),
      api(`/stocks/indicator/${code}`).catch((e) => ({ error: e.message })),
      api(`/stocks/news/${code}`).catch((e) => ({ error: e.message })),
      api(`/stocks/valuation/${code}`).catch((e) => ({ error: e.message })),
      api(`/stocks/history/${code}`).catch((e) => ({ error: e.message })),
      api(`/stocks/technicals/${code}`).catch((e) => ({ error: e.message })),
      api(`/stocks/institutional/${code}/volume-trend`).catch((e) => ({ error: e.message })),
    ]);
    box.innerHTML = '';
    const backBtn = el('button', { class: 'btn btn-ghost stock-detail-back', onclick: closeStockDetail }, '← 返回自選股列表');
    if (quote.error) {
      box.appendChild(el('div', { class: 'card' }, [
        backBtn,
        el('div', { style: 'margin-top:10px' }, [el('b', {}, code), ` — ${quote.error}`]),
      ]));
      return;
    }
    const changeColor = quote.change > 0 ? 'delta-up' : quote.change < 0 ? 'delta-down' : '';
    const prevClose = quote.closingPrice != null ? quote.closingPrice - quote.change : null;
    const changePct = prevClose ? (quote.change / prevClose) * 100 : null;

    box.appendChild(el('div', { class: 'stock-detail-topline' }, [
      backBtn,
      el('span', {
        class: `stock-pin-btn${pinnedStocks.has(code) ? ' active' : ''}`,
        style: 'font-size:18px',
        title: pinnedStocks.has(code) ? '取消釘選比較' : '釘選比較 (數字檢視)',
        onclick: () => togglePinStock(code),
      }, '📌'),
    ]));

    // ---- 主要區塊：左欄大字報價+基本數據，右欄圖表/技術指標/法人/新聞，兩欄各自呈現，減少整頁往下滑 ----
    const detail = el('div', { class: 'stock-detail-grid' });
    box.appendChild(detail);

    const colLeft = el('div', { class: 'stock-detail-col stock-detail-col-left' });
    const colRight = el('div', { class: 'stock-detail-col stock-detail-col-right' });
    detail.appendChild(colLeft);
    detail.appendChild(colRight);

    // ---- 左欄：主角級大字報價 ----
    colLeft.appendChild(el('div', { class: 'card stock-hero-card' }, [
      el('div', { style: 'font-size:13px;font-weight:700;color:var(--text-secondary)' }, `${quote.name || code} (${code})`),
      el('div', { class: 'stock-hero-price' }, quote.closingPrice != null ? quote.closingPrice.toFixed(2) : '--'),
      el('div', { class: changeColor, style: 'font-size:16px;font-weight:700' },
        `${quote.change > 0 ? '▲ +' : quote.change < 0 ? '▼ ' : ''}${quote.change}${changePct != null ? ` (${changePct > 0 ? '+' : ''}${changePct.toFixed(2)}%)` : ''}`),
      el('div', { class: 'label', style: 'margin-top:6px' }, `收盤日期 ${quote.date || '--'} (每日盤後更新)`),
    ]));

    // ---- 詳細數據格 (開高低量 + 估值) ----
    const kv = (k, v) => el('div', { class: 'kv' }, [el('div', { class: 'k' }, k), el('div', { class: 'v' }, v)]);
    const kvs = [
      kv('開盤', quote.openingPrice != null ? quote.openingPrice.toFixed(2) : '--'),
      kv('最高', quote.highestPrice != null ? quote.highestPrice.toFixed(2) : '--'),
      kv('最低', quote.lowestPrice != null ? quote.lowestPrice.toFixed(2) : '--'),
      kv('成交量', fmtNum(quote.tradeVolume) + ' 股'),
    ];
    if (!valuation.error && valuation && (valuation.peRatio != null || valuation.dividendYield != null || valuation.pbRatio != null)) {
      kvs.push(kv('本益比', valuation.peRatio != null ? valuation.peRatio.toFixed(2) : '--'));
      kvs.push(kv('殖利率', valuation.dividendYield != null ? valuation.dividendYield.toFixed(2) + '%' : '--'));
      kvs.push(kv('股價淨值比', valuation.pbRatio != null ? valuation.pbRatio.toFixed(2) : '--'));
      kvs.push(kv('振幅',
        quote.highestPrice != null && quote.lowestPrice != null && prevClose
          ? (((quote.highestPrice - quote.lowestPrice) / prevClose) * 100).toFixed(2) + '%' : '--'));
    }
    colLeft.appendChild(el('div', { class: 'card' }, [sectionTitle('關鍵數據'), el('div', { class: 'kv-grid' }, kvs)]));

    // ---- 均線位置描述 (非預測) ----
    if (!indicatorRes.error && indicatorRes.indicator && indicatorRes.indicator.available) {
      const ind = indicatorRes.indicator;
      const badgeClass = ind.tone === 'positive' ? 'badge-positive' : ind.tone === 'negative' ? 'badge-negative' : 'badge-neutral';
      colLeft.appendChild(el('div', { class: 'card' }, [
        sectionTitle('均線位置'),
        el('span', { class: `badge ${badgeClass}` }, ind.label),
        el('span', { style: 'margin-left:8px;font-size:12px;color:var(--text-muted)' }, `MA5 ${ind.ma5} / MA20 ${ind.ma20} (${ind.diffPct > 0 ? '+' : ''}${ind.diffPct}%)`),
        el('div', { style: 'font-size:11px;color:var(--text-muted);margin-top:4px' }, ind.disclaimer),
      ]));
    } else if (indicatorRes.indicator) {
      colLeft.appendChild(el('div', { class: 'card' }, [sectionTitle('均線位置'), el('div', { style: 'font-size:12px;color:var(--text-muted)' }, indicatorRes.indicator.reason || '')]));
    }

    // ---- 右欄：股價走勢 + 均線圖 ----
    if (!historyRes.error && historyRes.points && historyRes.points.length >= 5) {
      const sec = el('div', { class: 'card' }, [sectionTitle(`近 ${historyRes.points.length} 個交易日收盤走勢與均線`)]);
      const chartDiv = el('div');
      sec.appendChild(chartDiv);
      colRight.appendChild(sec);
      renderPriceChart(chartDiv, historyRes.points);
    }

    // ---- 更多技術指標 (RSI / KD / MACD / 成交量趨勢) ----
    if (!technicals.error) {
      const techBadges = [];
      if (technicals.rsi && technicals.rsi.available) techBadges.push(miniBadge(technicals.rsi.tone, `RSI ${technicals.rsi.value}`));
      if (technicals.kd && technicals.kd.available) techBadges.push(miniBadge(technicals.kd.tone, `KD K${technicals.kd.k} D${technicals.kd.d}`));
      if (technicals.macd && technicals.macd.available) techBadges.push(miniBadge(technicals.macd.tone, `MACD 柱狀 ${technicals.macd.histogram}`));
      if (technicals.volumeTrend && technicals.volumeTrend.available) techBadges.push(miniBadge(technicals.volumeTrend.tone, technicals.volumeTrend.label));
      if (techBadges.length) {
        const techSec = el('div', { class: 'card' }, [
          sectionTitle('更多技術指標 (統計描述，非預測)'),
          el('div', { style: 'display:flex;flex-wrap:wrap;gap:6px' }, techBadges),
        ]);
        if (technicals.rsi && technicals.rsi.available) techSec.appendChild(el('div', { class: 'label', style: 'margin-top:6px' }, `RSI(${technicals.rsi.period})：${technicals.rsi.label}`));
        if (technicals.kd && technicals.kd.available) techSec.appendChild(el('div', { class: 'label', style: 'margin-top:2px' }, `KD：${technicals.kd.label} · ${technicals.kd.crossNote}`));
        if (technicals.macd && technicals.macd.available) techSec.appendChild(el('div', { class: 'label', style: 'margin-top:2px' }, `MACD：${technicals.macd.label}`));
        if (!instVolTrend.error && instVolTrend.available) techSec.appendChild(el('div', { class: 'label', style: 'margin-top:2px' }, `法人力道：${instVolTrend.label}`));
        colRight.appendChild(techSec);
      }
    }

    // ---- 法人動向 (合計圖 + 外資/投信/自營商 分項) ----
    if (!inst.error) {
      const badgeClass = inst.signal.tone === 'positive' ? 'badge-positive' : inst.signal.tone === 'negative' ? 'badge-negative' : 'badge-neutral';
      const instSec = el('div', { class: 'card' }, [
        sectionTitle('三大法人買賣超 (近15個交易日)'),
        el('div', {}, [
          el('span', { class: `badge ${badgeClass}` }, inst.signal.label),
          el('span', { style: 'margin-left:8px;font-size:12px;color:var(--text-muted)' }, inst.signal.detail),
        ]),
      ]);
      const chartDiv = el('div', { style: 'margin-top:10px' });
      instSec.appendChild(chartDiv);
      colRight.appendChild(instSec);
      renderDivergingChart(chartDiv, inst.trend);

      const last = inst.trend[inst.trend.length - 1];
      if (last && last.foreign != null) {
        const sum = (k) => inst.trend.reduce((s, t) => s + (t[k] || 0), 0);
        const chip = (label, today, cum) => el('div', { class: 'inst-chip' }, [
          el('div', { class: 'k' }, `${label} (最新交易日)`),
          el('div', { class: 'v', style: today >= 0 ? 'color:var(--series-blue)' : 'color:var(--series-red)' },
            `${today >= 0 ? '買超 +' : '賣超 '}${fmtNum(today)} 股`),
          el('div', { class: 'k' }, `近${inst.trend.length}日累計 ${cum >= 0 ? '+' : ''}${fmtNum(cum)}`),
        ]);
        instSec.appendChild(el('div', { class: 'inst-chips' }, [
          chip('外資', last.foreign, sum('foreign')),
          chip('投信', last.trust, sum('trust')),
          chip('自營商', last.dealer, sum('dealer')),
        ]));
      }
    }

    // ---- 相關新聞 ----
    if (!newsRes.error && newsRes.items && newsRes.items.length) {
      const newsBox = el('div', { class: 'card' }, [sectionTitle('相關新聞 (來源: Yahoo奇摩股市)')]);
      newsRes.items.slice(0, 5).forEach((n) => {
        newsBox.appendChild(el('a', { href: n.link, target: '_blank', rel: 'noopener', style: 'display:block;font-size:12.5px;color:var(--series-blue);margin-bottom:5px;text-decoration:none' }, '· ' + n.title));
      });
      colRight.appendChild(newsBox);
    }
  } catch (e) {
    box.innerHTML = '';
    box.appendChild(el('div', { class: 'card' }, [el('button', { class: 'btn btn-ghost', onclick: closeStockDetail }, '← 返回自選股列表'), el('div', { style: 'margin-top:10px' }, `${code} 載入失敗: ${e.message}`)]));
  }
}

// ---------- 我的持股 (庫存損益追蹤) ----------
function renderPortfolioPanel() {
  return el('div', {}, [
    el('div', { class: 'card' }, [
      el('h3', {}, '➕ 新增交易紀錄'),
      el('p', { class: 'hint' }, '記下買賣進出，損益 (含已實現/未實現) 會自動用移動加權平均成本法算給你看，不用自己拿計算機算。'),
      el('div', { class: 'form-row' }, [
        el('input', { id: 'stxCode', list: 'stxCodeList', placeholder: '股票代號，如 2330' }),
        el('datalist', { id: 'stxCodeList' }),
        el('input', { id: 'stxDate', type: 'date', value: todayStr() }),
        el('select', { id: 'stxSide' }, [el('option', { value: 'buy' }, '買進'), el('option', { value: 'sell' }, '賣出')]),
      ]),
      el('div', { class: 'form-row', style: 'margin-top:8px' }, [
        el('input', { id: 'stxShares', type: 'number', placeholder: '股數' }),
        el('input', { id: 'stxPrice', type: 'number', placeholder: '成交價' }),
        el('input', { id: 'stxFee', type: 'number', placeholder: '手續費 (選填)' }),
        el('input', { id: 'stxTax', type: 'number', placeholder: '證交稅 (賣出，選填)' }),
      ]),
      el('button', { class: 'btn btn-primary', style: 'margin-top:10px', onclick: addStockTransaction }, '新增交易'),
    ]),
    el('div', { class: 'card' }, [
      el('h3', {}, '💰 股利紀錄'),
      el('div', { class: 'form-row' }, [
        el('input', { id: 'stxDivCode', list: 'stxCodeList', placeholder: '股票代號' }),
        el('input', { id: 'stxDivDate', type: 'date', value: todayStr() }),
        el('input', { id: 'stxDivAmount', type: 'number', placeholder: '發放金額' }),
      ]),
      el('button', { class: 'btn btn-ghost', style: 'margin-top:8px', onclick: addStockDividend }, '新增股利紀錄'),
      el('div', { id: 'stxDividendList', style: 'margin-top:10px' }),
    ]),
    el('div', { class: 'card' }, [
      el('h3', {}, '📊 庫存損益總覽'),
      el('div', { id: 'stxPortfolioSummary' }, el('div', { class: 'empty-state' }, '載入中...')),
      el('div', { id: 'stxPortfolioList', style: 'margin-top:10px' }),
    ]),
    el('div', { class: 'card' }, [
      el('h3', {}, '📜 交易紀錄'),
      el('div', { id: 'stxTransactionList' }, el('div', { class: 'empty-state' }, '載入中...')),
    ]),
  ]);
}

async function addStockTransaction() {
  const code = $('#stxCode').value.trim();
  const shares = Number($('#stxShares').value);
  const price = Number($('#stxPrice').value);
  if (!code || !shares || shares <= 0 || price == null || Number.isNaN(price)) { showToast('請填寫代號、股數、成交價'); return; }
  try {
    await api('/stocks/transactions', {
      method: 'POST',
      body: {
        code, tradeDate: $('#stxDate').value, side: $('#stxSide').value,
        shares, price, fee: Number($('#stxFee').value) || 0, tax: Number($('#stxTax').value) || 0,
      },
    });
    $('#stxCode').value = ''; $('#stxShares').value = ''; $('#stxPrice').value = ''; $('#stxFee').value = ''; $('#stxTax').value = '';
    showToast('已新增交易紀錄');
    loadPortfolio();
  } catch (e) { showToast('新增失敗：' + e.message); }
}

async function addStockDividend() {
  const code = $('#stxDivCode').value.trim();
  const amount = Number($('#stxDivAmount').value);
  if (!code || !amount || amount < 0) { showToast('請填寫代號與金額'); return; }
  try {
    await api('/stocks/dividends', { method: 'POST', body: { code, payDate: $('#stxDivDate').value, amount } });
    $('#stxDivCode').value = ''; $('#stxDivAmount').value = '';
    showToast('已記錄股利');
    loadPortfolio();
    loadStockDividendList();
  } catch (e) { showToast('新增失敗：' + e.message); }
}

async function loadStockDividendList() {
  const box = $('#stxDividendList');
  if (!box) return;
  try {
    const rows = await api('/stocks/dividends');
    box.innerHTML = '';
    if (!rows.length) { box.appendChild(el('div', { class: 'empty-state' }, '還沒有股利紀錄')); return; }
    rows.slice(0, 10).forEach((r) => {
      box.appendChild(el('div', { class: 'coping-note-item' }, [
        el('div', { class: 'content' }, `${r.pay_date} · ${r.name || r.code} (${r.code}) · ${fmtMoney(r.amount)}`),
        el('button', { class: 'del-btn', onclick: () => deleteStockDividend(r.id) }, '✕'),
      ]));
    });
  } catch (e) { box.innerHTML = ''; box.appendChild(el('div', { class: 'empty-state' }, '股利紀錄暫時無法取得')); }
}
async function deleteStockDividend(id) {
  await api(`/stocks/dividends/${id}`, { method: 'DELETE' });
  loadStockDividendList();
  loadPortfolio();
}

async function loadPortfolio() {
  const summaryBox = $('#stxPortfolioSummary');
  const listBox = $('#stxPortfolioList');
  const txBox = $('#stxTransactionList');
  if (!summaryBox) return;
  try {
    const [portfolio, transactions] = await Promise.all([api('/stocks/portfolio'), api('/stocks/transactions')]);
    populateStockCodeDatalist(transactions);
    loadStockDividendList();

    summaryBox.innerHTML = '';
    const t = portfolio.totals;
    summaryBox.appendChild(el('div', { class: 'stx-stat-strip' }, [
      el('div', { class: 'stx-stat' }, [el('div', { class: 'k' }, '總市值'), el('div', { class: 'v num' }, t.totalMarketValue != null ? fmtMoney(t.totalMarketValue) : '部分報價暫缺')]),
      el('div', { class: 'stx-stat' }, [el('div', { class: 'k' }, '未實現損益'), el('div', { class: 'v num', style: t.totalUnrealizedPL > 0 ? 'color:var(--series-red)' : t.totalUnrealizedPL < 0 ? 'color:var(--series-green)' : '' }, t.totalUnrealizedPL != null ? fmtMoney(t.totalUnrealizedPL) : '部分報價暫缺')]),
      el('div', { class: 'stx-stat' }, [el('div', { class: 'k' }, '已實現損益'), el('div', { class: 'v num', style: t.totalRealizedPL > 0 ? 'color:var(--series-red)' : t.totalRealizedPL < 0 ? 'color:var(--series-green)' : '' }, fmtMoney(t.totalRealizedPL))]),
      el('div', { class: 'stx-stat' }, [el('div', { class: 'k' }, '累計股利收入'), el('div', { class: 'v num' }, fmtMoney(t.totalDividendIncome))]),
    ]));
    summaryBox.appendChild(el('p', { class: 'hint', style: 'margin-top:8px' }, portfolio.disclaimer));

    listBox.innerHTML = '';
    if (!portfolio.positions.length) {
      listBox.appendChild(el('div', { class: 'empty-state' }, '還沒有任何交易紀錄'));
    } else {
      portfolio.positions.forEach((p) => {
        listBox.appendChild(el('div', { class: 'coping-note-item', style: 'flex-direction:column;align-items:stretch;gap:4px' }, [
          el('div', { style: 'display:flex;justify-content:space-between;font-weight:700' }, [
            el('div', {}, `${p.name || p.code} (${p.code})`),
            el('div', {}, p.shares > 0 ? `${fmtNum(p.shares)} 股` : '已全數賣出'),
          ]),
          el('div', { class: 'hint', style: 'margin:0' },
            p.shares > 0
              ? `均價 ${p.avgCost} · 現價 ${p.currentPrice != null ? p.currentPrice : '暫缺'} · 未實現 ${p.unrealizedPL != null ? fmtMoney(p.unrealizedPL) : '暫缺'}`
              : `已實現損益 ${fmtMoney(p.realizedPL)}`),
        ]));
      });
    }

    txBox.innerHTML = '';
    if (!transactions.length) {
      txBox.appendChild(el('div', { class: 'empty-state' }, '還沒有交易紀錄'));
    } else {
      transactions.slice(0, 30).forEach((t2) => {
        txBox.appendChild(el('div', { class: 'coping-note-item' }, [
          el('div', { class: 'content' }, `${t2.trade_date} · ${t2.side === 'buy' ? '買進' : '賣出'} ${t2.name || t2.code} (${t2.code}) ${fmtNum(t2.shares)} 股 @ ${t2.price}`),
          el('button', { class: 'del-btn', onclick: () => deleteStockTransaction(t2.id) }, '✕'),
        ]));
      });
    }
  } catch (e) {
    summaryBox.innerHTML = '';
    summaryBox.appendChild(el('div', { class: 'empty-state' }, '持股資料暫時無法取得'));
  }
}
async function deleteStockTransaction(id) {
  await api(`/stocks/transactions/${id}`, { method: 'DELETE' });
  loadPortfolio();
}
function populateStockCodeDatalist(transactions) {
  const list = $('#stxCodeList');
  if (!list) return;
  const codes = [...new Map(transactions.map((t) => [t.code, t.name])).entries()];
  list.innerHTML = '';
  codes.forEach(([code, name]) => list.appendChild(el('option', { value: code }, name || '')));
}

// ---------- 到價提醒 ----------
function renderAlertsPanel() {
  return el('div', {}, [
    el('div', { class: 'card' }, [
      el('h3', {}, '🔔 新增到價提醒'),
      el('p', { class: 'hint' }, '沒有背景推播機制，是「打開 App 或首頁摘要時檢查一次」的方式，不是即時通知。'),
      el('div', { class: 'form-row' }, [
        el('input', { id: 'alertCode', placeholder: '股票代號，如 2330' }),
        el('select', { id: 'alertDirection' }, [el('option', { value: 'above' }, '漲到 (≥)'), el('option', { value: 'below' }, '跌到 (≤)')]),
        el('input', { id: 'alertPrice', type: 'number', placeholder: '目標價' }),
      ]),
      el('button', { class: 'btn btn-primary', style: 'margin-top:10px', onclick: addStockAlert }, '新增提醒'),
    ]),
    el('div', { class: 'card' }, [
      el('h3', {}, '📋 提醒清單'),
      el('button', { class: 'btn btn-ghost', style: 'font-size:12px', onclick: checkStockAlerts }, '立即檢查是否到價'),
      el('div', { id: 'alertCheckResult', style: 'margin-top:8px' }),
      el('div', { id: 'alertListArea', style: 'margin-top:10px' }, el('div', { class: 'empty-state' }, '載入中...')),
    ]),
  ]);
}
async function addStockAlert() {
  const code = $('#alertCode').value.trim();
  const targetPrice = Number($('#alertPrice').value);
  if (!code || !targetPrice) { showToast('請填寫代號與目標價'); return; }
  try {
    await api('/stocks/alerts', { method: 'POST', body: { code, targetPrice, direction: $('#alertDirection').value } });
    $('#alertCode').value = ''; $('#alertPrice').value = '';
    showToast('已新增提醒');
    loadAlerts();
  } catch (e) { showToast('新增失敗：' + e.message); }
}
async function loadAlerts() {
  const area = $('#alertListArea');
  if (!area) return;
  try {
    const rows = await api('/stocks/alerts');
    area.innerHTML = '';
    if (!rows.length) { area.appendChild(el('div', { class: 'empty-state' }, '還沒有設定到價提醒')); return; }
    rows.forEach((r) => {
      area.appendChild(el('div', { class: 'coping-note-item' }, [
        el('div', { class: 'content' }, `${r.name || r.code} (${r.code}) ${r.direction === 'above' ? '漲到' : '跌到'} ${r.target_price}${r.triggered_at ? ' · ✅ 已到價' : ''}`),
        el('button', { class: 'del-btn', onclick: () => deleteStockAlert(r.id) }, '✕'),
      ]));
    });
  } catch (e) { area.innerHTML = ''; area.appendChild(el('div', { class: 'empty-state' }, '提醒清單暫時無法取得')); }
}
async function deleteStockAlert(id) {
  await api(`/stocks/alerts/${id}`, { method: 'DELETE' });
  loadAlerts();
}
async function checkStockAlerts() {
  const box = $('#alertCheckResult');
  box.innerHTML = '';
  box.appendChild(el('p', { class: 'hint', style: 'margin:0' }, '檢查中...'));
  try {
    const res = await api('/stocks/alerts/check');
    box.innerHTML = '';
    if (!res.triggered.length) {
      box.appendChild(el('p', { class: 'hint', style: 'margin:0' }, '目前沒有已到價的提醒'));
    } else {
      res.triggered.forEach((t) => {
        box.appendChild(el('div', { class: 'mood-signal-item' }, `🎯 ${t.name || t.code} (${t.code}) 已${t.direction === 'above' ? '漲到' : '跌到'} ${t.currentPrice} (目標 ${t.target_price})`));
      });
    }
    loadAlerts();
  } catch (e) { box.innerHTML = ''; box.appendChild(el('p', { class: 'hint', style: 'margin:0' }, '檢查失敗：' + e.message)); }
}

// ---------- 簡易選股/篩選 ----------
function renderScreenerPanel() {
  return el('div', {}, [
    el('div', { class: 'card' }, [
      el('h3', {}, '🔍 簡易選股工具'),
      el('p', { class: 'hint' }, '用證交所公開的全市場估值資料做排序整理，是資料篩選工具，不是選股建議。'),
      el('div', { class: 'form-row' }, [
        el('select', { id: 'screenerSortBy' }, [
          el('option', { value: 'dividendYield' }, '依殖利率排序'),
          el('option', { value: 'peRatio' }, '依本益比排序'),
          el('option', { value: 'pbRatio' }, '依股價淨值比排序'),
          el('option', { value: 'change' }, '依今日漲跌排序'),
          el('option', { value: 'tradeVolume' }, '依成交量排序'),
        ]),
        el('select', { id: 'screenerOrder' }, [el('option', { value: 'desc' }, '由高到低'), el('option', { value: 'asc' }, '由低到高')]),
      ]),
      el('div', { class: 'form-row', style: 'margin-top:8px' }, [
        el('input', { id: 'screenerMinYield', type: 'number', placeholder: '最低殖利率 % (選填)' }),
        el('input', { id: 'screenerMaxPE', type: 'number', placeholder: '最高本益比 (選填)' }),
        el('button', { class: 'btn btn-primary', onclick: runScreener }, '篩選') ,
      ]),
      el('div', { id: 'screenerResult', style: 'margin-top:14px' }),
    ]),
  ]);
}
async function runScreener() {
  const box = $('#screenerResult');
  box.innerHTML = '';
  box.appendChild(el('div', { class: 'empty-state' }, '搜尋中...'));
  try {
    const params = new URLSearchParams({
      sortBy: $('#screenerSortBy').value,
      order: $('#screenerOrder').value,
    });
    const minYield = $('#screenerMinYield').value;
    const maxPE = $('#screenerMaxPE').value;
    if (minYield) params.set('minDividendYield', minYield);
    if (maxPE) params.set('maxPE', maxPE);
    const res = await api(`/stocks/screener?${params.toString()}`);
    box.innerHTML = '';
    box.appendChild(el('p', { class: 'hint', style: 'margin-bottom:10px' }, `${res.disclaimer} (共 ${res.count} 檔符合，顯示前 ${res.results.length} 檔)`));
    if (!res.results.length) { box.appendChild(el('div', { class: 'empty-state' }, '沒有符合條件的股票，試試放寬篩選條件')); return; }
    const table = el('table', { class: 'stx-table' }, [
      el('thead', {}, el('tr', {}, [
        el('th', {}, '股票'),
        el('th', {}, '收盤價'),
        el('th', {}, '漲跌'),
        el('th', {}, '本益比'),
        el('th', {}, '殖利率'),
        el('th', {}, '股價淨值比'),
      ])),
    ]);
    const tbody = el('tbody', {});
    res.results.forEach((r) => {
      const changeText = r.change > 0 ? `▲+${r.change}` : r.change < 0 ? `▼${r.change}` : '持平';
      tbody.appendChild(el('tr', {}, [
        el('td', {}, `${r.name} (${r.code})`),
        el('td', { class: 'num' }, r.closingPrice != null ? r.closingPrice.toFixed(2) : '--'),
        el('td', { class: `num ${r.change > 0 ? 'delta-up' : r.change < 0 ? 'delta-down' : ''}` }, changeText),
        el('td', { class: 'num' }, r.peRatio != null ? r.peRatio.toFixed(2) : '--'),
        el('td', { class: 'num' }, r.dividendYield != null ? r.dividendYield.toFixed(2) + '%' : '--'),
        el('td', { class: 'num' }, r.pbRatio != null ? r.pbRatio.toFixed(2) : '--'),
      ]));
    });
    table.appendChild(tbody);
    box.appendChild(el('div', { style: 'overflow-x:auto' }, table));
  } catch (e) {
    box.innerHTML = '';
    box.appendChild(el('div', { class: 'empty-state' }, '篩選失敗：' + e.message));
  }
}

// ===================== 交通與旅遊 =====================
const TRAVEL_SUB_TABS = [
  { key: 'train', label: '🚄 台鐵 / 高鐵' },
  { key: 'flight', label: '✈️ 機票' },
  { key: 'hotel', label: '🏨 住宿' },
  { key: 'itinerary', label: '🗺️ 行程規劃' },
  { key: 'packing', label: '🎒 行前打包' },
  { key: 'split', label: '💸 旅遊分帳' },
];
let travelSubTab = 'train';

function switchTravelSub(key) {
  travelSubTab = key;
  renderTravel();
}

function renderTravel() {
  const c = $('#tab-travel');
  c.innerHTML = '';

  // 次分頁：把「火車 / 機票 / 住宿 / 行程規劃」分開，一次只看一個，不要全部塞在同一畫面
  c.appendChild(el('div', { class: 'subnav' }, TRAVEL_SUB_TABS.map((t) =>
    el('div', {
      class: `subnav-item${travelSubTab === t.key ? ' active' : ''}`,
      onclick: () => switchTravelSub(t.key),
    }, t.label)
  )));

  const panel = (key, children) => el('div', { class: `subpanel${travelSubTab === key ? ' active' : ''}` }, children);

  c.appendChild(panel('train', [
    el('div', { class: 'card' }, [
      el('h3', {}, '台鐵 / 高鐵 時刻搜尋'),
      el('p', { class: 'hint' }, '資料來源：交通部 TDX 運輸資料流通服務。僅提供時刻/誤點/票價區間查詢，實際訂票請至官方售票網站。'),
      el('div', { class: 'form-row' }, [
        el('select', { id: 'trainMode' }, [el('option', { value: 'tra' }, '台鐵 TRA'), el('option', { value: 'thsr' }, '高鐵 THSR')]),
        el('input', { id: 'stationName', placeholder: '出發站，如 台北' }),
        el('input', { id: 'stationTo', placeholder: '目的站，如 台中' }),
        el('input', { id: 'trainDate', type: 'date', value: todayStr() }),
      ]),
      el('div', { class: 'form-row' }, [
        el('input', { id: 'timeFrom', type: 'time', value: '06:00' }),
        el('span', { style: 'align-self:center;color:var(--text-muted)' }, '～'),
        el('input', { id: 'timeTo', type: 'time', value: '22:00' }),
        el('input', { id: 'trainNoSearch', placeholder: '搜尋車次號碼 (選填)' }),
        el('button', { class: 'btn btn-primary', onclick: searchTrain }, '查詢'),
      ]),
      el('div', { id: 'trainResult' }),
    ]),
    el('div', { class: 'card' }, [
      el('h3', {}, '⭐ 我的收藏車次'),
      el('p', { class: 'hint' }, '收藏常搭的車次，下次不用重新查詢。'),
      el('div', { id: 'favoriteTrainsArea' }),
    ]),
  ]));

  c.appendChild(panel('flight', [
    el('div', { class: 'card' }, [
      el('h3', {}, '機票 — 各家航空公司/比價網站'),
      el('p', { class: 'hint' }, '目前沒有免費即時比價 API，這裡改用「深連結」方式：點下去會直接跳到該網站，並幫你帶入出發地/目的地/日期。真正一頁比全部價格需要另外申請商業合作 API。'),
      el('div', { class: 'form-row' }, [
        el('input', { id: 'flyFrom', placeholder: '出發地，如 台北' }),
        el('input', { id: 'flyTo', placeholder: '目的地，如 大阪' }),
        el('input', { id: 'flyDate', type: 'date' }),
        el('button', { class: 'btn btn-primary', onclick: searchFlightProviders }, '列出各家連結' ),
      ]),
      el('div', { id: 'flightResult' }),
    ]),
  ]));

  c.appendChild(panel('hotel', [
    el('div', { class: 'card' }, [
      el('h3', {}, '住宿 — 各家訂房網站'),
      el('div', { class: 'form-row' }, [
        el('input', { id: 'hotelCity', placeholder: '城市，如 大阪' }),
        el('input', { id: 'hotelCheckin', type: 'date' }),
        el('input', { id: 'hotelCheckout', type: 'date' }),
        el('button', { class: 'btn btn-primary', onclick: searchHotelProviders }, '列出各家連結'),
      ]),
      el('div', { id: 'hotelResult' }),
    ]),
  ]));

  c.appendChild(panel('itinerary', [
    el('div', { class: 'card' }, [
      el('h3', {}, '智慧行程規劃'),
      el('p', { class: 'hint' }, '輸入出發地、目的地與天數，產生行程草案；若目的地或出發地是已收錄城市 (目前：台中、新北)，會額外附上精選景點/美食/休閒推薦。'),
      el('div', { class: 'form-row' }, [
        el('input', { id: 'tripFrom', placeholder: '出發地' }),
        el('input', { id: 'tripTo', placeholder: '目的地' }),
        el('input', { id: 'tripDays', type: 'number', value: 3, min: 1, max: 14 }),
        el('button', { class: 'btn btn-primary', onclick: generateItinerary }, '產生行程'),
      ]),
      el('div', { id: 'itineraryResult' }),
    ]),
  ]));

  c.appendChild(panel('packing', [
    el('div', { class: 'card' }, [
      el('h3', {}, '🎒 行前打包清單'),
      el('p', { class: 'hint' }, '常用清單，跟旅程無關的通用版；下面「旅遊分帳」建立旅程後，也可以在旅程裡建立專屬的打包清單。'),
      el('div', { class: 'form-row' }, [
        el('select', { id: 'packingTemplate' }, [
          el('option', { value: '' }, '套用範本...'),
          el('option', { value: 'general' }, '通用'),
          el('option', { value: 'beach' }, '海島/沙灘'),
          el('option', { value: 'cold' }, '寒冷天氣'),
          el('option', { value: 'business' }, '商務出差'),
        ]),
        el('button', { class: 'btn btn-ghost', onclick: applyPackingTemplate }, '套用'),
      ]),
      el('div', { class: 'form-row', style: 'margin-top:8px' }, [
        el('input', { id: 'packingItem', placeholder: '要帶的東西，如：護照' }),
        el('input', { id: 'packingCategory', placeholder: '分類 (選填)，如：證件' }),
        el('button', { class: 'btn btn-primary', onclick: addPackingItem }, '新增'),
      ]),
      el('div', { id: 'packingList', style: 'margin-top:12px' }, el('div', { class: 'empty-state' }, '載入中...')),
    ]),
  ]));

  c.appendChild(panel('split', renderTripSplitPanel()));

  if (travelSubTab === 'train') loadFavoriteTrains();
  if (travelSubTab === 'packing') loadPackingList();
  if (travelSubTab === 'split') loadTrips();
}

// ---------- 行前打包清單 ----------
async function applyPackingTemplate() {
  const type = $('#packingTemplate').value;
  if (!type) return;
  const res = await api(`/travel/packing/template/${type}`);
  for (const item of res.items) {
    await api('/travel/packing', { method: 'POST', body: { item, category: '範本' } });
  }
  showToast('已套用範本');
  loadPackingList();
}
async function addPackingItem() {
  const item = $('#packingItem').value.trim();
  if (!item) { showToast('請填寫項目'); return; }
  await api('/travel/packing', { method: 'POST', body: { item, category: $('#packingCategory').value.trim() || '其他' } });
  $('#packingItem').value = ''; $('#packingCategory').value = '';
  loadPackingList();
}
async function loadPackingList() {
  const box = $('#packingList');
  if (!box) return;
  try {
    const rows = await api('/travel/packing');
    box.innerHTML = '';
    if (!rows.length) { box.appendChild(el('div', { class: 'empty-state' }, '還沒有打包項目，套用範本或自行新增')); return; }
    const byCategory = {};
    rows.forEach((r) => { (byCategory[r.category || '其他'] = byCategory[r.category || '其他'] || []).push(r); });
    Object.entries(byCategory).forEach(([cat, items]) => {
      box.appendChild(el('div', { class: 'label', style: 'margin:10px 0 4px;font-weight:700' }, cat));
      items.forEach((r) => {
        box.appendChild(el('div', { class: 'coping-note-item' }, [
          el('label', { class: 'content', style: 'display:flex;align-items:center;gap:8px;cursor:pointer' }, [
            el('input', { type: 'checkbox', checked: !!r.checked, onchange: (e) => togglePackingItem(r.id, e.target.checked) }),
            el('span', { style: r.checked ? 'text-decoration:line-through;color:var(--flat-sub)' : '' }, r.item),
          ]),
          el('button', { class: 'del-btn', onclick: () => deletePackingItem(r.id) }, '✕'),
        ]));
      });
    });
  } catch (e) { box.innerHTML = ''; box.appendChild(el('div', { class: 'empty-state' }, '清單暫時無法取得')); }
}
async function togglePackingItem(id, checked) {
  await api(`/travel/packing/${id}`, { method: 'PUT', body: { checked } });
}
async function deletePackingItem(id) {
  await api(`/travel/packing/${id}`, { method: 'DELETE' });
  loadPackingList();
}

// ---------- 旅遊分帳 ----------
let currentTripId = null;
function renderTripSplitPanel() {
  return el('div', {}, [
    el('div', { class: 'card' }, [
      el('h3', {}, '💸 建立新旅程'),
      el('p', { class: 'hint' }, '記下這趟旅程有誰、誰墊了什麼，最後自動算出最少筆數的轉帳建議——不管是一人先墊全部、還是大家輪流出都可以。'),
      el('div', { class: 'form-row' }, [
        el('input', { id: 'tripName', placeholder: '旅程名稱，如：東京五日遊' }),
        el('select', { id: 'tripCurrency' }, ['TWD', 'JPY', 'USD', 'KRW', 'EUR', 'HKD'].map((c) => el('option', { value: c }, c))),
        el('input', { id: 'tripParticipants', placeholder: '參與者，用逗號分隔，如：我,小明,小華' }),
      ]),
      el('button', { class: 'btn btn-primary', style: 'margin-top:10px', onclick: addTrip }, '建立旅程'),
    ]),
    el('div', { class: 'card' }, [
      el('h3', {}, '📋 旅程列表'),
      el('div', { id: 'tripList' }, el('div', { class: 'empty-state' }, '載入中...')),
    ]),
    el('div', { id: 'tripDetail' }),
  ]);
}

async function addTrip() {
  const name = $('#tripName').value.trim();
  if (!name) { showToast('請填寫旅程名稱'); return; }
  const names = $('#tripParticipants').value.split(',').map((s) => s.trim()).filter(Boolean);
  await api('/travel/trips', { method: 'POST', body: { name, baseCurrency: $('#tripCurrency').value, participantNames: names.length ? names : ['我'] } });
  $('#tripName').value = ''; $('#tripParticipants').value = '';
  showToast('已建立旅程');
  loadTrips();
}

async function loadTrips() {
  const box = $('#tripList');
  if (!box) return;
  try {
    const rows = await api('/travel/trips');
    box.innerHTML = '';
    if (!rows.length) { box.appendChild(el('div', { class: 'empty-state' }, '還沒有建立任何旅程')); return; }
    rows.forEach((t) => {
      box.appendChild(el('div', { class: 'coping-note-item', style: 'cursor:pointer', onclick: () => openTripDetail(t.id) }, [
        el('div', { class: 'content' }, [
          `${t.name} `,
          el('span', { class: `badge ${t.settled ? 'badge-neutral' : 'badge-positive'}` }, t.settled ? '已結清' : '進行中'),
          el('span', { class: 'hint', style: 'margin:0;margin-left:8px' }, t.base_currency),
        ]),
        el('button', { class: 'del-btn', onclick: (e) => { e.stopPropagation(); deleteTrip(t.id); } }, '✕'),
      ]));
    });
    if (currentTripId && rows.some((t) => t.id === currentTripId)) openTripDetail(currentTripId);
  } catch (e) { box.innerHTML = ''; box.appendChild(el('div', { class: 'empty-state' }, '旅程清單暫時無法取得')); }
}
async function deleteTrip(id) {
  await api(`/travel/trips/${id}`, { method: 'DELETE' });
  if (currentTripId === id) { currentTripId = null; $('#tripDetail').innerHTML = ''; }
  loadTrips();
}

async function openTripDetail(tripId) {
  currentTripId = tripId;
  const box = $('#tripDetail');
  box.innerHTML = '';
  const [participants, expenses, settlement] = await Promise.all([
    api(`/travel/trips/${tripId}/participants`),
    api(`/travel/trips/${tripId}/expenses`),
    api(`/travel/trips/${tripId}/settlement`),
  ]);

  box.appendChild(el('div', { class: 'card' }, [
    el('h3', {}, '➕ 新增花費'),
    el('div', { class: 'form-row' }, [
      el('select', { id: 'expPayer' }, participants.map((p) => el('option', { value: p.id }, p.name))),
      el('input', { id: 'expDesc', placeholder: '花費說明，如：晚餐' }),
      el('input', { id: 'expAmount', type: 'number', placeholder: '金額' }),
    ]),
    el('div', { class: 'form-row', style: 'margin-top:8px' }, [
      el('input', { id: 'expCurrency', placeholder: '幣別，如 JPY (預設同旅程幣別)' }),
      el('input', { id: 'expRate', type: 'number', placeholder: '匯率換算 (1 單位 = 多少旅程幣別，預設1)' }),
      el('input', { id: 'expDate', type: 'date', value: todayStr() }),
    ]),
    el('p', { class: 'hint', style: 'margin-top:8px' }, '預設由所有參與者均分，之後可以擴充自訂分攤比例。'),
    el('button', { class: 'btn btn-primary', style: 'margin-top:6px', onclick: () => addTripExpense(tripId) }, '新增花費'),
    el('div', { style: 'margin-top:10px' }, [
      el('input', { id: 'newParticipantName', placeholder: '新增參與者名字' }),
      el('button', { class: 'btn btn-ghost', onclick: () => addTripParticipant(tripId) }, '加入旅伴'),
    ]),
  ]));

  box.appendChild(el('div', { class: 'card' }, [
    el('h3', {}, '⚖️ 結算結果'),
    el('div', { class: 'stat-strip' }, settlement.balances.map((b) => el('div', { class: 'stat-item' }, [
      el('div', { class: 'k' }, b.name),
      el('div', { class: 'v num', style: b.net > 0 ? 'color:var(--good)' : b.net < 0 ? 'color:var(--critical)' : '' }, `${b.net > 0 ? '+' : ''}${fmtCurrency(b.net, settlement.baseCurrency)}`),
    ]))),
    el('p', { class: 'hint', style: 'margin-top:8px' }, settlement.disclaimer),
    settlement.transfers.length
      ? el('div', {}, settlement.transfers.map((t) => el('div', { class: 'mood-signal-item' }, `💰 ${t.from} → ${t.to}：${fmtCurrency(t.amount, settlement.baseCurrency)}`)))
      : el('div', { class: 'empty-state' }, '目前帳務已經打平，不需要轉帳'),
    !settlement.transfers.length && !expenses.length ? null : el('button', { class: 'btn btn-ghost', style: 'margin-top:8px', onclick: () => markTripSettled(tripId) }, '標記這趟旅程已結清'),
  ]));

  box.appendChild(el('div', { class: 'card' }, [
    el('h3', {}, '📜 花費紀錄'),
    !expenses.length
      ? el('div', { class: 'empty-state' }, '還沒有花費紀錄')
      : el('div', {}, expenses.map((e) => el('div', { class: 'coping-note-item' }, [
          el('div', { class: 'content' }, `${e.expense_date || ''} · ${e.description || '花費'} · ${e.payer_name} 墊付 ${fmtCurrency(e.amount, e.currency)}${e.exchange_rate !== 1 ? ` (≈${fmtCurrency(Math.round(e.amount * e.exchange_rate), settlement.baseCurrency)})` : ''}`),
          el('button', { class: 'del-btn', onclick: () => deleteTripExpense(tripId, e.id) }, '✕'),
        ]))),
  ]));
}

async function addTripParticipant(tripId) {
  const name = $('#newParticipantName').value.trim();
  if (!name) return;
  await api(`/travel/trips/${tripId}/participants`, { method: 'POST', body: { name } });
  $('#newParticipantName').value = '';
  openTripDetail(tripId);
}

async function addTripExpense(tripId) {
  const payerId = Number($('#expPayer').value);
  const amount = Number($('#expAmount').value);
  if (!payerId || !amount || amount <= 0) { showToast('請填寫墊款人與金額'); return; }
  try {
    await api(`/travel/trips/${tripId}/expenses`, {
      method: 'POST',
      body: {
        payerId, description: $('#expDesc').value.trim(), amount,
        currency: $('#expCurrency').value.trim() || undefined,
        exchangeRate: Number($('#expRate').value) || 1,
        expenseDate: $('#expDate').value,
      },
    });
    showToast('已新增花費');
    openTripDetail(tripId);
  } catch (e) { showToast('新增失敗：' + e.message); }
}
async function deleteTripExpense(tripId, expenseId) {
  await api(`/travel/trips/${tripId}/expenses/${expenseId}`, { method: 'DELETE' });
  openTripDetail(tripId);
}
async function markTripSettled(tripId) {
  await api(`/travel/trips/${tripId}`, { method: 'PUT', body: { settled: true } });
  showToast('已標記為結清');
  loadTrips();
}

const PROVIDER_COLORS = ['--series-blue', '--series-orange', '--series-aqua', '--series-violet', '--series-magenta', '--series-yellow'];
function providerList(providers) {
  return el('div', {}, providers.map((p, i) => el('a', { href: p.url, target: '_blank', rel: 'noopener', class: 'provider-item' }, [
    el('div', { class: 'p-left' }, [
      el('div', { class: 'p-avatar', style: `background:${cssVar(PROVIDER_COLORS[i % PROVIDER_COLORS.length])}` }, p.name.replace(/^[^一-龥A-Za-z]*/, '').slice(0, 1).toUpperCase()),
      el('div', {}, [
        el('div', { class: 'p-name' }, [
          p.name,
          el('span', { class: p.prefill ? 'tag tag-fill' : 'tag tag-manual' }, p.prefill ? '已帶入條件' : '需自行輸入'),
        ]),
        el('div', { class: 'p-note' }, p.note),
      ]),
    ]),
    el('span', { class: 'p-go' }, '前往 →'),
  ])));
}

async function searchTrain() {
  const mode = $('#trainMode').value;
  const station = $('#stationName').value.trim();
  const to = $('#stationTo').value.trim();
  const date = $('#trainDate').value;
  const timeFrom = $('#timeFrom').value;
  const timeTo = $('#timeTo').value;
  const trainNo = $('#trainNoSearch').value.trim();
  const resultBox = $('#trainResult');
  if (!station) return;
  resultBox.innerHTML = '查詢中...';
  try {
    const qs = new URLSearchParams({ station, to, date, timeFrom, timeTo, trainNo }).toString();
    const data = await api(`/travel/train/${mode}/board?${qs}`);
    resultBox.innerHTML = '';
    if (data.isDemo) resultBox.appendChild(el('div', { class: 'disclaimer' }, data.notice));
    if (data.trains) {
      if (!data.trains.length) { resultBox.appendChild(el('div', { class: 'empty-state' }, '這個時間範圍沒有符合的車次')); return; }
      const rows = data.trains.map((t) => el('tr', {}, [
        el('td', {}, t.trainNo),
        el('td', {}, t.departure),
        el('td', {}, t.arrival || '--'),
        el('td', {}, t.fare != null ? fmtMoney(t.fare) : '--'),
        el('td', {}, t.status),
        el('td', {}, el('button', { class: 'btn btn-ghost', onclick: () => favoriteTrain(mode, t, station, to) }, '⭐ 收藏')),
      ]));
      resultBox.appendChild(el('table', {}, [
        el('thead', {}, el('tr', {}, [el('th', {}, '車次'), el('th', {}, '出發'), el('th', {}, '到達'), el('th', {}, '票價(估)'), el('th', {}, '狀態'), el('th', {}, '')])),
        el('tbody', {}, rows),
      ]));
    } else if (data.raw) {
      resultBox.appendChild(el('pre', { style: 'font-size:11px;white-space:pre-wrap' }, JSON.stringify(data.raw, null, 2).slice(0, 3000)));
    }
  } catch (e) { resultBox.innerHTML = `查詢失敗: ${e.message}`; }
}

async function favoriteTrain(mode, train, fromStation, toStation) {
  try {
    await api('/travel/train/favorites', {
      method: 'POST',
      body: { mode, trainNo: train.trainNo, fromStation, toStation, departureTime: train.departure },
    });
    showToast('已收藏車次');
    loadFavoriteTrains();
  } catch (e) { showToast('收藏失敗: ' + e.message); }
}

async function loadFavoriteTrains() {
  const area = $('#favoriteTrainsArea');
  if (!area) return;
  try {
    const rows = await api('/travel/train/favorites');
    area.innerHTML = '';
    if (!rows.length) { area.appendChild(el('div', { class: 'empty-state' }, '還沒有收藏的車次')); return; }
    rows.forEach((r) => {
      const dateInputId = `favTrainDate-${r.id}`;
      area.appendChild(el('div', { style: 'display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid var(--grid-line);flex-wrap:wrap;gap:8px' }, [
        el('div', { style: 'font-size:13px' }, `${r.mode === 'THSR' ? '高鐵' : '台鐵'} ${r.train_no} · ${r.from_station}${r.to_station ? ' → ' + r.to_station : ''} · ${r.departure_time || ''}`),
        el('div', { style: 'display:flex;gap:6px;align-items:center' }, [
          el('input', { id: dateInputId, type: 'date', style: 'width:132px;padding:6px 8px;font-size:12px' }),
          el('button', { class: 'btn btn-ghost', style: 'font-size:12px', onclick: () => addFavoriteTrainToCalendar(r, dateInputId) }, '📅 加入行事曆'),
          el('button', { class: 'btn btn-ghost', onclick: () => deleteFavoriteTrain(r.id) }, '移除'),
        ]),
      ]));
    });
  } catch (e) { area.innerHTML = ''; }
}
async function deleteFavoriteTrain(id) {
  await api(`/travel/train/favorites/${id}`, { method: 'DELETE' });
  loadFavoriteTrains();
}
async function addFavoriteTrainToCalendar(r, dateInputId) {
  const date = $(`#${dateInputId}`).value;
  if (!date) { showToast('請先選擇日期'); return; }
  try {
    await api('/calendar', {
      method: 'POST',
      body: {
        event_date: date,
        start_time: r.departure_time || null,
        title: `🚄 ${r.mode === 'THSR' ? '高鐵' : '台鐵'} ${r.train_no} ${r.from_station}${r.to_station ? '→' + r.to_station : ''}`,
        category: 'travel',
      },
    });
    showToast('已加入行事曆');
  } catch (e) { showToast('加入失敗: ' + e.message); }
}

async function searchFlightProviders() {
  const from = $('#flyFrom').value.trim(), to = $('#flyTo').value.trim(), date = $('#flyDate').value;
  const box = $('#flightResult');
  if (!from || !to) return;
  box.innerHTML = '載入中...';
  try {
    const data = await api(`/travel/flights/providers?from=${encodeURIComponent(from)}&to=${encodeURIComponent(to)}&date=${date || ''}`);
    box.innerHTML = '';
    box.appendChild(providerList(data.providers));
  } catch (e) { box.innerHTML = `載入失敗: ${e.message}`; }
}

async function searchHotelProviders() {
  const city = $('#hotelCity').value.trim();
  const checkin = $('#hotelCheckin').value, checkout = $('#hotelCheckout').value;
  const box = $('#hotelResult');
  if (!city) return;
  box.innerHTML = '載入中...';
  try {
    const data = await api(`/travel/hotels/providers?city=${encodeURIComponent(city)}&checkin=${checkin || ''}&checkout=${checkout || ''}`);
    box.innerHTML = '';
    box.appendChild(providerList(data.providers));
  } catch (e) { box.innerHTML = `載入失敗: ${e.message}`; }
}

async function generateItinerary() {
  const from = $('#tripFrom').value.trim(), to = $('#tripTo').value.trim(), days = $('#tripDays').value;
  const box = $('#itineraryResult');
  if (!from || !to) return;
  box.innerHTML = '規劃中...';
  try {
    const data = await api('/travel/itinerary', { method: 'POST', body: { from, to, days } });
    box.innerHTML = '';
    box.appendChild(el('p', { class: 'hint' }, data.disclaimer));
    data.plan.forEach((d) => {
      box.appendChild(el('div', { style: 'margin-bottom:10px' }, [el('b', {}, d.title), el('div', { style: 'font-size:13px;color:var(--text-secondary)' }, d.suggestion)]));
    });
    if (data.curated) {
      box.appendChild(el('div', { style: 'margin-top:14px;padding-top:14px;border-top:1px solid var(--grid-line)' }, [
        el('div', { style: 'font-weight:700;margin-bottom:4px' }, `📍 ${data.curated.city} 精選推薦`),
        el('p', { class: 'hint' }, data.curated.sourceNote),
      ]));
      Object.entries(data.curated.categories).forEach(([cat, items]) => {
        const wrap = el('div', { style: 'margin-bottom:10px' }, [el('div', { style: 'font-size:13px;font-weight:600;margin-bottom:4px' }, cat)]);
        items.forEach((it) => {
          wrap.appendChild(el('div', { style: 'font-size:13px;margin-bottom:4px' }, [
            el('b', {}, it.name), el('span', { style: 'color:var(--text-muted)' }, ` — ${it.note}`),
          ]));
        });
        box.appendChild(wrap);
      });
    }
  } catch (e) { box.innerHTML = `規劃失敗: ${e.message}`; }
}

// ===================== 日期/月曆共用工具 =====================
// 用本地時區組字串，不要用 toISOString()（那是 UTC，半夜時段會跟「今天」差一天）
function fmtYMD(date) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}
function todayStr() { return fmtYMD(new Date()); }
// 產生月曆格子 (含前後補空白，湊滿整週)，month 是 0-11
function monthGridDates(year, month) {
  const first = new Date(year, month, 1);
  const startWeekday = first.getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const cells = [];
  for (let i = 0; i < startWeekday; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(new Date(year, month, d));
  while (cells.length % 7 !== 0) cells.push(null);
  return cells;
}

// ===================== 日記 =====================
let diaryCalCursor = null;

function renderDiary() {
  const c = $('#tab-diary');
  c.innerHTML = '';
  const now = new Date();
  if (!diaryCalCursor) diaryCalCursor = { year: now.getFullYear(), month: now.getMonth() };

  c.appendChild(el('div', { class: 'grid-2' }, [
    el('div', { class: 'card', style: 'margin-bottom:0' }, [
      el('h3', {}, '寫日記'),
      el('div', { class: 'form-row' }, [
        el('input', { id: 'diaryDate', type: 'date', value: todayStr(), onchange: loadDiaryForDate }),
        el('label', { class: 'btn btn-ghost', style: 'cursor:pointer' }, [
          '📂 匯入文字',
          el('input', { type: 'file', accept: '.txt,.md', style: 'display:none', onchange: importDiaryFile }),
        ]),
      ]),
      el('textarea', { id: 'diaryContent', rows: 10, placeholder: '今天發生了什麼事...' }),
      el('div', { style: 'margin-top:10px' }, el('button', { class: 'btn btn-primary', onclick: saveDiary }, '儲存')),
    ]),
    el('div', { class: 'card', style: 'margin-bottom:0' }, [
      el('h3', {}, '月曆瀏覽'),
      el('p', { class: 'hint' }, '藍色圓點代表當天有寫日記，點日期直接跳過去看/編輯。'),
      el('div', { id: 'diaryCalendar' }),
    ]),
  ]));

  c.appendChild(el('div', { class: 'card' }, [
    el('h3', {}, '搜尋日記'),
    el('div', { class: 'form-row' }, [
      el('input', { id: 'diarySearchInput', placeholder: '輸入關鍵字搜尋內容...', onkeydown: (ev) => { if (ev.key === 'Enter') searchDiary(); } }),
      el('button', { class: 'btn btn-primary', onclick: searchDiary }, '搜尋'),
      el('button', { class: 'btn btn-ghost', onclick: clearDiarySearch }, '清除'),
    ]),
  ]));

  c.appendChild(el('div', { class: 'card' }, [el('h3', {}, '日記列表'), el('div', { id: 'diaryList' })]));

  loadDiaryForDate();
  loadDiaryList();
  renderDiaryCalendar();
}

async function renderDiaryCalendar() {
  const box = $('#diaryCalendar');
  if (!box) return;
  const { year, month } = diaryCalCursor;
  const from = fmtYMD(new Date(year, month, 1));
  const to = fmtYMD(new Date(year, month + 1, 0));
  let marked = new Set();
  try {
    const rows = await api(`/diary?from=${from}&to=${to}`);
    marked = new Set(rows.map((r) => r.entry_date));
  } catch (e) { /* 忽略，當作沒有標記 */ }

  const cells = monthGridDates(year, month);
  const weekdayLabels = ['日', '一', '二', '三', '四', '五', '六'];
  box.innerHTML = '';
  box.appendChild(el('div', { style: 'display:flex;justify-content:space-between;align-items:center;margin-bottom:8px' }, [
    el('button', { class: 'btn btn-ghost', style: 'padding:4px 10px', onclick: () => shiftDiaryMonth(-1) }, '‹'),
    el('div', { style: 'font-weight:700;font-size:13.5px' }, `${year} 年 ${month + 1} 月`),
    el('button', { class: 'btn btn-ghost', style: 'padding:4px 10px', onclick: () => shiftDiaryMonth(1) }, '›'),
  ]));
  const grid = el('div', { class: 'mini-cal-grid' });
  weekdayLabels.forEach((w) => grid.appendChild(el('div', { class: 'mini-cal-weekday' }, w)));
  cells.forEach((d) => {
    if (!d) { grid.appendChild(el('div', { class: 'mini-cal-cell empty' })); return; }
    const dateStr = fmtYMD(d);
    const isToday = dateStr === todayStr();
    const hasEntry = marked.has(dateStr);
    grid.appendChild(el('div', {
      class: `mini-cal-cell${isToday ? ' today' : ''}${hasEntry ? ' has-mark' : ''}`,
      onclick: () => { $('#diaryDate').value = dateStr; loadDiaryForDate(); },
    }, [String(d.getDate()), hasEntry ? el('span', { class: 'mini-cal-dot' }) : null]));
  });
  box.appendChild(grid);
}
function shiftDiaryMonth(delta) {
  let { year, month } = diaryCalCursor;
  month += delta;
  if (month < 0) { month = 11; year -= 1; }
  if (month > 11) { month = 0; year += 1; }
  diaryCalCursor = { year, month };
  renderDiaryCalendar();
}

async function loadDiaryForDate() {
  const date = $('#diaryDate').value;
  try {
    const row = await api(`/diary/${date}`);
    $('#diaryContent').value = row ? row.content : '';
  } catch (e) { $('#diaryContent').value = ''; }
}
async function saveDiary() {
  const date = $('#diaryDate').value;
  const content = $('#diaryContent').value;
  try {
    await api(`/diary/${date}`, { method: 'PUT', body: { content } });
    showToast('已儲存');
    loadDiaryList();
    renderDiaryCalendar();
  } catch (e) { showToast('儲存失敗: ' + e.message); }
}
function importDiaryFile(ev) {
  const file = ev.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => { $('#diaryContent').value = reader.result; };
  reader.readAsText(file, 'utf-8');
}
function searchDiary() {
  loadDiaryList($('#diarySearchInput').value.trim());
}
function clearDiarySearch() {
  $('#diarySearchInput').value = '';
  loadDiaryList();
}
async function loadDiaryList(q) {
  const list = $('#diaryList');
  list.innerHTML = '載入中...';
  try {
    const rows = await api(q ? `/diary?q=${encodeURIComponent(q)}` : '/diary');
    list.innerHTML = '';
    if (!rows.length) { list.appendChild(el('div', { class: 'empty-state' }, q ? '沒有符合的日記' : '還沒有日記')); return; }
    rows.slice(0, 30).forEach((r) => {
      list.appendChild(el('div', {
        style: 'padding:8px 0;border-bottom:1px solid var(--grid-line);cursor:pointer',
        onclick: () => { $('#diaryDate').value = r.entry_date; loadDiaryForDate(); },
      }, [
        el('b', {}, r.entry_date), el('div', { style: 'font-size:13px;color:var(--text-secondary)' }, (r.content || '').slice(0, 80)),
      ]));
    });
  } catch (e) { list.innerHTML = '載入失敗'; }
}

// ===================== 記帳 =====================
const FINANCE_CATEGORIES = ['餐飲', '交通', '娛樂', '購物', '居家', '醫療', '教育', '其他'];
let financeBudgets = [];
let financeSummaryCache = null;

function renderFinance() {
  const c = $('#tab-finance');
  c.innerHTML = '';
  c.appendChild(el('div', { class: 'card' }, [
    el('h3', {}, '新增一筆記帳'),
    el('p', { class: 'hint' }, '目前為手動輸入金額；即時銀行帳戶餘額串接屬於台灣「Open Banking」範疇，需金融機構/金管會核准的第三方資格，暫未開放，詳見規劃書說明。'),
    el('div', { class: 'form-row' }, [
      el('input', { id: 'txDate', type: 'date', value: todayStr() }),
      el('select', { id: 'txType' }, [el('option', { value: 'expense' }, '支出'), el('option', { value: 'income' }, '收入')]),
      el('select', { id: 'txCategory', onchange: onTxCategoryChange }, [
        ...FINANCE_CATEGORIES.map((cat) => el('option', { value: cat }, cat)),
        el('option', { value: '__custom__' }, '✏️ 自訂分類...'),
      ]),
      el('input', { id: 'txAmount', type: 'number', placeholder: '金額' }),
    ]),
    el('div', { class: 'form-row' }, [
      el('input', { id: 'txCategoryCustom', placeholder: '輸入自訂分類名稱', style: 'display:none' }),
    ]),
    el('label', { style: 'display:block;font-size:13px;color:var(--text-secondary,#666);margin:10px 0 4px' }, '📝 這筆消費原因/備註 (選填，自己打字寫也可以)'),
    el('input', { id: 'txNote', list: 'txNoteList', placeholder: '例如：跟朋友聚餐、幫家人買日用品、加油...', style: 'width:100%' }),
    el('datalist', { id: 'txNoteList' }),
    el('button', { class: 'btn btn-primary', onclick: addTransaction, style: 'margin-top:10px' }, '新增'),
  ]));

  c.appendChild(el('div', { class: 'grid-2' }, [
    el('div', { class: 'card' }, [el('h3', {}, '本月支出分類'), el('div', { id: 'financeBarChart' })]),
    el('div', { class: 'card' }, [el('h3', {}, '近12個月收支趨勢'), el('div', { id: 'financeLineChart' })]),
  ]));

  c.appendChild(el('div', { class: 'grid-2' }, [
    el('div', { class: 'card' }, [
      el('h3', {}, '🔁 可能的固定支出/訂閱'),
      el('p', { class: 'hint' }, '依「備註+分類」找出在多個月份都出現、金額相近的支出，幫你整理成一份清單，是猜測不是保證。'),
      el('div', { id: 'subscriptionsArea' }, el('div', { class: 'empty-state' }, '載入中...')),
    ]),
    el('div', { class: 'card' }, [
      el('h3', {}, '📈 淨資產趨勢 (累計結餘)'),
      el('p', { class: 'hint' }, '每月收支的累計結餘隨時間的變化，不含股票等投資部位市值 (投資市值請看股票頁)。'),
      el('div', { id: 'networthChart' }),
    ]),
  ]));

  c.appendChild(el('div', { class: 'card' }, [
    el('h3', {}, '🎯 財務目標'),
    el('p', { class: 'hint' }, '不用自己算存了多少，系統會用「設定目標之後的實際收入減支出」自動算進度，並用你的儲蓄速度推算大概什麼時候能達成。'),
    el('div', { class: 'form-row' }, [
      el('input', { id: 'goalName', placeholder: '目標名稱，例如：日本旅遊基金' }),
      el('input', { id: 'goalAmount', type: 'number', placeholder: '目標金額' }),
      el('input', { id: 'goalTargetDate', type: 'date', placeholder: '希望達成日 (選填)' }),
    ]),
    el('button', { class: 'btn btn-primary', onclick: addGoal, style: 'margin-top:6px' }, '新增目標'),
    el('div', { id: 'goalsArea', style: 'margin-top:14px' }),
  ]));

  c.appendChild(el('div', { class: 'card' }, [
    el('h3', {}, '📊 預算設定'),
    el('p', { class: 'hint' }, '設定每個分類的每月預算上限，超支會用顏色提醒 (不會擋你記帳，只是提醒)。'),
    el('div', { id: 'budgetArea' }),
  ]));

  c.appendChild(el('div', { class: 'card' }, [el('h3', {}, '本月明細'), el('div', { id: 'txTable' })]));

  loadFinance();
  loadBudgets();
  loadGoals();
  loadSubscriptions();
  loadNetworthTrend();
}

async function loadSubscriptions() {
  const area = $('#subscriptionsArea');
  if (!area) return;
  try {
    const res = await api('/finance/subscriptions');
    area.innerHTML = '';
    if (!res.candidates.length) { area.appendChild(el('div', { class: 'empty-state' }, '目前資料還看不出明顯的固定支出模式')); return; }
    res.candidates.slice(0, 10).forEach((c) => {
      area.appendChild(el('div', { class: 'coping-note-item' }, [
        el('div', { class: 'content' }, [
          el('div', { style: 'font-weight:700' }, `${c.note} (${c.category})`),
          el('div', { class: 'hint', style: 'margin:2px 0 0' }, `約 ${fmtMoney(c.avgAmount)}／次 · 出現在 ${c.monthsSeen} 個月 · 最近一次 ${c.lastDate}`),
        ]),
      ]));
    });
  } catch (e) { area.innerHTML = ''; area.appendChild(el('div', { class: 'empty-state' }, '暫時無法分析')); }
}

async function loadNetworthTrend() {
  const box = $('#networthChart');
  if (!box) return;
  try {
    const res = await api('/finance/networth-trend');
    if (!res.trend.length) { box.innerHTML = ''; box.appendChild(el('div', { class: 'empty-state' }, '目前沒有可用的趨勢資料')); return; }
    renderLineChart(box, [
      { name: '累計結餘', color: cssVar('--series-violet'), points: res.trend.map((t) => ({ x: t.ym, y: t.cumulativeBalance })) },
    ]);
  } catch (e) { box.innerHTML = ''; box.appendChild(el('div', { class: 'empty-state' }, '暫時無法取得趨勢')); }
}

async function addGoal() {
  const name = $('#goalName').value.trim();
  const target_amount = Number($('#goalAmount').value);
  const target_date = $('#goalTargetDate').value || null;
  if (!name || !target_amount || target_amount <= 0) { showToast('請輸入目標名稱與大於 0 的金額'); return; }
  try {
    await api('/finance/goals', { method: 'POST', body: { name, target_amount, target_date } });
    $('#goalName').value = ''; $('#goalAmount').value = ''; $('#goalTargetDate').value = '';
    showToast('已新增目標');
    loadGoals();
  } catch (e) { showToast('新增失敗: ' + e.message); }
}

async function deleteGoal(id) {
  await api(`/finance/goals/${id}`, { method: 'DELETE' });
  loadGoals();
}

async function loadGoals() {
  const area = $('#goalsArea');
  if (!area) return;
  try {
    const goals = await api('/finance/goals');
    area.innerHTML = '';
    if (!goals.length) { area.appendChild(el('div', { class: 'empty-state' }, '還沒有設定財務目標')); return; }
    goals.forEach((g) => {
      const pct = Math.max(0, Math.min(100, g.progressPct));
      const barColor = pct >= 100 ? 'var(--good)' : pct >= 60 ? 'var(--series-blue)' : 'var(--warning)';
      let statusLine;
      if (g.projectedDate === 'reached') {
        statusLine = '🎉 已達成目標金額！';
      } else if (g.projectedDate) {
        statusLine = `依目前儲蓄速度，預估 ${g.projectedDate} 左右可達成` + (g.target_date ? (g.onTrack ? '（在預定日期內）' : '（可能會晚於預定日期，僅供參考）') : '');
      } else {
        statusLine = '目前還沒有明顯的淨儲蓄，先累積一些記帳紀錄';
      }
      area.appendChild(el('div', { style: 'padding:12px 0;border-bottom:1px solid var(--grid-line)' }, [
        el('div', { style: 'display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;margin-bottom:6px' }, [
          el('div', { style: 'font-weight:700;font-size:14px' }, g.name),
          el('div', { style: 'display:flex;gap:8px;align-items:center' }, [
            el('span', { style: 'font-size:12px;color:var(--text-muted)' }, `${fmtMoney(g.netSaved)} / ${fmtMoney(g.target_amount)} (${pct}%)`),
            el('button', { class: 'btn btn-ghost', style: 'padding:5px 10px;font-size:12px', onclick: () => deleteGoal(g.id) }, '刪除'),
          ]),
        ]),
        el('div', { style: 'height:6px;background:var(--gray-mid);border-radius:999px;overflow:hidden' }, [
          el('div', { style: `height:100%;width:${pct}%;background:${barColor}` }),
        ]),
        el('p', { class: 'hint', style: 'margin:6px 0 0' }, statusLine),
      ]));
    });
  } catch (e) { area.innerHTML = ''; area.appendChild(el('div', { class: 'hint' }, '目標載入失敗')); }
}

function onTxCategoryChange() {
  $('#txCategoryCustom').style.display = $('#txCategory').value === '__custom__' ? 'block' : 'none';
}

async function addTransaction() {
  const sel = $('#txCategory').value;
  const category = sel === '__custom__' ? ($('#txCategoryCustom').value.trim() || '未分類') : sel;
  const body = {
    tx_date: $('#txDate').value,
    type: $('#txType').value,
    category,
    amount: Number($('#txAmount').value),
    note: $('#txNote').value.trim(),
  };
  if (!body.amount) { showToast('請輸入金額'); return; }
  try {
    await api('/finance/transactions', { method: 'POST', body });
    $('#txCategoryCustom').value = ''; $('#txAmount').value = ''; $('#txNote').value = '';
    showToast('已新增');
    loadFinance();
    loadSubscriptions();
    loadNetworthTrend();
  } catch (e) { showToast('新增失敗: ' + e.message); }
}
async function deleteTransaction(id) {
  await api(`/finance/transactions/${id}`, { method: 'DELETE' });
  loadFinance();
  loadSubscriptions();
  loadNetworthTrend();
}

// 表單自動記憶：用之前打過的備註填 <datalist>，保留自由輸入的同時提供建議，減少重複打字
function populateTxNoteDatalist(rows) {
  const list = $('#txNoteList');
  if (!list) return;
  const notes = [...new Set(rows.map((r) => (r.note || '').trim()).filter(Boolean))];
  list.innerHTML = '';
  notes.slice(0, 50).forEach((n) => list.appendChild(el('option', { value: n })));
}

async function loadFinance() {
  try {
    const summary = await api('/finance/summary');
    // 用最近 200 筆全部紀錄 (不限本月) 來準備備註自動完成的建議清單，這樣過去打過的字都記得住
    api('/finance/transactions').then(populateTxNoteDatalist).catch(() => {});
    financeSummaryCache = summary;
    const expenseByCat = summary.byCategory.filter((r) => r.type === 'expense').map((r) => ({ label: r.category, value: r.total }));
    renderBarChart($('#financeBarChart'), expenseByCat, { money: true, emptyText: '本月尚無支出紀錄' });

    const months = [...new Set(summary.monthlyTrend.map((r) => r.ym))];
    const income = months.map((m) => ({ x: m, y: (summary.monthlyTrend.find((r) => r.ym === m && r.type === 'income') || {}).total || 0 }));
    const expense = months.map((m) => ({ x: m, y: (summary.monthlyTrend.find((r) => r.ym === m && r.type === 'expense') || {}).total || 0 }));
    renderLineChart($('#financeLineChart'), [
      { name: '收入', color: cssVar('--series-blue'), points: income },
      { name: '支出', color: cssVar('--series-red'), points: expense },
    ]);

    const rows = await api('/finance/transactions?month=' + todayStr().slice(0, 7));
    populateTxNoteDatalist(rows);
    const table = $('#txTable');
    table.innerHTML = '';
    renderBudgetArea();
    if (!rows.length) { table.appendChild(el('div', { class: 'empty-state' }, '本月尚無紀錄')); return; }
    const trs = rows.map((r) => el('tr', {}, [
      el('td', {}, r.tx_date), el('td', {}, r.type === 'income' ? '收入' : '支出'), el('td', {}, r.category),
      el('td', { style: r.type === 'income' ? 'color:var(--good)' : 'color:var(--critical)' }, fmtMoney(r.amount)),
      el('td', {}, r.note || ''),
      el('td', {}, el('button', { class: 'btn btn-ghost', onclick: () => deleteTransaction(r.id) }, '刪除')),
    ]));
    table.appendChild(el('table', {}, [
      el('thead', {}, el('tr', {}, [el('th', {}, '日期'), el('th', {}, '類型'), el('th', {}, '分類'), el('th', {}, '金額'), el('th', {}, '備註'), el('th', {}, '')])),
      el('tbody', {}, trs),
    ]));
  } catch (e) { showToast('載入記帳資料失敗: ' + e.message); }
}

async function loadBudgets() {
  try { financeBudgets = await api('/finance/budgets'); } catch (e) { financeBudgets = []; }
  renderBudgetArea();
}

function renderBudgetArea() {
  const area = $('#budgetArea');
  if (!area) return;
  area.innerHTML = '';

  const spentByCategory = {};
  if (financeSummaryCache) {
    financeSummaryCache.byCategory.filter((r) => r.type === 'expense').forEach((r) => { spentByCategory[r.category] = r.total; });
  }
  const allCats = new Set(FINANCE_CATEGORIES);
  financeBudgets.forEach((b) => allCats.add(b.category));
  Object.keys(spentByCategory).forEach((cat) => allCats.add(cat));

  [...allCats].forEach((cat) => {
    const budget = financeBudgets.find((b) => b.category === cat);
    const limit = budget ? budget.monthly_limit : null;
    const spent = spentByCategory[cat] || 0;
    const pct = limit ? Math.round((spent / limit) * 100) : null;
    const barColor = pct == null ? 'var(--series-blue)' : pct >= 100 ? 'var(--critical)' : pct >= 70 ? 'var(--warning)' : 'var(--good)';
    const inputId = `budgetInput-${cat}`;

    area.appendChild(el('div', { style: 'padding:10px 0;border-bottom:1px solid var(--grid-line)' }, [
      el('div', { style: 'display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;margin-bottom:6px' }, [
        el('div', { style: 'font-weight:600;font-size:13.5px' }, cat),
        el('div', { style: 'display:flex;gap:8px;align-items:center' }, [
          el('span', { style: 'font-size:12px;color:var(--text-muted)' }, limit != null ? `${fmtMoney(spent)} / ${fmtMoney(limit)}` : `已花 ${fmtMoney(spent)}`),
          el('input', { id: inputId, type: 'number', placeholder: '預算上限', value: limit != null ? limit : '', style: 'width:100px;padding:5px 8px;font-size:12px' }),
          el('button', { class: 'btn btn-ghost', style: 'padding:5px 10px;font-size:12px', onclick: () => saveBudget(cat, inputId) }, '儲存'),
        ]),
      ]),
      limit != null ? el('div', { style: 'height:6px;background:var(--gray-mid);border-radius:999px;overflow:hidden' }, [
        el('div', { style: `height:100%;width:${Math.min(100, pct)}%;background:${barColor}` }),
      ]) : null,
    ]));
  });
}

async function saveBudget(cat, inputId) {
  const val = Number($(`#${inputId}`).value);
  if (!val || val <= 0) { showToast('請輸入有效的預算金額'); return; }
  try {
    await api(`/finance/budgets/${encodeURIComponent(cat)}`, { method: 'PUT', body: { monthly_limit: val } });
    showToast('已儲存預算');
    loadBudgets();
  } catch (e) { showToast('儲存失敗: ' + e.message); }
}

// ===================== 行事曆 =====================
const CALENDAR_CATEGORIES = [
  { key: 'meal', label: '🍜 飲食', colorVar: '--series-orange' },
  { key: 'movie', label: '🎬 電影', colorVar: '--series-violet' },
  { key: 'sport', label: '🏃 運動', colorVar: '--series-aqua' },
  { key: 'work', label: '💼 工作', colorVar: '--series-blue' },
  { key: 'date', label: '💗 約會', colorVar: '--series-magenta' },
  { key: 'travel', label: '🚄 交通旅遊', colorVar: '--series-green' },
  { key: 'other', label: '📌 其他', colorVar: '--series-yellow' },
];
function calCategoryInfo(key) {
  return CALENDAR_CATEGORIES.find((c) => c.key === key) || CALENDAR_CATEGORIES[CALENDAR_CATEGORIES.length - 1];
}

let calCursor = null;
let calEventsCache = [];
let selectedCalDate = null;

function renderCalendar() {
  const c = $('#tab-calendar');
  c.innerHTML = '';
  const now = new Date();
  if (!calCursor) calCursor = { year: now.getFullYear(), month: now.getMonth() };
  if (!selectedCalDate) selectedCalDate = todayStr();

  // 月曆放左邊 (畫面主體)，新增行程表單 + 選定日期行程放右邊直向排一起，
  // 桌面/大螢幕上這樣一畫面就能看到全部功能，不用再往下滑；手機螢幕窄的話會自動改成上下排列。
  c.appendChild(el('div', { class: 'grid-cal' }, [
    el('div', { class: 'card' }, [
      el('div', { id: 'calMonthNav' }),
      el('div', { id: 'calMonthGrid' }),
      el('div', { class: 'legend', style: 'margin-top:12px' }, CALENDAR_CATEGORIES.map((cat) => el('div', { class: 'legend-item' }, [
        el('span', { class: 'legend-dot', style: `background:${cssVar(cat.colorVar)}` }), cat.label,
      ]))),
    ]),
    el('div', { class: 'cal-side' }, [
      el('div', { class: 'card' }, [
        el('h3', {}, '新增行程'),
        el('div', { class: 'form-row' }, [
          el('input', { id: 'calDate', type: 'date', value: todayStr() }),
          el('input', { id: 'calTime', type: 'time' }),
        ]),
        el('input', { id: 'calTitle', placeholder: '要做什麼事？', style: 'width:100%;margin-top:8px' }),
        el('div', { class: 'form-row', style: 'margin-top:8px' }, [
          el('select', { id: 'calCategory' }, CALENDAR_CATEGORIES.map((cat) => el('option', { value: cat.key }, cat.label))),
        ]),
        el('input', { id: 'calNote', placeholder: '備註 (選填)', style: 'width:100%;margin-top:8px' }),
        el('button', { class: 'btn btn-primary', onclick: addCalendarEvent, style: 'margin-top:10px' }, '新增'),
      ]),
      el('div', { class: 'card' }, [el('h3', { id: 'calDayTitle' }, '選定日期的行程'), el('div', { id: 'calDayDetail' })]),
    ]),
  ]));

  loadCalendarMonth();
}

async function loadCalendarMonth() {
  const { year, month } = calCursor;
  const from = fmtYMD(new Date(year, month, 1));
  const to = fmtYMD(new Date(year, month + 1, 0));
  try {
    calEventsCache = await api(`/calendar?from=${from}&to=${to}`);
  } catch (e) { calEventsCache = []; }
  renderCalMonthNav();
  renderCalMonthGrid();
  renderCalDayDetail(selectedCalDate);
}

function renderCalMonthNav() {
  const nav = $('#calMonthNav');
  if (!nav) return;
  const { year, month } = calCursor;
  nav.innerHTML = '';
  nav.appendChild(el('div', { style: 'display:flex;justify-content:space-between;align-items:center;margin-bottom:12px' }, [
    el('button', { class: 'btn btn-ghost', onclick: () => shiftCalMonth(-1) }, '‹ 上個月'),
    el('div', { style: 'font-weight:800;font-size:16px' }, `${year} 年 ${month + 1} 月`),
    el('button', { class: 'btn btn-ghost', onclick: () => shiftCalMonth(1) }, '下個月 ›'),
  ]));
}
function shiftCalMonth(delta) {
  let { year, month } = calCursor;
  month += delta;
  if (month < 0) { month = 11; year -= 1; }
  if (month > 11) { month = 0; year += 1; }
  calCursor = { year, month };
  loadCalendarMonth();
}

function renderCalMonthGrid() {
  const grid = $('#calMonthGrid');
  if (!grid) return;
  grid.innerHTML = '';
  const { year, month } = calCursor;
  const cells = monthGridDates(year, month);
  const weekdayLabels = ['日', '一', '二', '三', '四', '五', '六'];
  const wrap = el('div', { class: 'cal-grid' });
  weekdayLabels.forEach((w) => wrap.appendChild(el('div', { class: 'cal-weekday' }, w)));

  const byDate = {};
  calEventsCache.forEach((ev) => { (byDate[ev.event_date] = byDate[ev.event_date] || []).push(ev); });

  cells.forEach((d) => {
    if (!d) { wrap.appendChild(el('div', { class: 'cal-cell empty' })); return; }
    const dateStr = fmtYMD(d);
    const isToday = dateStr === todayStr();
    const isSelected = dateStr === selectedCalDate;
    const dayEvents = byDate[dateStr] || [];
    // 桌面版：完整文字小方塊。手機螢幕較窄，改用色點表示「這天有幾件事」，
    // 點下去照樣會在下方「選定日期的行程」卡片看到完整內容，畫面不用一直橫向擠字。
    const chips = dayEvents.slice(0, 3).map((ev) => {
      const info = calCategoryInfo(ev.category);
      return el('div', { class: 'cal-chip', style: `background:color-mix(in srgb, ${cssVar(info.colorVar)} 18%, transparent);color:${cssVar(info.colorVar)}` }, ev.title.slice(0, 8));
    });
    const dots = dayEvents.slice(0, 4).map((ev) => {
      const info = calCategoryInfo(ev.category);
      return el('div', { class: 'cal-dot', style: `background:${cssVar(info.colorVar)}` });
    });
    wrap.appendChild(el('div', {
      class: `cal-cell${isToday ? ' today' : ''}${isSelected ? ' selected' : ''}`,
      onclick: () => { selectedCalDate = dateStr; renderCalMonthGrid(); renderCalDayDetail(dateStr); },
    }, [
      el('div', { class: 'cal-daynum' }, String(d.getDate())),
      el('div', { class: 'cal-chips-desktop' }, [
        ...chips,
        dayEvents.length > 3 ? el('div', { class: 'cal-more' }, `+${dayEvents.length - 3}`) : null,
      ]),
      dots.length ? el('div', { class: 'cal-dots-mobile' }, dots) : null,
    ]));
  });
  grid.appendChild(wrap);
}

function renderCalDayDetail(dateStr) {
  selectedCalDate = dateStr;
  const title = $('#calDayTitle');
  if (title) title.textContent = `${dateStr} 的行程`;
  const box = $('#calDayDetail');
  if (!box) return;
  box.innerHTML = '';
  const events = calEventsCache
    .filter((ev) => ev.event_date === dateStr)
    .sort((a, b) => (a.start_time || '').localeCompare(b.start_time || ''));
  if (!events.length) { box.appendChild(el('div', { class: 'empty-state' }, '這天還沒有安排行程')); return; }
  events.forEach((r) => {
    const info = calCategoryInfo(r.category);
    box.appendChild(el('div', { style: 'display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid var(--grid-line)' }, [
      el('div', {}, [
        el('span', { class: 'badge', style: `background:color-mix(in srgb, ${cssVar(info.colorVar)} 16%, transparent);color:${cssVar(info.colorVar)};margin-right:8px` }, info.label),
        el('span', { style: 'color:var(--series-blue);font-weight:600;margin-right:8px' }, r.start_time || '全天'),
        el('span', {}, r.title),
        r.note ? el('div', { style: 'font-size:12px;color:var(--text-muted);margin-top:2px' }, r.note) : null,
      ]),
      el('button', { class: 'btn btn-ghost', onclick: () => deleteCalendarEvent(r.id) }, '刪除'),
    ]));
  });
}

async function addCalendarEvent() {
  const body = {
    event_date: $('#calDate').value,
    start_time: $('#calTime').value,
    title: $('#calTitle').value.trim(),
    note: $('#calNote').value.trim(),
    category: $('#calCategory').value,
  };
  if (!body.event_date || !body.title) { showToast('請至少填日期與事項'); return; }
  try {
    await api('/calendar', { method: 'POST', body });
    $('#calTitle').value = ''; $('#calNote').value = ''; $('#calTime').value = '';
    showToast('已新增行程');
    if (body.event_date.slice(0, 7) === fmtYMD(new Date(calCursor.year, calCursor.month, 1)).slice(0, 7)) {
      selectedCalDate = body.event_date;
    }
    loadCalendarMonth();
  } catch (e) { showToast('新增失敗: ' + e.message); }
}
async function deleteCalendarEvent(id) {
  await api(`/calendar/${id}`, { method: 'DELETE' });
  loadCalendarMonth();
}

// ===================== AI 助理 =====================
// 對話記錄改存資料庫 (見 /api/assistant/history)，重新整理頁面或換裝置登入都還在，
// 不再只是瀏覽器記憶體裡的暫時變數。
if (!state.assistantHistory) state.assistantHistory = [];
const ASSISTANT_SUGGESTIONS = ['幫我規劃這週的行程', '推薦一道今晚的晚餐食譜', '把這段文字翻譯成英文', '解釋一下這筆記帳該歸哪個分類'];
function renderAssistant() {
  const c = $('#tab-assistant');
  c.innerHTML = '';
  c.appendChild(el('div', { class: 'assistant-wrap' }, [
    el('div', { class: 'assistant-card' }, [
      el('div', { class: 'assistant-header' }, [
        el('div', { class: 'assistant-orb' }),
        el('div', {}, [
          el('h3', {}, 'AI 助理'),
          el('p', { class: 'hint' }, '生活規劃、旅遊行程、記帳建議、股票資訊解讀、翻譯、食譜、單位換算——什麼都可以問，對話記錄會保存在你的帳號裡，換裝置登入也看得到。'),
        ]),
        el('div', { class: 'assistant-header-right' }, [
          el('button', { class: 'btn btn-ghost', style: 'font-size:12px', onclick: clearAssistantHistory }, '🗑️ 清除對話'),
        ]),
      ]),
      el('div', { class: 'assistant-suggest-row' }, ASSISTANT_SUGGESTIONS.map((s) =>
        el('span', { class: 'assistant-suggest-chip', onclick: () => { $('#assistantInput').value = s; $('#assistantInput').focus(); } }, s)
      )),
      el('div', { id: 'assistantMessages', class: 'chat-box' }, el('div', { class: 'empty-state' }, '載入中...')),
      el('div', { class: 'form-row' }, [
        el('input', { id: 'assistantInput', placeholder: '輸入訊息，按 Enter 送出', onkeydown: (ev) => { if (ev.key === 'Enter') sendAssistantMessage(); } }),
        el('button', { class: 'btn btn-primary', onclick: sendAssistantMessage }, '送出'),
      ]),
    ]),
  ]));
  loadAssistantHistory();
}
async function loadAssistantHistory() {
  try {
    state.assistantHistory = await api('/assistant/history');
  } catch (e) {
    state.assistantHistory = [];
  }
  renderAssistantMessages();
}
async function clearAssistantHistory() {
  try {
    await api('/assistant/history', { method: 'DELETE' });
    state.assistantHistory = [];
    renderAssistantMessages();
    showToast('已清除對話記錄');
  } catch (e) { showToast('清除失敗: ' + e.message); }
}
function renderAssistantMessages() {
  const box = $('#assistantMessages');
  if (!box) return;
  box.innerHTML = '';
  if (!state.assistantHistory.length) {
    box.appendChild(el('div', { class: 'empty-state' }, '還沒有對話，輸入訊息開始聊天吧'));
    return;
  }
  state.assistantHistory.forEach((m) => {
    box.appendChild(el('div', { class: 'chat-msg ' + (m.role === 'user' ? 'chat-user' : 'chat-ai') }, m.content));
  });
  box.scrollTop = box.scrollHeight;
}
async function sendAssistantMessage() {
  const input = $('#assistantInput');
  const text = input.value.trim();
  if (!text) return;
  state.assistantHistory.push({ role: 'user', content: text });
  input.value = '';
  renderAssistantMessages();
  try {
    const res = await api('/assistant/chat', { method: 'POST', body: { message: text } });
    state.assistantHistory.push({ role: 'assistant', content: res.reply });
    renderAssistantMessages();
  } catch (e) {
    state.assistantHistory.push({ role: 'assistant', content: '發生錯誤: ' + e.message });
    renderAssistantMessages();
  }
}

// ===================== 心情陪伴 =====================
const MOOD_TAGS = ['焦慮', '疲憊', '開心', '平靜', '煩躁', '難過', '有動力', '孤單'];
const moodState = { selectedScore: null, selectedTags: new Set(), chatHistory: null };
// 把「深度工具」區捲到看得到的地方並聚焦到指定欄位，取代舊版分頁籤切換。
function scrollMoodToolsIntoView(focusId) {
  const col = $('#moodDashRight');
  const target = focusId ? $('#' + focusId) : null;
  if (target && col) {
    col.scrollTo({ top: Math.max(0, target.offsetTop - 12), behavior: 'smooth' });
    target.focus();
  } else if (col) {
    col.scrollTo({ top: 0, behavior: 'smooth' });
  }
}

function todayStr() { return new Date().toISOString().slice(0, 10); }

function renderMood() {
  const c = $('#tab-mood');
  c.innerHTML = '';
  moodState.selectedScore = null;
  moodState.selectedTags = new Set();

  const checkinCard = el('div', { class: 'card' }, [
    el('h3', {}, [el('div', { class: 'hex-badge' }, '💗'), '今天的你感覺怎麼樣？']),
    el('p', { class: 'hint' }, '點一個最貼近現在的分數，標籤跟備註都是選填。'),
    el('div', { class: 'mood-score-row', id: 'moodScoreRow' }),
    el('div', { class: 'mood-tag-row', id: 'moodTagRow' }),
    el('input', { id: 'moodNote', placeholder: '想多寫一點也可以，這裡沒有人會評論你 (選填)' }),
    el('div', { style: 'margin-top:12px;display:flex;gap:8px;flex-wrap:wrap' }, [
      el('button', { class: 'btn btn-primary', onclick: saveMoodEntry }, '儲存今天的紀錄'),
      el('button', { class: 'btn btn-ghost', onclick: suggestMoodTechnique }, '給我一個因應技巧'),
    ]),
    el('div', { id: 'moodTechniqueBody' }),
  ]);

  const cycleCard = el('div', { class: 'card', style: 'margin-bottom:0' }, [
    el('h3', {}, '🌙 生理週期（選填）'),
    el('p', { class: 'hint' }, '記錄經期開始日，讓關心訊息跟模式分析也能考慮經前階段（選填）。'),
    el('div', { id: 'cycleStatusBody' }, el('div', { class: 'empty-state' }, '載入中...')),
    el('div', { class: 'form-row', style: 'margin-top:10px' }, [
      el('input', { id: 'cycleStartDate', type: 'date', value: todayStr() }),
      el('select', { id: 'cycleTrackingFor' }, [
        el('option', { value: 'self' }, '記錄自己的'),
        el('option', { value: 'partner' }, '幫另一半記錄'),
      ]),
    ]),
    el('input', { id: 'cycleNote', placeholder: '想順便記點什麼嗎？(選填，例如：這次經痛比較明顯)', style: 'width:100%;margin-top:8px' }),
    el('button', { class: 'btn btn-ghost', style: 'margin-top:8px', onclick: saveCycleEntry }, '記錄這次月經開始'),
    el('p', { class: 'hint', style: 'margin-top:6px' }, '選「幫另一半記錄」的話，這筆資料只會用來提醒/整理，不會被拿去分析你自己的心情關聯，會顯示在「陪伴另一半」分頁。'),
    el('button', { class: 'btn btn-ghost', style: 'font-size:12px;margin-top:8px', onclick: toggleCycleHistory }, '查看/管理紀錄'),
    el('div', { id: 'cycleHistoryList', style: 'display:none;margin-top:8px' }),
  ]);

  const patternsCard = el('div', { class: 'card mood-insight-card', style: 'margin-bottom:0' }, [
    el('h3', {}, '🧩 跨模塊深層模式'),
    el('p', { class: 'hint' }, '把心情、行程、記帳、日記的資料放在一起，長期累積後幫你找出屬於你自己的規律。'),
    el('button', { class: 'btn btn-ghost', onclick: refreshMoodPatterns }, '重新分析'),
    el('div', { id: 'moodPatternsBody', style: 'margin-top:10px' }, el('div', { class: 'empty-state' }, '載入中...')),
  ]);

  const monthlyReviewCard = el('div', { class: 'card', style: 'margin-bottom:0' }, [
    el('h3', {}, '📅 這個月的 AI 回顧'),
    el('p', { class: 'hint' }, '把這個月的心情紀錄交給 AI，寫一段完整一點的月度回顧。'),
    el('button', { class: 'btn btn-ghost', onclick: generateMoodMonthlyReview }, '產生本月回顧'),
    el('div', { id: 'moodMonthlyReviewBody' }),
  ]);

  const thoughtRecordCard = el('div', { class: 'card thought-record-card', style: 'margin-bottom:0' }, [
    el('h3', {}, '🧠 卡住的時候：想法重塑練習'),
    el('p', { class: 'hint' }, '寫下念頭，AI 可幫你想一個更平衡的角度（自助練習，非心理治療）。'),
    el('div', { class: 'thought-record-form' }, [
      el('div', { class: 'thought-record-row2' }, [
        el('input', { id: 'trSituation', list: 'trSituationList', placeholder: '情境 (選填)' }),
        el('input', { id: 'trEmotion', list: 'trEmotionList', placeholder: '情緒 (選填，例如：焦慮)' }),
      ]),
      el('datalist', { id: 'trSituationList' }),
      el('datalist', { id: 'trEmotionList' }),
      el('textarea', { id: 'trThought', rows: 1, placeholder: '腦中出現的念頭是什麼？(例如：他一定討厭我了)' }),
      el('div', { class: 'thought-record-row2' }, [
        el('textarea', { id: 'trEvidenceFor', rows: 1, placeholder: '支持這個念頭的證據 (選填)' }),
        el('textarea', { id: 'trEvidenceAgainst', rows: 1, placeholder: '不支持的證據 (選填)' }),
      ]),
      el('div', { class: 'thought-record-row2' }, [
        el('textarea', { id: 'trReframe', rows: 1, placeholder: '可能更平衡的想法 (可自己寫或請 AI 幫忙)' }),
        el('div', { class: 'thought-record-intensity-row' }, [
          el('span', { class: 'hint', style: 'margin:0' }, '強度：'),
          el('input', { id: 'trIntensity', type: 'number', min: '1', max: '10', placeholder: '1-10', style: 'width:66px;padding:6px 4px;text-align:center' }),
        ]),
      ]),
      el('div', { style: 'display:flex;gap:8px;flex-wrap:wrap;margin-top:2px' }, [
        el('button', { class: 'btn btn-ghost', onclick: suggestThoughtReframe }, '請 AI 幫我想一句'),
        el('button', { class: 'btn btn-primary', onclick: saveThoughtRecord }, '儲存這筆記錄'),
      ]),
    ]),
    el('div', { id: 'thoughtRecordList', class: 'coping-note-list', style: 'margin-top:12px' }, el('div', { class: 'empty-state' }, '載入中...')),
  ]);

  const trendCard = el('div', { class: 'card', style: 'margin-bottom:0' }, [
    el('h3', {}, '📈 心情趨勢 (近 30 天)'),
    el('div', { id: 'moodTrendChart' }, el('div', { class: 'empty-state' }, '載入中...')),
  ]);

  const insightsCard = el('div', { class: 'card mood-insight-card', style: 'margin-bottom:0' }, [
    el('h3', {}, '🔎 心情 × 行程 洞察'),
    el('div', { id: 'moodInsightBody' }, el('div', { class: 'empty-state' }, '載入中...')),
  ]);

  const weeklyReviewCard = el('div', { class: 'card', style: 'margin-bottom:0' }, [
    el('h3', {}, '🗓️ 這週的 AI 回顧'),
    el('p', { class: 'hint' }, '把這週的心情紀錄交給 AI，寫一段像朋友一樣的小卡片給你。'),
    el('button', { class: 'btn btn-ghost', onclick: generateMoodWeeklyReview }, '產生本週回顧'),
    el('div', { id: 'moodWeeklyReviewBody' }),
  ]);

  const toolboxCard = el('div', { class: 'card', style: 'margin-bottom:0' }, [
    el('h3', {}, '🧰 我的因應工具箱'),
    el('p', { class: 'hint' }, '根據你給過的回饋，整理出對你最有效的技巧。'),
    el('div', { id: 'moodToolboxBody' }, el('div', { class: 'empty-state' }, '載入中...')),
  ]);

  const copingNotesCard = el('div', { class: 'card', style: 'margin-bottom:0' }, [
    el('h3', {}, '🍃 安心小卡'),
    el('p', { class: 'hint' }, '收藏對自己有用的一句話，心情不好的時候可以回來看看。'),
    el('div', { class: 'coping-note-add-row' }, [
      el('input', { id: 'copingNoteInput', placeholder: '寫一句想留給自己的話...', onkeydown: (ev) => { if (ev.key === 'Enter') addCopingNote(); } }),
      el('button', { class: 'btn btn-primary', onclick: addCopingNote }, '新增'),
    ]),
    el('div', { id: 'copingNoteList', class: 'coping-note-list' }, el('div', { class: 'empty-state' }, '載入中...')),
  ]);

  const chatCard = el('div', { class: 'card mood-chat-card mood-chat-companion' }, [
    el('div', { class: 'mood-chat-avatar' }, '🌱'),
    el('div', { style: 'text-align:center;margin-bottom:4px' }, [
      el('h3', { style: 'justify-content:center;margin-bottom:2px' }, 'AI 心靈對話室'),
      el('p', { class: 'hint', style: 'margin-bottom:0' }, '隨時可以聊聊，這裡是陪伴傾聽，不是正式的心理治療'),
    ]),
    el('div', { id: 'moodChatMessages', class: 'chat-box', style: 'margin-top:10px' }, el('div', { class: 'empty-state' }, '載入中...')),
    el('div', { class: 'form-row' }, [
      el('input', { id: 'moodChatInput', placeholder: '想說什麼都可以，按 Enter 送出', onkeydown: (ev) => { if (ev.key === 'Enter') sendMoodChatMessage(); } }),
      el('button', { class: 'btn btn-primary', onclick: sendMoodChatMessage }, '送出'),
    ]),
    el('div', { style: 'text-align:center;margin-top:8px' }, [
      el('button', { class: 'btn btn-ghost', style: 'font-size:12px', onclick: clearMoodChatHistory }, '🗑️ 清除對話'),
    ]),
  ]);

  const statsCard = el('div', { class: 'card', style: 'margin-bottom:0' }, [
    el('h3', {}, '📊 情緒健康報告'),
    el('div', { id: 'moodStatsGrid', class: 'mood-stat-grid', style: 'max-height:320px;overflow-y:auto' }, el('div', { class: 'empty-state' }, '載入中...')),
  ]);
  const diaryCard = el('div', { class: 'card', style: 'margin-bottom:0' }, [
    el('h3', {}, '📔 今天的日記'),
    el('div', { id: 'moodDiaryLink' }, el('div', { class: 'empty-state' }, '載入中...')),
  ]);

  // 一畫面儀表板：整個心情頁鎖在螢幕高度內、不需要滑整頁。
  // 左欄：今天的打卡 + 安心小卡 + 生理週期 (輕量、常用的東西)。
  // 中欄：AI 陪伴對話室 (這個模塊的主軸，維持最大最顯眼)。
  // 右欄：比較「深」的工具跟資料 (想法重塑、趨勢、報告、洞察、回顧…)，這欄位內部自己捲動，
  //       其他兩欄跟整體畫面都不會被它撐高——這樣「巨型表單」跟「所有資料」才能真的並存在同一面。
  // 求助專線移進最上面的窄狀態列，永遠看得到，不需要額外捲動或切換。
  c.appendChild(el('div', { class: 'mood-dash-topline' }, [
    el('div', { class: 'mood-dash-topline-title' }, [
      el('span', { class: 'mood-dash-sky-badge' }, '🌤️ 晴空手札 · 今天也要給自己一個微笑'),
      el('div', { id: 'moodCareBanner', class: 'mood-dash-care' }),
    ]),
    el('div', { class: 'mood-dash-topline-right' }, [
      el('button', { class: 'btn btn-ghost', style: 'font-size:11.5px', onclick: enableMoodBrowserNotification }, '🔔 開啟瀏覽器提醒'),
      el('div', { class: 'mood-dash-crisis-badge', title: '安心專線 1925（24小時）／生命線 1995（24小時）／張老師專線 1980（日間）' }, [
        el('span', {}, '🚨 需要協助？'),
        el('span', { class: 'mood-dash-crisis-num' }, '安心專線 1925'),
      ]),
    ]),
  ]));

  c.appendChild(el('div', { class: 'mood-dash-grid', id: 'moodDashGrid' }, [
    el('section', { class: 'mood-dash-col mood-dash-col-left' }, [checkinCard, copingNotesCard, cycleCard]),
    el('section', { class: 'mood-dash-col mood-dash-col-mid' }, [chatCard]),
    el('section', { class: 'mood-dash-col mood-dash-col-right', id: 'moodDashRight' }, [
      thoughtRecordCard, trendCard, statsCard, insightsCard, patternsCard, toolboxCard, diaryCard, weeklyReviewCard, monthlyReviewCard,
    ]),
  ]));

  const scoreRow = $('#moodScoreRow');
  for (let i = 1; i <= 10; i++) {
    scoreRow.appendChild(el('button', { class: 'mood-score-btn', 'data-score': i, onclick: () => selectMoodScore(i) }, String(i)));
  }
  const tagRow = $('#moodTagRow');
  MOOD_TAGS.forEach((tag) => {
    tagRow.appendChild(el('button', { class: 'mood-tag-chip', 'data-tag': tag, onclick: () => toggleMoodTag(tag) }, tag));
  });

  loadMoodToday();
  loadMoodTrend();
  loadMoodDiaryLink();
  loadMoodChatHistory();
  loadMoodInsights();
  loadCopingNotes();
  loadMoodPatterns();
  loadThoughtRecords();
  loadMoodToolbox();
  loadCycleStatus();
}

// ---------- 生理週期 (選填) ----------
const CYCLE_PHASE_LABEL = { menstrual: '月經期', follicular: '濾泡期', ovulation: '排卵期', luteal: '黃體期' };
async function loadCycleStatus() {
  const area = $('#cycleStatusBody');
  if (!area) return;
  try {
    const status = await api('/mood/cycle/status');
    area.innerHTML = '';
    if (!status.hasData) {
      area.appendChild(el('div', { class: 'empty-state' }, '還沒有紀錄，記一次經期開始日就能開始估算'));
      return;
    }
    const phaseLabel = CYCLE_PHASE_LABEL[status.phase] || status.phase;
    const pmsNote = status.isPmsWindow ? '（經前觀察窗）' : '';
    area.appendChild(el('p', {}, `目前估計在「${phaseLabel}」${pmsNote} · 距離下次月經約 ${status.daysUntilNextPeriod} 天`));
    if (!status.hasEnoughDataForAvg) {
      area.appendChild(el('p', { class: 'hint', style: 'margin-top:4px' }, '目前用預設 28 天週期估算，多記錄幾次會愈來愈準。'));
    }
  } catch (e) {
    area.innerHTML = '';
    area.appendChild(el('div', { class: 'empty-state' }, '週期資料暫時無法取得'));
  }
}
async function saveCycleEntry() {
  const date = $('#cycleStartDate').value;
  if (!date) { showToast('請選擇日期'); return; }
  const trackingFor = $('#cycleTrackingFor') ? $('#cycleTrackingFor').value : 'self';
  const note = $('#cycleNote') ? $('#cycleNote').value.trim() : '';
  try {
    await api('/mood/cycle', { method: 'POST', body: { periodStartDate: date, trackingFor, symptoms: note || null } });
    $('#cycleNote').value = '';
    showToast('已記錄');
    loadCycleStatus();
    if ($('#cycleHistoryList').style.display !== 'none') loadCycleHistory();
  } catch (e) { showToast('儲存失敗：' + e.message); }
}
function toggleCycleHistory() {
  const box = $('#cycleHistoryList');
  const show = box.style.display === 'none';
  box.style.display = show ? 'block' : 'none';
  if (show) loadCycleHistory();
}
async function loadCycleHistory() {
  const box = $('#cycleHistoryList');
  box.innerHTML = '';
  try {
    const rows = await api('/mood/cycle');
    if (!rows.length) {
      box.appendChild(el('div', { class: 'empty-state' }, '還沒有紀錄'));
      return;
    }
    rows.forEach((r) => {
      box.appendChild(el('div', { class: 'coping-note-item' }, [
        el('div', { class: 'content' }, [
          el('div', {}, `${r.period_start_date}${r.tracking_for === 'partner' ? '（幫另一半記錄）' : ''}`),
          r.symptoms ? el('div', { class: 'hint', style: 'margin:2px 0 0' }, r.symptoms) : null,
        ]),
        el('button', { class: 'del-btn', onclick: () => deleteCycleEntry(r.id) }, '✕'),
      ]));
    });
  } catch (e) {
    box.appendChild(el('div', { class: 'empty-state' }, '紀錄暫時無法取得'));
  }
}
async function deleteCycleEntry(id) {
  try {
    await api(`/mood/cycle/${id}`, { method: 'DELETE' });
    loadCycleHistory();
    loadCycleStatus();
  } catch (e) { showToast('刪除失敗：' + e.message); }
}

async function loadMoodToolbox() {
  const area = $('#moodToolboxBody');
  if (!area) return;
  try {
    const rows = await api('/mood/techniques/stats');
    area.innerHTML = '';
    if (!rows.length) {
      area.appendChild(el('div', { class: 'empty-state' }, '還沒有累積技巧回饋，選標籤後點「給我一個因應技巧」，用完給個回饋，這裡就會開始累積屬於你的工具箱。'));
      return;
    }
    rows.forEach((r) => {
      area.appendChild(el('div', { class: 'mood-signal-item' }, `${r.tag}：${r.best.title}（${r.best.helped}/${r.best.total} 次覺得有幫助）`));
    });
  } catch (e) {
    area.innerHTML = '';
    area.appendChild(el('div', { class: 'empty-state' }, '工具箱資料暫時無法取得'));
  }
}

function selectMoodScore(score) {
  moodState.selectedScore = score;
  document.querySelectorAll('.mood-score-btn').forEach((b) => b.classList.toggle('selected', Number(b.dataset.score) === score));
}
function toggleMoodTag(tag) {
  if (moodState.selectedTags.has(tag)) moodState.selectedTags.delete(tag);
  else moodState.selectedTags.add(tag);
  document.querySelectorAll('.mood-tag-chip').forEach((b) => b.classList.toggle('selected', moodState.selectedTags.has(b.dataset.tag)));
}

async function loadMoodToday() {
  try {
    const today = todayStr();
    const rows = await api(`/mood/entries?from=${today}&to=${today}`);
    if (rows.length) {
      const entry = rows[0];
      selectMoodScore(entry.score);
      (entry.tags || '').split(',').filter(Boolean).forEach((t) => { moodState.selectedTags.add(t); });
      document.querySelectorAll('.mood-tag-chip').forEach((b) => b.classList.toggle('selected', moodState.selectedTags.has(b.dataset.tag)));
      if (entry.note) $('#moodNote').value = entry.note;
    }
  } catch (e) { /* 忽略，當作今天還沒記錄 */ }
}

async function saveMoodEntry() {
  if (!moodState.selectedScore) { showToast('先選一個 1-10 的分數'); return; }
  try {
    await api(`/mood/entries/${todayStr()}`, {
      method: 'PUT',
      body: { score: moodState.selectedScore, tags: [...moodState.selectedTags], note: $('#moodNote').value.trim() },
    });
    showToast('已記錄今天的心情 💗');
    loadMoodTrend();
    // 分數偏低又有選標籤時，直接主動問要不要看技巧建議或寫想法記錄，
    // 不用讓使用者自己想到要去別的卡片找，把整個流程串起來。
    if (moodState.selectedScore <= 4 && moodState.selectedTags.size) {
      showCheckinFollowupPrompt();
    } else {
      const followup = $('#moodCheckinFollowup');
      if (followup) followup.innerHTML = '';
    }
  } catch (e) { showToast('儲存失敗：' + e.message); }
}

function showCheckinFollowupPrompt() {
  let followup = $('#moodCheckinFollowup');
  if (!followup) {
    followup = el('div', { id: 'moodCheckinFollowup', style: 'margin-top:10px' });
    $('#moodTechniqueBody').after(followup);
  }
  followup.innerHTML = '';
  followup.appendChild(el('div', { class: 'mood-technique-box' }, [
    el('div', {}, '這幾天感覺不太容易，要不要看一個可能有幫助的技巧，或寫一筆想法記錄整理一下？'),
    el('div', { style: 'display:flex;gap:8px;margin-top:8px;flex-wrap:wrap' }, [
      el('button', { class: 'btn btn-ghost', style: 'font-size:12px', onclick: () => { suggestMoodTechnique(); followup.innerHTML = ''; } }, '看技巧建議'),
      el('button', { class: 'btn btn-ghost', style: 'font-size:12px', onclick: () => { scrollMoodToolsIntoView('trThought'); followup.innerHTML = ''; } }, '寫想法記錄'),
      el('button', { class: 'btn btn-ghost', style: 'font-size:12px', onclick: () => { followup.innerHTML = ''; } }, '先不用了'),
    ]),
  ]));
}

async function loadMoodTrend() {
  const chartArea = $('#moodTrendChart');
  const statsGrid = $('#moodStatsGrid');
  if (!chartArea) return;
  try {
    const summary = await api('/mood/summary?days=30');
    if (!summary.series.length) {
      chartArea.innerHTML = '';
      chartArea.appendChild(el('div', { class: 'empty-state' }, '還沒有心情紀錄，記錄第一筆之後這裡就會出現趨勢圖'));
    } else {
      renderMoodChart(chartArea, summary.series);
    }
    if (statsGrid) renderMoodStats(statsGrid, summary);
    const banner = $('#moodCareBanner');
    if (banner) {
      banner.innerHTML = '';
      if (summary.careMessage) {
        banner.appendChild(el('div', { class: 'mood-care-banner' }, `💌 ${summary.careMessage}`));
      }
    }
  } catch (e) {
    chartArea.innerHTML = '';
    chartArea.appendChild(el('div', { class: 'empty-state' }, '心情資料暫時無法取得'));
    if (statsGrid) { statsGrid.innerHTML = ''; statsGrid.appendChild(el('div', { class: 'empty-state' }, '心情資料暫時無法取得')); }
  }
}

async function loadMoodInsights() {
  const area = $('#moodInsightBody');
  if (!area) return;
  try {
    const insight = await api('/mood/insights');
    area.innerHTML = '';
    if (!insight.available) {
      area.appendChild(el('div', { class: 'empty-state' }, insight.message));
    } else {
      area.appendChild(el('p', {}, insight.message));
    }
  } catch (e) {
    area.innerHTML = '';
    area.appendChild(el('div', { class: 'empty-state' }, '洞察資料暫時無法取得'));
  }
}

async function generateMoodWeeklyReview() {
  const area = $('#moodWeeklyReviewBody');
  if (!area) return;
  area.innerHTML = '';
  area.appendChild(el('div', { class: 'empty-state' }, '正在為你寫這週的回顧...'));
  try {
    const result = await api('/mood/weekly-review', { method: 'POST' });
    area.innerHTML = '';
    area.appendChild(el('div', { class: 'mood-weekly-review-box' }, result.reply));
  } catch (e) {
    area.innerHTML = '';
    area.appendChild(el('div', { class: 'empty-state' }, '這週回顧暫時無法產生：' + e.message));
  }
}

async function loadCopingNotes() {
  const list = $('#copingNoteList');
  if (!list) return;
  try {
    const notes = await api('/mood/coping-notes');
    list.innerHTML = '';
    if (!notes.length) {
      list.appendChild(el('div', { class: 'empty-state' }, '還沒有安心小卡，寫一句想留給自己的話吧'));
      return;
    }
    notes.forEach((n) => {
      list.appendChild(el('div', { class: 'coping-note-item' }, [
        el('div', { class: 'content' }, n.content),
        el('button', { class: 'del-btn', onclick: () => deleteCopingNote(n.id) }, '✕'),
      ]));
    });
  } catch (e) {
    list.innerHTML = '';
    list.appendChild(el('div', { class: 'empty-state' }, '小卡資料暫時無法取得'));
  }
}

async function addCopingNote() {
  const input = $('#copingNoteInput');
  const text = input.value.trim();
  if (!text) return;
  try {
    await api('/mood/coping-notes', { method: 'POST', body: { content: text } });
    input.value = '';
    loadCopingNotes();
  } catch (e) { showToast('新增失敗：' + e.message); }
}

async function deleteCopingNote(id) {
  try {
    await api(`/mood/coping-notes/${id}`, { method: 'DELETE' });
    loadCopingNotes();
  } catch (e) { showToast('刪除失敗：' + e.message); }
}

// ---------- 這個月 AI 回顧 ----------
async function generateMoodMonthlyReview() {
  const area = $('#moodMonthlyReviewBody');
  if (!area) return;
  area.innerHTML = '';
  area.appendChild(el('div', { class: 'empty-state' }, '正在為你寫這個月的回顧...'));
  try {
    const month = todayStr().slice(0, 7);
    const result = await api('/mood/monthly-review', { method: 'POST', body: { month } });
    area.innerHTML = '';
    area.appendChild(el('div', { class: 'mood-weekly-review-box' }, result.reply));
  } catch (e) {
    area.innerHTML = '';
    area.appendChild(el('div', { class: 'empty-state' }, '這個月的回顧暫時無法產生：' + e.message));
  }
}

// ---------- 會學習的因應技巧庫 ----------
async function suggestMoodTechnique() {
  const area = $('#moodTechniqueBody');
  if (!area) return;
  const tag = [...moodState.selectedTags][0];
  if (!tag) {
    showToast('先選一個標籤，AI 才知道要給哪種技巧');
    return;
  }
  area.innerHTML = '';
  area.appendChild(el('div', { class: 'empty-state' }, '載入中...'));
  try {
    const res = await api(`/mood/techniques/suggest?tag=${encodeURIComponent(tag)}`);
    const t = res.technique;
    area.innerHTML = '';
    area.appendChild(el('div', { class: 'mood-technique-box' }, [
      el('div', { class: 'mood-technique-title' }, `💡 ${t.title}`),
      el('p', { style: 'margin:6px 0 10px' }, t.text),
      el('div', { style: 'display:flex;gap:8px;align-items:center' }, [
        el('span', { class: 'hint', style: 'margin:0' }, '這個方法有幫助嗎？'),
        el('button', { class: 'btn btn-ghost', style: 'font-size:12px;padding:4px 10px', onclick: () => giveTechniqueFeedback(tag, t.key, true) }, '👍 有幫助'),
        el('button', { class: 'btn btn-ghost', style: 'font-size:12px;padding:4px 10px', onclick: () => giveTechniqueFeedback(tag, t.key, false) }, '👎 沒有幫助'),
      ]),
    ]));
  } catch (e) {
    area.innerHTML = '';
    area.appendChild(el('div', { class: 'empty-state' }, '技巧建議暫時無法取得'));
  }
}
async function giveTechniqueFeedback(tag, techniqueKey, helped) {
  try {
    await api('/mood/techniques/feedback', { method: 'POST', body: { tag, techniqueKey, helped } });
    showToast('謝謝你的回饋，下次會愈推薦愈準');
    loadMoodToolbox();
  } catch (e) { showToast('回饋送出失敗：' + e.message); }
}

// ---------- 跨模塊深層模式識別 ----------
async function loadMoodPatterns() {
  const area = $('#moodPatternsBody');
  if (!area) return;
  try {
    const res = await api('/mood/patterns');
    renderMoodPatterns(area, res);
  } catch (e) {
    area.innerHTML = '';
    area.appendChild(el('div', { class: 'empty-state' }, '模式分析資料暫時無法取得'));
  }
}
async function refreshMoodPatterns() {
  const area = $('#moodPatternsBody');
  if (!area) return;
  area.innerHTML = '';
  area.appendChild(el('div', { class: 'empty-state' }, '正在分析中，資料量比較大的話可能要幾秒鐘...'));
  try {
    const res = await api('/mood/patterns/refresh', { method: 'POST' });
    renderMoodPatterns(area, res);
  } catch (e) {
    area.innerHTML = '';
    area.appendChild(el('div', { class: 'empty-state' }, '分析暫時無法完成：' + e.message));
  }
}
function renderMoodPatterns(area, res) {
  area.innerHTML = '';
  if (!res.available) {
    area.appendChild(el('div', { class: 'empty-state' }, res.message));
    return;
  }
  area.appendChild(el('p', {}, res.insights));
  if (res.signals && res.signals.length) {
    const list = el('div', { class: 'mood-signal-list' });
    res.signals.forEach((s) => {
      list.appendChild(el('div', { class: 'mood-signal-item' }, `${s.label}：${s.groupAName} ${s.avgA} 分 vs ${s.groupBName} ${s.avgB} 分`));
    });
    area.appendChild(list);
  }
  if (res.generatedAt) {
    area.appendChild(el('p', { class: 'hint', style: 'margin-top:8px' }, `上次分析時間：${new Date(res.generatedAt).toLocaleString('zh-TW')}`));
  }
}

// ---------- CBT 式思考記錄 ----------
async function suggestThoughtReframe() {
  const thought = $('#trThought').value.trim();
  if (!thought) { showToast('先寫下腦中出現的念頭'); return; }
  try {
    const result = await api('/mood/thought-records/reframe-suggest', {
      method: 'POST',
      body: {
        situation: $('#trSituation').value.trim(),
        thought,
        evidenceFor: $('#trEvidenceFor').value.trim(),
        evidenceAgainst: $('#trEvidenceAgainst').value.trim(),
      },
    });
    $('#trReframe').value = result.reply;
  } catch (e) { showToast('建議暫時無法產生：' + e.message); }
}
async function saveThoughtRecord() {
  const thought = $('#trThought').value.trim();
  if (!thought) { showToast('先寫下腦中出現的念頭'); return; }
  try {
    await api('/mood/thought-records', {
      method: 'POST',
      body: {
        situation: $('#trSituation').value.trim(),
        thought,
        emotion: $('#trEmotion').value.trim(),
        intensity: $('#trIntensity').value ? Number($('#trIntensity').value) : null,
        evidenceFor: $('#trEvidenceFor').value.trim(),
        evidenceAgainst: $('#trEvidenceAgainst').value.trim(),
        reframe: $('#trReframe').value.trim(),
      },
    });
    ['trSituation', 'trThought', 'trEmotion', 'trIntensity', 'trEvidenceFor', 'trEvidenceAgainst', 'trReframe'].forEach((id) => { $('#' + id).value = ''; });
    showToast('已儲存這筆思考記錄');
    loadThoughtRecords();
  } catch (e) { showToast('儲存失敗：' + e.message); }
}
async function loadThoughtRecords() {
  const list = $('#thoughtRecordList');
  if (!list) return;
  try {
    const rows = await api('/mood/thought-records');
    populateThoughtRecordDatalists(rows);
    list.innerHTML = '';
    if (!rows.length) {
      list.appendChild(el('div', { class: 'empty-state' }, '還沒有紀錄，卡住的時候可以試著寫一筆'));
      return;
    }
    rows.forEach((r) => {
      const parts = [];
      if (r.situation) parts.push(el('div', { class: 'hint', style: 'margin:0' }, `情境：${r.situation}`));
      parts.push(el('div', { style: 'font-weight:600' }, `念頭：${r.thought}`));
      if (r.emotion || r.intensity) parts.push(el('div', { class: 'hint', style: 'margin:0' }, `情緒：${r.emotion || ''}${r.intensity ? ` (強度 ${r.intensity}/10)` : ''}`));
      if (r.reframe) parts.push(el('div', { style: 'margin-top:4px;color:var(--series-aqua)' }, `→ ${r.reframe}`));
      list.appendChild(el('div', { class: 'coping-note-item' }, [
        el('div', { class: 'content' }, parts),
        el('button', { class: 'del-btn', onclick: () => deleteThoughtRecord(r.id) }, '✕'),
      ]));
    });
  } catch (e) {
    list.innerHTML = '';
    list.appendChild(el('div', { class: 'empty-state' }, '思考記錄暫時無法取得'));
  }
}
// 表單自動記憶：情境/情緒欄位常常是重複的字眼，記住之前打過的就好，之後用選的比較快，也可以繼續自己打字
function populateThoughtRecordDatalists(rows) {
  const situationList = $('#trSituationList');
  const emotionList = $('#trEmotionList');
  if (situationList) {
    situationList.innerHTML = '';
    [...new Set(rows.map((r) => (r.situation || '').trim()).filter(Boolean))].slice(0, 50).forEach((v) => situationList.appendChild(el('option', { value: v })));
  }
  if (emotionList) {
    emotionList.innerHTML = '';
    [...new Set(rows.map((r) => (r.emotion || '').trim()).filter(Boolean))].slice(0, 50).forEach((v) => emotionList.appendChild(el('option', { value: v })));
  }
}
async function deleteThoughtRecord(id) {
  try {
    await api(`/mood/thought-records/${id}`, { method: 'DELETE' });
    loadThoughtRecords();
  } catch (e) { showToast('刪除失敗：' + e.message); }
}

function moodStatTile(value, label) {
  return el('div', { class: 'mood-stat-tile' }, [
    el('div', { class: 'mood-stat-value' }, value),
    el('div', { class: 'mood-stat-label' }, label),
  ]);
}

function renderMoodStats(container, summary) {
  container.innerHTML = '';
  const series = summary.series || [];
  if (!series.length) {
    container.appendChild(el('div', { class: 'empty-state' }, '還沒有資料'));
    return;
  }
  const thisMonth = todayStr().slice(0, 7);
  const monthCount = series.filter((r) => r.entry_date.startsWith(thisMonth)).length;

  // 連續記錄天數：從今天往回算，只要中間斷一天就停止
  const dateSet = new Set(series.map((r) => r.entry_date));
  let streak = 0;
  let cursor = new Date();
  while (true) {
    const ds = cursor.toISOString().slice(0, 10);
    if (!dateSet.has(ds)) break;
    streak++;
    cursor.setDate(cursor.getDate() - 1);
  }

  // 情緒穩定度：分數波動愈小，數值愈高 (僅供參考，不是精確的醫學指標)
  let stability = null;
  if (series.length >= 2 && summary.average != null) {
    const variance = series.reduce((s, r) => s + Math.pow(r.score - summary.average, 2), 0) / series.length;
    const stdev = Math.sqrt(variance);
    stability = Math.max(0, Math.round(100 - (stdev / 4.5) * 100));
  }

  container.appendChild(moodStatTile(summary.average != null ? `${summary.average} 分` : '--', '近 30 天平均分數'));
  container.appendChild(moodStatTile(String(monthCount), '本月已記錄天數'));
  container.appendChild(moodStatTile(`${streak} 天`, '連續記錄天數'));
  container.appendChild(moodStatTile(stability != null ? `${stability}%` : '--', '情緒穩定度 (僅供參考)'));
  if (summary.topTags && summary.topTags.length) {
    const tagsBox = el('div', { style: 'grid-column:1/-1;margin-top:4px' }, [
      el('div', { class: 'mood-stat-label', style: 'margin-bottom:6px' }, '常見標籤'),
      el('div', { class: 'mood-tag-row', style: 'margin:0' }, summary.topTags.map((t) => el('span', { class: 'mood-tag-chip selected' }, `${t.tag} ×${t.count}`))),
    ]);
    container.appendChild(tagsBox);
  }

  const heatmapBox = el('div', { style: 'grid-column:1/-1;margin-top:14px' }, [
    el('div', { class: 'mood-stat-label', style: 'margin-bottom:6px' }, '近 30 天一覽'),
  ]);
  const grid = el('div', { class: 'mood-heatmap' });
  const byDate = {};
  series.forEach((r) => { byDate[r.entry_date] = r.score; });
  const days = [];
  for (let i = 29; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    days.push(d.toISOString().slice(0, 10));
  }
  days.forEach((ds) => {
    const score = byDate[ds];
    const cell = el('div', { class: 'mood-heatmap-cell' });
    if (score != null) {
      cell.style.background = `color-mix(in srgb, ${cssVar('--series-magenta')} ${Math.round((score / 10) * 85 + 15)}%, var(--surface-2))`;
      cell.addEventListener('mousemove', (ev) => showTooltip(ev, `${ds}：${score} 分`));
      cell.addEventListener('mouseleave', hideTooltip);
    }
    grid.appendChild(cell);
  });
  heatmapBox.appendChild(grid);
  container.appendChild(heatmapBox);
}

function renderMoodChart(container, series) {
  container.innerHTML = '';
  const width = container.clientWidth || 460;
  const height = 180;
  const padL = 28, padR = 12, padTop = 14, padBottom = 26;
  const plotW = width - padL - padR;
  const plotH = height - padTop - padBottom;
  const svg = svgEl('svg', { width: '100%', height, viewBox: `0 0 ${width} ${height}` });

  for (const gv of [1, 4, 7, 10]) {
    const y = padTop + plotH - ((gv - 1) / 9) * plotH;
    svg.appendChild(svgEl('line', { x1: padL, x2: width - padR, y1: y, y2: y, stroke: cssVar('--grid-line'), 'stroke-width': 1 }));
    const lbl = svgEl('text', { x: 2, y: y + 4, 'font-size': 10, fill: cssVar('--text-muted') });
    lbl.textContent = String(gv);
    svg.appendChild(lbl);
  }

  const n = series.length;
  const coords = series.map((p, i) => ({
    px: padL + (n > 1 ? (i / (n - 1)) * plotW : plotW / 2),
    py: padTop + plotH - ((p.score - 1) / 9) * plotH,
  }));
  const pathD = coords.map((p, i) => `${i === 0 ? 'M' : 'L'}${p.px},${p.py}`).join(' ');

  const gradId = 'moodAreaGrad';
  const defs = svgEl('defs', {});
  const grad = svgEl('linearGradient', { id: gradId, x1: '0', y1: '0', x2: '0', y2: '1' });
  const stop1 = svgEl('stop', { offset: '0%', 'stop-color': cssVar('--series-magenta'), 'stop-opacity': '0.35' });
  const stop2 = svgEl('stop', { offset: '100%', 'stop-color': cssVar('--series-magenta'), 'stop-opacity': '0' });
  grad.appendChild(stop1); grad.appendChild(stop2); defs.appendChild(grad); svg.appendChild(defs);

  const areaD = `${pathD} L${coords[coords.length - 1].px},${padTop + plotH} L${coords[0].px},${padTop + plotH} Z`;
  svg.appendChild(svgEl('path', { d: areaD, fill: `url(#${gradId})`, stroke: 'none' }));
  svg.appendChild(svgEl('path', { d: pathD, fill: 'none', stroke: cssVar('--series-magenta'), 'stroke-width': 2, 'stroke-linecap': 'round' }));

  series.forEach((p, i) => {
    const px = padL + (n > 1 ? (i / (n - 1)) * plotW : plotW / 2);
    const py = padTop + plotH - ((p.score - 1) / 9) * plotH;
    const dot = svgEl('circle', { cx: px, cy: py, r: 3.5, fill: cssVar('--series-magenta') });
    dot.addEventListener('mousemove', (ev) => showTooltip(ev, `${p.entry_date}：${p.score} 分`));
    dot.addEventListener('mouseleave', hideTooltip);
    svg.appendChild(dot);
    if (n <= 10 || i === 0 || i === n - 1 || i % Math.ceil(n / 6) === 0) {
      const lbl = svgEl('text', { x: px, y: height - 6, 'font-size': 9, 'text-anchor': 'middle', fill: cssVar('--text-muted') });
      lbl.textContent = p.entry_date.slice(5);
      svg.appendChild(lbl);
    }
  });

  container.appendChild(svg);
}

async function loadMoodDiaryLink() {
  const area = $('#moodDiaryLink');
  if (!area) return;
  try {
    const today = todayStr();
    const entries = await api(`/diary?from=${today}&to=${today}`);
    area.innerHTML = '';
    if (!entries.length) {
      area.appendChild(el('div', { class: 'empty-state' }, '今天還沒寫日記'));
      area.appendChild(el('button', { class: 'btn btn-ghost', style: 'margin-top:8px', onclick: () => switchTab('diary') }, '前往寫日記'));
    } else {
      const snippet = (entries[0].content || '').slice(0, 80);
      area.appendChild(el('p', { style: 'font-size:13px;color:var(--text-secondary)' }, snippet + (entries[0].content.length > 80 ? '…' : '')));
      area.appendChild(el('button', { class: 'btn btn-ghost', style: 'margin-top:4px', onclick: () => switchTab('diary') }, '查看完整日記'));
    }
  } catch (e) {
    area.innerHTML = '';
    area.appendChild(el('div', { class: 'empty-state' }, '日記資料暫時無法取得'));
  }
}

async function loadMoodChatHistory() {
  try {
    moodState.chatHistory = await api('/mood/chat/history');
  } catch (e) {
    moodState.chatHistory = [];
  }
  moodState.opener = null;
  // 只有「目前沒有對話紀錄，但之前留有長期記憶摘要」時，才會拿到主動開場白，
  // 這樣使用者清過對話畫面之後，AI 還是會像記得之前聊過的內容一樣主動先開口。
  if (!moodState.chatHistory.length) {
    try {
      const opener = await api('/mood/chat/opener');
      if (opener.available) moodState.opener = opener.reply;
    } catch (e) { /* 開場白失敗不影響主要功能 */ }
  }
  renderMoodChatMessages();
}
async function clearMoodChatHistory() {
  try {
    await api('/mood/chat/history', { method: 'DELETE' });
    moodState.chatHistory = [];
    renderMoodChatMessages();
    showToast('已清除陪伴對話記錄');
  } catch (e) { showToast('清除失敗: ' + e.message); }
}
function renderMoodChatMessages() {
  const box = $('#moodChatMessages');
  if (!box) return;
  box.innerHTML = '';
  if (!moodState.chatHistory || !moodState.chatHistory.length) {
    if (moodState.opener) {
      box.appendChild(el('div', { class: 'chat-msg chat-ai' }, moodState.opener));
    } else {
      box.appendChild(el('div', { class: 'empty-state' }, '還沒有對話，想聊聊嗎？隨時都可以開始'));
    }
    return;
  }
  moodState.chatHistory.forEach((m) => {
    box.appendChild(el('div', { class: 'chat-msg ' + (m.role === 'user' ? 'chat-user' : 'chat-ai') }, m.content));
  });
  box.scrollTop = box.scrollHeight;
}
async function sendMoodChatMessage() {
  const input = $('#moodChatInput');
  const text = input.value.trim();
  if (!text) return;
  moodState.chatHistory = moodState.chatHistory || [];
  moodState.chatHistory.push({ role: 'user', content: text });
  input.value = '';
  renderMoodChatMessages();
  try {
    const res = await api('/mood/chat', { method: 'POST', body: { message: text } });
    moodState.chatHistory.push({ role: 'assistant', content: res.reply });
    renderMoodChatMessages();
  } catch (e) {
    moodState.chatHistory.push({ role: 'assistant', content: '發生錯誤: ' + e.message });
    renderMoodChatMessages();
  }
}

// ===================== 健康紀錄 (睡眠 / 服藥) =====================
function renderHealth() {
  const c = $('#tab-health');
  c.innerHTML = '';

  const sleepCard = el('div', { class: 'card' }, [
    el('h3', {}, '😴 睡眠紀錄'),
    el('p', { class: 'hint' }, '記錄每天的睡眠時數，看看這幾天/這個月平均睡多少。'),
    el('div', { class: 'form-row' }, [
      el('input', { id: 'sleepDate', type: 'date', value: todayStr() }),
      el('input', { id: 'sleepHours', type: 'number', step: '0.5', min: '0', max: '24', placeholder: '睡眠時數 (小時)' }),
    ]),
    el('input', { id: 'sleepNote', placeholder: '備註 (選填)', style: 'width:100%;margin-top:8px' }),
    el('button', { class: 'btn btn-primary', style: 'margin-top:10px', onclick: saveSleepEntry }, '儲存'),
    el('div', { id: 'sleepChart', style: 'margin-top:16px' }, el('div', { class: 'empty-state' }, '載入中...')),
  ]);

  const medsCard = el('div', { class: 'card' }, [
    el('h3', {}, '💊 服藥提醒'),
    el('p', { class: 'hint' }, '把需要每天吃的藥加進來，每天打勾記錄有沒有吃。'),
    el('div', { class: 'form-row' }, [
      el('input', { id: 'medName', placeholder: '藥品名稱' }),
      el('input', { id: 'medDose', placeholder: '劑量 (選填)' }),
      el('input', { id: 'medTime', placeholder: '服用時間 (選填，例如 08:00)' }),
    ]),
    el('button', { class: 'btn btn-primary', style: 'margin-top:8px', onclick: addMed }, '新增藥品'),
    el('div', { id: 'medTodayList', style: 'margin-top:16px' }, el('div', { class: 'empty-state' }, '載入中...')),
  ]);

  c.appendChild(el('div', { class: 'grid-2' }, [sleepCard, medsCard]));

  loadSleepChart();
  loadMedsToday();
}

async function saveSleepEntry() {
  const date = $('#sleepDate').value || todayStr();
  const hours = $('#sleepHours').value;
  if (!hours) { showToast('請填寫睡眠時數'); return; }
  try {
    await api(`/health-track/sleep/${date}`, { method: 'PUT', body: { hours: Number(hours), note: $('#sleepNote').value.trim() } });
    showToast('已儲存睡眠紀錄');
    loadSleepChart();
  } catch (e) { showToast('儲存失敗：' + e.message); }
}
async function loadSleepChart() {
  const area = $('#sleepChart');
  if (!area) return;
  try {
    const summary = await api('/health-track/sleep/summary?days=30');
    area.innerHTML = '';
    if (!summary.series.length) {
      area.appendChild(el('div', { class: 'empty-state' }, '還沒有睡眠紀錄'));
      return;
    }
    area.appendChild(el('p', { class: 'hint' }, `近 30 天平均睡眠時數：${summary.average} 小時`));
    const svg = svgEl('svg', { width: '100%', height: 140, viewBox: '0 0 460 140' });
    const padL = 28, padR = 12, padTop = 10, padBottom = 20;
    const plotW = 460 - padL - padR, plotH = 140 - padTop - padBottom;
    const n = summary.series.length;
    const maxHours = Math.max(10, ...summary.series.map((r) => r.hours));
    const coords = summary.series.map((p, i) => ({
      px: padL + (n > 1 ? (i / (n - 1)) * plotW : plotW / 2),
      py: padTop + plotH - (p.hours / maxHours) * plotH,
    }));
    const pathD = coords.map((p, i) => `${i === 0 ? 'M' : 'L'}${p.px},${p.py}`).join(' ');
    svg.appendChild(svgEl('path', { d: pathD, fill: 'none', stroke: cssVar('--series-blue'), 'stroke-width': 2, 'stroke-linecap': 'round' }));
    summary.series.forEach((p, i) => {
      const dot = svgEl('circle', { cx: coords[i].px, cy: coords[i].py, r: 3, fill: cssVar('--series-blue') });
      dot.addEventListener('mousemove', (ev) => showTooltip(ev, `${p.entry_date}：${p.hours} 小時`));
      dot.addEventListener('mouseleave', hideTooltip);
      svg.appendChild(dot);
    });
    area.appendChild(svg);
  } catch (e) {
    area.innerHTML = '';
    area.appendChild(el('div', { class: 'empty-state' }, '睡眠資料暫時無法取得'));
  }
}

async function addMed() {
  const name = $('#medName').value.trim();
  if (!name) { showToast('請填寫藥品名稱'); return; }
  try {
    await api('/health-track/meds', { method: 'POST', body: { name, dose: $('#medDose').value.trim(), scheduleTime: $('#medTime').value.trim() } });
    $('#medName').value = ''; $('#medDose').value = ''; $('#medTime').value = '';
    loadMedsToday();
  } catch (e) { showToast('新增失敗：' + e.message); }
}
async function loadMedsToday() {
  const list = $('#medTodayList');
  if (!list) return;
  try {
    const meds = await api('/health-track/meds/today');
    list.innerHTML = '';
    if (!meds.length) {
      list.appendChild(el('div', { class: 'empty-state' }, '還沒有加入任何藥品'));
      return;
    }
    meds.forEach((m) => {
      const checkbox = el('input', { type: 'checkbox', onchange: (ev) => toggleMedTaken(m.id, ev.target.checked) });
      checkbox.checked = !!m.takenToday;
      list.appendChild(el('div', { class: 'coping-note-item' }, [
        el('label', { style: 'display:flex;align-items:center;gap:8px;flex:1;cursor:pointer' }, [
          checkbox,
          el('div', { class: 'content' }, `${m.name}${m.dose ? `（${m.dose}）` : ''}${m.schedule_time ? ` · ${m.schedule_time}` : ''}`),
        ]),
        el('button', { class: 'del-btn', onclick: () => deleteMed(m.id) }, '✕'),
      ]));
    });
  } catch (e) {
    list.innerHTML = '';
    list.appendChild(el('div', { class: 'empty-state' }, '服藥資料暫時無法取得'));
  }
}
async function toggleMedTaken(id, taken) {
  try {
    await api(`/health-track/meds/${id}/log`, { method: 'PUT', body: { taken, date: todayStr() } });
  } catch (e) { showToast('更新失敗：' + e.message); }
}
async function deleteMed(id) {
  try {
    await api(`/health-track/meds/${id}`, { method: 'DELETE' });
    loadMedsToday();
  } catch (e) { showToast('刪除失敗：' + e.message); }
}

// ===================== 帳單提醒 =====================
function renderBills() {
  const c = $('#tab-bills');
  c.innerHTML = '';

  const formCard = el('div', { class: 'card' }, [
    el('h3', {}, '🧾 新增固定帳單'),
    el('p', { class: 'hint' }, '記錄每月固定要繳的錢 (房租、保險、訂閱等)，到期前可以提醒自己還沒繳。'),
    el('div', { class: 'form-row' }, [
      el('input', { id: 'billName', placeholder: '帳單名稱' }),
      el('input', { id: 'billAmount', type: 'number', placeholder: '金額' }),
      el('input', { id: 'billDueDay', type: 'number', min: '1', max: '31', placeholder: '每月幾號到期' }),
    ]),
    el('input', { id: 'billCategory', placeholder: '分類 (選填，例如：居住、保險、訂閱)', style: 'width:100%;margin-top:8px' }),
    el('button', { class: 'btn btn-primary', style: 'margin-top:10px', onclick: addBill }, '新增帳單'),
  ]);

  const listCard = el('div', { class: 'card' }, [
    el('h3', {}, '📋 這個月的帳單'),
    el('div', { id: 'billsListArea' }, el('div', { class: 'empty-state' }, '載入中...')),
  ]);

  c.appendChild(formCard);
  c.appendChild(listCard);
  loadBills();
}
async function addBill() {
  const name = $('#billName').value.trim();
  const amount = $('#billAmount').value;
  const dueDay = $('#billDueDay').value;
  if (!name || !amount || !dueDay) { showToast('請填寫名稱、金額、到期日'); return; }
  try {
    await api('/bills', { method: 'POST', body: { name, amount: Number(amount), dueDay: Number(dueDay), category: $('#billCategory').value.trim() } });
    $('#billName').value = ''; $('#billAmount').value = ''; $('#billDueDay').value = ''; $('#billCategory').value = '';
    showToast('已新增帳單');
    loadBills();
  } catch (e) { showToast('新增失敗：' + e.message); }
}
async function loadBills() {
  const area = $('#billsListArea');
  if (!area) return;
  try {
    const res = await api('/bills/upcoming');
    area.innerHTML = '';
    if (!res.bills.length) {
      area.appendChild(el('div', { class: 'empty-state' }, '還沒有加入任何帳單'));
      return;
    }
    area.appendChild(el('p', { class: 'hint' }, `這個月還沒繳的總金額：NT$ ${Math.round(res.totalUnpaid)}`));
    res.bills.forEach((b) => {
      const dueText = b.paid ? '已繳' : (b.daysUntilDue < 0 ? `已過期 ${Math.abs(b.daysUntilDue)} 天` : b.daysUntilDue === 0 ? '今天到期' : `還有 ${b.daysUntilDue} 天到期`);
      area.appendChild(el('div', { class: 'coping-note-item', style: b.paid ? '' : (b.daysUntilDue <= 3 ? 'border-color:var(--series-magenta)' : '') }, [
        el('div', { class: 'content' }, [
          el('div', { style: 'font-weight:700' }, `${b.name}　NT$ ${Math.round(b.amount)}`),
          el('div', { class: 'hint', style: 'margin:2px 0 0' }, `每月 ${b.due_day} 號到期 · ${dueText}${b.category ? ` · ${b.category}` : ''}`),
        ]),
        el('div', { style: 'display:flex;gap:6px;align-items:center' }, [
          el('button', { class: 'btn btn-ghost', style: 'font-size:12px;padding:4px 10px', onclick: () => toggleBillPaid(b.id, !b.paid) }, b.paid ? '取消已繳' : '標記已繳'),
          el('button', { class: 'del-btn', onclick: () => deleteBill(b.id) }, '✕'),
        ]),
      ]));
    });
  } catch (e) {
    area.innerHTML = '';
    area.appendChild(el('div', { class: 'empty-state' }, '帳單資料暫時無法取得'));
  }
}
async function toggleBillPaid(id, paid) {
  try {
    await api(`/bills/${id}/${paid ? 'mark-paid' : 'mark-unpaid'}`, { method: 'POST' });
    loadBills();
  } catch (e) { showToast('更新失敗：' + e.message); }
}
async function deleteBill(id) {
  try {
    await api(`/bills/${id}`, { method: 'DELETE' });
    loadBills();
  } catch (e) { showToast('刪除失敗：' + e.message); }
}

// ===================== 待辦事項 =====================
function renderTasks() {
  const c = $('#tab-tasks');
  c.innerHTML = '';

  const formCard = el('div', { class: 'card' }, [
    el('h3', {}, '➕ 新增任務'),
    el('input', { id: 'taskTitle', placeholder: '要做什麼事？', style: 'width:100%' }),
    el('div', { class: 'form-row', style: 'margin-top:8px' }, [
      el('input', { id: 'taskDueDate', type: 'date' }),
      el('select', { id: 'taskPriority' }, [
        el('option', { value: 'high' }, '🔴 高優先'),
        el('option', { value: 'medium', selected: true }, '🟡 中優先'),
        el('option', { value: 'low' }, '🟢 低優先'),
      ]),
      el('select', { id: 'taskEnergy' }, [
        el('option', { value: '' }, '⚡ 所需精力 (選填)'),
        el('option', { value: 'low' }, '🔋 低精力 (輕鬆就能做)'),
        el('option', { value: 'medium' }, '🔋🔋 中精力'),
        el('option', { value: 'high' }, '🔋🔋🔋 高精力 (需要專注/體力)'),
      ]),
    ]),
    el('input', { id: 'taskNote', list: 'taskNoteList', placeholder: '備註 (選填)', style: 'width:100%;margin-top:8px' }),
    el('datalist', { id: 'taskNoteList' }),
    el('div', { class: 'form-row', style: 'margin-top:8px' }, [
      el('select', { id: 'taskRecurrence' }, [
        el('option', { value: '' }, '🔁 不重複'),
        el('option', { value: 'daily' }, '每天'),
        el('option', { value: 'weekly' }, '每週'),
        el('option', { value: 'monthly' }, '每月'),
      ]),
    ]),
    el('p', { class: 'hint', style: 'margin-top:4px' }, '設定重複的話，完成這筆任務時會自動照週期產生下一筆，不用重新輸入。'),
    el('button', { class: 'btn btn-primary', style: 'margin-top:10px', onclick: addTask }, '新增任務'),
  ]);

  const reviewCard = el('div', { class: 'card', id: 'taskReviewCard' }, [
    el('h3', {}, '🗓️ 這週回顧'),
    el('div', { id: 'taskReviewArea' }, el('div', { class: 'empty-state' }, '載入中...')),
  ]);

  const suggestCard = el('div', { class: 'card', id: 'taskSuggestCard' }, [
    el('h3', {}, '💡 今天建議先做'),
    el('div', { id: 'taskSuggestArea' }, el('div', { class: 'empty-state' }, '載入中...')),
  ]);

  const listCard = el('div', { class: 'card' }, [
    el('h3', {}, '📌 待完成'),
    el('div', { id: 'taskPendingList' }, el('div', { class: 'empty-state' }, '載入中...')),
  ]);
  const doneCard = el('div', { class: 'card' }, [
    el('h3', {}, '✅ 已完成'),
    el('div', { id: 'taskDoneList' }, el('div', { class: 'empty-state' }, '載入中...')),
  ]);

  c.appendChild(formCard);
  c.appendChild(reviewCard);
  c.appendChild(suggestCard);
  c.appendChild(el('div', { class: 'grid-2' }, [listCard, doneCard]));
  loadTasks();
  loadTaskSuggestions();
  loadTaskReview();
}
async function addTask() {
  const title = $('#taskTitle').value.trim();
  if (!title) { showToast('請填寫任務標題'); return; }
  try {
    await api('/tasks', { method: 'POST', body: { title, dueDate: $('#taskDueDate').value || null, priority: $('#taskPriority').value, energyLevel: $('#taskEnergy').value || null, note: $('#taskNote').value.trim(), recurrence: $('#taskRecurrence').value || null } });
    $('#taskTitle').value = ''; $('#taskDueDate').value = ''; $('#taskNote').value = ''; $('#taskEnergy').value = ''; $('#taskRecurrence').value = '';
    loadTasks();
    loadTaskSuggestions();
  } catch (e) { showToast('新增失敗：' + e.message); }
}

const RECURRENCE_LABEL = { daily: '每天', weekly: '每週', monthly: '每月' };

async function loadTaskReview() {
  const area = $('#taskReviewArea');
  if (!area) return;
  try {
    const res = await api('/tasks/review/week');
    area.innerHTML = '';
    area.appendChild(el('p', { class: 'hint', style: 'margin:0 0 8px' }, `${res.rangeFrom} ～ ${res.rangeTo}，完成了 ${res.completedCount} 件，目前還有 ${res.stillPendingCount} 件待完成。`));
    if (res.longPendingTasks.length) {
      area.appendChild(el('div', { style: 'font-size:12.5px;font-weight:700;margin-bottom:4px' }, `已經過期 3 天以上、還沒完成 (${res.longPendingTasks.length})`));
      res.longPendingTasks.slice(0, 5).forEach((t) => {
        area.appendChild(el('div', { class: 'mood-signal-item' }, `${t.title}（到期：${t.due_date}）`));
      });
    }
  } catch (e) { area.innerHTML = ''; area.appendChild(el('div', { class: 'empty-state' }, '這週回顧暫時無法取得')); }
}
const PRIORITY_LABEL = { high: '🔴 高', medium: '🟡 中', low: '🟢 低' };
const ENERGY_LABEL = { low: '🔋 低精力', medium: '🔋🔋 中精力', high: '🔋🔋🔋 高精力' };

async function loadTaskSuggestions() {
  const area = $('#taskSuggestArea');
  if (!area) return;
  try {
    const res = await api('/tasks/suggest-today');
    area.innerHTML = '';
    if (!res.moodLogged) {
      area.appendChild(el('p', { class: 'hint', style: 'margin:0 0 8px' }, res.note || '今天還沒記錄心情，先依優先度排序。'));
    } else {
      area.appendChild(el('p', { class: 'hint', style: 'margin:0 0 8px' }, `今天心情 ${res.todayScore} 分，${res.usedHistory ? '依你過去在類似心情下的完成狀況排序：' : '先用一般的建議順序排序 (累積更多紀錄後會更準)：'}`));
    }
    if (!res.tasks.length) {
      area.appendChild(el('div', { class: 'empty-state' }, '目前沒有待完成的任務'));
      return;
    }
    res.tasks.slice(0, 5).forEach((t) => {
      area.appendChild(el('div', { class: 'mood-signal-item' }, `${PRIORITY_LABEL[t.priority] || ''} ${t.title}${t.energy_level ? ` · ${ENERGY_LABEL[t.energy_level]}` : ''}`));
    });
  } catch (e) {
    area.innerHTML = '';
    area.appendChild(el('div', { class: 'empty-state' }, '建議清單暫時無法取得'));
  }
}
async function loadTasks() {
  const pendingArea = $('#taskPendingList');
  const doneArea = $('#taskDoneList');
  if (!pendingArea) return;
  try {
    const [pending, done] = await Promise.all([api('/tasks?status=pending'), api('/tasks?status=completed')]);
    populateTaskNoteDatalist([...pending, ...done]);
    pendingArea.innerHTML = '';
    if (!pending.length) {
      pendingArea.appendChild(el('div', { class: 'empty-state' }, '目前沒有待完成的任務'));
    } else {
      pending.forEach((t) => {
        pendingArea.appendChild(el('div', { class: 'coping-note-item' }, [
          el('label', { style: 'display:flex;align-items:flex-start;gap:8px;flex:1;cursor:pointer' }, [
            el('input', { type: 'checkbox', style: 'margin-top:3px', onchange: () => completeTask(t.id, true) }),
            el('div', { class: 'content' }, [
              el('div', {}, [
                `${PRIORITY_LABEL[t.priority] || ''} ${t.title}${t.energy_level ? ` · ${ENERGY_LABEL[t.energy_level]}` : ''} `,
                t.recurrence ? el('span', { class: 'badge badge-neutral' }, `🔁 ${RECURRENCE_LABEL[t.recurrence]}`) : null,
              ]),
              el('div', { class: 'hint', style: 'margin:2px 0 0' }, `${t.due_date ? `到期：${t.due_date}` : '沒有設定到期日'}${t.note ? ` · ${t.note}` : ''}`),
            ]),
          ]),
          el('button', { class: 'del-btn', onclick: () => deleteTask(t.id) }, '✕'),
        ]));
      });
    }
    doneArea.innerHTML = '';
    if (!done.length) {
      doneArea.appendChild(el('div', { class: 'empty-state' }, '還沒有完成的任務'));
    } else {
      done.forEach((t) => {
        doneArea.appendChild(el('div', { class: 'coping-note-item' }, [
          el('div', { class: 'content', style: 'text-decoration:line-through;opacity:0.6' }, t.title),
          el('button', { class: 'btn btn-ghost', style: 'font-size:12px', onclick: () => completeTask(t.id, false) }, '取消完成'),
        ]));
      });
    }
  } catch (e) {
    pendingArea.innerHTML = '';
    pendingArea.appendChild(el('div', { class: 'empty-state' }, '任務資料暫時無法取得'));
  }
}
function populateTaskNoteDatalist(rows) {
  const list = $('#taskNoteList');
  if (!list) return;
  const notes = [...new Set(rows.map((r) => (r.note || '').trim()).filter(Boolean))];
  list.innerHTML = '';
  notes.slice(0, 50).forEach((n) => list.appendChild(el('option', { value: n })));
}

async function completeTask(id, completed) {
  try {
    const res = await api(`/tasks/${id}/complete`, { method: 'PUT', body: { completed } });
    if (res.nextTaskId) showToast('已完成，下一次的重複任務已自動建立');
    loadTasks();
    loadTaskSuggestions();
    loadTaskReview();
  } catch (e) { showToast('更新失敗：' + e.message); }
}
async function deleteTask(id) {
  try {
    await api(`/tasks/${id}`, { method: 'DELETE' });
    loadTasks();
    loadTaskSuggestions();
  } catch (e) { showToast('刪除失敗：' + e.message); }
}

// ===================== 人際關係 =====================
function renderRelationships() {
  const c = $('#tab-relationships');
  c.innerHTML = '';

  const formCard = el('div', { class: 'card' }, [
    el('h3', {}, '➕ 新增聯絡人'),
    el('div', { class: 'form-row' }, [
      el('input', { id: 'relName', placeholder: '姓名' }),
      el('input', { id: 'relType', list: 'relTypeList', placeholder: '關係 (選填，例如：家人、朋友)' }),
      el('datalist', { id: 'relTypeList' }, ['家人', '朋友', '同事', '其他'].map((v) => el('option', { value: v }))),
      el('input', { id: 'relBirthday', placeholder: '生日 MM-DD (選填)' }),
    ]),
    el('button', { class: 'btn btn-primary', style: 'margin-top:10px', onclick: addRelationship }, '新增'),
  ]);

  const birthdayCard = el('div', { class: 'card' }, [
    el('h3', {}, '🎂 未來 30 天內的生日'),
    el('div', { id: 'relBirthdayList' }, el('div', { class: 'empty-state' }, '載入中...')),
  ]);

  const importantDatesCard = el('div', { class: 'card' }, [
    el('h3', {}, '📌 重要日期'),
    el('p', { class: 'hint' }, '不只是生日，紀念日、對方的特殊日子都可以記，每年會自動重複提醒。'),
    el('div', { class: 'form-row' }, [
      el('input', { id: 'impDateLabel', placeholder: '名稱，如：交往紀念日' }),
      el('input', { id: 'impDateMonthDay', placeholder: 'MM-DD，例如 08-15' }),
      el('select', { id: 'impDateRel' }, [el('option', { value: '' }, '不綁定聯絡人 (選填)')]),
    ]),
    el('button', { class: 'btn btn-primary', style: 'margin-top:8px', onclick: addImportantDate }, '新增日期'),
    el('div', { id: 'impDateUpcoming', style: 'margin-top:12px' }, el('div', { class: 'empty-state' }, '載入中...')),
    el('div', { id: 'impDateList', style: 'margin-top:8px' }),
  ]);

  const overdueCard = el('div', { class: 'card' }, [
    el('h3', {}, '🕰️ 好一陣子沒特別聯繫'),
    el('p', { class: 'hint' }, '只是時間上的小提醒，純參考用，要不要聯絡、什麼時候聯絡都由你自己決定；每個人可以在下方設定自己的提醒週期，或乾脆不設。'),
    el('div', { id: 'relOverdueArea' }, el('div', { class: 'empty-state' }, '載入中...')),
  ]);

  const listCard = el('div', { class: 'card' }, [
    el('h3', {}, '👥 聯絡人列表'),
    el('div', { id: 'relListArea' }, el('div', { class: 'empty-state' }, '載入中...')),
  ]);

  c.appendChild(formCard);
  c.appendChild(overdueCard);
  c.appendChild(el('div', { class: 'grid-2' }, [birthdayCard, importantDatesCard]));
  c.appendChild(listCard);
  loadRelationships();
  loadUpcomingBirthdays();
  loadOverdueContacts();
  loadImportantDates();
}

async function addImportantDate() {
  const label = $('#impDateLabel').value.trim();
  const monthDay = $('#impDateMonthDay').value.trim();
  if (!label) { showToast('請填寫日期名稱'); return; }
  if (!/^\d{2}-\d{2}$/.test(monthDay)) { showToast('日期請用 MM-DD 格式，例如 08-15'); return; }
  try {
    await api('/relationships/important-dates', { method: 'POST', body: { label, monthDay, relationshipId: $('#impDateRel').value || null } });
    $('#impDateLabel').value = ''; $('#impDateMonthDay').value = '';
    loadImportantDates();
  } catch (e) { showToast('新增失敗：' + e.message); }
}
async function deleteImportantDate(id) {
  await api(`/relationships/important-dates/${id}`, { method: 'DELETE' });
  loadImportantDates();
}
async function loadImportantDates() {
  const upcomingBox = $('#impDateUpcoming');
  const listBox = $('#impDateList');
  const relSelect = $('#impDateRel');
  if (!upcomingBox) return;
  try {
    const [upcoming, all, rels] = await Promise.all([
      api('/relationships/important-dates/upcoming'),
      api('/relationships/important-dates'),
      api('/relationships'),
    ]);
    if (relSelect) {
      relSelect.innerHTML = '';
      relSelect.appendChild(el('option', { value: '' }, '不綁定聯絡人 (選填)'));
      rels.forEach((r) => relSelect.appendChild(el('option', { value: r.id }, r.name)));
    }
    upcomingBox.innerHTML = '';
    if (!upcoming.length) {
      upcomingBox.appendChild(el('div', { class: 'empty-state' }, '未來 30 天內沒有重要日期'));
    } else {
      upcoming.forEach((r) => {
        upcomingBox.appendChild(el('div', { class: 'mood-signal-item' }, `${r.label}${r.relationship_name ? `（${r.relationship_name}）` : ''} · ${r.daysUntil === 0 ? '就是今天！' : `還有 ${r.daysUntil} 天`}`));
      });
    }
    listBox.innerHTML = '';
    all.forEach((r) => {
      listBox.appendChild(el('div', { class: 'coping-note-item' }, [
        el('div', { class: 'content' }, `${r.label}${r.relationship_name ? `（${r.relationship_name}）` : ''} · ${r.month_day}`),
        el('button', { class: 'del-btn', onclick: () => deleteImportantDate(r.id) }, '✕'),
      ]));
    });
  } catch (e) { upcomingBox.innerHTML = ''; upcomingBox.appendChild(el('div', { class: 'empty-state' }, '資料暫時無法取得')); }
}
async function addRelationship() {
  const name = $('#relName').value.trim();
  if (!name) { showToast('請填寫姓名'); return; }
  const birthday = $('#relBirthday').value.trim();
  if (birthday && !/^\d{2}-\d{2}$/.test(birthday)) { showToast('生日請用 MM-DD 格式，例如 03-15'); return; }
  try {
    await api('/relationships', { method: 'POST', body: { name, relationType: $('#relType').value.trim(), birthday: birthday || null } });
    $('#relName').value = ''; $('#relType').value = ''; $('#relBirthday').value = '';
    loadRelationships();
    loadUpcomingBirthdays();
    loadOverdueContacts();
  } catch (e) { showToast('新增失敗：' + e.message); }
}
async function loadOverdueContacts() {
  const area = $('#relOverdueArea');
  if (!area) return;
  try {
    const rows = await api('/relationships/overdue');
    area.innerHTML = '';
    if (!rows.length) {
      area.appendChild(el('div', { class: 'empty-state' }, '目前沒有特別要標記的' ));
      return;
    }
    rows.forEach((r) => {
      const timeText = r.daysSinceContact == null ? '目前還沒有互動紀錄' : `距離上次記錄的互動 ${r.daysSinceContact} 天`;
      area.appendChild(el('div', { class: 'mood-signal-item' }, `${r.name}${r.relation_type ? `（${r.relation_type}）` : ''} · ${timeText}`));
    });
  } catch (e) {
    area.innerHTML = '';
    area.appendChild(el('div', { class: 'empty-state' }, '資料暫時無法取得'));
  }
}
async function loadUpcomingBirthdays() {
  const area = $('#relBirthdayList');
  if (!area) return;
  try {
    const rows = await api('/relationships/upcoming-birthdays');
    area.innerHTML = '';
    if (!rows.length) {
      area.appendChild(el('div', { class: 'empty-state' }, '未來 30 天內沒有生日'));
      return;
    }
    rows.forEach((r) => {
      area.appendChild(el('div', { class: 'mood-signal-item' }, `${r.name}${r.relation_type ? `（${r.relation_type}）` : ''} · ${r.daysUntil === 0 ? '就是今天！' : `還有 ${r.daysUntil} 天`}`));
    });
  } catch (e) {
    area.innerHTML = '';
    area.appendChild(el('div', { class: 'empty-state' }, '生日資料暫時無法取得'));
  }
}
async function loadRelationships() {
  const area = $('#relListArea');
  if (!area) return;
  try {
    const rows = await api('/relationships');
    area.innerHTML = '';
    if (!rows.length) {
      area.appendChild(el('div', { class: 'empty-state' }, '還沒有加入任何聯絡人'));
      return;
    }
    rows.forEach((r) => {
      const item = el('div', { class: 'coping-note-item', style: 'flex-direction:column;align-items:stretch;gap:6px' }, []);
      item.appendChild(el('div', { style: 'display:flex;justify-content:space-between;align-items:center' }, [
        el('div', { class: 'content' }, `${r.name}${r.relation_type ? `（${r.relation_type}）` : ''}${r.birthday ? ` · 生日 ${r.birthday}` : ''}`),
        el('button', { class: 'del-btn', onclick: () => deleteRelationship(r.id) }, '✕'),
      ]));
      item.appendChild(el('div', { class: 'form-row' }, [
        el('input', { id: `relNote_${r.id}`, list: 'relNoteList', placeholder: '記一筆互動 (例如：一起吃了晚餐)', style: 'flex:1' }),
        el('button', { class: 'btn btn-ghost', style: 'font-size:12px', onclick: () => addInteraction(r.id) }, '新增互動'),
      ]));
      item.appendChild(el('div', { class: 'form-row' }, [
        el('input', {
          id: `relInterval_${r.id}`, type: 'number', min: '0',
          placeholder: '提醒週期 (天，選填)',
          value: r.reminder_interval_days != null ? r.reminder_interval_days : '',
          style: 'flex:1',
        }),
        el('button', { class: 'btn btn-ghost', style: 'font-size:12px', onclick: () => saveReminderInterval(r) }, '儲存提醒週期'),
      ]));
      area.appendChild(item);
    });
    area.appendChild(el('datalist', { id: 'relNoteList' }));
    populateRelNoteDatalist(rows);
  } catch (e) {
    area.innerHTML = '';
    area.appendChild(el('div', { class: 'empty-state' }, '聯絡人資料暫時無法取得'));
  }
}
async function addInteraction(relId) {
  const input = $(`#relNote_${relId}`);
  const note = input.value.trim();
  if (!note) return;
  try {
    await api(`/relationships/${relId}/interactions`, { method: 'POST', body: { note } });
    input.value = '';
    showToast('已記錄這筆互動');
    loadOverdueContacts();
  } catch (e) { showToast('新增失敗：' + e.message); }
}
async function deleteRelationship(id) {
  try {
    await api(`/relationships/${id}`, { method: 'DELETE' });
    loadRelationships();
    loadUpcomingBirthdays();
    loadOverdueContacts();
  } catch (e) { showToast('刪除失敗：' + e.message); }
}
async function saveReminderInterval(r) {
  const input = $(`#relInterval_${r.id}`);
  const val = input.value.trim();
  try {
    await api(`/relationships/${r.id}`, {
      method: 'PUT',
      body: { reminderIntervalDays: val === '' ? null : Number(val) },
    });
    showToast('已儲存提醒週期');
    loadOverdueContacts();
  } catch (e) { showToast('儲存失敗：' + e.message); }
}
// 表單自動記憶：把之前記錄過的互動內容整理成建議清單 (最多抓最近幾位聯絡人的紀錄，避免一次打太多 API)
async function populateRelNoteDatalist(rels) {
  const list = $('#relNoteList');
  if (!list || !rels.length) return;
  try {
    const results = await Promise.all(rels.slice(0, 15).map((r) => api(`/relationships/${r.id}/interactions`).catch(() => [])));
    const notes = [...new Set(results.flat().map((i) => (i.note || '').trim()).filter(Boolean))];
    list.innerHTML = '';
    notes.slice(0, 50).forEach((n) => list.appendChild(el('option', { value: n })));
  } catch (e) { /* 自動完成失敗不影響主要功能，靜默略過 */ }
}

// ===================== 陪伴另一半 =====================
// 給「幫另一半記錄生理週期」的使用者一個獨立的頁面：目前大概在哪個階段、可以怎麼體貼地陪伴，
// 以及一份簡單的紀錄日誌 (每次記錄可以順便寫一句觀察，例如「她今天說有點累」)。
// 所有描述都刻意用「有些人可能」這種保留語氣，不做斷言、不做醫療建議，把最終判斷留給使用者自己觀察。
const PARTNER_PHASE_TIPS = {
  menstrual: {
    label: '月經期',
    tip: '這幾天她的身體可能會比較不舒服，像是經痛、疲倦感增加。可以主動問問她需不需要什麼 (熱敷、止痛藥、清淡一點的食物)，安靜地陪伴通常比講道理更有幫助。',
  },
  follicular: {
    label: '濾泡期',
    tip: '這段時間精神狀態通常相對穩定，是規劃活動、聊比較需要專注的事情的好時機。不過每個人狀況不同，還是以她當下的感覺為主。',
  },
  ovulation: {
    label: '排卵期',
    tip: '這段時間精神狀態通常不錯，沒有特別需要注意的地方，維持平常的相處步調就好。',
  },
  luteal: {
    label: '黃體期',
    tip: '身體可能開始有變化，留意她有沒有提到不舒服或情緒上的起伏，多一點觀察就好，不用特別緊張。',
  },
};
const PARTNER_PMS_TIP = '這幾天正好在「經前」這個常見比較敏感的時間窗，有些人在這階段容易累、情緒起伏比較大，這是常見的生理反應，不代表她怎麼了、也不代表你們之間有什麼問題。這時候少一點講道理、多一點耐心和空間，通常會比較有幫助。';

function renderPartnerCare() {
  const c = $('#tab-partnerCare');
  c.innerHTML = '';
  c.appendChild(el('div', { class: 'disclaimer' }, '這裡的階段推算跟提示，是根據你記錄的經期開始日做統計上的估算，僅供理解與陪伴參考，不是醫療建議，每個人狀況不同，最準確的還是直接問她的感受和需求。'));

  c.appendChild(el('div', { class: 'card' }, [
    el('h3', {}, '🌷 目前狀態'),
    el('div', { id: 'partnerStatusBody' }, el('div', { class: 'empty-state' }, '載入中...')),
  ]));

  c.appendChild(el('div', { class: 'card' }, [
    el('h3', {}, '📝 記一筆'),
    el('p', { class: 'hint' }, '記錄這次月經開始日，也可以順便寫點觀察 (例如：她說這幾天特別累)，會變成下面的日誌。'),
    el('div', { class: 'form-row' }, [
      el('input', { id: 'partnerCycleDate', type: 'date', value: todayStr() }),
      el('button', { class: 'btn btn-primary', onclick: addPartnerCycleEntry }, '記錄這次月經開始'),
    ]),
    el('input', { id: 'partnerCycleNote', placeholder: '想記點什麼嗎？(選填)', style: 'width:100%;margin-top:8px' }),
  ]));

  c.appendChild(el('div', { class: 'card' }, [
    el('h3', {}, '📔 陪伴日誌'),
    el('p', { class: 'hint' }, '你幫她記錄過的經期跟觀察備註，依時間排列。'),
    el('div', { id: 'partnerLogArea' }, el('div', { class: 'empty-state' }, '載入中...')),
  ]));

  loadPartnerStatus();
  loadPartnerLog();
}

async function loadPartnerStatus() {
  const box = $('#partnerStatusBody');
  if (!box) return;
  try {
    const status = await api('/mood/cycle/partner-status');
    box.innerHTML = '';
    if (!status.hasData) {
      box.appendChild(el('div', { class: 'empty-state' }, '還沒有幫她記錄過經期，記一次開始日就能開始估算階段。'));
      return;
    }
    const phaseInfo = PARTNER_PHASE_TIPS[status.phase] || { label: status.phase, tip: '' };
    box.appendChild(el('div', { style: 'display:flex;align-items:center;gap:10px;flex-wrap:wrap' }, [
      el('span', { class: 'badge badge-neutral' }, `目前估計：${phaseInfo.label}`),
      status.isPmsWindow ? el('span', { class: 'badge', style: 'background:color-mix(in srgb, var(--warning) 18%, transparent);color:var(--warning)' }, '經前觀察窗') : null,
      el('span', { class: 'hint', style: 'margin:0' }, `距離下次月經約 ${status.daysUntilNextPeriod} 天`),
    ]));
    box.appendChild(el('p', { style: 'margin-top:10px;line-height:1.7' }, status.isPmsWindow ? PARTNER_PMS_TIP : phaseInfo.tip));
    if (!status.hasEnoughDataForAvg) {
      box.appendChild(el('p', { class: 'hint', style: 'margin-top:6px' }, '目前用預設 28 天週期估算，多記錄幾次會愈來愈準。'));
    }
  } catch (e) {
    box.innerHTML = '';
    box.appendChild(el('div', { class: 'empty-state' }, '狀態資料暫時無法取得'));
  }
}

async function addPartnerCycleEntry() {
  const date = $('#partnerCycleDate').value;
  if (!date) { showToast('請選擇日期'); return; }
  const note = $('#partnerCycleNote').value.trim();
  try {
    await api('/mood/cycle', { method: 'POST', body: { periodStartDate: date, trackingFor: 'partner', symptoms: note || null } });
    $('#partnerCycleNote').value = '';
    showToast('已記錄');
    loadPartnerStatus();
    loadPartnerLog();
  } catch (e) { showToast('儲存失敗：' + e.message); }
}

async function loadPartnerLog() {
  const area = $('#partnerLogArea');
  if (!area) return;
  try {
    const rows = (await api('/mood/cycle')).filter((r) => r.tracking_for === 'partner');
    area.innerHTML = '';
    if (!rows.length) { area.appendChild(el('div', { class: 'empty-state' }, '還沒有紀錄')); return; }
    rows.forEach((r) => {
      area.appendChild(el('div', { class: 'coping-note-item' }, [
        el('div', { class: 'content' }, [
          el('div', { style: 'font-weight:700' }, r.period_start_date),
          r.symptoms ? el('div', { class: 'hint', style: 'margin:2px 0 0' }, r.symptoms) : null,
        ]),
        el('button', { class: 'del-btn', onclick: () => deletePartnerCycleEntry(r.id) }, '✕'),
      ]));
    });
  } catch (e) {
    area.innerHTML = '';
    area.appendChild(el('div', { class: 'empty-state' }, '日誌暫時無法取得'));
  }
}
async function deletePartnerCycleEntry(id) {
  try {
    await api(`/mood/cycle/${id}`, { method: 'DELETE' });
    loadPartnerStatus();
    loadPartnerLog();
  } catch (e) { showToast('刪除失敗：' + e.message); }
}

// ===================== 個人化設定 =====================
function renderSettings() {
  const c = $('#tab-settings');
  c.innerHTML = '';
  // 跟首頁小工具拼貼 (手機版) / 星系版面 (桌面版) 共用同一份 enabledModules 設定，
  // 這裡列出全部可以自訂的項目，不只是原本的 4 個 (有些人比較常用的股票，另一些人完全用不到)。
  const labels = { stocks: '📈 股票', finance: '💰 記帳', tasks: '✅ 待辦事項', mood: '💗 心情陪伴', bills: '🧾 帳單提醒', calendar: '📅 行事曆' };
  const modules = Object.keys(labels);
  const enabled = (state.prefs && state.prefs.enabledModules) || {};

  const rows = modules.map((m) => el('div', { class: 'module-toggle-row' }, [
    el('span', {}, labels[m]),
    el('label', { class: 'switch' }, [
      el('input', { type: 'checkbox', checked: enabled[m] !== false, onchange: (ev) => toggleModule(m, ev.target.checked) }),
      el('span', { class: 'slider' }),
    ]),
  ]));
  c.appendChild(el('div', { class: 'card' }, [
    el('h3', {}, '首頁模組顯示設定'),
    el('p', { class: 'hint' }, '關閉的項目仍可從選單/底部導覽進入，只是不會出現在首頁摘要或小工具拼貼裡；在首頁按「✏️ 自訂」也可以調整同一份設定。'),
    ...rows,
  ]));

  c.appendChild(el('div', { class: 'card' }, [
    el('h3', {}, '📦 資料匯出／備份'),
    el('p', { class: 'hint' }, '把股票自選、日記、記帳、行事曆、心情陪伴（含安心小卡、思考記錄）等全部模組的資料，打包成一份 JSON 檔下載下來，可以自己留一份備份，或之後想搬到別的地方使用。'),
    el('button', { class: 'btn btn-primary', onclick: exportAllData }, '匯出全部資料'),
  ]));
}
function exportAllData() {
  window.open('/api/export/all', '_blank');
}
async function toggleModule(name, val) {
  state.prefs.enabledModules = { ...(state.prefs.enabledModules || {}), [name]: val };
  await api('/prefs', { method: 'PUT', body: state.prefs });
  showToast('已更新設定');
}

// ===================== Debug 面板 =====================
async function showDebug() {
  const token = prompt('輸入 Debug Token (見伺服器 .env 的 DEBUG_TOKEN)：');
  if (token == null) return;
  try {
    const res = await fetch('/api/debug', { headers: { 'X-Debug-Token': token } });
    const data = await res.json();
    if (!res.ok) { showToast(data.error || '驗證失敗'); return; }
    alert(JSON.stringify(data, null, 2).slice(0, 4000));
  } catch (e) { showToast('取得系統狀態失敗'); }
}

// ===================== 啟動 =====================
(async function boot() {
  try {
    const { user } = await api('/auth/me');
    if (user) onAuthed(user);
    else {
      const health = await api('/health');
      $('#appVersion').textContent = health.version;
    }
  } catch (e) {}
})();
