// 固定行程模板 (v0.51)。範本只是存一份「項目清單」，套用時才依起始日期 + day_offset
// 算出每一項的到期日，直接寫進 tasks 表——套用後的待辦事項就是普通的待辦事項，可以照常
// 在「待辦事項」分頁編輯/完成，範本本身不會因為待辦被改動而跟著變。

const { Router } = require('../mini-http');
const { getDb } = require('../services/db');
const { requireAuth } = require('../middleware/auth');

const router = Router();

function addDays(dateStr, days) {
  const d = new Date(dateStr + 'T00:00:00Z');
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}

router.get('/routine-templates', requireAuth, (req, res) => {
  const db = getDb();
  const templates = db.prepare('SELECT * FROM routine_templates WHERE user_id = ? ORDER BY created_at DESC').all(req.session.userId);
  const summarized = templates.map((t) => {
    const itemCount = db.prepare('SELECT COUNT(*) c FROM routine_template_items WHERE template_id = ?').get(t.id).c;
    return { ...t, itemCount };
  });
  res.json(summarized);
});

router.get('/routine-templates/:id', requireAuth, (req, res) => {
  const db = getDb();
  const template = db.prepare('SELECT * FROM routine_templates WHERE id = ? AND user_id = ?').get(req.params.id, req.session.userId);
  if (!template) return res.status(404).json({ error: '找不到這個範本' });
  const items = db.prepare('SELECT * FROM routine_template_items WHERE template_id = ? ORDER BY sort_order ASC, id ASC').all(template.id);
  res.json({ ...template, items });
});

router.post('/routine-templates', requireAuth, (req, res) => {
  const { name, items } = req.body || {};
  const trimmedName = String(name || '').trim();
  if (!trimmedName) return res.status(400).json({ error: '請輸入範本名稱' });
  const itemList = Array.isArray(items) ? items : [];
  const cleanedItems = itemList
    .map((it) => ({
      title: String((it && it.title) || '').trim(),
      note: (it && it.note) || '',
      dayOffset: Number.isFinite(Number(it && it.dayOffset)) ? Math.trunc(Number(it.dayOffset)) : 0,
    }))
    .filter((it) => it.title);
  if (!cleanedItems.length) return res.status(400).json({ error: '範本至少需要一個項目' });

  const db = getDb();
  const now = new Date().toISOString();
  const result = db.prepare('INSERT INTO routine_templates (user_id, name, created_at) VALUES (?, ?, ?)').run(req.session.userId, trimmedName, now);
  const templateId = result.lastInsertRowid;
  const insertItem = db.prepare('INSERT INTO routine_template_items (template_id, title, note, day_offset, sort_order, created_at) VALUES (?, ?, ?, ?, ?, ?)');
  cleanedItems.forEach((it, idx) => insertItem.run(templateId, it.title, it.note, it.dayOffset, idx, now));
  res.json({ id: templateId });
});

router.delete('/routine-templates/:id', requireAuth, (req, res) => {
  const db = getDb();
  const template = db.prepare('SELECT * FROM routine_templates WHERE id = ? AND user_id = ?').get(req.params.id, req.session.userId);
  if (!template) return res.status(404).json({ error: '找不到這個範本' });
  db.prepare('DELETE FROM routine_templates WHERE id = ?').run(template.id);
  res.json({ ok: true });
});

// 套用範本：以 startDate 為基準，依每個項目的 day_offset 算出到期日，各自建立一筆待辦事項。
router.post('/routine-templates/:id/apply', requireAuth, (req, res) => {
  const db = getDb();
  const template = db.prepare('SELECT * FROM routine_templates WHERE id = ? AND user_id = ?').get(req.params.id, req.session.userId);
  if (!template) return res.status(404).json({ error: '找不到這個範本' });
  const startDate = (req.body && req.body.startDate) || new Date().toISOString().slice(0, 10);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(startDate)) return res.status(400).json({ error: '起始日期格式不正確' });

  const items = db.prepare('SELECT * FROM routine_template_items WHERE template_id = ? ORDER BY sort_order ASC, id ASC').all(template.id);
  const now = new Date().toISOString();
  const insertTask = db.prepare(
    'INSERT INTO tasks (user_id, title, note, due_date, priority, completed, created_at) VALUES (?, ?, ?, ?, ?, 0, ?)'
  );
  const createdTaskIds = items.map((item) => {
    const dueDate = addDays(startDate, item.day_offset);
    const result = insertTask.run(req.session.userId, item.title, item.note || null, dueDate, 'medium', now);
    return result.lastInsertRowid;
  });
  res.json({ ok: true, createdCount: createdTaskIds.length, taskIds: createdTaskIds });
});

module.exports = router;
