const { Router } = require('../mini-http');
const { getDb } = require('../services/db');
const { requireAuth } = require('../middleware/auth');

const router = Router();

router.get('/', requireAuth, (req, res) => {
  const db = getDb();
  const rows = db.prepare('SELECT * FROM relationships WHERE user_id = ? ORDER BY name ASC').all(req.session.userId);
  res.json(rows);
});

router.post('/', requireAuth, (req, res) => {
  const { name, relationType, birthday, note } = req.body || {};
  if (!name || !String(name).trim()) return res.status(400).json({ error: '請提供姓名' });
  if (birthday && !/^\d{2}-\d{2}$/.test(birthday)) return res.status(400).json({ error: '生日請用 MM-DD 格式 (例如 03-15)' });
  const db = getDb();
  const now = new Date().toISOString();
  const result = db.prepare('INSERT INTO relationships (user_id, name, relation_type, birthday, note, created_at) VALUES (?, ?, ?, ?, ?, ?)').run(
    req.session.userId, String(name).trim(), relationType || null, birthday || null, note || null, now
  );
  res.json({ id: result.lastInsertRowid, ok: true });
});

router.delete('/:id', requireAuth, (req, res) => {
  const db = getDb();
  db.prepare('DELETE FROM relationships WHERE id = ? AND user_id = ?').run(req.params.id, req.session.userId);
  res.json({ ok: true });
});

router.put('/:id', requireAuth, (req, res) => {
  const { name, relationType, birthday, note, reminderIntervalDays } = req.body || {};
  const db = getDb();
  const existing = db.prepare('SELECT * FROM relationships WHERE id = ? AND user_id = ?').get(req.params.id, req.session.userId);
  if (!existing) return res.status(404).json({ error: '找不到這個人' });
  if (birthday && !/^\d{2}-\d{2}$/.test(birthday)) return res.status(400).json({ error: '生日請用 MM-DD 格式 (例如 03-15)' });
  db.prepare(
    'UPDATE relationships SET name = ?, relation_type = ?, birthday = ?, note = ?, reminder_interval_days = ? WHERE id = ? AND user_id = ?'
  ).run(
    name !== undefined && String(name).trim() ? String(name).trim() : existing.name,
    relationType !== undefined ? (relationType || null) : existing.relation_type,
    birthday !== undefined ? (birthday || null) : existing.birthday,
    note !== undefined ? (note || null) : existing.note,
    reminderIntervalDays !== undefined ? (reminderIntervalDays === null ? null : Number(reminderIntervalDays)) : existing.reminder_interval_days,
    req.params.id,
    req.session.userId
  );
  res.json({ ok: true });
});

router.get('/:id/interactions', requireAuth, (req, res) => {
  const db = getDb();
  const rows = db.prepare('SELECT * FROM relationship_interactions WHERE relationship_id = ? AND user_id = ? ORDER BY interaction_date DESC').all(req.params.id, req.session.userId);
  res.json(rows);
});

const VALID_QUALITIES = new Set(['positive', 'neutral', 'draining']);

router.post('/:id/interactions', requireAuth, (req, res) => {
  const { note, date, quality } = req.body || {};
  if (!note || !String(note).trim()) return res.status(400).json({ error: '請填寫互動內容' });
  if (quality !== undefined && quality !== null && !VALID_QUALITIES.has(quality)) {
    return res.status(400).json({ error: '互動感覺的值不合法' });
  }
  const db = getDb();
  const rel = db.prepare('SELECT id FROM relationships WHERE id = ? AND user_id = ?').get(req.params.id, req.session.userId);
  if (!rel) return res.status(404).json({ error: '找不到這個人' });
  const now = new Date().toISOString();
  const result = db.prepare('INSERT INTO relationship_interactions (user_id, relationship_id, interaction_date, note, quality, created_at) VALUES (?, ?, ?, ?, ?, ?)').run(
    req.session.userId, req.params.id, date || now.slice(0, 10), String(note).trim(), quality || null, now
  );
  res.json({ id: result.lastInsertRowid, ok: true });
});

// v0.65：互動品質摘要——依關係人分組統計每一種「互動感覺」被記錄過幾次，只算有填寫過
// quality 的紀錄 (沒填的不算進分母，避免舊資料全部被當成「普通」)。前端用這個資料在
// 關係人卡片上顯示一個簡單的品質徽章 (例如「多半正向」「偏消耗」)，不強迫使用者解讀。
router.get('/interaction-quality-summary', requireAuth, (req, res) => {
  const db = getDb();
  const rows = db
    .prepare(
      `SELECT relationship_id, quality, COUNT(*) as c
       FROM relationship_interactions
       WHERE user_id = ? AND quality IS NOT NULL
       GROUP BY relationship_id, quality`
    )
    .all(req.session.userId);
  const byRelationship = {};
  rows.forEach((r) => {
    if (!byRelationship[r.relationship_id]) byRelationship[r.relationship_id] = { positive: 0, neutral: 0, draining: 0 };
    byRelationship[r.relationship_id][r.quality] = r.c;
  });
  res.json(byRelationship);
});

// 未來 30 天內的生日 (跨年也算，例如現在 12 月、生日 1 月)
router.get('/upcoming-birthdays', requireAuth, (req, res) => {
  const db = getDb();
  const rows = db.prepare("SELECT id, name, relation_type, birthday FROM relationships WHERE user_id = ? AND birthday IS NOT NULL").all(req.session.userId);
  const todayStr = new Date().toISOString().slice(0, 10);
  const todayUTC = new Date(todayStr + 'T00:00:00Z');
  const thisYear = todayUTC.getUTCFullYear();

  const withDays = rows.map((r) => {
    const [mm, dd] = r.birthday.split('-').map(Number);
    let next = new Date(Date.UTC(thisYear, mm - 1, dd));
    if (next < todayUTC) next = new Date(Date.UTC(thisYear + 1, mm - 1, dd));
    const daysUntil = Math.round((next - todayUTC) / (1000 * 60 * 60 * 24));
    return { ...r, daysUntil };
  });

  res.json(withDays.filter((r) => r.daysUntil <= 30).sort((a, b) => a.daysUntil - b.daysUntil));
});

// 依關係類型給預設的「間隔提醒」天數 (使用者可在個別聯絡人上覆寫)
const DEFAULT_INTERVAL_BY_TYPE = { family: 30, friend: 45, colleague: 60, other: 60 };

// 這裡刻意不用「好久沒聯絡」這種帶壓力的詞，只是單純的時間資訊，
// 給不給提醒、要不要聯絡，決定權都在使用者身上。
router.get('/overdue', requireAuth, (req, res) => {
  const db = getDb();
  const rels = db.prepare('SELECT * FROM relationships WHERE user_id = ?').all(req.session.userId);
  const lastRows = db
    .prepare(
      `SELECT relationship_id, MAX(interaction_date) as last_date FROM relationship_interactions WHERE user_id = ? GROUP BY relationship_id`
    )
    .all(req.session.userId);
  const lastByRel = {};
  lastRows.forEach((r) => { lastByRel[r.relationship_id] = r.last_date; });

  const todayStr = new Date().toISOString().slice(0, 10);
  const today = new Date(todayStr + 'T00:00:00Z');

  const results = rels.map((r) => {
    const lastDate = lastByRel[r.id] || null;
    const intervalDays = r.reminder_interval_days || DEFAULT_INTERVAL_BY_TYPE[r.relation_type] || DEFAULT_INTERVAL_BY_TYPE.other;
    let daysSinceContact = null;
    if (lastDate) {
      daysSinceContact = Math.round((today - new Date(lastDate + 'T00:00:00Z')) / (1000 * 60 * 60 * 24));
    }
    const dueForContact = daysSinceContact == null || daysSinceContact >= intervalDays;
    return { ...r, lastInteractionDate: lastDate, daysSinceContact, intervalDays, dueForContact };
  });

  res.json(results.filter((r) => r.dueForContact).sort((a, b) => (b.daysSinceContact || 9999) - (a.daysSinceContact || 9999)));
});

// ---------- 重要日期 (比生日更通用：紀念日、對方特殊的日子，可以不綁定聯絡人) ----------
router.get('/important-dates', requireAuth, (req, res) => {
  const db = getDb();
  const rows = db
    .prepare(
      `SELECT d.*, r.name as relationship_name FROM important_dates d
       LEFT JOIN relationships r ON r.id = d.relationship_id
       WHERE d.user_id = ? ORDER BY d.month_day ASC`
    )
    .all(req.session.userId);
  res.json(rows);
});

router.post('/important-dates', requireAuth, (req, res) => {
  const { label, monthDay, relationshipId, note } = req.body || {};
  if (!label || !String(label).trim()) return res.status(400).json({ error: '請提供日期名稱' });
  if (!monthDay || !/^\d{2}-\d{2}$/.test(monthDay)) return res.status(400).json({ error: '日期請用 MM-DD 格式 (例如 03-15)' });
  const db = getDb();
  const now = new Date().toISOString();
  const result = db.prepare('INSERT INTO important_dates (user_id, relationship_id, label, month_day, note, created_at) VALUES (?, ?, ?, ?, ?, ?)').run(
    req.session.userId, relationshipId || null, String(label).trim(), monthDay, note || null, now
  );
  res.json({ id: result.lastInsertRowid, ok: true });
});

router.delete('/important-dates/:id', requireAuth, (req, res) => {
  const db = getDb();
  db.prepare('DELETE FROM important_dates WHERE id = ? AND user_id = ?').run(req.params.id, req.session.userId);
  res.json({ ok: true });
});

// 未來 30 天內的重要日期 (跟生日用同一套跨年邏輯)
router.get('/important-dates/upcoming', requireAuth, (req, res) => {
  const db = getDb();
  const rows = db
    .prepare(
      `SELECT d.*, r.name as relationship_name FROM important_dates d
       LEFT JOIN relationships r ON r.id = d.relationship_id
       WHERE d.user_id = ?`
    )
    .all(req.session.userId);
  const todayStr = new Date().toISOString().slice(0, 10);
  const todayUTC = new Date(todayStr + 'T00:00:00Z');
  const thisYear = todayUTC.getUTCFullYear();

  const withDays = rows.map((r) => {
    const [mm, dd] = r.month_day.split('-').map(Number);
    let next = new Date(Date.UTC(thisYear, mm - 1, dd));
    if (next < todayUTC) next = new Date(Date.UTC(thisYear + 1, mm - 1, dd));
    const daysUntil = Math.round((next - todayUTC) / (1000 * 60 * 60 * 24));
    return { ...r, daysUntil };
  });

  res.json(withDays.filter((r) => r.daysUntil <= 30).sort((a, b) => a.daysUntil - b.daysUntil));
});

module.exports = router;
