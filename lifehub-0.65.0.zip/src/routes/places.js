// 地點資料庫 + 「臨時揪一波」快速出遊建議 (v0.55)。
//
// 設計背景：使用者想要「出遊前臨時不知道去哪」時，選地區/氛圍/交通方式，立刻從資料庫
// 抓幾個地點組成建議路線，不滿意就換一批，全程是資料庫查詢，不即時呼叫 AI —— 原因見
// migrations/043_places.sql 開頭的說明：AI 即時生成的方案在額度/成本上撐不住，改用
// 「政府開放資料 + 使用者社群貢獻」的靜態資料庫，查詢免費、沒有次數限制。
//
// 這是全 App 第一個「公開」資料：任何登入的使用者都能看到全部地點、都能新增/評分，
// 不像願望清單/固定行程模板是限定跟已連結的家人共用。新增地點/評分會透過既有的點數
// 系統給獎勵，把「幫忙充實資料庫」變成使用者本來就有動機做的事。

const { Router } = require('../mini-http');
const { getDb } = require('../services/db');
const { requireAuth } = require('../middleware/auth');
const { awardPoints } = require('../services/points');

const router = Router();

// v0.60：新增「夜景」標籤——使用者反應原本 5 個心情分類還不夠，出遊氛圍常常還會想找
// 專門看夜景的地點，跟「拍照」不完全重疊 (拍照泛指任何好拍的景，夜景是專指晚上去的那種)。
const MOOD_TAGS = ['relax', 'food', 'outdoor', 'shopping', 'photo', 'night_view'];
const TRANSPORT_TAGS = ['walk', 'drive', 'bike'];
const REPORT_THRESHOLD = 3; // 累積到這個人數回報「疑似歇業/資訊有誤」，自動轉成待確認狀態

// v0.61：使用者反應 MOOD_TAGS 這種固定分類太粗、太少，希望打自己想的關鍵字就能直接改變
// 推薦內容，不要被侷限在預先分好的分類裡。這裡新增自由文字關鍵字搜尋——比對地點「名稱」
// 跟「介紹文字 (note，政府開放資料匯入時存了官方描述前 500 字，見
// scripts/import_gov_places.js)」，LIKE 子字串比對，不需要额外的全文索引或資料搬遷，
// 因為 note 欄位本來就存了足夠的描述文字可以比對。
// 這是跟 MOOD_TAGS 結構化篩選「並存」的兩套機制，不是取代關係：兩個都帶的話用 AND 合併
// (例如 主題=戶外 + 關鍵字=寵物 就是「戶外主題裡、名稱或介紹有提到寵物的地點」)。
function addKeywordClause(clauses, params, keyword) {
  const kw = String(keyword || '').trim();
  if (!kw) return;
  clauses.push('(name LIKE ? OR note LIKE ?)');
  params.push(`%${kw}%`, `%${kw}%`);
}

// v0.62：關鍵字比對到「名稱」還是只有「介紹文字」，代表命中的準確度差很多——名稱直接
// 是「XX老街」跟介紹文字裡隨口提一句附近有老街，後者常常讓人一頭霧水 (使用者才反應過
// 「打老街怎麼給我瀑布公園」)。所以有打關鍵字時，名稱命中的地點要排在前面，不能單純只
// 依評分排序，不然關鍵字篩選感覺不準、使用者會不信任這個功能。
function keywordMatchScore(place, keyword) {
  const kw = String(keyword || '').trim();
  if (!kw) return 0;
  return place.name && place.name.includes(kw) ? 1 : 0;
}

// 每一次帶了關鍵字的查詢都記一筆，之後 GET /places/popular-keywords 用這張表統計出「真的
// 常被搜尋的關鍵字」，取代/補充前端原本寫死的熱門關鍵字清單。故意用 try/catch 包起來、
// 失敗就默默放棄——記錄這件事本身不該讓查詢主流程壞掉，寧可少一筆統計資料，不要讓使用者
// 搜個地點還遇到錯誤。
function logKeywordSearch(db, keyword, userId) {
  const kw = String(keyword || '').trim();
  if (!kw) return;
  try {
    db.prepare('INSERT INTO place_keyword_searches (keyword, user_id, created_at) VALUES (?, ?, ?)')
      .run(kw, userId || null, new Date().toISOString());
  } catch (e) {
    // 忽略——見上面說明。
  }
}

function cleanTagList(raw, validSet) {
  const list = Array.isArray(raw) ? raw : String(raw || '').split(',');
  const cleaned = list.map((t) => String(t || '').trim()).filter((t) => validSet.includes(t));
  return cleaned.length ? `,${[...new Set(cleaned)].join(',')},` : '';
}

function tagsToArray(stored) {
  return String(stored || '')
    .split(',')
    .map((t) => t.trim())
    .filter(Boolean);
}

// 城市名稱正規化：使用者輸入「台北」「台北市」「臺北」「臺北市」在意義上是同一個城市，
// 但如果直接拿去做 SQL 精確比對 (city = ?)，四種寫法會被當成四個不同城市，新增/查詢/
// 「臨時揪一波」都會因為打法不同就查不到已經存在的資料——這正是使用者實際踩到的問題。
// 統一轉成「不帶市/縣後綴、臺一律轉台」的簡短寫法，新增時存這個正規化後的版本，查詢時
// 也一樣正規化再比對，兩邊才會對得上。跟 scripts/import_gov_places.js 的 normalizeCity
// 是同一套規則，之後政府資料匯入進來的城市名稱也會跟現有資料一致。
function normalizeCity(raw) {
  if (!raw) return '';
  let s = String(raw).trim();
  s = s.replace(/臺/g, '台');
  s = s.replace(/(市|縣)$/, '');
  return s;
}

// 幫一筆地點附上評分統計。評分數 < 3 筆的地點標示「評分還太少」，跟心情關聯分析那邊
// 已經用過的「至少 3 筆樣本才顯示」邏輯一致，避免一兩個人的評分就左右別人的判斷。
function withRatingStats(db, place) {
  const stats = db
    .prepare('SELECT COUNT(*) c, COALESCE(AVG(stars), 0) avg FROM place_ratings WHERE place_id = ?')
    .get(place.id);
  return {
    ...place,
    moodTags: tagsToArray(place.mood_tags),
    transportTags: tagsToArray(place.transport_tags),
    ratingCount: stats.c,
    avgRating: stats.c ? Math.round(stats.avg * 10) / 10 : null,
    ratingEnough: stats.c >= 3,
  };
}

router.get('/places', requireAuth, (req, res) => {
  const db = getDb();
  const { city, district, mood, transport, keyword, maxDuration, sort } = req.query || {};
  const clauses = ["status = 'active'"];
  const params = [];
  if (city) { clauses.push('city = ?'); params.push(normalizeCity(city)); }
  if (district) { clauses.push('district = ?'); params.push(district); }
  if (mood && MOOD_TAGS.includes(mood)) { clauses.push('mood_tags LIKE ?'); params.push(`%,${mood},%`); }
  if (transport && TRANSPORT_TAGS.includes(transport)) { clauses.push('transport_tags LIKE ?'); params.push(`%,${transport},%`); }
  addKeywordClause(clauses, params, keyword);
  if (maxDuration) { clauses.push('(visit_duration_min IS NULL OR visit_duration_min <= ?)'); params.push(Number(maxDuration)); }

  logKeywordSearch(db, keyword, req.session.userId);

  const rows = db.prepare(`SELECT * FROM places WHERE ${clauses.join(' AND ')} ORDER BY created_at DESC`).all(...params);
  let enriched = rows.map((p) => withRatingStats(db, p));
  if (sort === 'rating' || keyword) {
    enriched.sort((a, b) => {
      const km = keywordMatchScore(b, keyword) - keywordMatchScore(a, keyword);
      if (km !== 0) return km;
      if (sort === 'rating') return (b.avgRating || 0) - (a.avgRating || 0) || b.ratingCount - a.ratingCount;
      return 0; // 沒有指定排序、只有關鍵字時，維持 SQL 已經排好的 created_at DESC 順序 (穩定排序)
    });
  }
  res.json(enriched);
});

// 給前端做「城市下拉選單」用：只列出資料庫裡實際有資料、還在 active 狀態的城市，
// 使用者只能從真的查得到東西的城市裡選，不會再打錯字或打了資料庫裡沒有的寫法就撲空。
// 這個路由要放在 /places/:id 前面註冊，不然 mini-http 的路由是照註冊順序比對，
// "cities" 會先被 :id 那條規則吃掉，變成在找 id="cities" 的地點。
router.get('/places/cities', requireAuth, (req, res) => {
  const db = getDb();
  const rows = db.prepare(`SELECT city, COUNT(*) c FROM places WHERE status = 'active' GROUP BY city ORDER BY c DESC, city ASC`).all();
  res.json(rows.map((r) => ({ city: r.city, count: r.c })));
});

// v0.60：城市範圍太大 (例如新北市單一縣市就有 600 多筆地點) 時，光靠城市篩選還是不夠精準，
// 使用者要求能再往下篩到「區」。給前端做「區」下拉選單用，同樣只列出這個城市裡實際有資料
// 的區 (含筆數)，不用使用者自己打區名。district 是 NULL/空字串的地點 (地址判斷不出區的
// 資料) 不會出現在這份清單裡，但選「不限地區」時篩選條件本來就不會加 district，一樣找得到。
// 這個路由也要放在 /places/:id 前面註冊，理由跟上面的 /places/cities 一樣。
router.get('/places/districts', requireAuth, (req, res) => {
  const db = getDb();
  const city = normalizeCity(req.query.city);
  if (!city) return res.json([]);
  const rows = db
    .prepare(`SELECT district, COUNT(*) c FROM places WHERE status = 'active' AND city = ? AND district IS NOT NULL AND district != '' GROUP BY district ORDER BY c DESC, district ASC`)
    .all(city);
  res.json(rows.map((r) => ({ district: r.district, count: r.c })));
});

// v0.62：熱門關鍵字 chip 原本是前端寫死的固定清單，使用者反應希望改成「真的統計出來的」。
// 這裡從 place_keyword_searches (見 migrations/049) 統計出現次數最多的關鍵字，同一個關鍵字
// 出現次數越多分數越高；前端拿到這份清單後，會跟原本寫死的清單合併 (真實資料優先、寫死
// 清單補位)，剛上線資料還很少時畫面不會突然變得空空的。這裡也要放在 /places/:id 前面
// 註冊，理由跟 /places/cities、/places/districts 一樣 (mini-http 依註冊順序比對路由)。
router.get('/places/popular-keywords', requireAuth, (req, res) => {
  const db = getDb();
  const rows = db
    .prepare('SELECT keyword, COUNT(*) c FROM place_keyword_searches GROUP BY keyword ORDER BY c DESC, keyword ASC LIMIT 10')
    .all();
  res.json(rows.map((r) => ({ keyword: r.keyword, count: r.c })));
});

router.get('/places/:id', requireAuth, (req, res) => {
  const db = getDb();
  const place = db.prepare('SELECT * FROM places WHERE id = ?').get(req.params.id);
  if (!place) return res.status(404).json({ error: '找不到這個地點' });
  const ratings = db
    .prepare(
      `SELECT r.stars, r.note, r.created_at, u.name as user_name FROM place_ratings r
       JOIN users u ON u.id = r.user_id WHERE r.place_id = ? ORDER BY r.created_at DESC LIMIT 20`
    )
    .all(place.id);
  const myRating = db.prepare('SELECT stars, note FROM place_ratings WHERE place_id = ? AND user_id = ?').get(place.id, req.session.userId);
  const reportCount = db.prepare('SELECT COUNT(*) c FROM place_reports WHERE place_id = ?').get(place.id).c;
  res.json({ ...withRatingStats(db, place), ratings, myRating: myRating || null, reportCount });
});

router.post('/places', requireAuth, (req, res) => {
  const { name, city, district, address, moodTags, transportTags, hoursText, feeInfo, visitDurationMin, note } = req.body || {};
  const trimmedName = String(name || '').trim();
  const trimmedCity = normalizeCity(city);
  if (!trimmedName) return res.status(400).json({ error: '請輸入地點名稱' });
  if (!trimmedCity) return res.status(400).json({ error: '請輸入城市' });

  let duration = null;
  if (visitDurationMin !== undefined && visitDurationMin !== null && String(visitDurationMin).trim() !== '') {
    const n = Number(visitDurationMin);
    if (!Number.isFinite(n) || n < 0) return res.status(400).json({ error: '預估停留時間格式不正確' });
    duration = Math.round(n);
  }

  const db = getDb();
  const now = new Date().toISOString();
  const result = db
    .prepare(
      `INSERT INTO places (name, city, district, address, mood_tags, transport_tags, hours_text, fee_info, visit_duration_min, note, source, status, created_by_user_id, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'user', 'active', ?, ?, ?)`
    )
    .run(
      trimmedName,
      trimmedCity,
      (district && String(district).trim()) || null,
      (address && String(address).trim()) || null,
      cleanTagList(moodTags, MOOD_TAGS),
      cleanTagList(transportTags, TRANSPORT_TAGS),
      (hoursText && String(hoursText).trim()) || null,
      (feeInfo && String(feeInfo).trim()) || null,
      duration,
      (note && String(note).trim()) || null,
      req.session.userId,
      now,
      now
    );
  awardPoints(db, req.session.userId, 3, `add_place:${result.lastInsertRowid}`);
  const created = db.prepare('SELECT * FROM places WHERE id = ?').get(result.lastInsertRowid);
  res.json(withRatingStats(db, created));
});

router.put('/places/:id', requireAuth, (req, res) => {
  const db = getDb();
  const place = db.prepare('SELECT * FROM places WHERE id = ?').get(req.params.id);
  if (!place) return res.status(404).json({ error: '找不到這個地點' });
  if (place.created_by_user_id !== req.session.userId) return res.status(403).json({ error: '只有新增這個地點的人可以編輯' });

  const { name, district, address, moodTags, transportTags, hoursText, feeInfo, visitDurationMin, note } = req.body || {};
  const trimmedName = name != null ? String(name).trim() : place.name;
  if (!trimmedName) return res.status(400).json({ error: '請輸入地點名稱' });

  let duration = place.visit_duration_min;
  if (visitDurationMin !== undefined) {
    if (visitDurationMin === null || String(visitDurationMin).trim() === '') {
      duration = null;
    } else {
      const n = Number(visitDurationMin);
      if (!Number.isFinite(n) || n < 0) return res.status(400).json({ error: '預估停留時間格式不正確' });
      duration = Math.round(n);
    }
  }

  db.prepare(
    `UPDATE places SET name = ?, district = ?, address = ?, mood_tags = ?, transport_tags = ?, hours_text = ?, fee_info = ?, visit_duration_min = ?, note = ?, updated_at = ? WHERE id = ?`
  ).run(
    trimmedName,
    district !== undefined ? ((district && String(district).trim()) || null) : place.district,
    address !== undefined ? ((address && String(address).trim()) || null) : place.address,
    moodTags !== undefined ? cleanTagList(moodTags, MOOD_TAGS) : place.mood_tags,
    transportTags !== undefined ? cleanTagList(transportTags, TRANSPORT_TAGS) : place.transport_tags,
    hoursText !== undefined ? ((hoursText && String(hoursText).trim()) || null) : place.hours_text,
    feeInfo !== undefined ? ((feeInfo && String(feeInfo).trim()) || null) : place.fee_info,
    duration,
    note !== undefined ? ((note && String(note).trim()) || null) : place.note,
    new Date().toISOString(),
    place.id
  );
  const updated = db.prepare('SELECT * FROM places WHERE id = ?').get(place.id);
  res.json(withRatingStats(db, updated));
});

router.delete('/places/:id', requireAuth, (req, res) => {
  const db = getDb();
  const place = db.prepare('SELECT * FROM places WHERE id = ?').get(req.params.id);
  if (!place) return res.status(404).json({ error: '找不到這個地點' });
  if (place.created_by_user_id !== req.session.userId) return res.status(403).json({ error: '只有新增這個地點的人可以刪除' });
  db.prepare('DELETE FROM places WHERE id = ?').run(place.id);
  res.json({ ok: true });
});

// 評分：一人一地點一筆，重新評分是覆蓋，不是疊加。只有「第一次」評這個地點才加點數，
// 避免使用者一直改評分刷點數。
router.post('/places/:id/rate', requireAuth, (req, res) => {
  const db = getDb();
  const place = db.prepare('SELECT * FROM places WHERE id = ?').get(req.params.id);
  if (!place) return res.status(404).json({ error: '找不到這個地點' });
  const stars = Number((req.body || {}).stars);
  if (!Number.isInteger(stars) || stars < 1 || stars > 5) return res.status(400).json({ error: '星等要是 1-5 的整數' });
  const note = (req.body && req.body.note) || null;

  const db2 = db;
  const existing = db2.prepare('SELECT id FROM place_ratings WHERE place_id = ? AND user_id = ?').get(place.id, req.session.userId);
  const now = new Date().toISOString();
  if (existing) {
    db2.prepare('UPDATE place_ratings SET stars = ?, note = ?, updated_at = ? WHERE id = ?').run(stars, note, now, existing.id);
  } else {
    db2.prepare('INSERT INTO place_ratings (place_id, user_id, stars, note, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)').run(
      place.id, req.session.userId, stars, note, now, now
    );
    awardPoints(db2, req.session.userId, 1, `rate_place:${place.id}`);
  }
  res.json(withRatingStats(db2, db2.prepare('SELECT * FROM places WHERE id = ?').get(place.id)));
});

router.delete('/places/:id/rate', requireAuth, (req, res) => {
  const db = getDb();
  db.prepare('DELETE FROM place_ratings WHERE place_id = ? AND user_id = ?').run(req.params.id, req.session.userId);
  res.json({ ok: true });
});

// 回報「疑似歇業/資訊有誤」：一人一地點限一筆，累積到門檻自動轉成待確認狀態，
// 從「臨時揪一波」的建議結果中排除 (但地點本身沒有被刪除，詳細頁還是看得到，並標示提醒)。
router.post('/places/:id/report', requireAuth, (req, res) => {
  const db = getDb();
  const place = db.prepare('SELECT * FROM places WHERE id = ?').get(req.params.id);
  if (!place) return res.status(404).json({ error: '找不到這個地點' });
  const existing = db.prepare('SELECT id FROM place_reports WHERE place_id = ? AND user_id = ?').get(place.id, req.session.userId);
  if (existing) return res.status(400).json({ error: '你已經回報過這個地點了' });

  const reason = (req.body && req.body.reason) || null;
  db.prepare('INSERT INTO place_reports (place_id, user_id, reason, created_at) VALUES (?, ?, ?, ?)').run(
    place.id, req.session.userId, reason, new Date().toISOString()
  );
  const reportCount = db.prepare('SELECT COUNT(*) c FROM place_reports WHERE place_id = ?').get(place.id).c;
  if (reportCount >= REPORT_THRESHOLD && place.status === 'active') {
    db.prepare("UPDATE places SET status = 'needs_review', updated_at = ? WHERE id = ?").run(new Date().toISOString(), place.id);
  }
  res.json({ ok: true, reportCount });
});

// 「臨時揪一波」：依地區/氛圍/交通方式篩選，從排名前段的候選裡隨機挑幾個組成建議路線。
// exclude 可以帶上次已經看過的地點 id (逗號分隔)，重抽時盡量不要一直給同樣的組合；
// 候選不夠時才會允許重複，不會直接回傳空結果讓使用者卡住。
router.get('/places/suggest/route', requireAuth, (req, res) => {
  const db = getDb();
  const { city, district, mood, transport, keyword, maxDuration, count, exclude } = req.query || {};
  if (!city) return res.status(400).json({ error: '請提供 city' });
  const normalizedCity = normalizeCity(city);

  const clauses = ["status = 'active'", 'city = ?'];
  const params = [normalizedCity];
  if (district) { clauses.push('district = ?'); params.push(district); }
  if (mood && MOOD_TAGS.includes(mood)) { clauses.push('mood_tags LIKE ?'); params.push(`%,${mood},%`); }
  if (transport && TRANSPORT_TAGS.includes(transport)) { clauses.push('transport_tags LIKE ?'); params.push(`%,${transport},%`); }
  addKeywordClause(clauses, params, keyword);
  if (maxDuration) { clauses.push('(visit_duration_min IS NULL OR visit_duration_min <= ?)'); params.push(Number(maxDuration)); }

  logKeywordSearch(db, keyword, req.session.userId);

  const rows = db.prepare(`SELECT * FROM places WHERE ${clauses.join(' AND ')}`).all(...params);
  const enriched = rows
    .map((p) => withRatingStats(db, p))
    // 有打關鍵字時，名稱直接命中的地點要排到評分排序前面 (理由見 keywordMatchScore 說明)，
    // 不然「幫我選 3 個」隨機抽的候選池 (下面的 topPool) 可能全是只有介紹文字提到關鍵字、
    // 名稱完全無關的地點，使用者會覺得抽到的東西跟自己打的關鍵字對不太起來。
    .sort((a, b) => {
      const km = keywordMatchScore(b, keyword) - keywordMatchScore(a, keyword);
      if (km !== 0) return km;
      return (b.avgRating || 0) - (a.avgRating || 0) || b.ratingCount - a.ratingCount;
    });

  const topPool = enriched.slice(0, 12); // 只從排名前段抽，避免抽到評分墊底的地點
  const excludeIds = new Set(String(exclude || '').split(',').map((s) => Number(s)).filter(Boolean));
  let candidates = topPool.filter((p) => !excludeIds.has(p.id));
  if (!candidates.length) candidates = topPool; // 候選被排除光了就重置，不要回傳空結果

  // Fisher-Yates 洗牌，從候選裡隨機挑幾個，讓「重抽」每次感覺不一樣，不是死板地永遠回同一批。
  const shuffled = [...candidates];
  for (let i = shuffled.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  const wantCount = Math.max(1, Math.min(6, Number(count) || 3));
  res.json({ route: shuffled.slice(0, wantCount), totalCandidates: enriched.length });
});

module.exports = router;
